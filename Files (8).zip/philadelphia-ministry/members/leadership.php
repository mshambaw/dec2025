<?php
// leadership.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leadership - Philadelphia Ministry</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .leadership-section { background: white; padding: 2rem; border-radius: 15px; margin: 20px 0; }
        .year-leadership { margin: 30px 0; }
        .year-title { background: #2c3e50; color: white; padding: 10px 20px; border-radius: 5px; }
        .leaders-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 15px; margin-top: 15px; }
        .leader-card { background: #f8f9fa; padding: 15px; border-radius: 10px; border-left: 4px solid #3498db; }
        .position { color: #666; font-size: 0.9rem; }
        .leader-name { font-weight: bold; color: #2c3e50; }
    </style>
</head>
<body>
    <div class="container">
        <div class="leadership-section">
            <h1><i class="fas fa-user-tie"></i> Ministry Leadership</h1>
            <p>Leadership structure from 2021 to 2026</p>
            
            <!-- 2025/2026 -->
            <div class="year-leadership">
                <div class="year-title">YEAR 2025/2026</div>
                <div class="leaders-grid">
                    <div class="leader-card">
                        <div class="position">Chair</div>
                        <div class="leader-name">Peter Lukoye</div>
                    </div>
                    <div class="leader-card">
                        <div class="position">Assistant Chair</div>
                        <div class="leader-name">Tonny Blair</div>
                    </div>
                    <!-- Add all other positions -->
                </div>
            </div>
            
            <!-- 2024/2025 -->
            <div class="year-leadership">
                <div class="year-title">YEAR 2024/2025</div>
                <div class="leaders-grid">
                    <div class="leader-card">
                        <div class="position">Chair</div>
                        <div class="leader-name">Amiri Mansel</div>
                    </div>
                    <!-- Add all positions -->
                </div>
            </div>
        </div>
    </div>
</body>
</html>