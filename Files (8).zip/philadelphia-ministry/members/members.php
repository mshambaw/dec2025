<?php
// members.php - Members Directory
session_start();
require_once 'config/database.php';

$db = new Database();
$conn = $db->getConnection();

// Get all members
$stmt = $conn->query("SELECT * FROM members WHERE is_active = 1 ORDER BY year_group, full_name");
$members = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Members Directory - Philadelphia Ministry</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        header { background: white; padding: 2rem; border-radius: 15px; margin-bottom: 2rem; text-align: center; }
        .members-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }
        .member-card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .member-name { font-size: 1.2rem; font-weight: bold; color: #2c3e50; }
        .year-badge { background: #3498db; color: white; padding: 3px 10px; border-radius: 15px; font-size: 0.8rem; display: inline-block; margin: 5px 0; }
        .search-box { background: white; padding: 20px; border-radius: 10px; margin-bottom: 20px; }
        .search-box input { width: 100%; padding: 10px; border: 2px solid #ddd; border-radius: 5px; }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <h1><i class="fas fa-users"></i> Members Directory</h1>
            <p>Philadelphia Ministry Members</p>
        </header>
        
        <div class="search-box">
            <input type="text" id="search" placeholder="Search members by name, phone, or year group...">
        </div>
        
        <div class="members-grid" id="members-container">
            <?php foreach($members as $member): ?>
            <div class="member-card">
                <div class="member-name"><?php echo htmlspecialchars($member['full_name']); ?></div>
                <div class="year-badge"><?php echo $member['year_group']; ?></div>
                <div style="margin: 10px 0;">
                    <div><i class="fas fa-phone"></i> <?php echo htmlspecialchars($member['phone']); ?></div>
                    <div><i class="fas fa-venus-mars"></i> <?php echo $member['gender']; ?></div>
                    <?php if($member['residence']): ?>
                    <div><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($member['residence']); ?></div>
                    <?php endif; ?>
                </div>
                <div style="font-size: 0.8rem; color: #666;">
                    Member since: <?php echo date('M Y', strtotime($member['date_joined'])); ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <script>
        // Search functionality
        document.getElementById('search').addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const members = document.querySelectorAll('.member-card');
            
            members.forEach(member => {
                const text = member.textContent.toLowerCase();
                if(text.includes(searchTerm)) {
                    member.style.display = 'block';
                } else {
                    member.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>