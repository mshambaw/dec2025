<?php
require_once '../../includes/header.php';
require_once '../../includes/db_connect.php';
require_once '../includes/remedies-functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../members/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    exit();
}

$userId = $_SESSION['user_id'];
$userName = $_SESSION['full_name'] ?? 'Patient';

// Get upcoming appointments
$appointmentsQuery = "SELECT b.*, t.name as treatment_name, t.duration_minutes, 
                      p.full_name as practitioner_name 
                      FROM remedies_bookings b
                      JOIN remedies_treatments t ON b.treatment_id = t.id
                      LEFT JOIN remedies_practitioners p ON b.practitioner_id = p.id
                      WHERE b.patient_id = ? AND b.booking_date >= CURDATE() 
                      AND b.status IN ('confirmed', 'pending')
                      ORDER BY b.booking_date ASC, b.booking_time ASC
                      LIMIT 5";
$stmt = $conn->prepare($appointmentsQuery);
$stmt->bind_param("i", $userId);
$stmt->execute();
$appointmentsResult = $stmt->get_result();

// Get recent consultations
$consultationsQuery = "SELECT * FROM remedies_consultations 
                       WHERE patient_id = ? 
                       ORDER BY consultation_date DESC 
                       LIMIT 5";
$stmt = $conn->prepare($consultationsQuery);
$stmt->bind_param("i", $userId);
$stmt->execute();
$consultationsResult = $stmt->get_result();

// Get prescription count
$prescriptionsQuery = "SELECT COUNT(*) as count FROM remedies_prescriptions WHERE patient_id = ?";
$stmt = $conn->prepare($prescriptionsQuery);
$stmt->bind_param("i", $userId);
$stmt->execute();
$prescriptionsResult = $stmt->get_result();
$prescriptionCount = $prescriptionsResult->fetch_assoc()['count'];

// Get medical records count
$recordsQuery = "SELECT COUNT(*) as count FROM remedies_patient_records WHERE patient_id = ?";
$stmt = $conn->prepare($recordsQuery);
$stmt->bind_param("i", $userId);
$stmt->execute();
$recordsResult = $stmt->get_result();
$recordsCount = $recordsResult->fetch_assoc()['count'];
?>

<div class="main-banner patient-banner" id="top">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="header-text">
                    <h2>Patient Portal</h2>
                    <p>Welcome back, <?php echo htmlspecialchars($userName); ?>!</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Stats -->
<section class="patient-stats section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <a href="my-appointments.php" class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <div class="stat-content">
                        <h3>
                            <?php 
                            $upcomingCountQuery = "SELECT COUNT(*) as count FROM remedies_bookings 
                                                   WHERE patient_id = ? AND booking_date >= CURDATE() 
                                                   AND status IN ('confirmed', 'pending')";
                            $stmt = $conn->prepare($upcomingCountQuery);
                            $stmt->bind_param("i", $userId);
                            $stmt->execute();
                            $upcomingCountResult = $stmt->get_result();
                            $upcomingCount = $upcomingCountResult->fetch_assoc()['count'];
                            echo $upcomingCount;
                            ?>
                        </h3>
                        <p>Upcoming Appointments</p>
                    </div>
                </a>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <a href="medical-records.php" class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-file-medical"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo $recordsCount; ?></h3>
                        <p>Medical Records</p>
                    </div>
                </a>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <a href="prescriptions.php" class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-prescription"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo $prescriptionCount; ?></h3>
                        <p>Prescriptions</p>
                    </div>
                </a>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <a href="messages.php" class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <div class="stat-content">
                        <h3>
                            <?php 
                            $unreadQuery = "SELECT COUNT(*) as count FROM remedies_messages 
                                            WHERE patient_id = ? AND is_read = 0";
                            $stmt = $conn->prepare($unreadQuery);
                            $stmt->bind_param("i", $userId);
                            $stmt->execute();
                            $unreadResult = $stmt->get_result();
                            $unreadCount = $unreadResult->fetch_assoc()['count'];
                            echo $unreadCount;
                            ?>
                        </h3>
                        <p>Unread Messages</p>
                    </div>
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Dashboard Content -->
<section class="patient-dashboard section-padding">
    <div class="container">
        <div class="row">
            <!-- Left Column: Upcoming Appointments -->
            <div class="col-lg-6">
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3><i class="fas fa-calendar-alt"></i> Upcoming Appointments</h3>
                        <a href="../treatments/book-treatment.php" class="btn btn-primary btn-sm">
                            <i class="fas fa-plus"></i> Book New
                        </a>
                    </div>
                    <div class="card-body">
                        <?php if($appointmentsResult->num_rows > 0): ?>
                            <div class="appointments-list">
                                <?php while($appointment = $appointmentsResult->fetch_assoc()): ?>
                                <div class="appointment-item">
                                    <div class="appointment-date">
                                        <span class="day"><?php echo date('d', strtotime($appointment['booking_date'])); ?></span>
                                        <span class="month"><?php echo date('M', strtotime($appointment['booking_date'])); ?></span>
                                    </div>
                                    <div class="appointment-details">
                                        <h4><?php echo htmlspecialchars($appointment['treatment_name']); ?></h4>
                                        <p class="appointment-time">
                                            <i class="far fa-clock"></i> 
                                            <?php echo date('h:i A', strtotime($appointment['booking_time'])); ?>
                                            (<?php echo $appointment['duration_minutes']; ?> mins)
                                        </p>
                                        <?php if($appointment['practitioner_name']): ?>
                                        <p class="appointment-practitioner">
                                            <i class="fas fa-user-md"></i> <?php echo $appointment['practitioner_name']; ?>
                                        </p>
                                        <?php endif; ?>
                                        <span class="appointment-status status-<?php echo $appointment['status']; ?>">
                                            <?php echo ucfirst($appointment['status']); ?>
                                        </span>
                                    </div>
                                    <div class="appointment-actions">
                                        <a href="appointment-details.php?id=<?php echo $appointment['id']; ?>" 
                                           class="btn btn-outline-primary btn-sm">View</a>
                                        <a href="../treatments/process/cancel-booking.php?id=<?php echo $appointment['id']; ?>" 
                                           class="btn btn-outline-danger btn-sm">Cancel</a>
                                    </div>
                                </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-calendar-times"></i>
                                <p>No upcoming appointments</p>
                                <a href="../treatments/book-treatment.php" class="btn btn-primary">Book Appointment</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="dashboard-card mt-4">
                    <div class="card-header">
                        <h3><i class="fas fa-bolt"></i> Quick Actions</h3>
                    </div>
                    <div class="card-body">
                        <div class="quick-actions-grid">
                            <a href="../treatments/book-treatment.php" class="action-item">
                                <i class="fas fa-calendar-plus"></i>
                                <span>Book Appointment</span>
                            </a>
                            <a href="../consultations/book-consultation.php" class="action-item">
                                <i class="fas fa-stethoscope"></i>
                                <span>Book Consultation</span>
                            </a>
                            <a href="medical-records.php" class="action-item">
                                <i class="fas fa-file-medical-alt"></i>
                                <span>View Records</span>
                            </a>
                            <a href="prescriptions.php" class="action-item">
                                <i class="fas fa-prescription-bottle-alt"></i>
                                <span>Prescriptions</span>
                            </a>
                            <a href="lab-results.php" class="action-item">
                                <i class="fas fa-flask"></i>
                                <span>Lab Results</span>
                            </a>
                            <a href="messages.php" class="action-item">
                                <i class="fas fa-comment-medical"></i>
                                <span>Messages</span>
                            </a>
                            <a href="health-tracker.php" class="action-item">
                                <i class="fas fa-heartbeat"></i>
                                <span>Health Tracker</span>
                            </a>
                            <a href="billing.php" class="action-item">
                                <i class="fas fa-receipt"></i>
                                <span>Billing</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Right Column: Recent Activity -->
            <div class="col-lg-6">
                <!-- Recent Consultations -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3><i class="fas fa-comments-medical"></i> Recent Consultations</h3>
                        <a href="my-consultations.php" class="btn btn-outline-primary btn-sm">View All</a>
                    </div>
                    <div class="card-body">
                        <?php if($consultationsResult->num_rows > 0): ?>
                            <div class="consultations-list">
                                <?php while($consultation = $consultationsResult->fetch_assoc()): ?>
                                <div class="consultation-item">
                                    <div class="consultation-date">
                                        <?php echo date('M j', strtotime($consultation['consultation_date'])); ?>
                                    </div>
                                    <div class="consultation-details">
                                        <h4><?php echo ucfirst($consultation['type']); ?> Consultation</h4>
                                        <?php if($consultation['chief_complaint']): ?>
                                        <p class="consultation-complaint">
                                            <?php echo truncateText($consultation['chief_complaint'], 80); ?>
                                        </p>
                                        <?php endif; ?>
                                        <span class="consultation-status status-<?php echo $consultation['status']; ?>">
                                            <?php echo ucfirst($consultation['status']); ?>
                                        </span>
                                    </div>
                                    <div class="consultation-actions">
                                        <a href="consultation-details.php?id=<?php echo $consultation['id']; ?>" 
                                           class="btn btn-outline-primary btn-sm">View</a>
                                    </div>
                                </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-comment-slash"></i>
                                <p>No consultation history</p>
                                <a href="../consultations/book-consultation.php" class="btn btn-primary">Book Consultation</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Health Summary -->
                <div class="dashboard-card mt-4">
                    <div class="card-header">
                        <h3><i class="fas fa-chart-line"></i> Health Summary</h3>
                        <a href="health-tracker.php" class="btn btn-outline-primary btn-sm">Track Health</a>
                    </div>
                    <div class="card-body">
                        <div class="health-metrics">
                            <div class="metric-item">
                                <div class="metric-label">Last Blood Pressure</div>
                                <div class="metric-value">120/80</div>
                                <div class="metric-status normal">Normal</div>
                            </div>
                            <div class="metric-item">
                                <div class="metric-label">Last Weight</div>
                                <div class="metric-value">75 kg</div>
                                <div class="metric-status good">Good</div>
                            </div>
                            <div class="metric-item">
                                <div class="metric-label">Medication Adherence</div>
                                <div class="metric-value">95%</div>
                                <div class="metric-status excellent">Excellent</div>
                            </div>
                            <div class="metric-item">
                                <div class="metric-label">Next Follow-up</div>
                                <div class="metric-value"><?php echo date('M j', strtotime('+30 days')); ?></div>
                                <div class="metric-status upcoming">Upcoming</div>
                            </div>
                        </div>
                        
                        <div class="health-tips">
                            <h5><i class="fas fa-lightbulb"></i> Health Tip of the Day</h5>
                            <p>Drink at least 8 glasses of water daily to support detoxification and overall health.</p>
                        </div>
                    </div>
                </div>
                
                <!-- Messages -->
                <div class="dashboard-card mt-4">
                    <div class="card-header">
                        <h3><i class="fas fa-envelope"></i> Recent Messages</h3>
                        <a href="messages.php" class="btn btn-outline-primary btn-sm">View All</a>
                    </div>
                    <div class="card-body">
                        <div class="messages-list">
                            <div class="message-item unread">
                                <div class="message-sender">
                                    <strong>Dr. Jane Smith</strong>
                                    <span class="message-time">2 hours ago</span>
                                </div>
                                <div class="message-preview">
                                    Your lab results are ready. Please check your medical records.
                                </div>
                            </div>
                            <div class="message-item">
                                <div class="message-sender">
                                    <strong>Pharmacy</strong>
                                    <span class="message-time">1 day ago</span>
                                </div>
                                <div class="message-preview">
                                    Your prescription refill is ready for pickup.
                                </div>
                            </div>
                            <div class="message-item">
                                <div class="message-sender">
                                    <strong>Billing Department</strong>
                                    <span class="message-time">3 days ago</span>
                                </div>
                                <div class="message-preview">
                                    Your invoice for the recent consultation is available.
                                </div>
                            </div>
                        </div>
                        <a href="compose-message.php" class="btn btn-primary btn-block mt-3">
                            <i class="fas fa-pen"></i> Compose New Message
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Emergency Contacts -->
<section class="emergency-contacts section-padding bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h3><i class="fas fa-phone-alt"></i> Emergency Contacts</h3>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="contact-card">
                    <i class="fas fa-ambulance"></i>
                    <h4>Emergency Services</h4>
                    <p class="contact-number">999</p>
                    <p>National Emergency Line</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="contact-card">
                    <i class="fas fa-hospital"></i>
                    <h4>Our Clinic</h4>
                    <p class="contact-number">+254712345678</p>
                    <p>Available 24/7 for emergencies</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="contact-card">
                    <i class="fas fa-user-md"></i>
                    <h4>Your Practitioner</h4>
                    <p class="contact-number">+254712345679</p>
                    <p>For urgent medical concerns</p>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
.patient-banner {
    background: linear-gradient(135deg, #3498db, #2980b9);
    color: white;
    height: 40vh;
}

.patient-banner .header-text h2 {
    color: white;
}

.patient-banner .header-text p {
    font-size: 1.2rem;
    opacity: 0.9;
}

.patient-stats .stat-card {
    display: flex;
    align-items: center;
    background: white;
    border-radius: 10px;
    padding: 20px;
    text-decoration: none;
    color: inherit;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    transition: transform 0.3s ease;
    height: 100%;
    margin-bottom: 30px;
}

.patient-stats .stat-card:hover {
    transform: translateY(-5px);
    color: inherit;
}

.stat-icon {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, #3498db, #2980b9);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 20px;
}

.stat-icon i {
    font-size: 1.8rem;
    color: white;
}

.stat-content h3 {
    color: #2c3e50;
    margin-bottom: 5px;
    font-size: 2rem;
}

.stat-content p {
    color: #7f8c8d;
    margin: 0;
    font-size: 0.95rem;
}

.dashboard-card {
    background: white;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    margin-bottom: 30px;
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px;
    border-bottom: 1px solid #eee;
}

.card-header h3 {
    color: #2c3e50;
    margin: 0;
    font-size: 1.3rem;
}

.card-header h3 i {
    color: #3498db;
    margin-right: 10px;
}

.card-body {
    padding: 20px;
}

.appointments-list, .consultations-list, .messages-list {
    max-height: 400px;
    overflow-y: auto;
}

.appointment-item, .consultation-item, .message-item {
    display: flex;
    align-items: center;
    padding: 15px;
    border-bottom: 1px solid #eee;
}

.appointment-item:last-child, .consultation-item:last-child, .message-item:last-child {
    border-bottom: none;
}

.appointment-date, .consultation-date {
    flex-shrink: 0;
    width: 60px;
    text-align: center;
    margin-right: 15px;
}

.appointment-date .day {
    display: block;
    font-size: 1.5rem;
    font-weight: 700;
    color: #3498db;
}

.appointment-date .month {
    display: block;
    font-size: 0.9rem;
    color: #7f8c8d;
}

.consultation-date {
    background: #f8f9fa;
    padding: 8px 12px;
    border-radius: 5px;
    color: #5d6d7e;
    font-weight: 600;
}

.appointment-details, .consultation-details {
    flex-grow: 1;
    margin-right: 15px;
}

.appointment-details h4, .consultation-details h4 {
    color: #2c3e50;
    margin-bottom: 5px;
    font-size: 1.1rem;
}

.appointment-time, .appointment-practitioner, .consultation-complaint {
    color: #7f8c8d;
    font-size: 0.9rem;
    margin-bottom: 5px;
}

.appointment-time i, .appointment-practitioner i {
    margin-right: 5px;
    color: #3498db;
}

.appointment-status, .consultation-status {
    padding: 3px 10px;
    border-radius: 50px;
    font-size: 0.8rem;
    font-weight: 600;
}

.status-pending, .status-scheduled {
    background: #fff3cd;
    color: #856404;
}

.status-confirmed {
    background: #d1ecf1;
    color: #0c5460;
}

.status-completed {
    background: #d4edda;
    color: #155724;
}

.status-cancelled {
    background: #f8d7da;
    color: #721c24;
}

.appointment-actions, .consultation-actions {
    flex-shrink: 0;
}

.empty-state {
    text-align: center;
    padding: 40px 20px;
    color: #95a5a6;
}

.empty-state i {
    font-size: 3rem;
    margin-bottom: 20px;
    color: #bdc3c7;
}

.empty-state p {
    margin-bottom: 20px;
    font-size: 1.1rem;
}

.quick-actions-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.action-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 15px 10px;
    background: #f8f9fa;
    border-radius: 8px;
    text-decoration: none;
    color: inherit;
    transition: all 0.3s ease;
}

.action-item:hover {
    background: #3498db;
    color: white;
    transform: translateY(-2px);
}

.action-item i {
    font-size: 1.5rem;
    margin-bottom: 10px;
}

.action-item span {
    font-size: 0.85rem;
    text-align: center;
    font-weight: 500;
}

.health-metrics {
    margin-bottom: 25px;
}

.metric-item {
    display: flex;
    align-items: center;
    padding: 12px 0;
    border-bottom: 1px solid #eee;
}

.metric-item:last-child {
    border-bottom: none;
}

.metric-label {
    flex: 2;
    color: #5d6d7e;
    font-size: 0.95rem;
}

.metric-value {
    flex: 1;
    color: #2c3e50;
    font-weight: 600;
    font-size: 1.1rem;
    text-align: center;
}

.metric-status {
    flex: 1;
    padding: 5px 10px;
    border-radius: 50px;
    font-size: 0.8rem;
    font-weight: 600;
    text-align: center;
}

.metric-status.normal {
    background: #d4edda;
    color: #155724;
}

.metric-status.good {
    background: #d1ecf1;
    color: #0c5460;
}

.metric-status.excellent {
    background: #c3e6cb;
    color: #155724;
}

.metric-status.upcoming {
    background: #fff3cd;
    color: #856404;
}

.health-tips {
    background: #e8f4fc;
    padding: 15px;
    border-radius: 8px;
    border-left: 4px solid #3498db;
}

.health-tips h5 {
    color: #2c3e50;
    margin-bottom: 10px;
    font-size: 1.1rem;
}

.health-tips h5 i {
    color: #3498db;
    margin-right: 10px;
}

.health-tips p {
    color: #5d6d7e;
    margin: 0;
    font-size: 0.95rem;
}

.message-item {
    padding: 12px 0;
}

.message-item.unread {
    background: #e8f4fc;
    margin: -12px 0;
    padding: 12px;
    border-radius: 5px;
}

.message-sender {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 5px;
}

.message-sender strong {
    color: #2c3e50;
    font-size: 0.95rem;
}

.message-time {
    color: #95a5a6;
    font-size: 0.85rem;
}

.message-preview {
    color: #7f8c8d;
    font-size: 0.9rem;
}

.contact-card {
    text-align: center;
    padding: 30px 20px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    margin-bottom: 30px;
    transition: transform 0.3s ease;
}

.contact-card:hover {
    transform: translateY(-5px);
}

.contact-card i {
    font-size: 2.5rem;
    color: #e74c3c;
    margin-bottom: 20px;
}

.contact-card h4 {
    color: #2c3e50;
    margin-bottom: 10px;
    font-size: 1.3rem;
}

.contact-number {
    font-size: 1.8rem;
    color: #e74c3c;
    font-weight: 700;
    margin-bottom: 10px;
}

.contact-card p {
    color: #7f8c8d;
    margin: 0;
}
</style>

<script>
$(document).ready(function() {
    // Auto refresh appointments every 5 minutes
    setInterval(function() {
        $.ajax({
            url: '../api/patient-api.php',
            type: 'GET',
            data: { action: 'refresh_appointments' },
            success: function(response) {
                // Update appointment list if needed
            }
        });
    }, 300000);
});
</script>

<?php require_once '../../includes/footer.php'; ?>