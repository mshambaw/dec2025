<?php
// ============================================
// REMEDIES DEPARTMENT - INDEX PAGE
// ============================================

// ERROR HANDLING
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// PATHS & SESSIONS
define('BASE_PATH', dirname(__DIR__) . '/');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// DATABASE CONNECTION
function getDB() {
    static $conn = null;
    
    if ($conn === null) {
        try {
            $conn = new mysqli('localhost', 'root', '', 'philadelphia_ministry');
            
            if ($conn->connect_error) {
                error_log("Database connection failed: " . $conn->connect_error);
                return null;
            }
            
            $conn->set_charset("utf8mb4");
        } catch (Exception $e) {
            error_log("Database exception: " . $e->getMessage());
            return null;
        }
    }
    
    return $conn;
}

// ============================================
// TEMPLATE FUNCTIONS
// ============================================

function showHeader() {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Philadelphia Ministry - Remedies Department</title>
        
        <!-- Bootstrap 5 CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        
        <!-- Font Awesome 6 -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
        
        <!-- Custom Styles -->
        <style>
            :root {
                --primary-color: #3498db;
                --secondary-color: #2980b9;
                --accent-color: #2c3e50;
                --light-bg: #f8f9fa;
                --card-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
                --transition-speed: 0.3s;
            }
            
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background-color: var(--light-bg);
                color: #333;
                line-height: 1.6;
            }
            
            .remedies-hero {
                background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
                color: white;
                padding: 80px 0;
                margin-bottom: 40px;
            }
            
            .service-card {
                background: white;
                border-radius: 10px;
                padding: 30px;
                margin-bottom: 30px;
                box-shadow: var(--card-shadow);
                transition: transform var(--transition-speed) ease;
                height: 100%;
                border: 1px solid rgba(0, 0, 0, 0.05);
            }
            
            .service-card:hover {
                transform: translateY(-5px);
                box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12);
            }
            
            .service-icon {
                width: 70px;
                height: 70px;
                background: var(--primary-color);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                margin: 0 auto 20px;
            }
            
            .service-icon i {
                font-size: 30px;
                color: white;
            }
            
            .btn-primary {
                background: var(--primary-color);
                border: none;
                padding: 10px 25px;
                border-radius: 50px;
                transition: all var(--transition-speed) ease;
            }
            
            .btn-primary:hover {
                background: var(--secondary-color);
                transform: translateY(-2px);
            }
            
            .section-title {
                color: var(--accent-color);
                position: relative;
                padding-bottom: 15px;
                margin-bottom: 30px;
            }
            
            .section-title::after {
                content: '';
                position: absolute;
                bottom: 0;
                left: 50%;
                transform: translateX(-50%);
                width: 60px;
                height: 3px;
                background: var(--primary-color);
            }
            
            .navbar-brand {
                font-weight: 700;
                color: var(--primary-color) !important;
            }
            
            .nav-link {
                font-weight: 500;
                transition: color var(--transition-speed) ease;
            }
            
            .nav-link:hover {
                color: var(--primary-color) !important;
            }
            
            .call-to-action {
                background: linear-gradient(135deg, #f8f9fa, #e9ecef);
                border-left: 5px solid var(--primary-color);
            }
        </style>
    </head>
    <body>
        <!-- Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
            <div class="container">
                <a class="navbar-brand" href="<?php echo BASE_PATH; ?>">
                    <i class="fas fa-heartbeat me-2"></i>
                    Philadelphia Remedies
                </a>
                
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <div class="collapse navbar-collapse" id="mainNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active" href="./">
                                <i class="fas fa-home me-1"></i> Home
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="treatments/">
                                <i class="fas fa-spa me-1"></i> Treatments
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="consultations/">
                                <i class="fas fa-user-md me-1"></i> Consultations
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="store/">
                                <i class="fas fa-shopping-cart me-1"></i> Store
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_PATH; ?>members/login.php">
                                <i class="fas fa-sign-in-alt me-1"></i> Login
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    <?php
}

function showFooter() {
    ?>
        <!-- Footer -->
        <footer class="bg-dark text-white py-5 mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <h5 class="mb-3">
                            <i class="fas fa-heartbeat me-2"></i>Philadelphia Remedies
                        </h5>
                        <p class="text-light">Holistic healing through natural remedies, consultations, and health education.</p>
                    </div>
                    
                    <div class="col-lg-4 mb-4">
                        <h5 class="mb-3">Contact Information</h5>
                        <p class="mb-2">
                            <i class="fas fa-phone me-2"></i> +254 712 345 678
                        </p>
                        <p class="mb-2">
                            <i class="fas fa-envelope me-2"></i> remedies@philadelphia-ministry.org
                        </p>
                        <p class="mb-0">
                            <i class="fas fa-clock me-2"></i> Mon-Fri: 8:00 AM - 6:00 PM
                        </p>
                    </div>
                    
                    <div class="col-lg-4 mb-4">
                        <h5 class="mb-3">Quick Links</h5>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <a href="treatments/" class="text-light text-decoration-none">
                                    <i class="fas fa-chevron-right me-1"></i> Book Treatment
                                </a>
                            </li>
                            <li class="mb-2">
                                <a href="consultations/" class="text-light text-decoration-none">
                                    <i class="fas fa-chevron-right me-1"></i> Get Consultation
                                </a>
                            </li>
                            <li class="mb-2">
                                <a href="store/" class="text-light text-decoration-none">
                                    <i class="fas fa-chevron-right me-1"></i> Shop Products
                                </a>
                            </li>
                            <li>
                                <a href="contact.php" class="text-light text-decoration-none">
                                    <i class="fas fa-chevron-right me-1"></i> Contact Us
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                
                <hr class="bg-light my-4">
                
                <div class="row">
                    <div class="col-md-12 text-center">
                        <p class="mb-0">
                            &copy; <?php echo date('Y'); ?> Philadelphia Ministry. All rights reserved.
                        </p>
                    </div>
                </div>
            </div>
        </footer>

        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        
        <!-- Custom Scripts -->
        <script>
        $(document).ready(function() {
            // Smooth scrolling for anchor links
            $('a[href^="#"]').on('click', function(e) {
                e.preventDefault();
                
                const target = $(this.hash);
                if (target.length) {
                    $('html, body').animate({
                        scrollTop: target.offset().top - 80
                    }, 800);
                }
            });
            
            // Navbar background on scroll
            $(window).scroll(function() {
                if ($(window).scrollTop() > 50) {
                    $('.navbar').addClass('bg-white shadow-sm');
                } else {
                    $('.navbar').removeClass('bg-white shadow-sm');
                }
            });
            
            console.log('Philadelphia Remedies - Ready for healing!');
        });
        </script>
    </body>
    </html>
    <?php
}

// ============================================
// PAGE RENDER
// ============================================

showHeader();
?>

<!-- Hero Section -->
<section class="remedies-hero">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8 mx-auto text-center">
                <h1 class="display-4 fw-bold mb-4">Natural Remedies & Wellness Center</h1>
                <p class="lead mb-4">Experience holistic healing through proven natural remedies, personalized consultations, and comprehensive health education.</p>
                <div class="d-flex flex-wrap justify-content-center gap-3">
                    <a href="treatments/book-treatment.php" class="btn btn-light btn-lg px-4 py-3">
                        <i class="fas fa-calendar-check me-2"></i> Book Treatment
                    </a>
                    <a href="consultations/book-consultation.php" class="btn btn-outline-light btn-lg px-4 py-3">
                        <i class="fas fa-user-md me-2"></i> Get Consultation
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Services Section -->
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center mb-5">
                <h2 class="section-title">Our Comprehensive Services</h2>
                <p class="text-muted mb-0">Integrative natural healthcare solutions for your wellness journey</p>
            </div>
        </div>
        
        <div class="row g-4">
            <!-- Service 1 -->
            <div class="col-lg-4 col-md-6">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-spa"></i>
                    </div>
                    <h4 class="fw-bold mb-3">Natural Treatments</h4>
                    <p class="text-muted mb-4">Herbal remedies, hydrotherapy, massage therapy, acupuncture, and other evidence-based natural healing modalities.</p>
                    <a href="treatments/" class="btn btn-primary w-100">Explore Treatments</a>
                </div>
            </div>
            
            <!-- Service 2 -->
            <div class="col-lg-4 col-md-6">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-user-md"></i>
                    </div>
                    <h4 class="fw-bold mb-3">Health Consultations</h4>
                    <p class="text-muted mb-4">Personalized one-on-one sessions with certified natural health practitioners and wellness coaches.</p>
                    <a href="consultations/" class="btn btn-primary w-100">Schedule Consultation</a>
                </div>
            </div>
            
            <!-- Service 3 -->
            <div class="col-lg-4 col-md-6">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-mortar-pestle"></i>
                    </div>
                    <h4 class="fw-bold mb-3">Remedies Store</h4>
                    <p class="text-muted mb-4">Premium natural products, organic herbs, supplements, essential oils, and wellness accessories.</p>
                    <a href="store/" class="btn btn-primary w-100">Visit Store</a>
                </div>
            </div>
            
            <!-- Service 4 -->
            <div class="col-lg-4 col-md-6">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-graduation-cap"></i>
                    </div>
                    <h4 class="fw-bold mb-3">Health Education</h4>
                    <p class="text-muted mb-4">Interactive workshops, online courses, seminars, and resources to empower your health decisions.</p>
                    <a href="education/" class="btn btn-primary w-100">Start Learning</a>
                </div>
            </div>
            
            <!-- Service 5 -->
            <div class="col-lg-4 col-md-6">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-hands-helping"></i>
                    </div>
                    <h4 class="fw-bold mb-3">Medical Missionary</h4>
                    <p class="text-muted mb-4">Community outreach programs, health missions, and volunteer opportunities to serve others.</p>
                    <a href="medical-missionary/" class="btn btn-primary w-100">Join Our Mission</a>
                </div>
            </div>
            
            <!-- Service 6 -->
            <div class="col-lg-4 col-md-6">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-heartbeat"></i>
                    </div>
                    <h4 class="fw-bold mb-3">Wellness Programs</h4>
                    <p class="text-muted mb-4">Structured 30-90 day programs designed for specific health goals, chronic conditions, and detoxification.</p>
                    <a href="programs/" class="btn btn-primary w-100">View Programs</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Call to Action -->
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 mx-auto">
                <div class="card call-to-action border-0 shadow-lg">
                    <div class="card-body p-5 text-center">
                        <h3 class="card-title fw-bold mb-3">Begin Your Healing Journey Today</h3>
                        <p class="card-text lead mb-4">
                            Take the first step towards optimal health. Our team is ready to guide you through personalized natural healing solutions.
                        </p>
                        <div class="d-flex flex-wrap justify-content-center gap-3">
                            <a href="treatments/book-treatment.php" class="btn btn-primary btn-lg px-5 py-3">
                                <i class="fas fa-calendar-plus me-2"></i> Book Your First Appointment
                            </a>
                            <a href="tel:+254712345678" class="btn btn-outline-primary btn-lg px-5 py-3">
                                <i class="fas fa-phone-alt me-2"></i> Call Now: +254 712 345 678
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
showFooter();
?>