<?php
/**
 * Remedies Department Configuration
 */

// Prevent direct access
if (!defined('BASE_PATH')) {
    die('Direct access not permitted');
}

// Remedies Department Settings
define('REMEDIES_ENABLED', true);
define('REMEDIES_NAME', 'Natural Remedies & Wellness Center');
define('REMEDIES_EMAIL', 'remedies@philadelphia-ministry.org');
define('REMEDIES_PHONE', '+254712345678');
define('REMEDIES_ADDRESS', 'Philadelphia Ministry, Nairobi, Kenya');

// Business Hours
define('BUSINESS_OPEN', '08:00');
define('BUSINESS_CLOSE', '18:00');
define('BUSINESS_DAYS', ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']);

// Appointment Settings
define('APPOINTMENT_DURATION', 60); // minutes
define('APPOINTMENT_BUFFER', 15); // minutes between appointments
define('CANCEL_HOURS', 24); // hours before appointment to cancel without penalty
define('MAX_BOOKINGS_PER_DAY', 20);
define('TIME_SLOTS', ['09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00', '17:00']);

// Store Settings
define('STORE_ENABLED', true);
define('CURRENCY', 'Ksh');
define('TAX_RATE', 16); // 16% VAT
define('SHIPPING_FEE', 300); // Default shipping fee
define('FREE_SHIPPING_THRESHOLD', 5000); // Free shipping above this amount
define('LOW_STOCK_THRESHOLD', 10);

// Payment Settings
define('PAYMENT_METHODS', ['cash', 'card', 'mobile_money']);
define('MPESA_SHORTCODE', '123456');
define('MPESA_CONSUMER_KEY', 'your_consumer_key');
define('MPESA_CONSUMER_SECRET', 'your_consumer_secret');
define('STRIPE_PUBLIC_KEY', 'your_stripe_public_key');
define('STRIPE_SECRET_KEY', 'your_stripe_secret_key');

// SMS & Email Settings
define('SMS_ENABLED', true);
define('SMS_PROVIDER', 'africastalking'); // or 'nexmo', 'twilio'
define('SMS_SENDER_ID', 'PHILADELPH');
define('SMS_API_KEY', 'your_sms_api_key');
define('SMS_USERNAME', 'your_sms_username');

define('EMAIL_ENABLED', true);
define('EMAIL_FROM', 'remedies@philadelphia-ministry.org');
define('EMAIL_FROM_NAME', 'Philadelphia Remedies');
define('EMAIL_REPLY_TO', 'info@philadelphia-ministry.org');

// File Upload Settings
define('UPLOAD_DIR', '../../assets/uploads/remedies/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif']);
define('ALLOWED_DOC_TYPES', ['pdf', 'doc', 'docx']);

// Security Settings
define('SESSION_TIMEOUT', 3600); // 1 hour
define('MAX_LOGIN_ATTEMPTS', 5);
define('PASSWORD_MIN_LENGTH', 8);

// Reporting Settings
define('REPORT_DIR', '../../reports/');
define('BACKUP_DIR', '../../backup/remedies/');
define('LOG_DIR', '../../logs/remedies/');

// API Settings
define('API_ENABLED', true);
define('API_KEY', 'your_api_key_here');
define('API_SECRET', 'your_api_secret_here');

// Cache Settings
define('CACHE_ENABLED', true);
define('CACHE_DIR', '../../temp/cache/remedies/');
define('CACHE_DURATION', 300); // 5 minutes

// Debug Settings
define('DEBUG_MODE', true);
define('LOG_LEVEL', 'error'); // error, warning, info, debug

/**
 * Get remedies configuration
 */
function getRemediesConfig($key = null) {
    $config = [
        'business_name' => REMEDIES_NAME,
        'email' => REMEDIES_EMAIL,
        'phone' => REMEDIES_PHONE,
        'address' => REMEDIES_ADDRESS,
        'currency' => CURRENCY,
        'tax_rate' => TAX_RATE,
        'time_slots' => TIME_SLOTS,
        'business_hours' => [
            'open' => BUSINESS_OPEN,
            'close' => BUSINESS_CLOSE,
            'days' => BUSINESS_DAYS
        ]
    ];
    
    if ($key) {
        return $config[$key] ?? null;
    }
    
    return $config;
}

/**
 * Validate remedies access
 */
function validateRemediesAccess($userId, $requiredRole = 'patient') {
    global $conn;
    
    if (!$userId) {
        return false;
    }
    
    $query = "SELECT role FROM members WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($user = $result->fetch_assoc()) {
        $userRole = $user['role'];
        
        $roleHierarchy = [
            'super_admin' => ['super_admin', 'admin', 'remedies_admin', 'practitioner', 'patient'],
            'admin' => ['admin', 'remedies_admin', 'practitioner', 'patient'],
            'remedies_admin' => ['remedies_admin', 'practitioner', 'patient'],
            'practitioner' => ['practitioner', 'patient'],
            'patient' => ['patient']
        ];
        
        if (isset($roleHierarchy[$userRole]) && in_array($requiredRole, $roleHierarchy[$userRole])) {
            return true;
        }
    }
    
    return false;
}

/**
 * Log remedies activity
 */
function logRemediesActivity($action, $details = [], $userId = null) {
    $logFile = LOG_DIR . 'activity.log';
    $timestamp = date('Y-m-d H:i:s');
    $user = $userId ?? ($_SESSION['user_id'] ?? 'system');
    
    $logEntry = json_encode([
        'timestamp' => $timestamp,
        'user' => $user,
        'action' => $action,
        'details' => $details,
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
    ]);
    
    file_put_contents($logFile, $logEntry . PHP_EOL, FILE_APPEND | LOCK_EX);
}

/**
 * Get remedies roles
 */
function getRemediesRoles() {
    return [
        'super_admin' => 'Super Administrator',
        'admin' => 'System Administrator',
        'remedies_admin' => 'Remedies Administrator',
        'practitioner' => 'Health Practitioner',
        'patient' => 'Patient',
        'volunteer' => 'Mission Volunteer'
    ];
}

/**
 * Generate remedies report
 */
function generateRemediesReport($type, $startDate, $endDate) {
    global $conn;
    
    $reports = [];
    
    switch ($type) {
        case 'financial':
            $query = "SELECT 
                DATE(created_at) as date,
                COUNT(*) as sales_count,
                SUM(net_amount) as total_revenue,
                AVG(net_amount) as average_sale,
                SUM(CASE WHEN payment_method = 'mobile_money' THEN net_amount ELSE 0 END) as mobile_money_total,
                SUM(CASE WHEN payment_method = 'cash' THEN net_amount ELSE 0 END) as cash_total
                FROM remedies_sales 
                WHERE created_at BETWEEN ? AND ?
                AND payment_status = 'paid'
                GROUP BY DATE(created_at)
                ORDER BY date";
            break;
            
        case 'appointments':
            $query = "SELECT 
                booking_date as date,
                COUNT(*) as total_bookings,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
                SUM(CASE WHEN status = 'no-show' THEN 1 ELSE 0 END) as no_show
                FROM remedies_bookings 
                WHERE booking_date BETWEEN ? AND ?
                GROUP BY booking_date
                ORDER BY booking_date";
            break;
            
        case 'inventory':
            $query = "SELECT 
                p.category,
                COUNT(p.id) as total_products,
                SUM(p.quantity_in_stock) as total_stock,
                SUM(p.quantity_in_stock * p.unit_price) as stock_value,
                SUM(CASE WHEN p.quantity_in_stock <= p.reorder_level THEN 1 ELSE 0 END) as low_stock_count
                FROM remedies_products p
                WHERE p.is_active = 1
                GROUP BY p.category
                ORDER BY p.category";
            break;
            
        default:
            return [];
    }
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $startDate, $endDate);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $reports[] = $row;
    }
    
    return $reports;

}
// Email Settings
define('EMAIL_ENABLED', true);
define('EMAIL_FROM', 'remedies@philadelphia-ministry.org');
define('EMAIL_FROM_NAME', 'Philadelphia Remedies');
define('EMAIL_REPLY_TO', 'info@philadelphia-ministry.org');

// For Gmail SMTP (Recommended for production)
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'your-email@gmail.com');
define('SMTP_PASSWORD', 'your-app-password');
define('SMTP_ENCRYPTION', 'tls');

// For localhost testing (XAMPP)
/*
define('SMTP_HOST', 'localhost');
define('SMTP_PORT', 25);
define('SMTP_USERNAME', '');
define('SMTP_PASSWORD', '');
define('SMTP_ENCRYPTION', '');
*/
?>