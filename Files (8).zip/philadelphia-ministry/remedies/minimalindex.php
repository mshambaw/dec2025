<?php
// ============================================
// MINIMAL WORKING VERSION OF REMEDIES INDEX
// ============================================

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Define base path
define('BASE_PATH', dirname(__DIR__) . '/');

// Start session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Simple database connection
function getDB() {
    static $conn = null;
    if ($conn === null) {
        $conn = new mysqli('localhost', 'root', '', 'philadelphia_ministry');
        if ($conn->connect_error) {
            // Don't die, just return null
            error_log("Database connection failed: " . $conn->connect_error);
            return null;
        }
        $conn->set_charset("utf8mb4");
    }
    return $conn;
}

// Simple header
function showHeader() {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Philadelphia Ministry - Remedies Department</title>
        
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
        
        <!-- Custom CSS -->
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: #f8f9fa;
            }
            .remedies-hero {
                background: linear-gradient(135deg, #3498db, #2980b9);
                color: white;
                padding: 80px 0;
                margin-bottom: 40px;
            }
            .service-card {
                background: white;
                border-radius: 10px;
                padding: 30px;
                margin-bottom: 30px;
                box-shadow: 0 5px 15px rgba(0,0,0,0.08);
                transition: transform 0.3s ease;
                height: 100%;
            }
            .service-card:hover {
                transform: translateY(-5px);
            }
            .service-icon {
                width: 70px;
                height: 70px;
                background: #3498db;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-bottom: 20px;
            }
            .service-icon i {
                font-size: 30px;
                color: white;
            }
            .btn-primary {
                background: #3498db;
                border: none;
                padding: 10px 25px;
                border-radius: 50px;
            }
            .btn-primary:hover {
                background: #2980b9;
            }
        </style>
    </head>
    <body>
        <!-- Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="../">
                    <i class="fas fa-heartbeat text-primary"></i>
                    <span class="fw-bold">Philadelphia Remedies</span>
                </a>
                
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active" href="./">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="treatments/">Treatments</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="consultations/">Consultations</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="store/">Store</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../members/login.php">
                                <i class="fas fa-sign-in-alt"></i> Login
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    <?php
}

// Simple footer
function showFooter() {
    ?>
        <!-- Footer -->
        <footer class="bg-dark text-white py-4 mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <h5>Philadelphia Remedies</h5>
                        <p>Natural healing through traditional remedies and modern wellness practices.</p>
                    </div>
                    <div class="col-md-4">
                        <h5>Contact Info</h5>
                        <p><i class="fas fa-phone"></i> +254 712 345 678</p>
                        <p><i class="fas fa-envelope"></i> remedies@philadelphia-ministry.org</p>
                    </div>
                    <div class="col-md-4">
                        <h5>Quick Links</h5>
                        <ul class="list-unstyled">
                            <li><a href="treatments/" class="text-light">Book Treatment</a></li>
                            <li><a href="consultations/" class="text-light">Get Consultation</a></li>
                            <li><a href="store/" class="text-light">Shop Products</a></li>
                        </ul>
                    </div>
                </div>
                <hr class="bg-light">
                <p class="text-center mb-0">&copy; <?php echo date('Y'); ?> Philadelphia Ministry. All rights reserved.</p>
            </div>
        </footer>

        <!-- Bootstrap JS -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        
        <!-- jQuery -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        
        <script>
        $(document).ready(function() {
            console.log('Remedies page loaded successfully!');
        });
        </script>
    </body>
    </html>
    <?php
}

// ============================================
// MAIN PAGE CONTENT
// ============================================

// Show header
showHeader();
?>

<!-- Hero Section -->
<section class="remedies-hero">
    <div class="container text-center">
        <h1 class="display-4 fw-bold">Natural Remedies & Wellness Center</h1>
        <p class="lead">Holistic healing through natural remedies, consultations, and health education</p>
        <div class="mt-4">
            <a href="treatments/book-treatment.php" class="btn btn-light btn-lg me-2">
                <i class="fas fa-calendar-check"></i> Book Treatment
            </a>
            <a href="consultations/book-consultation.php" class="btn btn-outline-light btn-lg">
                <i class="fas fa-user-md"></i> Get Consultation
            </a>
        </div>
    </div>
</section>

<!-- Services -->
<section class="container">
    <div class="row">
        <div class="col-lg-12 text-center mb-5">
            <h2 class="section-title">Our Services</h2>
            <p class="text-muted">Comprehensive natural healthcare solutions</p>
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-4 col-md-6">
            <div class="service-card">
                <div class="service-icon">
                    <i class="fas fa-spa"></i>
                </div>
                <h4>Natural Treatments</h4>
                <p>Herbal remedies, hydrotherapy, massage therapy, and other natural healing modalities.</p>
                <a href="treatments/" class="btn btn-primary">View Treatments</a>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6">
            <div class="service-card">
                <div class="service-icon">
                    <i class="fas fa-user-md"></i>
                </div>
                <h4>Health Consultations</h4>
                <p>Personalized consultations with certified natural health practitioners.</p>
                <a href="consultations/" class="btn btn-primary">Book Consultation</a>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6">
            <div class="service-card">
                <div class="service-icon">
                    <i class="fas fa-mortar-pestle"></i>
                </div>
                <h4>Remedies Store</h4>
                <p>High-quality natural products, herbs, supplements, and wellness tools.</p>
                <a href="store/" class="btn btn-primary">Shop Now</a>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6">
            <div class="service-card">
                <div class="service-icon">
                    <i class="fas fa-graduation-cap"></i>
                </div>
                <h4>Health Education</h4>
                <p>Workshops, courses, and resources to empower your health journey.</p>
                <a href="education/" class="btn btn-primary">Learn More</a>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6">
            <div class="service-card">
                <div class="service-icon">
                    <i class="fas fa-hands-helping"></i>
                </div>
                <h4>Medical Missionary</h4>
                <p>Community outreach and health mission services.</p>
                <a href="medical-missionary/" class="btn btn-primary">Get Involved</a>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6">
            <div class="service-card">
                <div class="service-icon">
                    <i class="fas fa-heartbeat"></i>
                </div>
                <h4>Wellness Programs</h4>
                <p>Structured programs for specific health goals and conditions.</p>
                <a href="programs/" class="btn btn-primary">View Programs</a>
            </div>
        </div>
    </div>
</section>

<!-- Call to Action -->
<section class="container my-5">
    <div class="row">
        <div class="col-lg-8 mx-auto text-center">
            <div class="card border-0 shadow-lg">
                <div class="card-body p-5">
                    <h3 class="card-title">Ready to Begin Your Healing Journey?</h3>
                    <p class="card-text">Book your first treatment or consultation today and experience the power of natural healing.</p>
                    <div class="mt-4">
                        <a href="treatments/book-treatment.php" class="btn btn-primary btn-lg me-3">
                            <i class="fas fa-calendar-plus"></i> Book Appointment
                        </a>
                        <a href="contact.php" class="btn btn-outline-primary btn-lg">
                            <i class="fas fa-phone-alt"></i> Contact Us
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
// Show footer
showFooter();
?>