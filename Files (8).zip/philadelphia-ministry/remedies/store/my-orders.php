<?php
// Define access
define('STORE_ACCESS', true);

// Include config
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_PATH . 'members/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    exit;
}

$userId = $_SESSION['user_id'];
$userName = $_SESSION['user_name'] ?? '';
$cartCount = getCartCount();

// Get user orders
$orders = getUserOrders($userId);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders - <?php echo $storeSettings['store_name']; ?></title>
    
    <!-- Include styles -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        <?php include 'styles.php'; ?>
        
        .orders-section {
            padding: 80px 0;
        }
        
        .account-sidebar {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .user-info {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .user-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            color: white;
            font-size: 2rem;
        }
        
        .account-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .account-menu li {
            margin-bottom: 5px;
        }
        
        .account-menu a {
            display: block;
            padding: 12px 15px;
            border-radius: 8px;
            color: var(--text-color);
            transition: all 0.3s;
        }
        
        .account-menu a:hover, .account-menu a.active {
            background: rgba(26, 82, 118, 0.1);
            color: var(--primary-color);
            padding-left: 20px;
        }
        
        .orders-header {
            margin-bottom: 40px;
        }
        
        .order-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            transition: all 0.3s;
            border-left: 5px solid var(--primary-color);
        }
        
        .order-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        
        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .order-number {
            font-weight: 600;
            color: var(--primary-color);
            font-size: 1.1rem;
        }
        
        .order-date {
            color: var(--text-light);
            font-size: 0.9rem;
        }
        
        .order-status {
            padding: 6px 15px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        
        .status-pending {
            background: rgba(255, 193, 7, 0.1);
            color: #ffc107;
        }
        
        .status-processing {
            background: rgba(0, 123, 255, 0.1);
            color: #007bff;
        }
        
        .status-shipped {
            background: rgba(39, 174, 96, 0.1);
            color: var(--accent-color);
        }
        
        .status-delivered {
            background: rgba(111, 66, 193, 0.1);
            color: #6f42c1;
        }
        
        .status-cancelled {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }
        
        .order-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .detail-item {
            margin-bottom: 10px;
        }
        
        .detail-label {
            font-size: 0.9rem;
            color: var(--text-light);
            margin-bottom: 5px;
        }
        
        .detail-value {
            font-weight: 600;
        }
        
        .order-items {
            margin-top: 20px;
        }
        
        .order-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid var(--border-color);
        }
        
        .order-item:last-child {
            border-bottom: none;
        }
        
        .item-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .item-image {
            width: 60px;
            height: 60px;
            border-radius: 8px;
            overflow: hidden;
        }
        
        .item-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .item-price {
            text-align: right;
        }
        
        .order-actions {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        
        .empty-orders {
            text-align: center;
            padding: 60px 20px;
        }
        
        .empty-orders i {
            font-size: 4rem;
            color: var(--text-light);
            margin-bottom: 20px;
        }
        
        @media (max-width: 768px) {
            .order-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .order-details {
                grid-template-columns: 1fr;
            }
            
            .item-info {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .order-actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <!-- Include Header -->
    <?php include 'header.php'; ?>
    
    <!-- My Orders -->
    <section class="orders-section">
        <div class="container">
            <div class="orders-header">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item"><a href="my-account.php">My Account</a></li>
                        <li class="breadcrumb-item active">My Orders</li>
                    </ol>
                </nav>
                
                <h1 class="mb-3"><i class="fas fa-box me-2"></i>My Orders</h1>
                <p class="text-muted">View your order history and track current orders</p>
            </div>
            
            <div class="row">
                <!-- Account Sidebar -->
                <div class="col-lg-3">
                    <div class="account-sidebar">
                        <div class="user-info">
                            <div class="user-avatar">
                                <i class="fas fa-user"></i>
                            </div>
                            <h5><?php echo htmlspecialchars($userName); ?></h5>
                            <p class="text-muted small">Member since <?php echo date('Y'); ?></p>
                        </div>
                        
                        <ul class="account-menu">
                            <li>
                                <a href="my-account.php">
                                    <i class="fas fa-user-circle me-2"></i>My Profile
                                </a>
                            </li>
                            <li>
                                <a href="my-orders.php" class="active">
                                    <i class="fas fa-box me-2"></i>My Orders
                                </a>
                            </li>
                            <li>
                                <a href="my-addresses.php">
                                    <i class="fas fa-address-book me-2"></i>My Addresses
                                </a>
                            </li>
                            <li>
                                <a href="wishlist.php">
                                    <i class="fas fa-heart me-2"></i>Wishlist
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo BASE_PATH; ?>members/logout.php" class="text-danger">
                                    <i class="fas fa-sign-out-alt me-2"></i>Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                
                <!-- Orders Content -->
                <div class="col-lg-9">
                    <?php if(empty($orders)): ?>
                    <!-- Empty Orders -->
                    <div class="empty-orders">
                        <i class="fas fa-box-open"></i>
                        <h3>No Orders Yet</h3>
                        <p class="text-muted mb-4">You haven't placed any orders yet.</p>
                        <a href="products.php" class="btn btn-primary">
                            <i class="fas fa-store me-2"></i>Start Shopping
                        </a>
                    </div>
                    <?php else: ?>
                    
                    <!-- Orders List -->
                    <div class="orders-list">
                        <?php foreach($orders as $order): 
                            $statusClass = 'status-' . $order['status'];
                            $createdDate = date('F d, Y', strtotime($order['created_at']));
                            $totalAmount = formatCurrency($order['total_amount']);
                        ?>
                        <div class="order-card">
                            <div class="order-header">
                                <div>
                                    <div class="order-number">Order #<?php echo htmlspecialchars($order['order_number']); ?></div>
                                    <div class="order-date">Placed on <?php echo $createdDate; ?></div>
                                </div>
                                <div class="order-status <?php echo $statusClass; ?>">
                                    <?php echo ucfirst($order['status']); ?>
                                </div>
                            </div>
                            
                            <div class="order-details">
                                <div class="detail-item">
                                    <div class="detail-label">Items</div>
                                    <div class="detail-value"><?php echo $order['items_count']; ?> item(s)</div>
                                </div>
                                <div class="detail-item">
                                    <div class="detail-label">Total Amount</div>
                                    <div class="detail-value"><?php echo $totalAmount; ?></div>
                                </div>
                                <div class="detail-item">
                                    <div class="detail-label">Payment Method</div>
                                    <div class="detail-value"><?php echo ucfirst(str_replace('_', ' ', $order['payment_method'])); ?></div>
                                </div>
                            </div>
                            
                            <?php if($order['products']): ?>
                            <div class="order-items">
                                <h6 class="mb-3">Order Items:</h6>
                                <?php 
                                $products = explode(', ', $order['products']);
                                foreach($products as $product):
                                    if(empty($product)) continue;
                                ?>
                                <div class="order-item">
                                    <div class="item-info">
                                        <div class="item-image">
                                            <img src="<?php echo ASSETS_URL; ?>images/products/default.jpg" 
                                                 alt="<?php echo htmlspecialchars($product); ?>">
                                        </div>
                                        <div>
                                            <div class="item-name"><?php echo htmlspecialchars($product); ?></div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <?php endif; ?>
                            
                            <div class="order-actions">
                                <a href="order-details.php?id=<?php echo $order['id']; ?>" 
                                   class="btn btn-outline-primary btn-sm">
                                    <i class="fas fa-eye me-2"></i>View Details
                                </a>
                                
                                <?php if($order['status'] == 'pending' || $order['status'] == 'processing'): ?>
                                <button class="btn btn-outline-danger btn-sm" 
                                        onclick="cancelOrder(<?php echo $order['id']; ?>)">
                                    <i class="fas fa-times me-2"></i>Cancel Order
                                </button>
                                <?php endif; ?>
                                
                                <?php if($order['status'] == 'delivered'): ?>
                                <button class="btn btn-outline-success btn-sm">
                                    <i class="fas fa-redo me-2"></i>Reorder
                                </button>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Include Footer -->
    <?php include 'footer.php'; ?>
    
    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    function cancelOrder(orderId) {
        if (confirm('Are you sure you want to cancel this order?')) {
            $.ajax({
                url: 'api/orders.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'cancel_order',
                    order_id: orderId,
                    csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
                },
                success: function(response) {
                    if (response.success) {
                        alert('Order cancelled successfully');
                        location.reload();
                    } else {
                        alert('Error: ' + response.message);
                    }
                },
                error: function() {
                    alert('Network error. Please try again.');
                }
            });
        }
    }
    </script>
</body>
</html>