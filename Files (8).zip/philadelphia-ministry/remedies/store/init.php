<?php
/**
 * Store Initialization File
 * Include this at the top of every store page
 */

// Define store system if not defined
if (!defined('STORE_SYSTEM')) {
    define('STORE_SYSTEM', true);
}

// Include config
require_once __DIR__ . '/config.php';

// Check if user is logged in for certain pages
$protectedPages = ['shopping-cart.php', 'checkout.php', 'my-orders.php', 'my-account.php'];
$currentPage = basename($_SERVER['PHP_SELF']);

if (in_array($currentPage, $protectedPages) && !isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_PATH . 'members/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    exit;
}

// Get user info
$userName = $_SESSION['user_name'] ?? '';
$userId = $_SESSION['user_id'] ?? 0;
$userEmail = $_SESSION['user_email'] ?? '';
$userPhone = $_SESSION['user_phone'] ?? '';

// Get cart info
$cartCount = getCartCount();
$cartTotal = getCartTotal();
?>