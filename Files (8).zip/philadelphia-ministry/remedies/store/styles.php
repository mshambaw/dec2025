<?php
// Common styles
?>
<style>
    :root {
        --primary-color: #1a5276;
        --secondary-color: #2c3e50;
        --accent-color: #27ae60;
        --light-color: #f8f9fa;
        --dark-color: #2c3e50;
        --text-color: #333;
        --text-light: #6c757d;
        --border-color: #dee2e6;
        --shadow: 0 4px 15px rgba(0,0,0,0.1);
        --transition: all 0.3s ease;
    }
    
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: var(--text-color);
        background-color: #fff;
        line-height: 1.6;
    }
    
    h1, h2, h3, h4, h5 {
        font-weight: 600;
        color: var(--dark-color);
    }
    
    a {
        text-decoration: none;
        color: inherit;
        transition: var(--transition);
    }
    
    a:hover {
        color: var(--accent-color);
    }
    
    .btn {
        border-radius: 8px;
        padding: 10px 24px;
        font-weight: 500;
        transition: var(--transition);
        border: none;
    }
    
    .btn-primary {
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        color: white;
    }
    
    .btn-primary:hover {
        background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
        color: white;
        transform: translateY(-2px);
        box-shadow: var(--shadow);
    }
    
    .btn-accent {
        background: var(--accent-color);
        color: white;
    }
    
    .btn-accent:hover {
        background: #219653;
        color: white;
        transform: translateY(-2px);
        box-shadow: var(--shadow);
    }
</style>