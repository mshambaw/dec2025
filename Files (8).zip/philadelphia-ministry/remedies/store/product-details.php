<?php
// Include config - DON'T define STORE_ACCESS here
require_once 'config.php';

// Get product ID
$productId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($productId <= 0) {
    header('Location: products.php');
    exit;
}

// Get product details
$product = getProduct($productId);
if (!$product) {
    header('Location: products.php');
    exit;
}

// Get related products (same category)
$relatedProducts = [];
$conn = getStoreConnection();
if ($conn) {
    $stmt = $conn->prepare("
        SELECT r.* 
        FROM remedies r 
        WHERE r.is_active = 1 AND r.quantity_in_stock > 0 
        AND r.category = ? AND r.id != ?
        ORDER BY RAND()
        LIMIT 4
    ");
    $stmt->execute([$product['category'], $productId]);
    $relatedProducts = $stmt->fetchAll();
}

// Get user info from session
$userName = $_SESSION['user_name'] ?? '';
$userId = $_SESSION['user_id'] ?? 0;
$cartCount = getCartCount();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name']); ?> - <?php echo $storeSettings['store_name']; ?></title>
    
    <!-- Include styles -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Store Main CSS -->
    <style>
        /* Include base styles */
        :root {
            --primary-color: #1a5276;
            --secondary-color: #2c3e50;
            --accent-color: #27ae60;
            --light-color: #f8f9fa;
            --dark-color: #2c3e50;
            --text-color: #333;
            --text-light: #6c757d;
            --border-color: #dee2e6;
            --shadow: 0 4px 15px rgba(0,0,0,0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text-color);
            background-color: #fff;
            line-height: 1.6;
        }
        
        h1, h2, h3, h4, h5 {
            font-weight: 600;
            color: var(--dark-color);
        }
        
        a {
            text-decoration: none;
            color: inherit;
            transition: var(--transition);
        }
        
        a:hover {
            color: var(--accent-color);
        }
        
        .btn {
            border-radius: 8px;
            padding: 10px 24px;
            font-weight: 500;
            transition: var(--transition);
            border: none;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
            color: white;
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }
        
        /* Product Details Specific Styles */
        .product-detail-section { 
            padding: 80px 0; 
        }
        
        .product-gallery { 
            position: sticky; 
            top: 100px; 
        }
        
        .main-image { 
            background: white; 
            border-radius: 15px; 
            overflow: hidden; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.1); 
            margin-bottom: 20px; 
        }
        
        .main-image img { 
            width: 100%; 
            height: 400px; 
            object-fit: contain; 
            background: #f8f9fa; 
        }
        
        .thumbnails { 
            display: flex; 
            gap: 10px; 
        }
        
        .thumbnail { 
            width: 80px; 
            height: 80px; 
            border-radius: 10px; 
            overflow: hidden; 
            cursor: pointer; 
            border: 2px solid transparent; 
            transition: all 0.3s; 
        }
        
        .thumbnail:hover, .thumbnail.active { 
            border-color: var(--primary-color); 
        }
        
        .thumbnail img { 
            width: 100%; 
            height: 100%; 
            object-fit: cover; 
        }
        
        .product-info { 
            background: white; 
            border-radius: 15px; 
            padding: 40px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.1); 
        }
        
        .product-title { 
            font-size: 2.2rem; 
            margin-bottom: 10px; 
        }
        
        .product-code { 
            color: var(--text-light); 
            font-size: 0.9rem; 
            margin-bottom: 20px; 
        }
        
        .product-price { 
            font-size: 2.5rem; 
            font-weight: 700; 
            color: var(--primary-color); 
            margin-bottom: 20px; 
        }
        
        .original-price { 
            font-size: 1.5rem; 
            color: var(--text-light); 
            text-decoration: line-through; 
            margin-right: 10px; 
        }
        
        .product-meta { 
            display: flex; 
            flex-wrap: wrap; 
            gap: 20px; 
            margin-bottom: 30px; 
        }
        
        .meta-item { 
            display: flex; 
            align-items: center; 
            gap: 8px; 
        }
        
        .meta-item i { 
            color: var(--primary-color); 
        }
        
        .stock-status { 
            padding: 6px 12px; 
            border-radius: 20px; 
            font-weight: 600; 
            font-size: 0.9rem; 
        }
        
        .in-stock { 
            background: rgba(39, 174, 96, 0.1); 
            color: var(--accent-color); 
        }
        
        .low-stock { 
            background: rgba(255, 193, 7, 0.1); 
            color: #ffc107; 
        }
        
        .out-stock { 
            background: rgba(220, 53, 69, 0.1); 
            color: #dc3545; 
        }
        
        .product-description { 
            line-height: 1.8; 
            margin-bottom: 30px; 
        }
        
        .quantity-selector { 
            display: flex; 
            align-items: center; 
            gap: 15px; 
            margin-bottom: 30px; 
        }
        
        .quantity-control { 
            display: flex; 
            align-items: center; 
            border: 2px solid var(--border-color); 
            border-radius: 10px; 
            overflow: hidden; 
        }
        
        .quantity-btn { 
            width: 45px; 
            height: 45px; 
            border: none; 
            background: var(--light-color); 
            font-size: 1.2rem; 
            cursor: pointer; 
            transition: all 0.3s; 
        }
        
        .quantity-btn:hover { 
            background: var(--border-color); 
        }
        
        .quantity-input { 
            width: 60px; 
            height: 45px; 
            border: none; 
            text-align: center; 
            font-size: 1.1rem; 
            font-weight: 600; 
        }
        
        .action-buttons { 
            display: flex; 
            gap: 15px; 
            flex-wrap: wrap; 
        }
        
        .btn-add-cart, .btn-buy-now { 
            padding: 15px 30px; 
            font-size: 1.1rem; 
            font-weight: 600; 
        }
        
        .btn-add-cart { 
            background: var(--primary-color); 
            color: white; 
            border: none; 
            flex: 1; 
        }
        
        .btn-buy-now { 
            background: var(--accent-color); 
            color: white; 
            border: none; 
            flex: 1; 
        }
        
        .product-tabs { 
            margin-top: 60px; 
        }
        
        .tab-content { 
            background: white; 
            border-radius: 15px; 
            padding: 30px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.1); 
        }
        
        .related-products { 
            margin-top: 80px; 
        }
        
        .related-title { 
            font-size: 1.8rem; 
            margin-bottom: 30px; 
            text-align: center; 
        }
        
        .specifications-table { 
            width: 100%; 
        }
        
        .specifications-table tr { 
            border-bottom: 1px solid var(--border-color); 
        }
        
        .specifications-table td { 
            padding: 12px 0; 
        }
        
        .specifications-table td:first-child { 
            font-weight: 600; 
            color: var(--dark-color); 
            width: 200px; 
        }
        
        .review-item { 
            border-bottom: 1px solid var(--border-color); 
            padding: 20px 0; 
        }
        
        .review-item:last-child { 
            border-bottom: none; 
        }
        
        .review-author { 
            font-weight: 600; 
            margin-bottom: 5px; 
        }
        
        .review-date { 
            color: var(--text-light); 
            font-size: 0.9rem; 
        }
        
        .review-rating { 
            color: #ffc107; 
            margin-bottom: 10px; 
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .product-title {
                font-size: 1.8rem;
            }
            
            .product-price {
                font-size: 2rem;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .btn-add-cart, .btn-buy-now {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <!-- Simple Header for testing -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-heartbeat text-primary me-2"></i>
                Philadelphia Remedies
            </a>
            <div class="d-flex align-items-center">
                <a href="shopping-cart.php" class="btn btn-outline-primary me-2">
                    <i class="fas fa-shopping-cart"></i>
                    <?php if($cartCount > 0): ?>
                    <span class="badge bg-danger ms-1"><?php echo $cartCount; ?></span>
                    <?php endif; ?>
                </a>
                <?php if($userId): ?>
                <span class="me-3">Hello, <?php echo htmlspecialchars($userName); ?></span>
                <?php else: ?>
                <a href="<?php echo BASE_PATH; ?>members/login.php" class="btn btn-primary">
                    Login
                </a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    
    <!-- Product Details -->
    <section class="product-detail-section">
        <div class="container">
            <nav aria-label="breadcrumb" class="mb-4">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="products.php">Shop</a></li>
                    <li class="breadcrumb-item active"><?php echo htmlspecialchars($product['name']); ?></li>
                </ol>
            </nav>
            
            <div class="row">
                <!-- Product Gallery -->
                <div class="col-lg-5">
                    <div class="product-gallery">
                        <div class="main-image">
                            <img id="mainProductImage" 
                                 src="<?php echo !empty($product['image_url']) ? htmlspecialchars($product['image_url']) : 'https://via.placeholder.com/600x400/1a5276/ffffff?text=' . urlencode($product['name']); ?>" 
                                 alt="<?php echo htmlspecialchars($product['name']); ?>">
                        </div>
                    </div>
                </div>
                
                <!-- Product Info -->
                <div class="col-lg-7">
                    <div class="product-info">
                        <h1 class="product-title"><?php echo htmlspecialchars($product['name']); ?></h1>
                        <div class="product-code">
                            <i class="fas fa-barcode me-2"></i>
                            Code: <?php echo htmlspecialchars($product['remedy_code'] ?? 'N/A'); ?>
                        </div>
                        
                        <div class="product-price">
                            <?php if(isset($product['cost_price']) && $product['unit_price'] > $product['cost_price']): ?>
                            <span class="original-price"><?php echo formatCurrency($product['cost_price']); ?></span>
                            <?php endif; ?>
                            <?php echo formatCurrency($product['unit_price']); ?>
                        </div>
                        
                        <div class="product-meta">
                            <div class="meta-item">
                                <i class="fas fa-tags"></i>
                                <span>Category: <?php echo htmlspecialchars($product['category_name'] ?? 'General'); ?></span>
                            </div>
                            <div class="meta-item">
                                <i class="fas fa-box"></i>
                                <span>Stock: 
                                    <span class="stock-status 
                                        <?php echo $product['quantity_in_stock'] > 10 ? 'in-stock' : 
                                               ($product['quantity_in_stock'] > 0 ? 'low-stock' : 'out-stock'); ?>">
                                        <?php echo $product['quantity_in_stock'] > 10 ? 'In Stock' : 
                                               ($product['quantity_in_stock'] > 0 ? 'Low Stock (' . $product['quantity_in_stock'] . ' left)' : 'Out of Stock'); ?>
                                    </span>
                                </span>
                            </div>
                            <div class="meta-item">
                                <i class="fas fa-weight"></i>
                                <span>Unit: <?php echo htmlspecialchars($product['unit_type'] ?? 'Each'); ?></span>
                            </div>
                        </div>
                        
                        <div class="product-description">
                            <?php echo nl2br(htmlspecialchars($product['description'] ?? 'No description available.')); ?>
                        </div>
                        
                        <?php if($product['quantity_in_stock'] > 0): ?>
                        <div class="quantity-selector">
                            <label class="form-label mb-0">Quantity:</label>
                            <div class="quantity-control">
                                <button class="quantity-btn decrease">-</button>
                                <input type="number" class="quantity-input" value="1" min="1" 
                                       max="<?php echo min($product['quantity_in_stock'], 99); ?>" 
                                       id="productQuantity">
                                <button class="quantity-btn increase">+</button>
                            </div>
                            <small class="text-muted">
                                <?php echo $product['quantity_in_stock']; ?> available
                            </small>
                        </div>
                        
                        <div class="action-buttons">
                            <button class="btn-add-cart" onclick="addToCart(<?php echo $product['id']; ?>)">
                                <i class="fas fa-cart-plus me-2"></i>Add to Cart
                            </button>
                            <button class="btn-buy-now" onclick="buyNow(<?php echo $product['id']; ?>)">
                                <i class="fas fa-bolt me-2"></i>Buy Now
                            </button>
                        </div>
                        <?php else: ?>
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            This product is currently out of stock. Please check back later.
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Related Products -->
            <?php if(!empty($relatedProducts)): ?>
            <div class="related-products">
                <h3 class="related-title">Related Products</h3>
                <div class="row">
                    <?php foreach($relatedProducts as $related): ?>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="card h-100">
                            <img src="<?php echo !empty($related['image_url']) ? htmlspecialchars($related['image_url']) : 'https://via.placeholder.com/300x200/1a5276/ffffff?text=' . urlencode($related['name']); ?>" 
                                 class="card-img-top" alt="<?php echo htmlspecialchars($related['name']); ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($related['name']); ?></h5>
                                <p class="card-text"><?php echo formatCurrency($related['unit_price']); ?></p>
                                <a href="product-details.php?id=<?php echo $related['id']; ?>" 
                                   class="btn btn-primary btn-sm">View Details</a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </section>
    
    <!-- Simple Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <p class="mb-0">
                        &copy; <?php echo date('Y'); ?> Philadelphia Ministry. All rights reserved.
                    </p>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    // Quantity control
    document.querySelector('.decrease')?.addEventListener('click', function() {
        const input = document.getElementById('productQuantity');
        if (parseInt(input.value) > 1) {
            input.value = parseInt(input.value) - 1;
        }
    });
    
    document.querySelector('.increase')?.addEventListener('click', function() {
        const input = document.getElementById('productQuantity');
        const max = parseInt(input.max);
        if (parseInt(input.value) < max) {
            input.value = parseInt(input.value) + 1;
        }
    });
    
    function addToCart(productId) {
        const quantity = document.getElementById('productQuantity')?.value || 1;
        
        <?php if(!$userId): ?>
        window.location.href = '<?php echo BASE_PATH; ?>members/login.php?redirect=' + 
                              encodeURIComponent(window.location.pathname);
        return;
        <?php endif; ?>
        
        const button = document.querySelector('.btn-add-cart');
        if (button) {
            const originalHtml = button.innerHTML;
            button.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Adding...';
            button.disabled = true;
        }
        
        $.ajax({
            url: 'api/cart.php',
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'add_to_cart',
                product_id: productId,
                quantity: quantity,
                csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
            },
            success: function(response) {
                if (response.success) {
                    alert('Product added to cart successfully!');
                    if (button) {
                        button.innerHTML = originalHtml;
                        button.disabled = false;
                    }
                } else {
                    alert('Error: ' + response.message);
                    if (button) {
                        button.innerHTML = originalHtml;
                        button.disabled = false;
                    }
                }
            },
            error: function() {
                alert('Network error. Please try again.');
                if (button) {
                    button.innerHTML = originalHtml;
                    button.disabled = false;
                }
            }
        });
    }
    
    function buyNow(productId) {
        const quantity = document.getElementById('productQuantity')?.value || 1;
        
        <?php if(!$userId): ?>
        window.location.href = '<?php echo BASE_PATH; ?>members/login.php?redirect=' + 
                              encodeURIComponent(window.location.pathname);
        return;
        <?php endif; ?>
        
        // Add to cart then redirect to checkout
        $.ajax({
            url: 'api/cart.php',
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'add_to_cart',
                product_id: productId,
                quantity: quantity,
                csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
            },
            success: function(response) {
                if (response.success) {
                    window.location.href = 'checkout.php';
                } else {
                    alert('Error: ' + response.message);
                }
            },
            error: function() {
                alert('Network error. Please try again.');
            }
        });
    }
    </script>
</body>
</html>