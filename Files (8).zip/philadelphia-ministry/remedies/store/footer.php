<?php
// Footer component
?>
<!-- Footer -->
<footer class="store-footer">
    <div class="container">
        <div class="row">
            <!-- Logo & Description -->
            <div class="col-lg-4 mb-5 mb-lg-0">
                <a href="index.php" class="footer-logo">
                    <i class="fas fa-heartbeat me-2"></i>Philadelphia Remedies
                </a>
                <p class="mb-4" style="color: rgba(255,255,255,0.8);">
                    Natural healing through traditional remedies and modern wellness practices. 
                    Part of Philadelphia Ministry's holistic health initiative.
                </p>
            </div>
            
            <!-- Quick Links -->
            <div class="col-lg-2 col-md-6 mb-5 mb-lg-0">
                <div class="footer-links">
                    <h5>Shop</h5>
                    <ul>
                        <li><a href="products.php">All Products</a></li>
                        <li><a href="products.php?category=herbs">Herbal Remedies</a></li>
                        <li><a href="products.php?category=oils">Essential Oils</a></li>
                        <li><a href="products.php?category=supplements">Supplements</a></li>
                        <li><a href="products.php?category=teas">Herbal Teas</a></li>
                    </ul>
                </div>
            </div>
            
            <!-- Resources -->
            <div class="col-lg-2 col-md-6 mb-5 mb-lg-0">
                <div class="footer-links">
                    <h5>Resources</h5>
                    <ul>
                        <li><a href="../treatments/">Treatments</a></li>
                        <li><a href="../consultations/">Consultations</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li><a href="faq.php">FAQ</a></li>
                    </ul>
                </div>
            </div>
            
            <!-- Contact -->
            <div class="col-lg-4">
                <div class="footer-contact">
                    <h5>Contact Info</h5>
                    <p><i class="fas fa-map-marker-alt"></i> Philadelphia Ministry, Nairobi, Kenya</p>
                    <p><i class="fas fa-phone"></i> +254 712 345 678</p>
                    <p><i class="fas fa-envelope"></i> remedies@philadelphia-ministry.org</p>
                    <p><i class="fas fa-clock"></i> Mon-Fri: 8:00 AM - 6:00 PM</p>
                </div>
            </div>
        </div>
        
        <!-- Copyright -->
        <div class="footer-bottom">
            <div class="row">
                <div class="col-md-12">
                    <p class="mb-0">
                        &copy; <?php echo date('Y'); ?> Philadelphia Ministry. All rights reserved. | 
                        <a href="privacy.php" style="color: rgba(255,255,255,0.6);">Privacy Policy</a> | 
                        <a href="terms.php" style="color: rgba(255,255,255,0.6);">Terms of Service</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</footer>