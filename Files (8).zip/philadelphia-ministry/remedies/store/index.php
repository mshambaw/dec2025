<?php
// ===== PHP CONFIGURATION - MUST BE AT THE VERY TOP =====
session_start();

// Initialize cart in session if not exists
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Process form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add_to_cart':
                $productId = (int)($_POST['product_id'] ?? 0);
                if ($productId > 0) addToCart($productId);
                break;
            case 'remove_from_cart':
                $productId = (int)($_POST['product_id'] ?? 0);
                if ($productId > 0) removeFromCart($productId);
                break;
            case 'update_quantity':
                $productId = (int)($_POST['product_id'] ?? 0);
                $change = (int)($_POST['change'] ?? 0);
                if ($productId > 0) updateCartQuantity($productId, $change);
                break;
            case 'clear_cart':
                clearCart();
                break;
            case 'submit_order':
                processOrder($_POST);
                break;
            case 'newsletter_subscribe':
                $email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
                if ($email) processNewsletter($email);
                break;
        }
    }
    // Redirect to avoid form resubmission
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// ===== PHP PRODUCT DATA =====
$products = [
    // Spices & Herbs
    [
        'id' => 1,
        'name' => "Organic Cayenne Powder",
        'category' => "spices",
        'price' => 300,
        'originalPrice' => 450,
        'image' => "images/cayenne.jpg",
        'description' => "Pure organic Cayenne powder with powerful anti-inflammatory and circulatory properties.",
        'benefits' => ["Anti-inflammatory", "Circulation Boost", "Joint Health", "Ulcer Support", "Nerve Support"],
        'usage' => "1 tablespoon in the morning with warm water on empty stomach.",
        'ingredients' => "100% Pure Organic Cayenne Pepper",
        'stock' => 15,
        'popular' => true,
        'size' => "100g"
    ],
    [
        'id' => 2,
        'name' => "Premium Cloves Powder",
        'category' => "spices",
        'price' => 300,
        'originalPrice' => 450,
        'image' => "images/cloves.jpg",
        'description' => "Finely ground cloves powder for dental pain relief and digestive support.",
        'benefits' => ["Dental Pain Relief", "Digestive Aid", "Antimicrobial", "Antioxidant", "Respiratory Support"],
        'usage' => "1 teaspoon with warm water before meals.",
        'ingredients' => "Pure Cloves (Syzygium aromaticum)",
        'stock' => 12,
        'popular' => true,
        'size' => "100g"
    ],
    [
        'id' => 3,
        'name' => "Organic Turmeric Powder",
        'category' => "spices",
        'price' => 350,
        'originalPrice' => 500,
        'image' => "images/turmeric.jpg",
        'description' => "Pure organic turmeric powder with high curcumin content.",
        'benefits' => ["Anti-inflammatory", "Antioxidant", "Joint Health", "Brain Health", "Digestive Support"],
        'usage' => "1 teaspoon daily with black pepper and healthy fat for absorption.",
        'ingredients' => "100% Organic Turmeric (Curcuma longa)",
        'stock' => 20,
        'popular' => true,
        'size' => "100g"
    ],
    [
        'id' => 4,
        'name' => "Fresh Ginger Powder",
        'category' => "spices",
        'price' => 250,
        'originalPrice' => 350,
        'image' => "images/ginger.jpg",
        'description' => "Dried ginger root powder for digestive health and nausea relief.",
        'benefits' => ["Nausea Relief", "Digestive Aid", "Anti-inflammatory", "Immune Boost", "Circulation"],
        'usage' => "1-2 teaspoons daily in tea or warm water.",
        'ingredients' => "Pure Ginger Root (Zingiber officinale)",
        'stock' => 18,
        'popular' => false,
        'size' => "100g"
    ],
    [
        'id' => 5,
        'name' => "Cinnamon Powder",
        'category' => "spices",
        'price' => 280,
        'originalPrice' => 400,
        'image' => "images/cinnamon.jpg",
        'description' => "Pure Ceylon cinnamon powder for blood sugar regulation.",
        'benefits' => ["Blood Sugar Support", "Antioxidant", "Anti-inflammatory", "Heart Health", "Brain Function"],
        'usage' => "1/2 to 1 teaspoon daily in food or beverages.",
        'ingredients' => "Pure Ceylon Cinnamon (Cinnamomum verum)",
        'stock' => 16,
        'popular' => false,
        'size' => "100g"
    ],
    // Sweeteners & Foods
    [
        'id' => 6,
        'name' => "Pure Natural Honey",
        'category' => "sweeteners",
        'price' => 500,
        'originalPrice' => 700,
        'image' => "images/honeyp.jpg",
        'description' => "Raw, unfiltered, pure natural honey from Kenyan forests.",
        'benefits' => ["Cough Relief", "Energy Boost", "Ulcer Healing", "Antibacterial", "Wound Healing"],
        'usage' => "1-2 teaspoons daily. Can be used in tea, on toast, or taken straight.",
        'ingredients' => "100% Pure Raw Honey",
        'stock' => 25,
        'popular' => true,
        'size' => "500g"
    ],
    [
        'id' => 7,
        'name' => "Black Seed Oil",
        'category' => "sweeteners",
        'price' => 800,
        'originalPrice' => 1200,
        'image' => "images/black-seed.jpg",
        'description' => "Cold-pressed black seed oil (Nigella sativa) known as the 'seed of blessing'.",
        'benefits' => ["Immune Support", "Anti-inflammatory", "Asthma Relief", "Skin Health", "Digestive Aid"],
        'usage' => "1 teaspoon daily before meals. Can be applied topically for skin conditions.",
        'ingredients' => "100% Cold-pressed Black Seed Oil",
        'stock' => 8,
        'popular' => false,
        'size' => "100ml"
    ],
    // Tinctures & Extracts
    [
        'id' => 8,
        'name' => "Moringa Leaf Tincture",
        'category' => "tinctures",
        'price' => 600,
        'originalPrice' => 900,
        'image' => "images/moringa.jpg",
        'description' => "Alcohol-free moringa leaf extract for energy, nutrition, and detoxification.",
        'benefits' => ["Energy Boost", "Nutrient Dense", "Detox Support", "Anti-aging", "Immune Support"],
        'usage' => "30 drops in water 2-3 times daily before meals.",
        'ingredients' => "Moringa oleifera leaf extract, vegetable glycerin",
        'stock' => 10,
        'popular' => true,
        'size' => "60ml"
    ],
    [
        'id' => 9,
        'name' => "Neem Leaf Tincture",
        'category' => "tinctures",
        'price' => 550,
        'originalPrice' => 800,
        'image' => "images/neem.jpg",
        'description' => "Neem leaf extract for blood purification and skin health.",
        'benefits' => ["Blood Purifier", "Skin Health", "Antimicrobial", "Dental Health", "Immune Support"],
        'usage' => "20-30 drops in water 2 times daily.",
        'ingredients' => "Azadirachta indica leaf extract, vegetable glycerin",
        'stock' => 12,
        'popular' => false,
        'size' => "60ml"
    ],
    // Herbal Teas
    [
        'id' => 10,
        'name' => "Detox Herbal Tea Blend",
        'category' => "teas",
        'price' => 400,
        'originalPrice' => 600,
        'image' => "images/detox-tea.jpg",
        'description' => "Special blend of dandelion, nettle, and burdock root for gentle detoxification.",
        'benefits' => ["Liver Support", "Detoxification", "Kidney Health", "Digestive Aid", "Skin Clearance"],
        'usage' => "Steep 1 teaspoon in hot water for 5-10 minutes. Drink 1-2 cups daily.",
        'ingredients' => "Dandelion root, Nettle leaf, Burdock root, Peppermint",
        'stock' => 15,
        'popular' => true,
        'size' => "50g"
    ],
    [
        'id' => 11,
        'name' => "Immune Support Tea",
        'category' => "teas",
        'price' => 450,
        'originalPrice' => 650,
        'image' => "images/immune-tea.jpg",
        'description' => "Potent blend of echinacea, elderberry, and ginger for immune system strengthening.",
        'benefits' => ["Immune Boost", "Antiviral", "Anti-inflammatory", "Respiratory Support", "Energy"],
        'usage' => "Steep 1 tablespoon in hot water for 10 minutes. Drink at first sign of illness.",
        'ingredients' => "Echinacea, Elderberry, Ginger, Licorice root",
        'stock' => 14,
        'popular' => false,
        'size' => "50g"
    ],
    [
        'id' => 12,
        'name' => "Calming Sleep Tea",
        'category' => "teas",
        'price' => 380,
        'originalPrice' => 550,
        'image' => "images/sleep-tea.jpg",
        'description' => "Gentle blend of chamomile, lavender, and lemon balm for relaxation and restful sleep.",
        'benefits' => ["Sleep Aid", "Stress Relief", "Relaxation", "Anxiety Reduction", "Digestive Calm"],
        'usage' => "Steep 1 teaspoon in hot water for 5 minutes. Drink 30 minutes before bed.",
        'ingredients' => "Chamomile, Lavender, Lemon balm, Passionflower",
        'stock' => 20,
        'popular' => true,
        'size' => "50g"
    ]
];

// ===== PHP FUNCTIONS =====
function formatPrice($price) {
    return 'KES ' . number_format($price);
}

function getCategoryName($category) {
    $names = [
        'spices' => 'Spices & Herbs',
        'sweeteners' => 'Sweeteners & Foods',
        'tinctures' => 'Tinctures & Extracts',
        'teas' => 'Herbal Teas',
        'all' => 'All Products'
    ];
    return $names[$category] ?? $category;
}

function getStockClass($stock) {
    if ($stock > 10) return 'in-stock';
    if ($stock > 0) return 'low-stock';
    return 'out-of-stock';
}

function addToCart($productId) {
    global $products;
    $product = null;
    
    foreach ($products as $p) {
        if ($p['id'] == $productId) {
            $product = $p;
            break;
        }
    }
    
    if (!$product) return;
    
    if ($product['stock'] <= 0) {
        $_SESSION['message'] = ['type' => 'warning', 'text' => "{$product['name']} is out of stock"];
        return;
    }
    
    // Check if product already in cart
    $found = false;
    foreach ($_SESSION['cart'] as &$item) {
        if ($item['productId'] == $productId) {
            if ($item['quantity'] < $product['stock']) {
                $item['quantity']++;
                $found = true;
                $_SESSION['message'] = ['type' => 'success', 'text' => "Added another {$product['name']} to cart"];
            } else {
                $_SESSION['message'] = ['type' => 'warning', 'text' => "Only {$product['stock']} units of '{$product['name']}' available"];
                return;
            }
            break;
        }
    }
    
    if (!$found) {
        $_SESSION['cart'][] = [
            'productId' => $productId,
            'quantity' => 1,
            'addedAt' => date('Y-m-d H:i:s')
        ];
        $_SESSION['message'] = ['type' => 'success', 'text' => "{$product['name']} added to cart"];
    }
}

function removeFromCart($productId) {
    foreach ($_SESSION['cart'] as $key => $item) {
        if ($item['productId'] == $productId) {
            unset($_SESSION['cart'][$key]);
            $_SESSION['cart'] = array_values($_SESSION['cart']); // Re-index array
            $_SESSION['message'] = ['type' => 'info', 'text' => 'Item removed from cart'];
            break;
        }
    }
}

function updateCartQuantity($productId, $change) {
    global $products;
    
    foreach ($_SESSION['cart'] as &$item) {
        if ($item['productId'] == $productId) {
            $product = null;
            foreach ($products as $p) {
                if ($p['id'] == $productId) {
                    $product = $p;
                    break;
                }
            }
            
            $newQuantity = $item['quantity'] + $change;
            
            if ($newQuantity < 1) {
                removeFromCart($productId);
                return;
            }
            
            if ($newQuantity > $product['stock']) {
                $_SESSION['message'] = ['type' => 'warning', 'text' => "Only {$product['stock']} units available"];
                return;
            }
            
            $item['quantity'] = $newQuantity;
            break;
        }
    }
}

function clearCart() {
    $_SESSION['cart'] = [];
    $_SESSION['message'] = ['type' => 'info', 'text' => 'Cart cleared'];
}

function processOrder($data) {
    $name = htmlspecialchars($data['name'] ?? '');
    $phone = htmlspecialchars($data['phone'] ?? '');
    $email = htmlspecialchars($data['email'] ?? '');
    $address = htmlspecialchars($data['address'] ?? '');
    $notes = htmlspecialchars($data['notes'] ?? '');
    
    if (empty($_SESSION['cart'])) {
        $_SESSION['message'] = ['type' => 'warning', 'text' => 'Please add items to your cart before ordering'];
        return;
    }
    
    if (empty($name) || empty($phone) || empty($address)) {
        $_SESSION['message'] = ['type' => 'warning', 'text' => 'Please fill in all required fields'];
        return;
    }
    
    // Calculate total
    $total = 0;
    $orderItems = [];
    global $products;
    
    foreach ($_SESSION['cart'] as $item) {
        foreach ($products as $product) {
            if ($product['id'] == $item['productId']) {
                $itemTotal = $product['price'] * $item['quantity'];
                $total += $itemTotal;
                $orderItems[] = [
                    'product' => $product,
                    'quantity' => $item['quantity'],
                    'total' => $itemTotal
                ];
                break;
            }
        }
    }
    
    // Save order to session
    $_SESSION['last_order'] = [
        'name' => $name,
        'phone' => $phone,
        'email' => $email,
        'address' => $address,
        'notes' => $notes,
        'items' => $orderItems,
        'total' => $total,
        'date' => date('Y-m-d H:i:s')
    ];
    
    // Clear cart
    clearCart();
    
    // Set success message
    $_SESSION['message'] = ['type' => 'success', 'text' => 'Order submitted successfully! We will contact you shortly.'];
    
    // Generate WhatsApp message
    $whatsappMessage = "🌿 NEW ORDER - Philadelphia Remedies\n\n";
    $whatsappMessage .= "Name: $name\n";
    $whatsappMessage .= "Phone: $phone\n";
    $whatsappMessage .= "Email: " . ($email ?: 'Not provided') . "\n";
    $whatsappMessage .= "Address: $address\n\n";
    $whatsappMessage .= "Order Items:\n";
    
    foreach ($orderItems as $item) {
        $whatsappMessage .= "• {$item['product']['name']} ({$item['quantity']} x " . formatPrice($item['product']['price']) . ") = " . formatPrice($item['total']) . "\n";
    }
    
    $whatsappMessage .= "\nTotal: " . formatPrice($total) . "\n\n";
    $whatsappMessage .= "Order Notes: $notes\n\n";
    $whatsappMessage .= "Order Time: " . date('Y-m-d H:i:s');
    
    // Encode for WhatsApp URL
    $encodedMessage = urlencode($whatsappMessage);
    $whatsappUrl = "https://wa.me/+254759172878?text=$encodedMessage";
    
    // Store WhatsApp URL in session
    $_SESSION['whatsapp_url'] = $whatsappUrl;
    
    // Redirect to success page or show success modal
    $_SESSION['order_success'] = true;
}

function processNewsletter($email) {
    // In real app, save to database
    $_SESSION['message'] = ['type' => 'success', 'text' => 'Thank you for subscribing to our newsletter!'];
}

// Calculate cart total
$cartTotal = 0;
$cartCount = 0;
foreach ($_SESSION['cart'] as $item) {
    foreach ($products as $product) {
        if ($product['id'] == $item['productId']) {
            $cartTotal += $product['price'] * $item['quantity'];
            $cartCount += $item['quantity'];
            break;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="Philadelphia MUSDA Remedies - Natural healing through God's remedies. Pure honey, turmeric, cloves, ginger for holistic wellness in Kenya.">
    <meta name="keywords" content="natural remedies, honey, turmeric, cloves, ginger, Kenya, holistic healing, medical missionary">
    <meta name="author" content="Philadelphia Remedies">
    <meta property="og:title" content="Philadelphia Remedies | God's Healing Way">
    <meta property="og:description" content="Natural Remedies for holistic healing in Kenya">
    <meta property="og:image" content="images/rowrems.jpg">
    <meta property="og:url" content="https://yourwebsite.com">
    
    <title>Philadelphia Remedies | God's Healing Way</title>
    
    <!-- External Resources -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    
    <!-- Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-JYK6VW8G8X"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'G-JYK6VW8G8X');
    </script>
    
    <style>
        /* ===== CSS RESET & VARIABLES ===== */
        :root {
            --primary: #2e7d32;
            --primary-light: #4caf50;
            --primary-dark: #1b5e20;
            --secondary: #8d6e63;
            --accent: #ff9800;
            --light: #f1f8e9;
            --dark: #1b5e20;
            --text: #5d4037;
            --gray: #757575;
            --gray-light: #e8f5e9;
            --danger: #d32f2f;
            --success: #388e3c;
            --warning: #f57c00;
            --shadow: 0 8px 25px rgba(30, 60, 30, 0.1);
            --shadow-lg: 0 15px 35px rgba(30, 60, 30, 0.15);
            --radius: 12px;
            --transition: all 0.3s ease;
            --nature-gradient: linear-gradient(135deg, #2e7d32 0%, #8d6e63 100%);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f1f8e9 0%, #e8f5e9 50%, #c8e6c9 100%);
            color: var(--text);
            min-height: 100vh;
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* ===== TYPOGRAPHY ===== */
        h1, h2, h3, h4 {
            font-weight: 700;
            line-height: 1.2;
            color: var(--primary-dark);
        }

        p {
            margin-bottom: 1rem;
        }

        /* ===== ACCESSIBILITY ===== */
        .skip-link {
            position: absolute;
            top: -40px;
            left: 0;
            background: var(--primary);
            color: white;
            padding: 8px 16px;
            text-decoration: none;
            z-index: 1001;
        }

        .skip-link:focus {
            top: 0;
        }

        /* ===== LOADING SPINNER ===== */
        .loading-spinner {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.95);
            z-index: 9999;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        .loading-spinner.active {
            display: flex;
        }

        .spinner {
            width: 60px;
            height: 60px;
            border: 6px solid var(--gray-light);
            border-top: 6px solid var(--primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* ===== HEADER ===== */
        .header {
            background: white;
            box-shadow: 0 4px 30px rgba(30, 60, 30, 0.08);
            position: sticky;
            top: 0;
            z-index: 1000;
            padding: 12px 0;
        }

        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 15px;
            text-decoration: none;
            transition: var(--transition);
        }

        .logo:hover {
            transform: translateY(-2px);
        }

        .logo-icon {
            width: 200px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }

        .logo-image {
            width: 100%;
            height: 100%;
            object-fit: contain;
            transition: var(--transition);
        }

        .logo:hover .logo-image {
            transform: scale(1.05);
        }

        .logo-text {
            font-size: 1.9rem;
            font-weight: 800;
            color: var(--primary-dark);
            background: var(--nature-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            letter-spacing: -0.5px;
        }

        .logo-tagline {
            color: var(--gray);
            font-size: 0.85rem;
            margin-top: 2px;
            font-style: italic;
        }

        /* ===== SEARCH BAR ===== */
        .search-container {
            position: relative;
            flex: 1;
            max-width: 400px;
            margin: 0 30px;
        }

        .search-input-wrapper {
            position: relative;
        }

        #searchInput {
            width: 100%;
            padding: 12px 20px 12px 45px;
            border: 2px solid var(--gray-light);
            border-radius: 30px;
            font-size: 0.95rem;
            background: var(--gray-light);
            transition: var(--transition);
        }

        #searchInput:focus {
            outline: none;
            border-color: var(--primary);
            background: white;
            box-shadow: 0 4px 15px rgba(46, 125, 50, 0.1);
        }

        .search-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
        }

        #searchBtn {
            position: absolute;
            right: 5px;
            top: 50%;
            transform: translateY(-50%);
            background: var(--primary);
            color: white;
            border: none;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            cursor: pointer;
            transition: var(--transition);
        }

        #searchBtn:hover {
            background: var(--primary-dark);
            transform: translateY(-50%) scale(1.1);
        }

        .search-results {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border-radius: var(--radius);
            box-shadow: var(--shadow-lg);
            max-height: 400px;
            overflow-y: auto;
            display: none;
            z-index: 100;
        }

        .search-results.active {
            display: block;
        }

        .search-result-item {
            padding: 15px;
            border-bottom: 1px solid var(--gray-light);
            display: flex;
            align-items: center;
            gap: 15px;
            cursor: pointer;
            transition: var(--transition);
        }

        .search-result-item:hover {
            background: var(--gray-light);
        }

        .search-result-image {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 8px;
        }

        /* ===== NAVIGATION ===== */
        .nav-links {
            display: flex;
            gap: 30px;
            align-items: center;
        }

        .nav-link {
            color: var(--dark);
            text-decoration: none;
            font-weight: 600;
            font-size: 0.95rem;
            transition: var(--transition);
            position: relative;
            padding: 8px 0;
        }

        .nav-link::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary);
            transition: var(--transition);
        }

        .nav-link:hover::after,
        .nav-link.active::after {
            width: 100%;
        }

        .nav-link:hover,
        .nav-link.active {
            color: var(--primary);
        }

        .nav-cta {
            background: var(--nature-gradient);
            color: white;
            padding: 12px 28px;
            border-radius: 30px;
            font-weight: 700;
            text-decoration: none;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.95rem;
        }

        .nav-cta:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(46, 125, 50, 0.3);
        }

        .cart-icon {
            position: relative;
            font-size: 1.4rem;
            color: var(--dark);
            cursor: pointer;
            padding: 10px;
            border-radius: 50%;
            transition: var(--transition);
        }

        .cart-icon:hover {
            background: var(--gray-light);
            transform: scale(1.1);
        }

        .cart-count {
            position: absolute;
            top: 0;
            right: 0;
            background: var(--danger);
            color: white;
            font-size: 0.7rem;
            font-weight: 700;
            min-width: 20px;
            height: 20px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0 5px;
        }

        .mobile-menu-toggle {
            display: none;
            background: none;
            border: none;
            font-size: 1.6rem;
            color: var(--dark);
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            transition: var(--transition);
        }

        .mobile-menu-toggle:hover {
            background: var(--gray-light);
        }

        /* ===== HERO SECTION ===== */
        .hero {
            position: relative;
            padding: 120px 0 80px;
            min-height: 85vh;
            display: flex;
            align-items: center;
            color: white;
            overflow: hidden;
        }

        .hero-background {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
        }

        .hero-bg-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center;
        }

        .hero-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.5));
        }

        .hero-content {
            position: relative;
            z-index: 2;
            text-align: center;
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }

        .hero-title {
            font-size: 4rem;
            font-weight: 800;
            margin-bottom: 25px;
            line-height: 1.1;
            text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.5);
        }

        .hero-subtitle {
            font-size: 1.4rem;
            max-width: 700px;
            margin: 0 auto 50px;
            opacity: 0.95;
            text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.5);
            line-height: 1.7;
        }

        .hero-features {
            display: flex;
            justify-content: center;
            gap: 50px;
            margin-top: 40px;
            flex-wrap: wrap;
        }

        .feature {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5);
            max-width: 150px;
        }

        .feature-icon {
            background: rgba(255, 255, 255, 0.25);
            color: white;
            width: 80px;
            height: 80px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.2rem;
            backdrop-filter: blur(10px);
            border: 2px solid rgba(255, 255, 255, 0.4);
            transition: var(--transition);
        }

        .feature-icon:hover {
            background: rgba(255, 255, 255, 0.35);
            transform: translateY(-8px) scale(1.1);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        }

        .feature span {
            font-weight: 600;
            font-size: 1rem;
        }

        /* ===== SECTION COMMON STYLES ===== */
        .section-title {
            text-align: center;
            font-size: 2.8rem;
            color: var(--primary-dark);
            margin-bottom: 60px;
            position: relative;
            padding-bottom: 20px;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 120px;
            height: 5px;
            background: var(--nature-gradient);
            border-radius: 3px;
        }

        .section-subtitle {
            text-align: center;
            color: var(--gray);
            font-size: 1.2rem;
            max-width: 700px;
            margin: -40px auto 60px;
            line-height: 1.6;
        }

        /* ===== TRUST BADGES ===== */
        .trust-section {
            padding: 60px 0;
            background: white;
        }

        .trust-badges {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 30px;
            margin-top: 40px;
        }

        .badge {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
            text-align: center;
            padding: 30px 20px;
            background: white;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            transition: var(--transition);
        }

        .badge:hover {
            transform: translateY(-10px);
            box-shadow: var(--shadow-lg);
        }

        .badge i {
            font-size: 2.8rem;
            color: var(--primary);
            background: var(--gray-light);
            width: 80px;
            height: 80px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .badge span {
            font-weight: 700;
            color: var(--dark);
            font-size: 1.1rem;
        }

        /* ===== PRODUCTS SECTION ===== */
        .products-section {
            padding: 100px 0;
            background: var(--light);
        }

        .product-controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .sort-filter {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        #sortBy {
            padding: 12px 30px 12px 15px;
            border: 2px solid var(--gray-light);
            border-radius: var(--radius);
            background: white;
            color: var(--text);
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            min-width: 200px;
        }

        #sortBy:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 4px 15px rgba(46, 125, 50, 0.1);
        }

        .price-filter {
            display: flex;
            align-items: center;
            gap: 15px;
            background: white;
            padding: 15px 25px;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
        }

        .price-filter label {
            font-weight: 600;
            color: var(--dark);
        }

        #priceRange {
            width: 200px;
            height: 6px;
            background: var(--gray-light);
            border-radius: 3px;
            outline: none;
            -webkit-appearance: none;
        }

        #priceRange::-webkit-slider-thumb {
            -webkit-appearance: none;
            width: 22px;
            height: 22px;
            background: var(--primary);
            border-radius: 50%;
            cursor: pointer;
            border: 3px solid white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }

        #priceValue {
            font-weight: 700;
            color: var(--primary);
            min-width: 120px;
        }

        .category-filters {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-bottom: 50px;
            flex-wrap: wrap;
        }

        .filter-btn {
            padding: 14px 28px;
            background: white;
            border: 2px solid var(--gray-light);
            border-radius: 30px;
            font-weight: 700;
            color: var(--text);
            cursor: pointer;
            transition: var(--transition);
        }

        .filter-btn:hover,
        .filter-btn.active {
            background: var(--nature-gradient);
            color: white;
            border-color: transparent;
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(46, 125, 50, 0.2);
        }

        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 35px;
            margin-bottom: 50px;
        }

        .product-card {
            background: white;
            border-radius: var(--radius);
            overflow: hidden;
            box-shadow: var(--shadow);
            transition: var(--transition);
            border: 1px solid #e0e0e0;
            position: relative;
            cursor: pointer;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .product-card:hover {
            transform: translateY(-15px);
            box-shadow: var(--shadow-lg);
        }

        .product-badge {
            position: absolute;
            top: 20px;
            left: 20px;
            background: var(--accent);
            color: white;
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 700;
            z-index: 1;
        }

        .product-image-container {
            height: 220px;
            overflow: hidden;
        }

        .product-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: var(--transition);
        }

        .product-card:hover .product-image {
            transform: scale(1.05);
        }

        .product-content {
            padding: 25px;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        }

        .product-category {
            color: var(--primary);
            font-size: 0.9rem;
            font-weight: 700;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .product-title {
            font-size: 1.4rem;
            font-weight: 800;
            color: var(--dark);
            margin-bottom: 12px;
            line-height: 1.3;
        }

        .product-description {
            color: var(--gray);
            font-size: 0.95rem;
            margin-bottom: 20px;
            line-height: 1.5;
            flex-grow: 1;
        }

        .product-benefits {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-bottom: 25px;
        }

        .benefit-tag {
            background: var(--gray-light);
            color: var(--primary);
            padding: 6px 15px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            transition: var(--transition);
        }

        .benefit-tag:hover {
            background: var(--primary);
            color: white;
            transform: translateY(-2px);
        }

        .product-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: auto;
        }

        .product-price {
            font-size: 1.6rem;
            font-weight: 800;
            color: var(--primary);
        }

        .product-price span {
            font-size: 1rem;
            color: var(--gray);
            text-decoration: line-through;
            margin-left: 10px;
            font-weight: 600;
        }

        .add-to-cart {
            background: var(--nature-gradient);
            color: white;
            border: none;
            padding: 14px 30px;
            border-radius: 30px;
            font-weight: 700;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.95rem;
        }

        .add-to-cart:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(46, 125, 50, 0.3);
        }

        .stock-info {
            margin-top: 15px;
            color: var(--gray);
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .stock-info.in-stock {
            color: var(--success);
        }

        .stock-info.low-stock {
            color: var(--warning);
        }

        /* ===== EDUCATION SECTION ===== */
        .education-section {
            padding: 100px 0;
            background: white;
        }

        .education-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 35px;
            margin-top: 40px;
        }

        .education-card {
            background: white;
            border-radius: var(--radius);
            overflow: hidden;
            box-shadow: var(--shadow);
            transition: var(--transition);
            border: 1px solid var(--gray-light);
        }

        .education-card:hover {
            transform: translateY(-10px);
            box-shadow: var(--shadow-lg);
        }

        .education-image {
            height: 200px;
            width: 100%;
            object-fit: cover;
        }

        .education-content {
            padding: 30px;
        }

        .education-content h3 {
            font-size: 1.4rem;
            margin-bottom: 15px;
            color: var(--primary-dark);
        }

        .education-content p {
            color: var(--gray);
            margin-bottom: 20px;
            line-height: 1.6;
        }

        .read-more {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--primary);
            font-weight: 700;
            text-decoration: none;
            transition: var(--transition);
        }

        .read-more:hover {
            color: var(--primary-dark);
            gap: 12px;
        }

        /* ===== HEALTH DISCLAIMER ===== */
        .disclaimer {
            background: linear-gradient(135deg, #fff8e1 0%, #fff3e0 100%);
            padding: 30px 0;
            border-top: 3px solid var(--warning);
            border-bottom: 3px solid var(--warning);
        }

        .disclaimer-content {
            max-width: 900px;
            margin: 0 auto;
            text-align: center;
            position: relative;
            padding: 0 40px;
        }

        .disclaimer-icon {
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            color: var(--warning);
            font-size: 2rem;
        }

        .disclaimer p {
            font-size: 0.95rem;
            color: var(--text);
            line-height: 1.7;
        }

        /* ===== ABOUT SECTION ===== */
        .about-section {
            padding: 100px 0;
            background: var(--light);
        }

        .about-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 60px;
            align-items: center;
        }

        .about-image {
            width: 100%;
            border-radius: var(--radius);
            box-shadow: var(--shadow-lg);
            transition: var(--transition);
        }

        .about-image:hover {
            transform: scale(1.02);
        }

        .about-text h3 {
            font-size: 2.2rem;
            margin-bottom: 25px;
            color: var(--primary-dark);
        }

        .mission-points {
            list-style: none;
            margin: 30px 0;
        }

        .mission-points li {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 20px;
            padding: 20px;
            background: white;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            transition: var(--transition);
        }

        .mission-points li:hover {
            transform: translateX(10px);
            box-shadow: var(--shadow-lg);
        }

        .mission-points i {
            color: var(--primary);
            font-size: 1.4rem;
            min-width: 24px;
        }

        /* ===== IMPACT SECTION ===== */
        .impact-section {
            padding: 100px 0;
            background: white;
        }

        .impact-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 40px;
            margin: 60px 0;
        }

        .stat {
            text-align: center;
            padding: 40px 20px;
            background: var(--light);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            transition: var(--transition);
        }

        .stat:hover {
            transform: translateY(-10px);
            box-shadow: var(--shadow-lg);
            background: white;
        }

        .stat h3 {
            font-size: 3rem;
            color: var(--primary);
            margin-bottom: 15px;
            font-weight: 800;
        }

        .stat p {
            color: var(--dark);
            font-weight: 600;
            font-size: 1.1rem;
        }

        .mission-gallery {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-top: 60px;
        }

        .mission-gallery img {
            width: 100%;
            height: 250px;
            object-fit: cover;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            transition: var(--transition);
        }

        .mission-gallery img:hover {
            transform: scale(1.05);
            box-shadow: var(--shadow-lg);
        }

        /* ===== TESTIMONIALS ===== */
        .testimonials {
            padding: 100px 0;
            background: var(--light);
        }

        .testimonial-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 35px;
        }

        .testimonial-card {
            background: white;
            padding: 40px;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            border-left: 6px solid var(--primary);
            transition: var(--transition);
        }

        .testimonial-card:hover {
            transform: translateY(-10px);
            box-shadow: var(--shadow-lg);
        }

        .testimonial-text {
            font-style: italic;
            color: var(--text);
            margin-bottom: 30px;
            line-height: 1.7;
            font-size: 1.05rem;
            position: relative;
            padding-left: 20px;
        }

        .testimonial-text::before {
            content: '"';
            position: absolute;
            left: 0;
            top: -10px;
            font-size: 4rem;
            color: var(--primary-light);
            opacity: 0.2;
            font-family: Georgia, serif;
        }

        .testimonial-author {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .author-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: var(--nature-gradient);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 1.2rem;
            flex-shrink: 0;
        }

        .author-info h4 {
            margin-bottom: 5px;
            color: var(--dark);
        }

        .author-info span {
            color: var(--gray);
            font-size: 0.9rem;
        }

        /* ===== SOCIAL PROOF ===== */
        .social-proof {
            padding: 60px 0;
            background: white;
        }

        .reviews {
            display: flex;
            justify-content: center;
            gap: 50px;
            flex-wrap: wrap;
        }

        .review-platform {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 25px 40px;
            background: var(--light);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            transition: var(--transition);
        }

        .review-platform:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .review-platform i {
            font-size: 2.5rem;
            color: var(--primary);
        }

        .stars {
            color: #ffc107;
            font-size: 1.2rem;
            letter-spacing: 2px;
        }

        .review-platform span {
            font-weight: 600;
            color: var(--dark);
            font-size: 1.1rem;
        }

        /* ===== NEWSLETTER ===== */
        .newsletter-section {
            padding: 80px 0;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            text-align: center;
        }

        .newsletter {
            max-width: 600px;
            margin: 0 auto;
        }

        .newsletter h3 {
            font-size: 2.2rem;
            margin-bottom: 20px;
            color: white;
        }

        .newsletter p {
            font-size: 1.1rem;
            margin-bottom: 40px;
            opacity: 0.9;
        }

        #newsletterForm {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        #newsletterForm input {
            flex: 1;
            min-width: 250px;
            padding: 18px 25px;
            border: none;
            border-radius: 30px;
            font-size: 1rem;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            transition: var(--transition);
        }

        #newsletterForm input:focus {
            outline: none;
            background: rgba(255, 255, 255, 0.2);
        }

        #newsletterForm input::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }

        #newsletterForm button {
            padding: 18px 40px;
            background: white;
            color: var(--primary);
            border: none;
            border-radius: 30px;
            font-weight: 700;
            cursor: pointer;
            transition: var(--transition);
            font-size: 1rem;
        }

        #newsletterForm button:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        }

        .privacy-note {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        /* ===== CONTACT SECTION ===== */
        .contact-section {
            padding: 100px 0;
            background: var(--light);
        }

        .contact-form {
            max-width: 700px;
            margin: 0 auto;
            background: white;
            padding: 50px;
            border-radius: var(--radius);
            box-shadow: var(--shadow-lg);
        }

        .form-group {
            margin-bottom: 30px;
        }

        .form-group label {
            display: block;
            margin-bottom: 12px;
            font-weight: 700;
            color: var(--dark);
            font-size: 1rem;
        }

        .form-control {
            width: 100%;
            padding: 18px 25px;
            border: 2px solid var(--gray-light);
            border-radius: var(--radius);
            font-size: 1rem;
            transition: var(--transition);
            background: white;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 8px 20px rgba(46, 125, 50, 0.1);
        }

        .submit-btn {
            width: 100%;
            padding: 20px;
            background: var(--nature-gradient);
            color: white;
            border: none;
            border-radius: var(--radius);
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
        }

        .submit-btn:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(46, 125, 50, 0.3);
        }

        /* ===== MODALS ===== */
        .cart-modal {
            position: fixed;
            top: 0;
            right: -450px;
            width: 420px;
            height: 100vh;
            background: white;
            box-shadow: -10px 0 40px rgba(0,0,0,0.15);
            transition: right 0.4s ease;
            z-index: 1001;
            padding: 40px;
            overflow-y: auto;
        }

        .cart-modal.open {
            right: 0;
        }

        .cart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
        }

        .cart-header h3 {
            font-size: 1.8rem;
        }

        .cart-items {
            margin-bottom: 40px;
        }

        .cart-item {
            display: flex;
            align-items: center;
            gap: 20px;
            padding: 20px;
            background: var(--light);
            border-radius: var(--radius);
            margin-bottom: 20px;
            transition: var(--transition);
        }

        .cart-item:hover {
            transform: translateX(5px);
            box-shadow: var(--shadow);
        }

        .cart-item-image {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 12px;
        }

        .cart-item-details {
            flex-grow: 1;
        }

        .cart-item-title {
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--dark);
        }

        .cart-item-price {
            color: var(--primary);
            font-weight: 700;
            font-size: 1.1rem;
        }

        .cart-item-controls {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-top: 10px;
        }

        .quantity-btn {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: white;
            border: 2px solid var(--gray-light);
            color: var(--text);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
        }

        .quantity-btn:hover {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .cart-item-quantity {
            font-weight: 700;
            min-width: 20px;
            text-align: center;
        }

        .cart-item-remove {
            color: var(--danger);
            background: none;
            border: none;
            cursor: pointer;
            font-size: 1.3rem;
            padding: 5px;
            border-radius: 5px;
            transition: var(--transition);
        }

        .cart-item-remove:hover {
            background: rgba(211, 47, 47, 0.1);
        }

        .cart-total {
            text-align: right;
            font-size: 1.5rem;
            font-weight: 800;
            margin: 30px 0;
            color: var(--primary-dark);
            padding-top: 20px;
            border-top: 2px solid var(--gray-light);
        }

        .cart-actions {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .cart-action-btn {
            padding: 20px;
            border-radius: var(--radius);
            font-weight: 700;
            cursor: pointer;
            transition: var(--transition);
            font-size: 1.1rem;
        }

        .checkout-btn {
            background: var(--nature-gradient);
            color: white;
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
        }

        .checkout-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(46, 125, 50, 0.3);
        }

        .continue-shopping {
            background: transparent;
            border: 3px solid var(--primary);
            color: var(--primary);
        }

        .continue-shopping:hover {
            background: var(--primary);
            color: white;
        }

        .product-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 1002;
            padding: 20px;
        }

        .product-modal.open {
            display: flex;
            animation: fadeIn 0.3s ease;
        }

        .product-modal-content {
            background: white;
            max-width: 900px;
            width: 100%;
            max-height: 90vh;
            overflow-y: auto;
            border-radius: 20px;
            padding: 50px;
            position: relative;
            animation: slideUp 0.4s ease;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .close-modal {
            position: absolute;
            top: 25px;
            right: 25px;
            background: var(--gray-light);
            border: none;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            font-size: 1.5rem;
            color: var(--gray);
            cursor: pointer;
            z-index: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
        }

        .close-modal:hover {
            background: var(--primary);
            color: white;
            transform: rotate(90deg);
        }

        .product-modal-body {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 50px;
        }

        /* ===== FOOTER ===== */
        .footer {
            background: var(--primary-dark);
            color: white;
            padding: 80px 0 40px;
        }

        .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 50px;
            margin-bottom: 60px;
        }

        .footer-section h4 {
            font-size: 1.4rem;
            margin-bottom: 25px;
            color: white;
            position: relative;
            padding-bottom: 15px;
        }

        .footer-section h4::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50px;
            height: 3px;
            background: var(--primary-light);
        }

        .footer-links {
            list-style: none;
        }

        .footer-links li {
            margin-bottom: 15px;
        }

        .footer-links a {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        .footer-links a:hover {
            color: white;
            padding-left: 10px;
        }

        .social-links {
            display: flex;
            gap: 20px;
            margin-top: 30px;
        }

        .social-links a {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
            font-size: 1.2rem;
        }

        .social-links a:hover {
            background: var(--primary-light);
            transform: translateY(-5px);
        }

        .legal-links {
            display: flex;
            justify-content: center;
            gap: 40px;
            margin-top: 40px;
            flex-wrap: wrap;
        }

        .legal-links a {
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            font-size: 0.9rem;
            transition: var(--transition);
        }

        .legal-links a:hover {
            color: white;
        }

        .copyright {
            text-align: center;
            padding-top: 40px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9rem;
            margin-top: 40px;
        }

        /* ===== RESPONSIVE STYLES ===== */
        @media (max-width: 1200px) {
            .hero-title {
                font-size: 3.5rem;
            }
            
            .section-title {
                font-size: 2.5rem;
            }
        }

        @media (max-width: 992px) {
            .search-container {
                order: 3;
                max-width: 100%;
                margin: 20px 0 0;
            }
            
            .nav-container {
                gap: 20px;
            }
            
            .hero-title {
                font-size: 3rem;
            }
            
            .about-content {
                grid-template-columns: 1fr;
                gap: 40px;
            }
            
            .product-modal-body {
                grid-template-columns: 1fr;
                gap: 30px;
            }
        }

        @media (max-width: 768px) {
            .mobile-menu-toggle {
                display: block;
            }
            
            .nav-links {
                display: none;
                position: fixed;
                top: 80px;
                left: 0;
                width: 100%;
                background: white;
                flex-direction: column;
                padding: 30px;
                box-shadow: 0 15px 30px rgba(0,0,0,0.1);
                gap: 25px;
                z-index: 999;
            }
            
            .nav-links.active {
                display: flex;
            }
            
            .hero {
                padding: 80px 0 60px;
                min-height: 70vh;
            }
            
            .hero-title {
                font-size: 2.5rem;
            }
            
            .hero-subtitle {
                font-size: 1.1rem;
                margin-bottom: 40px;
            }
            
            .hero-features {
                gap: 30px;
            }
            
            .feature-icon {
                width: 70px;
                height: 70px;
                font-size: 2rem;
            }
            
            .product-controls {
                flex-direction: column;
                align-items: stretch;
            }
            
            .sort-filter {
                flex-direction: column;
            }
            
            #sortBy {
                min-width: 100%;
            }
            
            .price-filter {
                justify-content: space-between;
            }
            
            .products-grid {
                grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
                gap: 25px;
            }
            
            .testimonial-grid {
                grid-template-columns: 1fr;
            }
            
            .cart-modal {
                width: 100%;
                right: -100%;
            }
            
            .product-modal-content {
                padding: 30px;
            }
            
            .logo-icon {
                width: 180px;
                height: 50px;
            }
            
            .logo-text {
                font-size: 1.6rem;
            }
            
            .section-title {
                font-size: 2rem;
            }
            
            .impact-stats {
                grid-template-columns: repeat(2, 1fr);
                gap: 20px;
            }
            
            .stat h3 {
                font-size: 2.5rem;
            }
            
            .newsletter h3 {
                font-size: 1.8rem;
            }
            
            #newsletterForm {
                flex-direction: column;
            }
            
            #newsletterForm input {
                min-width: 100%;
            }
        }

        @media (max-width: 576px) {
            .hero-title {
                font-size: 2rem;
            }
            
            .hero-subtitle {
                font-size: 1rem;
            }
            
            .hero-features {
                gap: 20px;
            }
            
            .feature-icon {
                width: 60px;
                height: 60px;
                font-size: 1.8rem;
            }
            
            .products-grid {
                grid-template-columns: 1fr;
            }
            
            .product-price {
                font-size: 1.4rem;
            }
            
            .add-to-cart {
                padding: 12px 20px;
                font-size: 0.9rem;
            }
            
            .section-title {
                font-size: 1.8rem;
            }
            
            .impact-stats {
                grid-template-columns: 1fr;
            }
            
            .mission-gallery {
                grid-template-columns: 1fr;
            }
            
            .contact-form {
                padding: 30px 20px;
            }
            
            .education-grid {
                grid-template-columns: 1fr;
            }
            
            .trust-badges {
                grid-template-columns: 1fr;
            }
        }

        /* ===== ANIMATIONS ===== */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        /* ===== UTILITY CLASSES ===== */
        .text-center {
            text-align: center;
        }

        .mt-20 { margin-top: 20px; }
        .mt-30 { margin-top: 30px; }
        .mt-40 { margin-top: 40px; }
        .mt-50 { margin-top: 50px; }
        .mb-20 { margin-bottom: 20px; }
        .mb-30 { margin-bottom: 30px; }
        .mb-40 { margin-bottom: 40px; }
        .mb-50 { margin-bottom: 50px; }

        /* ===== MESSAGE NOTIFICATION ===== */
        .message-notification {
            position: fixed;
            top: 100px;
            right: 20px;
            z-index: 1003;
            padding: 15px 25px;
            border-radius: var(--radius);
            color: white;
            box-shadow: var(--shadow);
            animation: slideIn 0.4s ease;
            max-width: 400px;
        }
        
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    </style>
</head>
<body>
    <!-- Skip to Main Content -->
    <a href="#main-content" class="skip-link">Skip to main content</a>

    <!-- Loading Spinner -->
    <div class="loading-spinner" id="loadingSpinner">
        <div class="spinner"></div>
        <p style="margin-top: 20px; color: var(--primary); font-weight: 600;">Loading natural remedies...</p>
    </div>

    <!-- Header -->
    <header class="header">
        <div class="container nav-container">
            <a href="index.php" class="logo">
                <div class="logo-icon">
                    <img src="images/logo.png" alt="Philadelphia Remedies Logo" class="logo-image">
                </div>
                <div>
                    <div class="logo-text">Philadelphia Remedies</div>
                    <div class="logo-tagline">God's Remedies Cleanse The System.</div>
                </div>
            </a>

            <!-- Search Bar -->
            <div class="search-container">
                <div class="search-input-wrapper">
                    <i class="fas fa-search search-icon"></i>
                    <input type="text" id="searchInput" placeholder="Search remedies...">
                    <button id="searchBtn" aria-label="Search"><i class="fas fa-search"></i></button>
                </div>
                <div class="search-results" id="searchResults"></div>
            </div>

            <!-- Mobile Menu Toggle -->
            <button class="mobile-menu-toggle" id="mobileMenuToggle" aria-label="Toggle navigation menu">
                <i class="fas fa-bars"></i>
            </button>

            <!-- Navigation -->
            <nav class="nav-links">
                <a href="#home" class="nav-link active"><i class="fas fa-home"></i> Home</a>
                <a href="#products" class="nav-link"><i class="fas fa-leaf"></i> Remedies</a>
                <a href="#education" class="nav-link"><i class="fas fa-book-medical"></i> Learn</a>
                <a href="#about" class="nav-link"><i class="fas fa-hand-holding-heart"></i> Mission</a>
                <a href="#testimonials" class="nav-link"><i class="fas fa-comment-medical"></i> Stories</a>
                <a href="#contact" class="nav-link"><i class="fas fa-shopping-cart"></i> Order</a>
                <a href="donate.php" class="nav-cta">
                    <i class="fas fa-heart"></i> Support Mission
                </a>
                <div class="cart-icon" id="cartToggle" aria-label="View shopping cart">
                    <i class="fas fa-shopping-cart"></i>
                    <span class="cart-count" id="cartCount"><?php echo $cartCount; ?></span>
                </div>
            </nav>
        </div>
    </header>

    <!-- Display Messages -->
    <?php if (isset($_SESSION['message'])): ?>
        <div class="message-notification" style="background: <?php 
            echo $_SESSION['message']['type'] == 'success' ? 'var(--success)' : 
                ($_SESSION['message']['type'] == 'warning' ? 'var(--warning)' : 
                ($_SESSION['message']['type'] == 'error' ? 'var(--danger)' : 'var(--primary)')); 
        ?>;">
            <i class="fas fa-<?php 
                echo $_SESSION['message']['type'] == 'success' ? 'check-circle' : 
                    ($_SESSION['message']['type'] == 'warning' ? 'exclamation-triangle' : 
                    ($_SESSION['message']['type'] == 'error' ? 'times-circle' : 'info-circle')); 
            ?>"></i>
            <?php echo $_SESSION['message']['text']; ?>
        </div>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <!-- Order Success Modal -->
    <?php if (isset($_SESSION['order_success']) && $_SESSION['order_success']): ?>
        <div class="product-modal open" id="orderSuccessModal">
            <div class="product-modal-content">
                <div style="text-align: center; padding: 40px;">
                    <i class="fas fa-check-circle" style="font-size: 5rem; color: var(--success); margin-bottom: 30px;"></i>
                    <h3 style="color: var(--primary-dark); margin-bottom: 20px; font-size: 1.8rem;">Order Submitted Successfully!</h3>
                    <p style="color: var(--text); margin-bottom: 25px; line-height: 1.6;">
                        Thank you for your order! We'll contact you on WhatsApp shortly to confirm your order details and arrange delivery.
                    </p>
                    <p style="font-size: 1.4rem; font-weight: 800; color: var(--primary); margin-bottom: 40px;">
                        Order Total: <?php echo formatPrice($_SESSION['last_order']['total'] ?? 0); ?>
                    </p>
                    <div style="display: flex; gap: 15px; justify-content: center; flex-wrap: wrap;">
                        <a href="<?php echo $_SESSION['whatsapp_url'] ?? '#'; ?>" target="_blank" 
                           style="padding: 16px 40px; background: var(--success); color: white; border: none; border-radius: 30px; cursor: pointer; font-weight: 700; font-size: 1.1rem; text-decoration: none; transition: var(--transition);">
                            <i class="fab fa-whatsapp"></i> Open WhatsApp
                        </a>
                        <button onclick="document.getElementById('orderSuccessModal').classList.remove('open')" 
                                style="padding: 16px 40px; background: var(--primary); color: white; border: none; border-radius: 30px; cursor: pointer; font-weight: 700; font-size: 1.1rem; transition: var(--transition);">
                            Continue Shopping
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <?php unset($_SESSION['order_success']); ?>
    <?php endif; ?>

    <!-- Main Content -->
    <main id="main-content">
        <!-- Hero Section -->
        <section class="hero" id="home">
            <div class="hero-background">
                <img src="images/rowrems.jpg" alt="Natural Remedies Collection" class="hero-bg-image">
                <div class="hero-overlay"></div>
            </div>
            <div class="container hero-content">
                <h1 class="hero-title">God's Healing Way</h1>
                <p class="hero-subtitle">The only hope of better things is in the education of the people in right principles. Let physicians teach the people that restorative power is not in drugs, but in nature. Disease is an effort of nature to free the system from conditions that result from a violation of the laws of health. In case of sickness, the cause should be ascertained. Unhealthful conditions should be changed, wrong habits corrected. Then nature is to be assisted in her effort to expel impurities and to re-establish right conditions in the system.  MH 127</p>
                
                <div class="hero-features">
                    <div class="feature">
                        <div class="feature-icon">
                            <i class="fas fa-seedling"></i>
                        </div>
                        <span>100% Organic</span>
                    </div>
                    <div class="feature">
                        <div class="feature-icon">
                            <i class="fas fa-hand-holding-heart"></i>
                        </div>
                        <span>Mission Supported</span>
                    </div>
                    <div class="feature">
                        <div class="feature-icon">
                            <i class="fas fa-shipping-fast"></i>
                        </div>
                        <span>Free Delivery</span>
                    </div>
                    <div class="feature">
                        <div class="feature-icon">
                            <i class="fas fa-certificate"></i>
                        </div>
                        <span>Quality Assured</span>
                    </div>
                </div>
            </div>
        </section>

        <!-- Trust Badges -->
        <section class="trust-section">
            <div class="container">
                <h2 class="section-title">Why Trust Us</h2>
                <p class="section-subtitle">Committed to excellence in natural healing and supporting medical missions</p>
                
                <div class="trust-badges">
                    <div class="badge">
                        <i class="fas fa-award"></i>
                        <span>Certified Organic</span>
                    </div>
                    <div class="badge">
                        <i class="fas fa-shield-alt"></i>
                        <span>Quality Guaranteed</span>
                    </div>
                    <div class="badge">
                        <i class="fas fa-truck"></i>
                        <span>Free Local Delivery</span>
                    </div>
                    <div class="badge">
                        <i class="fas fa-hand-holding-heart"></i>
                        <span>Mission Supported</span>
                    </div>
                </div>
            </div>
        </section>

        <!-- Products Section -->
        <section class="products-section" id="products">
            <div class="container">
                <h2 class="section-title">Our Natural Remedies</h2>
                <p class="section-subtitle">Carefully sourced, ethically harvested, and prepared with prayer</p>

                <!-- Product Controls -->
                <div class="product-controls">
                    <div class="sort-filter">
                        <select id="sortBy">
                            <option value="default">Sort by: Recommended</option>
                            <option value="price-low">Price: Low to High</option>
                            <option value="price-high">Price: High to Low</option>
                            <option value="name">Name A-Z</option>
                            <option value="popular">Most Popular</option>
                        </select>
                        
                        <div class="price-filter">
                            <label>Price Range:</label>
                            <input type="range" id="priceRange" min="0" max="5000" value="5000">
                            <span id="priceValue">KES 0 - 5000</span>
                        </div>
                    </div>
                </div>

                <!-- Category Filters -->
                <div class="category-filters">
                    <button class="filter-btn active" data-category="all">All Products</button>
                    <button class="filter-btn" data-category="spices">Spices & Herbs</button>
                    <button class="filter-btn" data-category="sweeteners">Sweeteners & Foods</button>
                    <button class="filter-btn" data-category="tinctures">Tinctures & Extracts</button>
                    <button class="filter-btn" data-category="teas">Herbal Teas</button>
                </div>

                <!-- Products Grid -->
                <div class="products-grid" id="productsGrid">
                    <?php foreach ($products as $product): ?>
                    <div class="product-card" data-id="<?php echo $product['id']; ?>">
                        <?php if ($product['originalPrice'] > $product['price']): ?>
                            <div class="product-badge">Save <?php echo formatPrice($product['originalPrice'] - $product['price']); ?></div>
                        <?php endif; ?>
                        <?php if ($product['popular']): ?>
                            <div class="product-badge" style="left: auto; right: 20px; background: var(--primary);">Popular</div>
                        <?php endif; ?>
                        
                        <div class="product-image-container">
                            <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>" class="product-image" loading="lazy" onerror="this.onerror=null; this.src='data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"400\" height=\"300\" viewBox=\"0 0 400 300\"><rect width=\"400\" height=\"300\" fill=\"%23e8f5e9\"/><text x=\"50%\" y=\"50%\" font-family=\"Arial\" font-size=\"16\" fill=\"%232e7d32\" text-anchor=\"middle\" dy=\".3em\"><?php echo urlencode($product['name']); ?></text></svg>'">
                        </div>
                        
                        <div class="product-content">
                            <div class="product-category"><?php echo getCategoryName($product['category']); ?></div>
                            <h3 class="product-title"><?php echo $product['name']; ?></h3>
                            <p class="product-description"><?php echo $product['description']; ?></p>
                            
                            <div class="product-benefits">
                                <?php foreach (array_slice($product['benefits'], 0, 3) as $benefit): ?>
                                    <span class="benefit-tag"><?php echo $benefit; ?></span>
                                <?php endforeach; ?>
                            </div>
                            
                            <div class="product-footer">
                                <div class="product-price">
                                    <?php echo formatPrice($product['price']); ?>
                                    <?php if ($product['originalPrice'] > $product['price']): ?>
                                        <span><?php echo formatPrice($product['originalPrice']); ?></span>
                                    <?php endif; ?>
                                </div>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="add_to_cart">
                                    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                    <button type="submit" class="add-to-cart" aria-label="Add <?php echo $product['name']; ?> to cart">
                                        <i class="fas fa-cart-plus"></i> Add
                                    </button>
                                </form>
                            </div>
                            
                            <div class="stock-info <?php echo getStockClass($product['stock']); ?>">
                                <i class="fas fa-box"></i> 
                                <?php 
                                if ($product['stock'] > 10) echo 'In Stock';
                                elseif ($product['stock'] > 0) echo 'Only ' . $product['stock'] . ' left';
                                else echo 'Out of Stock';
                                ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <!-- Health Disclaimer -->
        <div class="disclaimer">
            <div class="container">
                <div class="disclaimer-content">
                    <i class="fas fa-exclamation-circle disclaimer-icon"></i>
                    <p><strong>Education in health principles was never more needed than now. Notwithstanding the wonderful progress in so many lines relating to the comforts and conveniences of life, even to sanitary matters and to the treatment of disease, the decline in physical vigor and power of endurance is alarming. It demands the attention of all who have at heart the well-being of their fellow men.</strong></p>
                </div>
            </div>
        </div>

        <!-- Education Section -->
        <section class="education-section" id="education">
            <div class="container">
                <h2 class="section-title">Learn About Natural Healing</h2>
                <p class="section-subtitle">Empowering knowledge for your wellness journey</p>
                
                <div class="education-grid">
                    <article class="education-card">
                        <img src="images/herbal-guide.jpg" alt="Herbal Guide" class="education-image">
                        <div class="education-content">
                            <h3>Beginner's Guide to Herbs</h3>
                            <p>Learn how to safely incorporate medicinal herbs into your daily routine. Discover the basics of herbalism and God's design for natural healing.</p>
                            <a href="guide.php" class="read-more">
                                Read More <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </article>
                    
                    <article class="education-card">
                        <img src="images/detox.jpg" alt="Natural Detox" class="education-image">
                        <div class="education-content">
                            <h3>Natural Detox Methods</h3>
                            <p>Safe and effective ways to cleanse your body naturally. Learn about God's original plan for cleansing and rejuvenation through simple practices.</p>
                            <a href="detox.php" class="read-more">
                                Read More <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </article>
                    
                    <article class="education-card">
                        <img src="images/immune.jpg" alt="Immune System" class="education-image">
                        <div class="education-content">
                            <h3>Boosting Immunity Naturally</h3>
                            <p>Strengthen your immune system with God's remedies. Learn how to support your body's natural defenses through diet, herbs, and lifestyle.</p>
                            <a href="immunity.php" class="read-more">
                                Read More <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </article>
                </div>
            </div>
        </section>

        <!-- About Section -->
        <section class="about-section" id="about">
            <div class="container">
                <div class="about-content">
                    <img src="images/mitaboni.jpg" alt="Medical Missionary Work" class="about-image">
                    <div class="about-text">
                        <h3>Medical Missionary Work</h3>
                        <p>Medical missionary work—Christlike ministry for the suffering—this is the work that will remove the mist of ignorance and superstition which for so long has hung over the Southern field. Ms 86, 1901.</p>
                        
                        <ul class="mission-points">
                            <li>
                                <i class="fas fa-check-circle"></i>
                                <div>
                                    <strong>Ethically Sourced</strong>
                                    <p>All products wildcrafted or organic farmed with care</p>
                                </div>
                            </li>
                            <li>
                                <i class="fas fa-check-circle"></i>
                                <div>
                                    <strong>Mission Support</strong>
                                    <p>100% of profits support medical missionary work</p>
                                </div>
                            </li>
                            <li>
                                <i class="fas fa-check-circle"></i>
                                <div>
                                    <strong>God's Healing Way</strong>
                                    <p>Following the eight natural remedies for true healing</p>
                                </div>
                            </li>
                            <li>
                                <i class="fas fa-check-circle"></i>
                                <div>
                                    <strong>Sustainable Practices</strong>
                                    <p>Eco-friendly packaging and sustainable harvesting</p>
                                </div>
                            </li>
                        </ul>
                        
                        <p>Our team consists of trained medical missionaries from trusted institutions, dedicated to providing Christ-centered holistic treatments to God's glory.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Impact Section -->
        <section class="impact-section">
            <div class="container">
                <h2 class="section-title">Your Purchase Makes a Difference</h2>
                <p class="section-subtitle">Every purchase supports medical missionary work in Kenya</p>
                
                <div class="impact-stats">
                    <div class="stat">
                        <h3>KES 50,000+</h3>
                        <p>Donated to Medical Missions</p>
                    </div>
                    <div class="stat">
                        <h3>200+</h3>
                        <p>Families Helped</p>
                    </div>
                    <div class="stat">
                        <h3>15+</h3>
                        <p>Communities Reached</p>
                    </div>
                    <div class="stat">
                        <h3>500+</h3>
                        <p>Health Consultations</p>
                    </div>
                </div>
                
                <div class="mission-gallery">
                    <img src="images/mission1.jpg" alt="Medical Missionary Training" loading="lazy">
                    <img src="images/mission2.jpg" alt="Community Health Outreach" loading="lazy">
                    <img src="images/mission3.jpg" alt="Health Education Workshop" loading="lazy">
                </div>
            </div>
        </section>

        <!-- Testimonials -->
        <section class="testimonials" id="testimonials">
            <div class="container">
                <h2 class="section-title">Healing Stories</h2>
                <p class="section-subtitle">Real experiences from people who found healing through natural remedies</p>
                
                <div class="testimonial-grid">
                    <div class="testimonial-card">
                        <p class="testimonial-text">"The immune support tincture helped me recover from a persistent cough when modern medicine failed. I'm now a believer in natural healing! The cayenne powder has been amazing for my circulation too."</p>
                        <div class="testimonial-author">
                            <div class="author-avatar">SM</div>
                            <div class="author-info">
                                <h4>Shosho</h4>
                                <span>Makuchi, Kenya</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="testimonial-card">
                        <p class="testimonial-text">"Knowing my purchase supports medical missions gives me double joy. The pain relief salve works wonders for my arthritis. The ginger tea has completely transformed my digestion issues."</p>
                        <div class="testimonial-author">
                            <div class="author-avatar">JK</div>
                            <div class="author-info">
                                <h4>James K.</h4>
                                <span>Makuchi, Kenya</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="testimonial-card">
                        <p class="testimonial-text">"Your remedies and methods have been effective in helping me overcome addiction from narcotics. I really see great improvements. The detox tea and counseling helped me through withdrawal."</p>
                        <div class="testimonial-author">
                            <div class="author-avatar">FM</div>
                            <div class="author-info">
                                <h4>Festus Musembi</h4>
                                <span>Makuchi, Kenya</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Social Proof -->
        <section class="social-proof">
            <div class="container">
                <h2 class="section-title">Trusted by Many</h2>
                <div class="reviews">
                    <div class="review-platform">
                        <i class="fab fa-google"></i>
                        <div class="stars">★★★★★</div>
                        <span>4.9/5 (124 reviews)</span>
                    </div>
                    <div class="review-platform">
                        <i class="fas fa-comment-alt"></i>
                        <div class="stars">★★★★★</div>
                        <span>98% Satisfaction Rate</span>
                    </div>
                    <div class="review-platform">
                        <i class="fas fa-users"></i>
                        <span>500+ Happy Customers</span>
                    </div>
                </div>
            </div>
        </section>

        <!-- Newsletter -->
        <section class="newsletter-section">
            <div class="container">
                <div class="newsletter">
                    <h3>Join Our Healing Community</h3>
                    <p>Get health tips, new product updates, mission stories, and exclusive offers delivered to your inbox</p>
                    <form id="newsletterForm" method="POST">
                        <input type="hidden" name="action" value="newsletter_subscribe">
                        <input type="email" name="email" placeholder="Your email address" required>
                        <button type="submit">Subscribe</button>
                    </form>
                    <p class="privacy-note">We respect your privacy. Unsubscribe at any time.</p>
                </div>
            </div>
        </section>

        <!-- Contact Section -->
        <section class="contact-section" id="contact">
            <div class="container">
                <h2 class="section-title">Order & Consultation</h2>
                <p class="section-subtitle">Place your order or request a personalized health consultation</p>
                
                <div class="contact-form">
                    <form id="orderForm" method="POST">
                        <input type="hidden" name="action" value="submit_order">
                        
                        <div class="form-group">
                            <label for="name">Full Name *</label>
                            <input type="text" id="name" name="name" class="form-control" required value="<?php echo $_SESSION['last_order']['name'] ?? ''; ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="phone">Phone Number *</label>
                            <input type="tel" id="phone" name="phone" class="form-control" placeholder="07XX XXX XXX" required value="<?php echo $_SESSION['last_order']['phone'] ?? ''; ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" id="email" name="email" class="form-control" placeholder="optional@example.com" value="<?php echo $_SESSION['last_order']['email'] ?? ''; ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="address">Delivery Address *</label>
                            <textarea id="address" name="address" class="form-control" rows="3" required placeholder="Your complete delivery address"><?php echo $_SESSION['last_order']['address'] ?? ''; ?></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="notes">Order Notes / Health Concerns</label>
                            <textarea id="notes" name="notes" class="form-control" rows="4" placeholder="List products you want to order or describe health concerns for personalized recommendations..."><?php echo $_SESSION['last_order']['notes'] ?? ''; ?></textarea>
                        </div>
                        
                        <button type="submit" class="submit-btn">
                            <i class="fas fa-paper-plane"></i> Submit Order Request
                        </button>
                    </form>
                </div>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-section">
                    <h4>Philadelphia Remedies</h4>
                    <p>Natural healing through God's remedies. Supporting medical missionary work in Kenya through holistic wellness products.</p>
                    <div class="social-links">
                        <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                        <a href="https://wa.me/+254759172878" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>
                        <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                        <a href="#" aria-label="YouTube"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul class="footer-links">
                        <li><a href="#home"><i class="fas fa-chevron-right"></i> Home</a></li>
                        <li><a href="#products"><i class="fas fa-chevron-right"></i> All Products</a></li>
                        <li><a href="#education"><i class="fas fa-chevron-right"></i> Health Education</a></li>
                        <li><a href="#about"><i class="fas fa-chevron-right"></i> Our Mission</a></li>
                        <li><a href="#testimonials"><i class="fas fa-chevron-right"></i> Testimonials</a></li>
                        <li><a href="#contact"><i class="fas fa-chevron-right"></i> Contact Us</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4>Contact Info</h4>
                    <ul class="footer-links">
                        <li><a href="tel:+254759172878"><i class="fas fa-phone"></i> +254 759 172 878</a></li>
                        <li><a href="https://wa.me/+254759172878"><i class="fab fa-whatsapp"></i> WhatsApp Chat</a></li>
                        <li><a href="#"><i class="fas fa-map-marker-alt"></i> Maseno, Kenya</a></li>
                        <li><a href="#"><i class="fas fa-clock"></i> Sun-Fri: 8AM-6PM</a></li>
                        <li><a href="mailto:philadelphiamusda@gmail.com"><i class="fas fa-envelope"></i> philadelphiamusda@gmail.com</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4>Product Categories</h4>
                    <ul class="footer-links">
                        <li><a href="#products" data-category="spices"><i class="fas fa-pepper-hot"></i> Spices & Herbs</a></li>
                        <li><a href="#products" data-category="sweeteners"><i class="fas fa-honey-pot"></i> Sweeteners & Foods</a></li>
                        <li><a href="#products" data-category="tinctures"><i class="fas fa-flask"></i> Tinctures & Extracts</a></li>
                        <li><a href="#products" data-category="teas"><i class="fas fa-mug-hot"></i> Herbal Teas</a></li>
                        <li><a href="#products" data-category="oils"><i class="fas fa-oil-can"></i> Essential Oils</a></li>
                        <li><a href="#products" data-category="salves"><i class="fas fa-hand-holding-medical"></i> Salves & Balms</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="legal-links">
                <a href="privacy.php">Privacy Policy</a>
                <a href="terms.php">Terms of Service</a>
                <a href="refund.php">Refund Policy</a>
                <a href="shipping.php">Shipping Policy</a>
                <a href="contact.php">Contact Us</a>
            </div>
            
            <div class="copyright">
                &copy; <?php echo date('Y'); ?> Philadelphia Remedies. All rights reserved. | "God's Remedies Cleanse The System."
            </div>
        </div>
    </footer>

    <!-- Cart Modal -->
    <div class="cart-modal" id="cartModal">
        <div class="cart-header">
            <h3>Your Shopping Cart</h3>
            <button class="close-modal" id="closeCart" aria-label="Close cart">&times;</button>
        </div>
        
        <div class="cart-items" id="cartItems">
            <?php if (empty($_SESSION['cart'])): ?>
                <div class="text-center" style="padding: 40px 20px;">
                    <i class="fas fa-shopping-cart" style="font-size: 3rem; color: var(--gray); margin-bottom: 20px;"></i>
                    <h4 style="color: var(--dark); margin-bottom: 10px;">Your cart is empty</h4>
                    <p style="color: var(--gray);">Add some natural remedies to get started</p>
                </div>
            <?php else: ?>
                <?php foreach ($_SESSION['cart'] as $item): ?>
                    <?php 
                    $product = null;
                    foreach ($products as $p) {
                        if ($p['id'] == $item['productId']) {
                            $product = $p;
                            break;
                        }
                    }
                    if (!$product) continue;
                    ?>
                    <div class="cart-item" data-id="<?php echo $product['id']; ?>">
                        <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>" class="cart-item-image" onerror="this.onerror=null; this.src='data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"80\" height=\"80\" viewBox=\"0 0 80 80\"><rect width=\"80\" height=\"80\" fill=\"%23e8f5e9\"/><text x=\"50%\" y=\"50%\" font-family=\"Arial\" font-size=\"10\" fill=\"%232e7d32\" text-anchor=\"middle\" dy=\".3em\"><?php echo urlencode(substr($product['name'], 0, 10)); ?></text></svg>'">
                        <div class="cart-item-details">
                            <div class="cart-item-title"><?php echo $product['name']; ?></div>
                            <div class="cart-item-price"><?php echo formatPrice($product['price']); ?> each</div>
                            <div class="cart-item-controls">
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="update_quantity">
                                    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                    <input type="hidden" name="change" value="-1">
                                    <button type="submit" class="quantity-btn" aria-label="Decrease quantity">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </form>
                                <span class="cart-item-quantity"><?php echo $item['quantity']; ?></span>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="update_quantity">
                                    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                    <input type="hidden" name="change" value="1">
                                    <button type="submit" class="quantity-btn" aria-label="Increase quantity">
                                        <i class="fas fa-plus"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                        <form method="POST" style="display: inline;">
                            <input type="hidden" name="action" value="remove_from_cart">
                            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                            <button type="submit" class="cart-item-remove" aria-label="Remove item">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <?php if (!empty($_SESSION['cart'])): ?>
        <div class="cart-total">
            Total: KES <span id="cartTotal"><?php echo number_format($cartTotal); ?></span>
        </div>
        
        <div class="cart-actions">
            <a href="#contact" class="cart-action-btn checkout-btn" onclick="document.getElementById('cartModal').classList.remove('open')">
                <i class="fas fa-lock"></i> Proceed to Checkout
            </a>
            <form method="POST" style="display: inline; width: 100%;">
                <input type="hidden" name="action" value="clear_cart">
                <button type="submit" class="cart-action-btn continue-shopping" style="width: 100%; background: var(--danger); color: white; border: none;">
                    <i class="fas fa-trash"></i> Clear Cart
                </button>
            </form>
            <button class="cart-action-btn continue-shopping" id="continueShopping">
                <i class="fas fa-shopping-cart"></i> Continue Shopping
            </button>
        </div>
        <?php endif; ?>
    </div>

    <!-- Product Details Modal -->
    <div class="product-modal" id="productModal">
        <div class="product-modal-content">
            <button class="close-modal" id="closeProductModal" aria-label="Close product details">&times;</button>
            <div class="product-modal-body" id="productModalBody">
                <!-- Product details loaded by JavaScript -->
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script>
        // ===== APPLICATION STATE =====
        const products = <?php echo json_encode($products); ?>;
        let currentCategory = 'all';
        let currentSort = 'default';
        let currentPriceRange = 5000;
        let searchResults = [];

        // ===== DOM ELEMENTS =====
        const DOM = {
            loadingSpinner: document.getElementById('loadingSpinner'),
            productsGrid: document.getElementById('productsGrid'),
            cartCount: document.getElementById('cartCount'),
            cartItems: document.getElementById('cartItems'),
            cartTotal: document.getElementById('cartTotal'),
            cartModal: document.getElementById('cartModal'),
            productModal: document.getElementById('productModal'),
            productModalBody: document.getElementById('productModalBody'),
            searchInput: document.getElementById('searchInput'),
            searchResults: document.getElementById('searchResults'),
            sortBy: document.getElementById('sortBy'),
            priceRange: document.getElementById('priceRange'),
            priceValue: document.getElementById('priceValue'),
            mobileMenuToggle: document.getElementById('mobileMenuToggle'),
            cartToggle: document.getElementById('cartToggle'),
            closeCart: document.getElementById('closeCart'),
            closeProductModal: document.getElementById('closeProductModal'),
            continueShopping: document.getElementById('continueShopping'),
            checkoutBtn: document.querySelector('.checkout-btn'),
            orderForm: document.getElementById('orderForm'),
            newsletterForm: document.getElementById('newsletterForm'),
            searchBtn: document.getElementById('searchBtn')
        };

        // ===== UTILITY FUNCTIONS =====
        const utils = {
            formatPrice: (price) => `KES ${price.toLocaleString()}`,
            
            getCategoryName: (category) => {
                const names = {
                    'spices': 'Spices & Herbs',
                    'sweeteners': 'Sweeteners & Foods',
                    'tinctures': 'Tinctures & Extracts',
                    'teas': 'Herbal Teas',
                    'all': 'All Products'
                };
                return names[category] || category;
            },

            getStockClass: (stock) => {
                if (stock > 10) return 'in-stock';
                if (stock > 0) return 'low-stock';
                return 'out-of-stock';
            },

            createImageFallback: (alt) => 
                `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300" viewBox="0 0 400 300"><rect width="400" height="300" fill="%23e8f5e9"/><text x="50%" y="50%" font-family="Arial" font-size="16" fill="%232e7d32" text-anchor="middle" dy=".3em">${encodeURIComponent(alt.substring(0, 50))}</text></svg>`,

            animateElement: (element, animation) => {
                element.style.animation = 'none';
                setTimeout(() => {
                    element.style.animation = animation;
                }, 10);
            }
        };

        // ===== INITIALIZATION =====
        document.addEventListener('DOMContentLoaded', function() {
            initializeApp();
        });

        function initializeApp() {
            setupEventListeners();
            setupImageErrorHandling();
            hideMessageNotifications();
        }

        function hideMessageNotifications() {
            setTimeout(() => {
                const notification = document.querySelector('.message-notification');
                if (notification) {
                    notification.style.animation = 'slideOut 0.4s ease';
                    setTimeout(() => notification.remove(), 400);
                }
            }, 4000);
        }

        // ===== EVENT LISTENERS SETUP =====
        function setupEventListeners() {
            // Mobile Menu
            if (DOM.mobileMenuToggle) {
                DOM.mobileMenuToggle.addEventListener('click', toggleMobileMenu);
            }
            
            // Navigation
            document.querySelectorAll('.nav-link').forEach(link => {
                link.addEventListener('click', handleNavClick);
            });
            
            // Category Filters
            document.querySelectorAll('.filter-btn').forEach(btn => {
                btn.addEventListener('click', handleCategoryFilter);
            });
            
            // Sort & Filter
            if (DOM.sortBy) {
                DOM.sortBy.addEventListener('change', handleSortChange);
            }
            if (DOM.priceRange) {
                DOM.priceRange.addEventListener('input', handlePriceRangeChange);
            }
            
            // Search
            if (DOM.searchInput) {
                DOM.searchInput.addEventListener('input', handleSearch);
            }
            if (DOM.searchBtn) {
                DOM.searchBtn.addEventListener('click', handleSearchClick);
            }
            
            // Cart
            if (DOM.cartToggle) {
                DOM.cartToggle.addEventListener('click', toggleCart);
            }
            if (DOM.closeCart) {
                DOM.closeCart.addEventListener('click', toggleCart);
            }
            if (DOM.continueShopping) {
                DOM.continueShopping.addEventListener('click', toggleCart);
            }
            
            // Modals
            if (DOM.closeProductModal) {
                DOM.closeProductModal.addEventListener('click', () => {
                    DOM.productModal.classList.remove('open');
                });
            }
            
            // Close modals on outside click
            document.addEventListener('click', (e) => {
                if (e.target === DOM.productModal) {
                    DOM.productModal.classList.remove('open');
                }
                if (e.target === DOM.cartModal) {
                    DOM.cartModal.classList.remove('open');
                }
            });
            
            // Smooth scroll for anchor links
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', smoothScroll);
            });
            
            // Footer category links
            document.querySelectorAll('.footer-links a[data-category]').forEach(link => {
                link.addEventListener('click', handleFooterCategoryClick);
            });
            
            // Product card clicks for details
            document.querySelectorAll('.product-card').forEach(card => {
                card.addEventListener('click', (e) => {
                    // Don't trigger if clicking on add-to-cart button or form
                    if (!e.target.classList.contains('add-to-cart') && 
                        e.target.tagName !== 'BUTTON' && 
                        e.target.tagName !== 'FORM' &&
                        !e.target.closest('form')) {
                        const productId = parseInt(card.getAttribute('data-id'));
                        showProductDetails(productId);
                    }
                });
            });
        }

        // ===== EVENT HANDLERS =====
        function toggleMobileMenu() {
            const navLinks = document.querySelector('.nav-links');
            if (navLinks) {
                navLinks.classList.toggle('active');
            }
        }

        function handleNavClick(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            // Update active nav link
            document.querySelectorAll('.nav-link').forEach(link => {
                link.classList.remove('active');
            });
            this.classList.add('active');
            
            // Close mobile menu if open
            const navLinks = document.querySelector('.nav-links');
            if (navLinks) {
                navLinks.classList.remove('active');
            }
            
            // Scroll to section
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({ behavior: 'smooth' });
            }
        }

        function handleCategoryFilter() {
            document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            currentCategory = this.getAttribute('data-category');
            filterProducts();
        }

        function handleSortChange() {
            currentSort = this.value;
            filterProducts();
        }

        function handlePriceRangeChange() {
            currentPriceRange = parseInt(this.value);
            if (DOM.priceValue) {
                DOM.priceValue.textContent = `KES 0 - ${currentPriceRange}`;
            }
            filterProducts();
        }

        function filterProducts() {
            const productCards = document.querySelectorAll('.product-card');
            
            productCards.forEach(card => {
                const productId = parseInt(card.getAttribute('data-id'));
                const product = products.find(p => p.id === productId);
                
                if (!product) {
                    card.style.display = 'none';
                    return;
                }
                
                // Category filter
                if (currentCategory !== 'all' && product.category !== currentCategory) {
                    card.style.display = 'none';
                    return;
                }
                
                // Price filter
                if (product.price > currentPriceRange) {
                    card.style.display = 'none';
                    return;
                }
                
                card.style.display = 'flex';
            });
            
            // Sort products visually
            sortProductsVisually();
        }

        function sortProductsVisually() {
            const productsGrid = DOM.productsGrid;
            const productCards = Array.from(productsGrid.querySelectorAll('.product-card:not([style*="display: none"])'));
            
            productCards.sort((a, b) => {
                const productA = products.find(p => p.id === parseInt(a.getAttribute('data-id')));
                const productB = products.find(p => p.id === parseInt(b.getAttribute('data-id')));
                
                if (!productA || !productB) return 0;
                
                switch (currentSort) {
                    case 'price-low':
                        return productA.price - productB.price;
                    case 'price-high':
                        return productB.price - productA.price;
                    case 'name':
                        return productA.name.localeCompare(productB.name);
                    case 'popular':
                        return (productB.popular ? 1 : 0) - (productA.popular ? 1 : 0);
                    default:
                        return 0;
                }
            });
            
            // Reorder in DOM
            productCards.forEach(card => productsGrid.appendChild(card));
        }

        function handleSearch() {
            const searchTerm = this.value.toLowerCase().trim();
            
            if (searchTerm.length < 2) {
                if (DOM.searchResults) {
                    DOM.searchResults.classList.remove('active');
                }
                searchResults = [];
                return;
            }
            
            searchResults = products.filter(product => 
                product.name.toLowerCase().includes(searchTerm) ||
                product.description.toLowerCase().includes(searchTerm) ||
                product.category.toLowerCase().includes(searchTerm) ||
                product.benefits.some(benefit => benefit.toLowerCase().includes(searchTerm))
            );
            
            displaySearchResults();
        }

        function handleSearchClick() {
            if (DOM.searchInput && DOM.searchInput.value.trim()) {
                handleSearch.call(DOM.searchInput);
            }
        }

        function smoothScroll(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({ behavior: 'smooth' });
            }
        }

        function handleFooterCategoryClick(e) {
            e.preventDefault();
            const category = this.getAttribute('data-category');
            
            // Update active filter
            document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
            const filterBtn = document.querySelector(`.filter-btn[data-category="${category}"]`);
            if (filterBtn) {
                filterBtn.classList.add('active');
            }
            
            // Set category and filter products
            currentCategory = category;
            filterProducts();
            
            // Scroll to products section
            const productsSection = document.getElementById('products');
            if (productsSection) {
                productsSection.scrollIntoView({ behavior: 'smooth' });
            }
        }

        // ===== PRODUCT FUNCTIONS =====
        function displaySearchResults() {
            if (!DOM.searchResults) return;
            
            if (searchResults.length === 0) {
                DOM.searchResults.classList.remove('active');
                return;
            }

            DOM.searchResults.innerHTML = searchResults.slice(0, 5).map(product => `
                <div class="search-result-item" data-id="${product.id}">
                    <img src="${product.image}" alt="${product.name}" class="search-result-image" onerror="this.onerror=null; this.src='data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"50\" height=\"50\" viewBox=\"0 0 50 50\"><rect width=\"50\" height=\"50\" fill=\"%23e8f5e9\"/><text x=\"50%\" y=\"50%\" font-family=\"Arial\" font-size=\"8\" fill=\"%232e7d32\" text-anchor=\"middle\" dy=\".3em\">${encodeURIComponent(product.name.substring(0, 10))}</text></svg>'">
                    <div>
                        <div style="font-weight: 700;">${product.name}</div>
                        <div style="font-size: 0.9rem; color: var(--primary);">${utils.formatPrice(product.price)}</div>
                    </div>
                </div>
            `).join('');

            DOM.searchResults.classList.add('active');

            // Add click events to search results
            DOM.searchResults.querySelectorAll('.search-result-item').forEach(item => {
                item.addEventListener('click', () => {
                    const productId = parseInt(item.getAttribute('data-id'));
                    showProductDetails(productId);
                    DOM.searchResults.classList.remove('active');
                    if (DOM.searchInput) {
                        DOM.searchInput.value = '';
                    }
                });
            });
        }

        function showProductDetails(productId) {
            const product = products.find(p => p.id === productId);
            if (!product) return;

            DOM.productModalBody.innerHTML = `
                <div>
                    <img src="${product.image}" alt="${product.name}" style="width: 100%; border-radius: var(--radius);" onerror="this.onerror=null; this.src='${utils.createImageFallback(product.name)}'">
                    <div style="margin-top: 30px;">
                        <form method="POST" style="width: 100%;">
                            <input type="hidden" name="action" value="add_to_cart">
                            <input type="hidden" name="product_id" value="${product.id}">
                            <button type="submit" class="add-to-cart" style="width: 100%; padding: 20px; font-size: 1.1rem;" 
                                    aria-label="Add ${product.name} to cart">
                                <i class="fas fa-cart-plus"></i> Add to Cart - ${utils.formatPrice(product.price)}
                            </button>
                        </form>
                    </div>
                </div>
                <div>
                    <h3 style="color: var(--primary-dark); margin-bottom: 10px; font-size: 1.8rem;">${product.name}</h3>
                    <div class="product-category" style="font-size: 1rem;">${utils.getCategoryName(product.category)} • ${product.size}</div>
                    
                    <p style="margin: 25px 0; font-size: 1.05rem; line-height: 1.7;">${product.description}</p>
                    
                    <div style="background: var(--gray-light); padding: 25px; border-radius: var(--radius); margin: 25px 0;">
                        <h4 style="color: var(--primary); margin-bottom: 15px; display: flex; align-items: center; gap: 10px;">
                            <i class="fas fa-heart"></i> Health Benefits
                        </h4>
                        <div style="display: flex; flex-wrap: wrap; gap: 10px; margin-top: 15px;">
                            ${product.benefits.map(benefit => 
                                `<span class="benefit-tag" style="font-size: 0.9rem;">${benefit}</span>`
                            ).join('')}
                        </div>
                    </div>
                    
                    <div style="margin: 25px 0;">
                        <h4 style="color: var(--primary); margin-bottom: 15px; display: flex; align-items: center; gap: 10px;">
                            <i class="fas fa-book-medical"></i> How to Use
                        </h4>
                        <p style="padding: 15px; background: #f8f9fa; border-radius: 8px;">${product.usage}</p>
                    </div>
                    
                    <div style="margin: 25px 0;">
                        <h4 style="color: var(--primary); margin-bottom: 15px; display: flex; align-items: center; gap: 10px;">
                            <i class="fas fa-leaf"></i> Ingredients
                        </h4>
                        <p>${product.ingredients}</p>
                    </div>
                    
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 30px; padding-top: 20px; border-top: 2px solid var(--gray-light);">
                        <div class="stock-info ${utils.getStockClass(product.stock)}" style="font-size: 1rem;">
                            <i class="fas fa-box"></i> 
                            ${product.stock > 10 ? 'In Stock - Ready to Ship' : 
                             product.stock > 0 ? `Low Stock - Only ${product.stock} remaining` : 'Currently Out of Stock'}
                        </div>
                        <div style="font-weight: 700; color: var(--primary); font-size: 1.3rem;">
                            ${utils.formatPrice(product.price)}
                            ${product.originalPrice > product.price ? 
                                `<span style="font-size: 1rem; color: var(--gray); text-decoration: line-through; margin-left: 10px;">
                                    ${utils.formatPrice(product.originalPrice)}
                                </span>` : ''}
                        </div>
                    </div>
                </div>
            `;

            DOM.productModal.classList.add('open');
        }

        // ===== CART FUNCTIONS =====
        function toggleCart() {
            DOM.cartModal.classList.toggle('open');
        }

        // ===== UI HELPERS =====
        function setupImageErrorHandling() {
            document.addEventListener('error', function(e) {
                if (e.target.tagName === 'IMG') {
                    e.target.onerror = null;
                    const alt = e.target.alt || 'Product Image';
                    e.target.src = utils.createImageFallback(alt);
                }
            }, true);
        }

        // ===== ANALYTICS =====
        function trackEvent(category, action, label) {
            if (typeof gtag !== 'undefined') {
                gtag('event', action, {
                    'event_category': category,
                    'event_label': label
                });
            }
        }
    </script>
</body>
</html>