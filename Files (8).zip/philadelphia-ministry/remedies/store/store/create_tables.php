<?php
// ============================================
// STORE DATABASE SETUP SCRIPT
// ============================================

// Configuration
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Database connection
$host = 'localhost';
$username = 'root';
$password = '';  // Default XAMPP has no password
$database = 'philadelphia_ministry';

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("<div style='background: #f8d7da; color: #721c24; padding: 20px; border-radius: 5px;'>
            <h2>❌ Database Connection Failed</h2>
            <p>Error: " . $conn->connect_error . "</p>
            <p>Please make sure:</p>
            <ol>
                <li>XAMPP is running (Apache & MySQL)</li>
                <li>Database 'philadelphia_ministry' exists</li>
                <li>MySQL username is 'root' (default)</li>
                <li>MySQL password is empty (default)</li>
            </ol>
        </div>");
}

echo "<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Store Database Setup | Philadelphia Ministry</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8f9fa;
            padding: 20px;
            line-height: 1.6;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2c3e50;
            border-bottom: 3px solid #27ae60;
            padding-bottom: 10px;
            margin-bottom: 30px;
        }
        .success {
            color: #155724;
            background: #d4edda;
            padding: 10px 15px;
            border-radius: 5px;
            margin: 10px 0;
            border-left: 4px solid #28a745;
        }
        .error {
            color: #721c24;
            background: #f8d7da;
            padding: 10px 15px;
            border-radius: 5px;
            margin: 10px 0;
            border-left: 4px solid #dc3545;
        }
        .info {
            color: #0c5460;
            background: #d1ecf1;
            padding: 10px 15px;
            border-radius: 5px;
            margin: 10px 0;
            border-left: 4px solid #17a2b8;
        }
        .table-info {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            margin: 20px 0;
            border: 1px solid #dee2e6;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #27ae60;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
        .btn:hover {
            background: #219653;
        }
        .steps {
            background: #e8f4fc;
            padding: 20px;
            border-radius: 5px;
            margin: 20px 0;
        }
        .steps ol {
            margin-left: 20px;
        }
        .steps li {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class='container'>
        <h1>🏪 Philadelphia Remedies Store - Database Setup</h1>
        
        <div class='steps'>
            <h3>📋 Setup Steps:</h3>
            <ol>
                <li>Create database tables</li>
                <li>Insert sample products</li>
                <li>Verify setup</li>
                <li>Access the store</li>
            </ol>
        </div>";

echo "<div class='info'>📊 Database: <strong>$database</strong> | Host: <strong>$host</strong> | User: <strong>$username</strong></div>";

// ============================================
// CREATE TABLES
// ============================================

echo "<h2>1. Creating Database Tables</h2>";

// Create remedies_products table
$sql = "CREATE TABLE IF NOT EXISTS remedies_products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100) NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    cost_price DECIMAL(10,2),
    quantity_in_stock INT DEFAULT 0,
    image_url VARCHAR(500),
    is_active BOOLEAN DEFAULT TRUE,
    is_featured BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($conn->query($sql) === TRUE) {
    echo "<div class='success'>✅ Table 'remedies_products' created successfully</div>";
} else {
    echo "<div class='error'>❌ Error creating 'remedies_products' table: " . $conn->error . "</div>";
}

// Create remedies_cart table
$sql = "CREATE TABLE IF NOT EXISTS remedies_cart (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_product_id (product_id),
    FOREIGN KEY (product_id) REFERENCES remedies_products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($conn->query($sql) === TRUE) {
    echo "<div class='success'>✅ Table 'remedies_cart' created successfully</div>";
} else {
    echo "<div class='error'>❌ Error creating 'remedies_cart' table: " . $conn->error . "</div>";
}

// Create remedies_orders table
$sql = "CREATE TABLE IF NOT EXISTS remedies_orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    user_id INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    payment_method VARCHAR(50),
    shipping_address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_order_number (order_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($conn->query($sql) === TRUE) {
    echo "<div class='success'>✅ Table 'remedies_orders' created successfully</div>";
} else {
    echo "<div class='error'>❌ Error creating 'remedies_orders' table: " . $conn->error . "</div>";
}

// Create remedies_order_items table
$sql = "CREATE TABLE IF NOT EXISTS remedies_order_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES remedies_orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES remedies_products(id) ON DELETE CASCADE,
    INDEX idx_order_id (order_id),
    INDEX idx_product_id (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($conn->query($sql) === TRUE) {
    echo "<div class='success'>✅ Table 'remedies_order_items' created successfully</div>";
} else {
    echo "<div class='error'>❌ Error creating 'remedies_order_items' table: " . $conn->error . "</div>";
}

// ============================================
// INSERT SAMPLE DATA
// ============================================

echo "<h2>2. Inserting Sample Products</h2>";

$sampleProducts = [
    ["Echinacea Tincture", "Boosts immune system and fights infections. Made from organic Echinacea purpurea.", "Herbs", 1200.00, 800.00, 50, "https://via.placeholder.com/400x300/27ae60/ffffff?text=Echinacea+Tincture", true, true],
    ["Turmeric Capsules", "Anti-inflammatory and antioxidant supplement with 95% curcuminoids.", "Supplements", 1500.00, 1000.00, 100, "https://via.placeholder.com/400x300/3498db/ffffff?text=Turmeric+Capsules", true, true],
    ["Lavender Essential Oil", "100% pure lavender oil for calming, relaxation, and skin care.", "Oils", 800.00, 500.00, 30, "https://via.placeholder.com/400x300/9b59b6/ffffff?text=Lavender+Oil", true, true],
    ["Chamomile Tea", "Organic chamomile flowers for a calming herbal tea experience.", "Teas", 450.00, 300.00, 75, "https://via.placeholder.com/400x300/f39c12/ffffff?text=Chamomile+Tea", true, false],
    ["Natural Remedies Guide", "Comprehensive guide to natural healing and herbal medicine.", "Books", 2500.00, 1500.00, 20, "https://via.placeholder.com/400x300/e74c3c/ffffff?text=Remedies+Guide", true, true],
    ["Herbal Steam Inhaler", "Medical-grade steam inhaler for respiratory health.", "Equipment", 3500.00, 2500.00, 15, "https://via.placeholder.com/400x300/95a5a6/ffffff?text=Steam+Inhaler", true, false],
    ["Ginger Powder", "Organic ginger powder for digestion and inflammation.", "Powders", 600.00, 400.00, 60, "https://via.placeholder.com/400x300/e67e22/ffffff?text=Ginger+Powder", true, true],
    ["Aloe Vera Gel", "Pure aloe vera gel for skin soothing and healing.", "Creams", 700.00, 450.00, 40, "https://via.placeholder.com/400x300/1abc9c/ffffff?text=Aloe+Vera+Gel", true, false],
    ["Ashwagandha Capsules", "Adaptogenic herb for stress relief and energy.", "Supplements", 1800.00, 1200.00, 35, "https://via.placeholder.com/400x300/16a085/ffffff?text=Ashwagandha", true, true],
    ["Peppermint Oil", "Pure peppermint essential oil for digestion and headaches.", "Oils", 750.00, 480.00, 45, "https://via.placeholder.com/400x300/27ae60/ffffff?text=Peppermint+Oil", true, false],
    ["Green Tea Bags", "Antioxidant-rich organic green tea.", "Teas", 550.00, 350.00, 80, "https://via.placeholder.com/400x300/2ecc71/ffffff?text=Green+Tea", true, true],
    ["Acupuncture Kit", "Professional acupuncture set for home use.", "Equipment", 4200.00, 3000.00, 10, "https://via.placeholder.com/400x300/34495e/ffffff?text=Acupuncture+Kit", true, false]
];

$productsAdded = 0;
$productsSkipped = 0;

foreach ($sampleProducts as $product) {
    // Check if product already exists
    $checkSql = "SELECT id FROM remedies_products WHERE name = ?";
    $checkStmt = $conn->prepare($checkSql);
    $checkStmt->bind_param("s", $product[0]);
    $checkStmt->execute();
    $checkStmt->store_result();
    
    if ($checkStmt->num_rows == 0) {
        // Product doesn't exist, insert it
        $sql = "INSERT INTO remedies_products (name, description, category, unit_price, cost_price, quantity_in_stock, image_url, is_active, is_featured) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssdddiss", ...$product);
        
        if ($stmt->execute()) {
            echo "<div class='success'>✅ Added: {$product[0]} (Ksh {$product[3]})</div>";
            $productsAdded++;
        } else {
            echo "<div class='error'>❌ Error adding {$product[0]}: {$stmt->error}</div>";
        }
        $stmt->close();
    } else {
        echo "<div class='info'>⏭️ Skipped (already exists): {$product[0]}</div>";
        $productsSkipped++;
    }
    $checkStmt->close();
}

// ============================================
// VERIFY SETUP
// ============================================

echo "<h2>3. Verifying Setup</h2>";

// Check tables
$tables = ['remedies_products', 'remedies_cart', 'remedies_orders', 'remedies_order_items'];
foreach ($tables as $table) {
    $result = $conn->query("SHOW TABLES LIKE '$table'");
    if ($result && $result->num_rows > 0) {
        echo "<div class='success'>✅ Table '$table' exists</div>";
    } else {
        echo "<div class='error'>❌ Table '$table' NOT found</div>";
    }
    if ($result) $result->free();
}

// Count products
$result = $conn->query("SELECT COUNT(*) as count FROM remedies_products");
if ($result) {
    $row = $result->fetch_assoc();
    echo "<div class='info'>📦 Total Products in Database: <strong>{$row['count']}</strong></div>";
    $result->free();
}

// ============================================
// FINAL SUMMARY
// ============================================

echo "<h2>4. Setup Summary</h2>";

echo "<div class='table-info'>
        <h3>📊 Database Summary</h3>
        <ul>
            <li>Tables Created: 4</li>
            <li>Products Added: $productsAdded</li>
            <li>Products Skipped: $productsSkipped</li>
            <li>Total Products: " . ($productsAdded + $productsSkipped) . "</li>
        </ul>
      </div>";

echo "<div class='success' style='font-size: 1.2em; padding: 20px;'>
        <h3>🎉 Setup Complete!</h3>
        <p>Your store database has been successfully set up.</p>
      </div>";

echo "<h3>🎯 Next Steps:</h3>
      <div class='steps'>
        <ol>
            <li><strong>Visit the Store:</strong> <a href='index.php' style='color: #27ae60; text-decoration: none; font-weight: bold;'>Go to Store →</a></li>
            <li><strong>Test Features:</strong> Browse products, add to cart, etc.</li>
            <li><strong>Add More Products:</strong> Use the store admin panel (when created)</li>
            <li><strong>Delete this file:</strong> For security, remove or rename this setup file</li>
        </ol>
      </div>";

echo "<div style='margin-top: 30px; padding: 20px; background: #f8f9fa; border-radius: 5px;'>
        <h4>⚠️ Security Note:</h4>
        <p>This setup file should be deleted or renamed after use to prevent unauthorized access.</p>
        <button class='btn' onclick='window.location.href=\"index.php\"'>
            🛍️ Go to Store
        </button>
        <button class='btn' onclick='window.location.href=\"../\"' style='background: #3498db; margin-left: 10px;'>
            🏠 Back to Remedies
        </button>
      </div>";

echo "</div></body></html>";

// Close connection
$conn->close();
?>