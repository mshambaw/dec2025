<?php

// Don't define STORE_ACCESS here
// Include config
require_once 'config.php';

// Rest of your code...


// Get parameters
$categoryId = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$searchQuery = isset($_GET['q']) ? trim($_GET['q']) : '';
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$limit = 12;
$offset = ($page - 1) * $limit;

// Get products
$products = [];
$totalProducts = 0;

if ($searchQuery) {
    // Search products
    $products = searchProducts($searchQuery, $limit, $offset);
    $totalProducts = count(searchProducts($searchQuery, 1000));
} elseif ($categoryId > 0) {
    // Get products by category
    $stmt = getStoreDB()->prepare("
        SELECT r.*, rc.name as category_name 
        FROM remedies r 
        LEFT JOIN remedy_categories rc ON r.category = rc.id
        WHERE r.is_active = 1 AND r.quantity_in_stock > 0 AND r.category = ?
        ORDER BY r.name
        LIMIT ? OFFSET ?
    ");
    $stmt->execute([$categoryId, $limit, $offset]);
    $products = $stmt->fetchAll();
    
    // Get total count
    $stmt = getStoreDB()->prepare("
        SELECT COUNT(*) as count FROM remedies 
        WHERE is_active = 1 AND quantity_in_stock > 0 AND category = ?
    ");
    $stmt->execute([$categoryId]);
    $totalProducts = $stmt->fetch()['count'];
} else {
    // Get all products
    $stmt = getStoreDB()->query("
        SELECT r.*, rc.name as category_name 
        FROM remedies r 
        LEFT JOIN remedy_categories rc ON r.category = rc.id
        WHERE r.is_active = 1 AND r.quantity_in_stock > 0 
        ORDER BY r.name
        LIMIT $limit OFFSET $offset
    ");
    $products = $stmt->fetchAll();
    
    // Get total count
    $stmt = getStoreDB()->query("
        SELECT COUNT(*) as count FROM remedies 
        WHERE is_active = 1 AND quantity_in_stock > 0
    ");
    $totalProducts = $stmt->fetch()['count'];
}

// Get categories
$categories = getCategories();

// Get current category name
$currentCategoryName = 'All Products';
if ($categoryId > 0) {
    foreach ($categories as $cat) {
        if ($cat['id'] == $categoryId) {
            $currentCategoryName = $cat['name'];
            break;
        }
    }
}

// Calculate pagination
$totalPages = ceil($totalProducts / $limit);

// Get user info
$userName = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : '';
$userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;
$cartCount = getCartCount();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $currentCategoryName; ?> - <?php echo $storeSettings['store_name']; ?></title>
    
    <!-- Include styles from index.php -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Include all styles from index.php */
        <?php include 'styles.php'; ?>
        
        /* Additional styles for products page */
        .products-header {
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            padding: 60px 0 30px;
            margin-bottom: 40px;
        }
        
        .filter-sidebar {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            margin-bottom: 30px;
        }
        
        .filter-title {
            font-size: 1.2rem;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid var(--primary-color);
        }
        
        .category-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .category-list li {
            margin-bottom: 8px;
        }
        
        .category-list a {
            display: block;
            padding: 10px 15px;
            border-radius: 8px;
            color: var(--text-color);
            transition: all 0.3s;
        }
        
        .category-list a:hover, .category-list a.active {
            background: rgba(26, 82, 118, 0.1);
            color: var(--primary-color);
            padding-left: 20px;
        }
        
        .product-grid-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .sort-options {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .pagination {
            justify-content: center;
            margin-top: 40px;
        }
        
        .page-link {
            color: var(--primary-color);
            border: 1px solid var(--border-color);
            margin: 0 3px;
            border-radius: 8px;
        }
        
        .page-link:hover, .page-link.active {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
        }
        
        .empty-state i {
            font-size: 4rem;
            color: var(--text-light);
            margin-bottom: 20px;
        }
        
        .search-results-info {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }
    </style>
</head>
<body>
    <!-- Include Header -->
    <?php include 'header.php'; ?>
    
    <!-- Products Header -->
    <section class="products-header">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="products.php">Shop</a></li>
                    <?php if($searchQuery): ?>
                    <li class="breadcrumb-item active">Search Results</li>
                    <?php else: ?>
                    <li class="breadcrumb-item active"><?php echo $currentCategoryName; ?></li>
                    <?php endif; ?>
                </ol>
            </nav>
            
            <h1 class="mb-3">
                <?php if($searchQuery): ?>
                <i class="fas fa-search me-2"></i>Search Results
                <?php else: ?>
                <i class="fas fa-store me-2"></i><?php echo $currentCategoryName; ?>
                <?php endif; ?>
            </h1>
            
            <?php if($searchQuery): ?>
            <p class="lead">Search results for: <strong>"<?php echo htmlspecialchars($searchQuery); ?>"</strong></p>
            <?php else: ?>
            <p class="lead">Discover our collection of natural healing remedies</p>
            <?php endif; ?>
        </div>
    </section>
    
    <!-- Products Content -->
    <div class="container">
        <div class="row">
            <!-- Sidebar Filters -->
            <div class="col-lg-3">
                <div class="filter-sidebar">
                    <h4 class="filter-title">Categories</h4>
                    <ul class="category-list">
                        <li>
                            <a href="products.php" class="<?php echo !$categoryId ? 'active' : ''; ?>">
                                <i class="fas fa-th-large me-2"></i>All Products
                            </a>
                        </li>
                        <?php foreach($categories as $category): ?>
                        <li>
                            <a href="products.php?category=<?php echo $category['id']; ?>" 
                               class="<?php echo $categoryId == $category['id'] ? 'active' : ''; ?>">
                                <i class="fas fa-chevron-right me-2"></i>
                                <?php echo htmlspecialchars($category['name']); ?>
                            </a>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    
                    <hr class="my-4">
                    
                    <h4 class="filter-title">Why Choose Us</h4>
                    <div class="mt-3">
                        <div class="d-flex align-items-center mb-3">
                            <div class="me-3 text-primary">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <div>
                                <small>100% Natural Products</small>
                            </div>
                        </div>
                        <div class="d-flex align-items-center mb-3">
                            <div class="me-3 text-primary">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <div>
                                <small>Quality Guaranteed</small>
                            </div>
                        </div>
                        <div class="d-flex align-items-center mb-3">
                            <div class="me-3 text-primary">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <div>
                                <small>Free Shipping Over Ksh 5,000</small>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Special Offer -->
                <div class="card border-primary mt-4">
                    <div class="card-body text-center">
                        <h5 class="card-title text-primary">
                            <i class="fas fa-gift me-2"></i>Special Offer
                        </h5>
                        <p class="card-text">Get 10% off your first order!</p>
                        <small class="text-muted">Use code: <strong>WELCOME10</strong></small>
                    </div>
                </div>
            </div>
            
            <!-- Products Grid -->
            <div class="col-lg-9">
                <!-- Results Header -->
                <div class="product-grid-header">
                    <div>
                        <p class="mb-0">
                            <strong><?php echo $totalProducts; ?></strong> products found
                            <?php if($searchQuery): ?>
                            for "<strong><?php echo htmlspecialchars($searchQuery); ?></strong>"
                            <?php endif; ?>
                        </p>
                    </div>
                    
                    <div class="sort-options">
                        <label class="me-2">Sort by:</label>
                        <select class="form-select form-select-sm" style="width: auto;">
                            <option>Featured</option>
                            <option>Price: Low to High</option>
                            <option>Price: High to Low</option>
                            <option>Newest First</option>
                        </select>
                    </div>
                </div>
                
                <?php if(empty($products)): ?>
                <!-- Empty State -->
                <div class="empty-state">
                    <i class="fas fa-search"></i>
                    <h3>No Products Found</h3>
                    <p class="text-muted mb-4">
                        <?php if($searchQuery): ?>
                        No products found for your search criteria. Try different keywords.
                        <?php else: ?>
                        No products available in this category at the moment.
                        <?php endif; ?>
                    </p>
                    <a href="products.php" class="btn btn-primary">
                        <i class="fas fa-store me-2"></i>Browse All Products
                    </a>
                </div>
                <?php else: ?>
                
                <!-- Products Grid -->
                <div class="row">
                    <?php foreach($products as $product): ?>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="product-card">
                            <?php if($product['quantity_in_stock'] < 10): ?>
                            <div class="product-badge">
                                <span class="badge bg-warning">Low Stock</span>
                            </div>
                            <?php endif; ?>
                            
                            <div class="product-image">
                                <img src="<?php echo $product['image_url'] ?: ASSETS_URL . 'images/products/default.jpg'; ?>" 
                                     alt="<?php echo htmlspecialchars($product['name']); ?>">
                                <div class="product-overlay">
                                    <a href="product-details.php?id=<?php echo $product['id']; ?>" 
                                       class="btn btn-outline-light">
                                        <i class="fas fa-eye me-2"></i> View Details
                                    </a>
                                </div>
                            </div>
                            
                            <div class="product-content">
                                <h3 class="product-title"><?php echo htmlspecialchars($product['name']); ?></h3>
                                <p class="product-description">
                                    <?php echo substr(htmlspecialchars($product['description'] ?: ''), 0, 80); ?>...
                                </p>
                                
                                <div class="product-meta">
                                    <span class="product-category"><?php echo htmlspecialchars($product['category_name'] ?: 'General'); ?></span>
                                    <span class="product-stock <?php echo $product['quantity_in_stock'] > 0 ? 'stock-in' : 'stock-out'; ?>">
                                        <i class="fas fa-<?php echo $product['quantity_in_stock'] > 0 ? 'check' : 'times'; ?>-circle me-1"></i>
                                        <?php echo $product['quantity_in_stock'] > 0 ? 'In Stock' : 'Out of Stock'; ?>
                                    </span>
                                </div>
                                
                                <div class="product-price">
                                    <?php echo formatCurrency($product['unit_price']); ?>
                                    <?php if($product['cost_price'] && $product['unit_price'] > $product['cost_price']): ?>
                                    <small class="text-muted d-block">
                                        <s><?php echo formatCurrency($product['cost_price']); ?></s>
                                    </small>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="product-actions">
                                    <a href="product-details.php?id=<?php echo $product['id']; ?>" 
                                       class="btn btn-outline-primary btn-sm">
                                        <i class="fas fa-eye me-1"></i> View
                                    </a>
                                    <?php if($product['quantity_in_stock'] > 0): ?>
                                    <button class="btn btn-primary btn-sm add-to-cart" 
                                            data-product-id="<?php echo $product['id']; ?>"
                                            data-product-name="<?php echo htmlspecialchars($product['name']); ?>">
                                        <i class="fas fa-cart-plus me-1"></i> Add to Cart
                                    </button>
                                    <?php else: ?>
                                    <button class="btn btn-secondary btn-sm" disabled>
                                        Out of Stock
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Pagination -->
                <?php if($totalPages > 1): ?>
                <nav aria-label="Page navigation">
                    <ul class="pagination">
                        <?php if($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?<?php 
                                echo ($categoryId ? "category=$categoryId&" : '') .
                                     ($searchQuery ? "q=" . urlencode($searchQuery) . "&" : '') .
                                     "page=" . ($page - 1); 
                            ?>">
                                <i class="fas fa-chevron-left"></i>
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <?php for($i = 1; $i <= $totalPages; $i++): ?>
                            <?php if($i == $page): ?>
                            <li class="page-item active">
                                <span class="page-link"><?php echo $i; ?></span>
                            </li>
                            <?php else: ?>
                            <li class="page-item">
                                <a class="page-link" href="?<?php 
                                    echo ($categoryId ? "category=$categoryId&" : '') .
                                         ($searchQuery ? "q=" . urlencode($searchQuery) . "&" : '') .
                                         "page=$i"; 
                                ?>">
                                    <?php echo $i; ?>
                                </a>
                            </li>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if($page < $totalPages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?<?php 
                                echo ($categoryId ? "category=$categoryId&" : '') .
                                     ($searchQuery ? "q=" . urlencode($searchQuery) . "&" : '') .
                                     "page=" . ($page + 1); 
                            ?>">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
                <?php endif; ?>
                
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Include Footer -->
    <?php include 'footer.php'; ?>
    
    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    $(document).ready(function() {
        // Add to cart functionality
        $('.add-to-cart').click(function() {
            const productId = $(this).data('product-id');
            const productName = $(this).data('product-name');
            
            <?php if(!$userId): ?>
            window.location.href = '<?php echo BASE_PATH; ?>members/login.php?redirect=' + 
                                  encodeURIComponent(window.location.pathname);
            <?php else: ?>
            
            const button = $(this);
            const originalHtml = button.html();
            button.html('<i class="fas fa-spinner fa-spin"></i>');
            button.prop('disabled', true);
            
            $.ajax({
                url: 'api/cart.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'add_to_cart',
                    product_id: productId,
                    quantity: 1,
                    csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
                },
                success: function(response) {
                    if (response.success) {
                        $('.cart-count').text(response.cart_count);
                        button.html('<i class="fas fa-check"></i> Added');
                        button.removeClass('btn-primary').addClass('btn-success');
                        
                        // Show toast
                        showToast('Success', productName + ' added to cart!', 'success');
                        
                        setTimeout(function() {
                            button.html(originalHtml);
                            button.removeClass('btn-success').addClass('btn-primary');
                            button.prop('disabled', false);
                        }, 2000);
                    } else {
                        showToast('Error', response.message, 'error');
                        button.html(originalHtml);
                        button.prop('disabled', false);
                    }
                },
                error: function() {
                    showToast('Error', 'Network error. Please try again.', 'error');
                    button.html(originalHtml);
                    button.prop('disabled', false);
                }
            });
            <?php endif; ?>
        });
        
        function showToast(title, message, type) {
            const toast = $(`
                <div class="position-fixed top-0 end-0 p-3" style="z-index: 9999">
                    <div class="toast align-items-center text-white bg-${type === 'success' ? 'success' : 'danger'} border-0" 
                         role="alert" aria-live="assertive" aria-atomic="true">
                        <div class="d-flex">
                            <div class="toast-body">
                                <strong>${title}:</strong> ${message}
                            </div>
                            <button type="button" class="btn-close btn-close-white me-2 m-auto" 
                                    data-bs-dismiss="toast"></button>
                        </div>
                    </div>
                </div>
            `);
            
            $('body').append(toast);
            const bsToast = new bootstrap.Toast(toast.find('.toast')[0]);
            bsToast.show();
            
            toast.find('.toast').on('hidden.bs.toast', function() {
                $(this).closest('.position-fixed').remove();
            });
        }
    });
    </script>
</body>
</html>