<?php
// Header component
?>
<!-- Header -->
<header class="store-header">
    <div class="container">
        <nav class="navbar navbar-expand-lg store-navbar">
            <div class="container-fluid">
                <!-- Logo -->
                <a class="navbar-brand" href="index.php">
                    <i class="fas fa-heartbeat me-2"></i>
                    Philadelphia Remedies
                </a>
                
                <!-- Mobile Toggle -->
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
                    <i class="fas fa-bars"></i>
                </button>
                
                <!-- Navigation -->
                <div class="collapse navbar-collapse" id="mainNav">
                    <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>" 
                               href="index.php">
                                <i class="fas fa-home me-1"></i> Home
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'products.php' ? 'active' : ''; ?>" 
                               href="products.php">
                                <i class="fas fa-store me-1"></i> Shop
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../treatments/">
                                <i class="fas fa-spa me-1"></i> Treatments
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../consultations/">
                                <i class="fas fa-user-md me-1"></i> Consultations
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php">
                                <i class="fas fa-info-circle me-1"></i> About
                            </a>
                        </li>
                    </ul>
                    
                    <!-- User Actions -->
                    <div class="d-flex align-items-center gap-3">
                        <!-- Search Button -->
                        <button class="btn btn-outline-primary btn-sm" data-bs-toggle="modal" data-bs-target="#searchModal">
                            <i class="fas fa-search"></i>
                        </button>
                        
                        <!-- Cart -->
                        <a href="shopping-cart.php" class="cart-btn position-relative">
                            <i class="fas fa-shopping-cart"></i>
                            <?php if($cartCount > 0): ?>
                            <span class="cart-count"><?php echo $cartCount; ?></span>
                            <?php endif; ?>
                        </a>
                        
                        <!-- User -->
                        <?php if($userId): ?>
                        <div class="dropdown">
                            <button class="btn btn-outline-primary user-dropdown dropdown-toggle" data-bs-toggle="dropdown">
                                <i class="fas fa-user me-2"></i>
                                <?php echo htmlspecialchars($userName); ?>
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="my-account.php">
                                    <i class="fas fa-user-circle me-2"></i> My Account
                                </a></li>
                                <li><a class="dropdown-item" href="my-orders.php">
                                    <i class="fas fa-box me-2"></i> My Orders
                                </a></li>
                                <li><a class="dropdown-item" href="wishlist.php">
                                    <i class="fas fa-heart me-2"></i> Wishlist
                                </a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="<?php echo BASE_PATH; ?>members/logout.php">
                                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                                </a></li>
                            </ul>
                        </div>
                        <?php else: ?>
                        <a href="<?php echo BASE_PATH; ?>members/login.php?redirect=<?php echo urlencode($_SERVER['REQUEST_URI']); ?>" 
                           class="btn btn-primary btn-sm">
                            <i class="fas fa-sign-in-alt me-1"></i> Login
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </nav>
    </div>
</header>

<!-- Search Modal -->
<div class="modal fade" id="searchModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Search Products</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form action="search.php" method="GET">
                    <div class="input-group">
                        <input type="text" name="q" class="form-control form-control-lg" 
                               placeholder="What are you looking for?" autofocus>
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>