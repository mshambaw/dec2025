<?php
// Define access
define('STORE_ACCESS', true);

// Include config
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_PATH . 'members/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    exit;
}

// Check if cart is empty
if (empty($_SESSION['cart'])) {
    header('Location: shopping-cart.php');
    exit;
}

// Get user info from session or database
$userId = $_SESSION['user_id'];
$userEmail = $_SESSION['user_email'] ?? '';
$userPhone = $_SESSION['user_phone'] ?? '';
$userName = $_SESSION['user_name'] ?? '';

// Get cart items
$cartItems = [];
$subtotal = 0;

foreach ($_SESSION['cart'] as $item) {
    $product = getProduct($item['product_id']);
    if ($product) {
        $itemTotal = $item['quantity'] * $item['price'];
        $cartItems[] = [
            'id' => $product['id'],
            'name' => $product['name'],
            'price' => $product['unit_price'],
            'quantity' => $item['quantity'],
            'image' => $product['image_url'] ?? ASSETS_URL . 'images/products/default.jpg',
            'item_total' => $itemTotal
        ];
        $subtotal += $itemTotal;
    }
}

// Calculate totals
$shipping = ($subtotal >= 5000) ? 0 : 300;
$tax = $subtotal * 0.16;
$total = $subtotal + $shipping + $tax;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and process order
    $errors = [];
    
    // Required fields
    $required = ['full_name', 'email', 'phone', 'shipping_address'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            $errors[] = ucfirst(str_replace('_', ' ', $field)) . ' is required';
        }
    }
    
    // Validate email
    if (!empty($_POST['email']) && !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email address';
    }
    
    // Validate phone
    if (!empty($_POST['phone']) && !preg_match('/^[0-9+\-\s]{10,15}$/', $_POST['phone'])) {
        $errors[] = 'Invalid phone number';
    }
    
    if (empty($errors)) {
        // Prepare order data
        $orderData = [
            'name' => $_POST['full_name'],
            'email' => $_POST['email'],
            'phone' => $_POST['phone'],
            'shipping_address' => $_POST['shipping_address'],
            'billing_address' => $_POST['billing_address'] ?? $_POST['shipping_address'],
            'payment_method' => $_POST['payment_method'],
            'notes' => $_POST['order_notes'] ?? ''
        ];
        
        // Create order
        $orderNumber = createOrder($userId, $orderData, $_SESSION['cart']);
        
        if ($orderNumber) {
            // Clear cart
            $_SESSION['cart'] = [];
            
            // Redirect to success page
            header('Location: order-success.php?order=' . $orderNumber);
            exit;
        } else {
            $errors[] = 'Failed to create order. Please try again.';
        }
    }
    
    // If there are errors, show them
    $errorMessage = implode('<br>', $errors);
}

// Get cart count
$cartCount = getCartCount();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - <?php echo $storeSettings['store_name']; ?></title>
    
    <!-- Include styles -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        <?php include 'styles.php'; ?>
        
        .checkout-section {
            padding: 80px 0;
        }
        
        .checkout-header {
            margin-bottom: 40px;
        }
        
        .checkout-steps {
            display: flex;
            justify-content: space-between;
            margin-bottom: 40px;
            position: relative;
        }
        
        .checkout-steps:before {
            content: '';
            position: absolute;
            top: 20px;
            left: 0;
            right: 0;
            height: 2px;
            background: var(--border-color);
            z-index: 1;
        }
        
        .step {
            text-align: center;
            position: relative;
            z-index: 2;
        }
        
        .step-number {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: white;
            border: 2px solid var(--border-color);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 10px;
            font-weight: 600;
        }
        
        .step.active .step-number {
            background: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        
        .step-label {
            font-size: 0.9rem;
            color: var(--text-light);
        }
        
        .checkout-form {
            background: white;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .form-section {
            margin-bottom: 40px;
        }
        
        .section-title {
            font-size: 1.3rem;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid var(--light-color);
        }
        
        .order-summary {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            position: sticky;
            top: 100px;
        }
        
        .order-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            padding-bottom: 10px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .order-item:last-child {
            border-bottom: none;
        }
        
        .item-name {
            flex: 2;
        }
        
        .item-quantity {
            flex: 1;
            text-align: center;
        }
        
        .item-price {
            flex: 1;
            text-align: right;
        }
        
        .summary-total {
            display: flex;
            justify-content: space-between;
            font-size: 1.2rem;
            font-weight: 700;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 2px solid var(--border-color);
        }
        
        .payment-method {
            border: 2px solid var(--border-color);
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .payment-method:hover {
            border-color: var(--primary-color);
        }
        
        .payment-method.selected {
            border-color: var(--primary-color);
            background: rgba(26, 82, 118, 0.05);
        }
        
        .payment-icon {
            font-size: 1.5rem;
            margin-right: 10px;
        }
        
        .form-check-input:checked + .payment-method {
            border-color: var(--primary-color);
            background: rgba(26, 82, 118, 0.05);
        }
        
        @media (max-width: 768px) {
            .checkout-steps {
                flex-wrap: wrap;
            }
            
            .step {
                width: 33.33%;
                margin-bottom: 20px;
            }
            
            .checkout-form, .order-summary {
                padding: 20px;
            }
            
            .order-summary {
                position: static;
                margin-top: 30px;
            }
        }
    </style>
</head>
<body>
    <!-- Include Header -->
    <?php include 'header.php'; ?>
    
    <!-- Checkout -->
    <section class="checkout-section">
        <div class="container">
            <div class="checkout-header">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item"><a href="shopping-cart.php">Cart</a></li>
                        <li class="breadcrumb-item active">Checkout</li>
                    </ol>
                </nav>
                
                <h1 class="mb-3"><i class="fas fa-shopping-bag me-2"></i>Checkout</h1>
                <p class="text-muted">Complete your purchase</p>
            </div>
            
            <!-- Checkout Steps -->
            <div class="checkout-steps">
                <div class="step active">
                    <div class="step-number">1</div>
                    <div class="step-label">Information</div>
                </div>
                <div class="step">
                    <div class="step-number">2</div>
                    <div class="step-label">Shipping</div>
                </div>
                <div class="step">
                    <div class="step-number">3</div>
                    <div class="step-label">Payment</div>
                </div>
                <div class="step">
                    <div class="step-number">4</div>
                    <div class="step-label">Confirmation</div>
                </div>
            </div>
            
            <?php if(isset($errorMessage)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i>
                <?php echo $errorMessage; ?>
            </div>
            <?php endif; ?>
            
            <form method="POST" id="checkoutForm">
                <div class="row">
                    <!-- Checkout Form -->
                    <div class="col-lg-8">
                        <div class="checkout-form">
                            <!-- Contact Information -->
                            <div class="form-section">
                                <h3 class="section-title">
                                    <i class="fas fa-user-circle me-2"></i>Contact Information
                                </h3>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Full Name *</label>
                                        <input type="text" class="form-control" name="full_name" 
                                               value="<?php echo htmlspecialchars($_POST['full_name'] ?? $userName); ?>" 
                                               required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Email Address *</label>
                                        <input type="email" class="form-control" name="email" 
                                               value="<?php echo htmlspecialchars($_POST['email'] ?? $userEmail); ?>" 
                                               required>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Phone Number *</label>
                                    <input type="tel" class="form-control" name="phone" 
                                           value="<?php echo htmlspecialchars($_POST['phone'] ?? $userPhone); ?>" 
                                           placeholder="e.g., +254 712 345 678" required>
                                </div>
                            </div>
                            
                            <!-- Shipping Address -->
                            <div class="form-section">
                                <h3 class="section-title">
                                    <i class="fas fa-truck me-2"></i>Shipping Address
                                </h3>
                                
                                <div class="mb-3">
                                    <label class="form-label">Street Address *</label>
                                    <textarea class="form-control" name="shipping_address" rows="3" 
                                              placeholder="House number, street, apartment" 
                                              required><?php echo htmlspecialchars($_POST['shipping_address'] ?? ''); ?></textarea>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">City</label>
                                        <input type="text" class="form-control" name="city" 
                                               value="<?php echo htmlspecialchars($_POST['city'] ?? ''); ?>">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Postal Code</label>
                                        <input type="text" class="form-control" name="postal_code" 
                                               value="<?php echo htmlspecialchars($_POST['postal_code'] ?? ''); ?>">
                                    </div>
                                </div>
                                
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" id="sameAddress" checked>
                                    <label class="form-check-label" for="sameAddress">
                                        Billing address same as shipping address
                                    </label>
                                </div>
                                
                                <div id="billingAddress" style="display: none;">
                                    <div class="mb-3">
                                        <label class="form-label">Billing Address</label>
                                        <textarea class="form-control" name="billing_address" rows="3" 
                                                  placeholder="If different from shipping address"><?php echo htmlspecialchars($_POST['billing_address'] ?? ''); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Payment Method -->
                            <div class="form-section">
                                <h3 class="section-title">
                                    <i class="fas fa-credit-card me-2"></i>Payment Method
                                </h3>
                                
                                <div class="mb-4">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="payment_method" 
                                               id="mpesa" value="mpesa" checked>
                                        <label class="form-check-label w-100" for="mpesa">
                                            <div class="payment-method selected" id="mpesaMethod">
                                                <i class="fas fa-mobile-alt payment-icon text-success"></i>
                                                <strong>M-Pesa</strong>
                                                <small class="d-block text-muted mt-1">
                                                    Pay securely via M-Pesa. You will receive a prompt on your phone.
                                                </small>
                                            </div>
                                        </label>
                                    </div>
                                    
                                    <div class="form-check mt-3">
                                        <input class="form-check-input" type="radio" name="payment_method" 
                                               id="cash" value="cash">
                                        <label class="form-check-label w-100" for="cash">
                                            <div class="payment-method" id="cashMethod">
                                                <i class="fas fa-money-bill-wave payment-icon text-success"></i>
                                                <strong>Cash on Delivery</strong>
                                                <small class="d-block text-muted mt-1">
                                                    Pay when you receive your order. Additional delivery fee may apply.
                                                </small>
                                            </div>
                                        </label>
                                    </div>
                                    
                                    <div class="form-check mt-3">
                                        <input class="form-check-input" type="radio" name="payment_method" 
                                               id="card" value="card">
                                        <label class="form-check-label w-100" for="card">
                                            <div class="payment-method" id="cardMethod">
                                                <i class="fab fa-cc-visa payment-icon text-dark"></i>
                                                <strong>Credit/Debit Card</strong>
                                                <small class="d-block text-muted mt-1">
                                                    Pay securely with your Visa or MasterCard.
                                                </small>
                                            </div>
                                        </label>
                                    </div>
                                    
                                    <div class="form-check mt-3">
                                        <input class="form-check-input" type="radio" name="payment_method" 
                                               id="bank" value="bank_transfer">
                                        <label class="form-check-label w-100" for="bank">
                                            <div class="payment-method" id="bankMethod">
                                                <i class="fas fa-university payment-icon text-primary"></i>
                                                <strong>Bank Transfer</strong>
                                                <small class="d-block text-muted mt-1">
                                                    Transfer funds directly to our bank account.
                                                </small>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Order Notes (Optional)</label>
                                    <textarea class="form-control" name="order_notes" rows="3" 
                                              placeholder="Special instructions for your order..."><?php echo htmlspecialchars($_POST['order_notes'] ?? ''); ?></textarea>
                                </div>
                            </div>
                            
                            <!-- Terms -->
                            <div class="form-check mb-4">
                                <input class="form-check-input" type="checkbox" id="terms" required>
                                <label class="form-check-label" for="terms">
                                    I agree to the <a href="terms.php" target="_blank">Terms & Conditions</a> 
                                    and <a href="privacy.php" target="_blank">Privacy Policy</a>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Order Summary -->
                    <div class="col-lg-4">
                        <div class="order-summary">
                            <h3 class="section-title">Order Summary</h3>
                            
                            <!-- Order Items -->
                            <div class="mb-4">
                                <?php foreach($cartItems as $item): ?>
                                <div class="order-item">
                                    <div class="item-name">
                                        <?php echo htmlspecialchars($item['name']); ?>
                                    </div>
                                    <div class="item-quantity">
                                        x<?php echo $item['quantity']; ?>
                                    </div>
                                    <div class="item-price">
                                        <?php echo formatCurrency($item['item_total']); ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            
                            <!-- Order Totals -->
                            <div class="mb-3">
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Subtotal</span>
                                    <span><?php echo formatCurrency($subtotal); ?></span>
                                </div>
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Shipping</span>
                                    <span><?php echo $shipping == 0 ? 'FREE' : formatCurrency($shipping); ?></span>
                                </div>
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Tax (16%)</span>
                                    <span><?php echo formatCurrency($tax); ?></span>
                                </div>
                            </div>
                            
                            <div class="summary-total">
                                <span>Total</span>
                                <span><?php echo formatCurrency($total); ?></span>
                            </div>
                            
                            <?php if($subtotal < 5000): ?>
                            <div class="alert alert-info mt-3">
                                <i class="fas fa-info-circle me-2"></i>
                                Add <?php echo formatCurrency(5000 - $subtotal); ?> more for free shipping!
                            </div>
                            <?php endif; ?>
                            
                            <!-- Place Order Button -->
                            <button type="submit" class="btn btn-primary btn-lg w-100 mt-4">
                                <i class="fas fa-lock me-2"></i>Place Order
                            </button>
                            
                            <div class="text-center mt-3">
                                <small class="text-muted">
                                    <i class="fas fa-shield-alt me-1"></i>Secure SSL encryption
                                </small>
                            </div>
                        </div>
                        
                        <!-- Need Help? -->
                        <div class="card mt-4">
                            <div class="card-body">
                                <h6 class="card-title">
                                    <i class="fas fa-question-circle me-2 text-primary"></i>Need Help?
                                </h6>
                                <p class="card-text small">
                                    Contact our customer support for assistance with your order.
                                </p>
                                <div class="d-flex align-items-center mt-2">
                                    <i class="fas fa-phone text-primary me-2"></i>
                                    <span><?php echo $storeSettings['store_phone']; ?></span>
                                </div>
                                <div class="d-flex align-items-center mt-2">
                                    <i class="fas fa-envelope text-primary me-2"></i>
                                    <span><?php echo $storeSettings['store_email']; ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
    
    <!-- Include Footer -->
    <?php include 'footer.php'; ?>
    
    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    $(document).ready(function() {
        // Toggle billing address
        $('#sameAddress').change(function() {
            if (this.checked) {
                $('#billingAddress').slideUp();
            } else {
                $('#billingAddress').slideDown();
            }
        });
        
        // Payment method selection
        $('input[name="payment_method"]').change(function() {
            $('.payment-method').removeClass('selected');
            $(`#${this.value}Method`).addClass('selected');
        });
        
        // Form submission
        $('#checkoutForm').submit(function(e) {
            // Validate form
            const phone = $('input[name="phone"]').val();
            const phoneRegex = /^[0-9+\-\s]{10,15}$/;
            
            if (!phoneRegex.test(phone)) {
                e.preventDefault();
                alert('Please enter a valid phone number (10-15 digits)');
                $('input[name="phone"]').focus();
                return false;
            }
            
            // Show loading
            const submitBtn = $(this).find('button[type="submit"]');
            const originalText = submitBtn.html();
            submitBtn.html('<i class="fas fa-spinner fa-spin me-2"></i>Processing...');
            submitBtn.prop('disabled', true);
            
            return true;
        });
        
        // Auto-format phone number
        $('input[name="phone"]').on('input', function() {
            let value = $(this).val().replace(/\D/g, '');
            if (value.length > 0) {
                if (value.startsWith('0')) {
                    value = '+254' + value.substring(1);
                } else if (!value.startsWith('+')) {
                    value = '+254' + value;
                }
                $(this).val(value);
            }
        });
    });
    </script>
</body>
</html>