<?php
// ============================================
// REMEDIES STORE - MAIN ENTRY POINT
// ============================================

// Configuration
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Path definitions
define('BASE_PATH', dirname(__DIR__, 2) . '/');
define('INCLUDES_PATH', BASE_PATH . 'includes/');
define('ASSETS_PATH', BASE_PATH . 'assets/');
define('REMEDIES_PATH', dirname(__DIR__) . '/');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// CSRF Token for forms (if not exists)
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Initialize database connection FIRST
function getDatabaseConnection() {
    static $connection = null;
    
    if ($connection === null) {
        try {
            $connection = new mysqli('localhost', 'root', '', 'philadelphia_ministry');
            
            if ($connection->connect_error) {
                error_log("Database connection failed: " . $connection->connect_error);
                return null;
            }
            
            $connection->set_charset("utf8mb4");
        } catch (Exception $e) {
            error_log("Database exception: " . $e->getMessage());
            return null;
        }
    }
    
    return $connection;
}

// Get database connection
$conn = getDatabaseConnection();

// Now include other files (they can use $conn)
require_once REMEDIES_PATH . 'includes/remedies-functions.php';

// ============================================
// BUSINESS LOGIC FUNCTIONS
// ============================================

function getCartCount($connection) {
    $cartCount = 0;
    
    if (isset($_SESSION['user_id']) && $connection) {
        $userId = (int)$_SESSION['user_id'];
        $cartQuery = "SELECT COUNT(*) as count FROM remedies_cart WHERE user_id = ?";
        
        if ($stmt = $connection->prepare($cartQuery)) {
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($cartData = $result->fetch_assoc()) {
                $cartCount = (int)$cartData['count'];
            }
            
            $stmt->close();
        }
    }
    
    return $cartCount;
}

function getFeaturedProducts($connection) {
    if (!$connection) {
        return false;
    }
    
    $query = "SELECT * FROM remedies_products 
              WHERE is_active = 1 AND quantity_in_stock > 0 
              ORDER BY RAND() LIMIT 6";
    
    return $connection->query($query);
}

function getCategories($connection) {
    if (!$connection) {
        return false;
    }
    
    $query = "SELECT category, COUNT(*) as count FROM remedies_products 
              WHERE is_active = 1 AND quantity_in_stock > 0 
              GROUP BY category ORDER BY count DESC";
    
    return $connection->query($query);
}

function getCategoryIcon($category) {
    $icons = [
        'herbs' => 'fas fa-leaf',
        'supplements' => 'fas fa-capsules',
        'oils' => 'fas fa-oil-can',
        'teas' => 'fas fa-mug-hot',
        'books' => 'fas fa-book',
        'equipment' => 'fas fa-dumbbell',
        'creams' => 'fas fa-pump-soap',
        'tinctures' => 'fas fa-flask',
        'powders' => 'fas fa-mortar-pestle',
        'capsules' => 'fas fa-capsules',
        'herbal' => 'fas fa-leaf',
        'supplement' => 'fas fa-capsules',
        'oil' => 'fas fa-oil-can',
        'tea' => 'fas fa-mug-hot',
        'book' => 'fas fa-book',
        'tools' => 'fas fa-tools'
    ];
    
    $key = strtolower(trim($category));
    return $icons[$key] ?? 'fas fa-shopping-basket';
}

// Function to truncate text if remedies-functions.php is not available
if (!function_exists('truncateText')) {
    function truncateText($text, $length = 100) {
        if (strlen($text) <= $length) {
            return $text;
        }
        return substr($text, 0, $length) . '...';
    }
}

// ============================================
// DATA FETCHING
// ============================================

$cartCount = 0;
$featuredProducts = null;
$categories = null;

if ($conn) {
    $cartCount = getCartCount($conn);
    $featuredProducts = getFeaturedProducts($conn);
    $categories = getCategories($conn);
} else {
    error_log("Database connection not available for store index");
}

// ============================================
// HTML OUTPUT
// ============================================
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Natural Remedies Store | Philadelphia Ministry</title>
    
    <!-- Meta Tags -->
    <meta name="description" content="High-quality natural remedies, herbs, supplements, and wellness products for holistic healing.">
    <meta name="keywords" content="natural remedies, herbal medicine, supplements, wellness products, organic herbs">
    
    <!-- Stylesheets -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Store-specific Styles -->
    <style>
        :root {
            --store-primary: #27ae60;
            --store-secondary: #2ecc71;
            --store-accent: #e74c3c;
            --store-dark: #2c3e50;
            --store-light: #ecf0f1;
            --store-gray: #95a5a6;
        }
        
        .store-banner {
            background: linear-gradient(rgba(44, 62, 80, 0.9), rgba(44, 62, 80, 0.9)),
                        url('<?php echo ASSETS_PATH; ?>images/store-banner.jpg');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 100px 0;
            margin-bottom: 40px;
        }
        
        .store-banner h1 {
            font-size: 3.5rem;
            font-weight: 700;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        .store-nav {
            background: white;
            border-bottom: 2px solid var(--store-light);
            padding: 15px 0;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .store-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .store-actions {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        
        .cart-link, .orders-link {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--store-dark);
            text-decoration: none;
            font-weight: 600;
            padding: 10px 20px;
            border-radius: 50px;
            transition: all 0.3s ease;
            background: var(--store-light);
        }
        
        .cart-link:hover, .orders-link:hover {
            background: var(--store-primary);
            color: white;
            transform: translateY(-2px);
        }
        
        .cart-count {
            background: var(--store-accent);
            color: white;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            font-weight: 700;
        }
        
        .search-box {
            flex: 1;
            max-width: 400px;
        }
        
        .search-box form {
            position: relative;
        }
        
        .search-box input {
            width: 100%;
            padding: 12px 50px 12px 20px;
            border: 2px solid var(--store-light);
            border-radius: 50px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        .search-box input:focus {
            outline: none;
            border-color: var(--store-primary);
            box-shadow: 0 0 0 3px rgba(39, 174, 96, 0.1);
        }
        
        .search-box button {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--store-gray);
            font-size: 1.2rem;
            cursor: pointer;
            transition: color 0.3s ease;
        }
        
        .search-box button:hover {
            color: var(--store-primary);
        }
        
        /* Categories */
        .category-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        
        .category-card {
            background: white;
            border-radius: 10px;
            padding: 25px 15px;
            text-align: center;
            text-decoration: none;
            color: var(--store-dark);
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }
        
        .category-card:hover {
            transform: translateY(-5px);
            border-color: var(--store-primary);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        
        .category-icon {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, var(--store-primary), var(--store-secondary));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
        }
        
        .category-icon i {
            font-size: 2rem;
            color: white;
        }
        
        .category-card h3 {
            font-size: 1.2rem;
            margin-bottom: 5px;
            font-weight: 600;
        }
        
        .product-count {
            color: var(--store-gray);
            font-size: 0.9rem;
        }
        
        /* Products */
        .product-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 30px;
            transition: all 0.3s ease;
            height: 100%;
            position: relative;
        }
        
        .product-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.15);
        }
        
        .product-badge {
            position: absolute;
            top: 15px;
            left: 15px;
            z-index: 2;
        }
        
        .badge {
            padding: 5px 12px;
            font-size: 0.8rem;
            font-weight: 600;
            margin-right: 5px;
        }
        
        .product-image {
            height: 250px;
            overflow: hidden;
            position: relative;
        }
        
        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }
        
        .product-card:hover .product-image img {
            transform: scale(1.1);
        }
        
        .product-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .product-card:hover .product-overlay {
            opacity: 1;
        }
        
        .product-info {
            padding: 20px;
        }
        
        .product-title {
            font-size: 1.2rem;
            color: var(--store-dark);
            margin-bottom: 10px;
            font-weight: 600;
            height: 50px;
            overflow: hidden;
        }
        
        .product-description {
            color: var(--store-gray);
            font-size: 0.95rem;
            margin-bottom: 15px;
            height: 60px;
            overflow: hidden;
        }
        
        .product-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            font-size: 0.9rem;
        }
        
        .product-category {
            background: var(--store-light);
            color: var(--store-dark);
            padding: 5px 15px;
            border-radius: 50px;
            font-size: 0.85rem;
        }
        
        .product-stock {
            font-weight: 600;
        }
        
        .stock-in {
            color: var(--store-primary);
        }
        
        .stock-out {
            color: var(--store-accent);
        }
        
        .product-price {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 15px;
        }
        
        .price {
            font-size: 1.5rem;
            color: var(--store-accent);
            font-weight: 700;
        }
        
        .product-actions {
            display: flex;
            gap: 10px;
        }
        
        /* Offers */
        .offers-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin-top: 30px;
        }
        
        .offer-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            border: 2px solid transparent;
            transition: all 0.3s ease;
        }
        
        .offer-card:hover {
            border-color: var(--store-primary);
            transform: translateY(-5px);
        }
        
        .offer-badge {
            position: absolute;
            top: 20px;
            right: 20px;
            background: var(--store-accent);
            color: white;
            padding: 8px 20px;
            border-radius: 50px;
            font-weight: 700;
            font-size: 0.9rem;
        }
        
        .offer-title {
            font-size: 1.5rem;
            color: var(--store-dark);
            margin-bottom: 10px;
        }
        
        .offer-price {
            margin: 20px 0;
        }
        
        .old-price {
            text-decoration: line-through;
            color: var(--store-gray);
            font-size: 1.2rem;
            margin-right: 10px;
        }
        
        .new-price {
            color: var(--store-accent);
            font-size: 2rem;
            font-weight: 700;
        }
        
        /* Features */
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin-top: 40px;
        }
        
        .feature-card {
            text-align: center;
            padding: 30px 20px;
            border-radius: 10px;
            background: white;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        
        .feature-icon {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, var(--store-primary), var(--store-secondary));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
        }
        
        .feature-icon i {
            font-size: 2rem;
            color: white;
        }
        
        .feature-title {
            font-size: 1.2rem;
            color: var(--store-dark);
            margin-bottom: 10px;
            font-weight: 600;
        }
        
        /* Newsletter */
        .newsletter-section {
            background: linear-gradient(135deg, var(--store-dark), #1a252f);
            color: white;
            padding: 60px 0;
            margin-top: 60px;
        }
        
        .newsletter-form {
            max-width: 600px;
            margin: 0 auto;
        }
        
        .form-control-lg {
            padding: 15px 25px;
            border-radius: 50px;
            border: none;
            font-size: 1.1rem;
        }
        
        .btn-lg {
            padding: 15px 40px;
            border-radius: 50px;
            font-size: 1.1rem;
            font-weight: 600;
        }
        
        /* Utility Classes */
        .section-padding {
            padding: 80px 0;
        }
        
        .section-title {
            color: var(--store-dark);
            position: relative;
            padding-bottom: 15px;
            margin-bottom: 30px;
            font-weight: 700;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 3px;
            background: var(--store-primary);
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .store-header {
                flex-direction: column;
                align-items: stretch;
            }
            
            .store-actions {
                justify-content: center;
            }
            
            .search-box {
                max-width: 100%;
            }
            
            .store-banner h1 {
                font-size: 2.5rem;
            }
            
            .section-padding {
                padding: 50px 0;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand" href="<?php echo BASE_PATH; ?>">
                <i class="fas fa-heartbeat text-primary me-2"></i>
                <span class="fw-bold">Philadelphia Remedies</span>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="mainNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_PATH; ?>">
                            <i class="fas fa-home me-1"></i> Home
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_PATH; ?>remedies/">
                            <i class="fas fa-spa me-1"></i> Remedies
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="./">
                            <i class="fas fa-store me-1"></i> Store
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_PATH; ?>remedies/consultations/">
                            <i class="fas fa-user-md me-1"></i> Consultations
                        </a>
                    </li>
                    <?php if(isset($_SESSION['user_id'])): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user me-1"></i> My Account
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="shopping-cart.php">
                                <i class="fas fa-shopping-cart me-2"></i> My Cart
                                <span class="badge bg-primary ms-2"><?php echo $cartCount; ?></span>
                            </a></li>
                            <li><a class="dropdown-item" href="my-orders.php">
                                <i class="fas fa-box me-2"></i> My Orders
                            </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_PATH; ?>members/logout.php">
                                <i class="fas fa-sign-out-alt me-2"></i> Logout
                            </a></li>
                        </ul>
                    </li>
                    <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_PATH; ?>members/login.php?redirect=<?php echo urlencode($_SERVER['REQUEST_URI']); ?>">
                            <i class="fas fa-sign-in-alt me-1"></i> Login
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    
    <!-- Store Banner -->
    <section class="store-banner">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center">
                    <h1 class="display-4 fw-bold mb-3">Natural Remedies Store</h1>
                    <p class="lead mb-4">Premium herbs, supplements, and wellness products for holistic healing</p>
                    <div class="d-flex flex-wrap justify-content-center gap-3">
                        <a href="#featured-products" class="btn btn-light btn-lg px-4">
                            <i class="fas fa-shopping-bag me-2"></i> Shop Now
                        </a>
                        <a href="#categories" class="btn btn-outline-light btn-lg px-4">
                            <i class="fas fa-list me-2"></i> Browse Categories
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Store Navigation -->
    <section class="store-nav" id="store-nav">
        <div class="container">
            <div class="store-header">
                <div class="store-actions">
                    <a href="shopping-cart.php" class="cart-link">
                        <i class="fas fa-shopping-cart"></i>
                        <span class="cart-count"><?php echo $cartCount; ?></span>
                        <span>My Cart</span>
                    </a>
                    
                    <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="my-orders.php" class="orders-link">
                        <i class="fas fa-box"></i>
                        <span>My Orders</span>
                    </a>
                    <?php endif; ?>
                </div>
                
                <div class="search-box">
                    <form action="search.php" method="GET" class="search-form">
                        <input type="text" name="q" placeholder="Search products, herbs, supplements..." 
                               value="<?php echo htmlspecialchars($_GET['q'] ?? ''); ?>"
                               aria-label="Search products">
                        <button type="submit" aria-label="Search">
                            <i class="fas fa-search"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Categories Section -->
    <section class="section-padding" id="categories">
        <div class="container">
            <div class="row mb-5">
                <div class="col-lg-12 text-center">
                    <h2 class="section-title mb-3">Shop by Category</h2>
                    <p class="text-muted">Browse our wide selection of natural products</p>
                </div>
            </div>
            
            <div class="category-grid">
                <?php if($categories && $categories->num_rows > 0): ?>
                    <?php while($category = $categories->fetch_assoc()): ?>
                    <a href="product-category.php?category=<?php echo urlencode($category['category']); ?>" 
                       class="category-card">
                        <div class="category-icon">
                            <i class="<?php echo getCategoryIcon($category['category']); ?>"></i>
                        </div>
                        <h3><?php echo htmlspecialchars($category['category']); ?></h3>
                        <span class="product-count"><?php echo $category['count']; ?> products</span>
                    </a>
                    <?php endwhile; ?>
                <?php else: ?>
                <div class="col-12 text-center py-5">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        <?php echo $conn ? 'No categories available at the moment.' : 'Database connection issue. Please try again later.'; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    
    <!-- Featured Products -->
    <section class="section-padding bg-light" id="featured-products">
        <div class="container">
            <div class="row mb-5">
                <div class="col-lg-12 text-center">
                    <h2 class="section-title mb-3">Featured Products</h2>
                    <p class="text-muted">Our most popular natural remedies</p>
                </div>
            </div>
            
            <div class="row">
                <?php if($featuredProducts && $featuredProducts->num_rows > 0): ?>
                    <?php while($product = $featuredProducts->fetch_assoc()): ?>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="product-card">
                            <!-- Product Badges -->
                            <div class="product-badge">
                                <?php if(($product['quantity_in_stock'] ?? 0) < 10): ?>
                                <span class="badge bg-warning">Low Stock</span>
                                <?php endif; ?>
                                <?php if($product['is_featured'] ?? false): ?>
                                <span class="badge bg-info">Featured</span>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Product Image -->
                            <div class="product-image">
                                <?php 
                                $imageUrl = $product['image_url'] ?? ASSETS_PATH . 'images/products/default.jpg';
                                // Check if image exists locally
                                $localPath = $_SERVER['DOCUMENT_ROOT'] . parse_url($imageUrl, PHP_URL_PATH);
                                if (!filter_var($imageUrl, FILTER_VALIDATE_URL) && !file_exists($localPath)) {
                                    $imageUrl = 'https://via.placeholder.com/400x300/ecf0f1/95a5a6?text=' . urlencode($product['name'] ?? 'Product');
                                }
                                ?>
                                <img src="<?php echo htmlspecialchars($imageUrl); ?>" 
                                     alt="<?php echo htmlspecialchars($product['name'] ?? 'Product'); ?>"
                                     loading="lazy">
                                <div class="product-overlay">
                                    <a href="product-details.php?id=<?php echo $product['id']; ?>" 
                                       class="btn btn-outline-light mb-2 w-75">
                                        <i class="fas fa-eye me-2"></i> View Details
                                    </a>
                                    
                                    <?php if(($product['quantity_in_stock'] ?? 0) > 0): ?>
                                    <button class="btn btn-light add-to-cart w-75" 
                                            data-product-id="<?php echo $product['id']; ?>">
                                        <i class="fas fa-cart-plus me-2"></i> Add to Cart
                                    </button>
                                    <?php else: ?>
                                    <button class="btn btn-light w-75" disabled>
                                        <i class="fas fa-times me-2"></i> Out of Stock
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <!-- Product Info -->
                            <div class="product-info">
                                <h3 class="product-title"><?php echo htmlspecialchars($product['name'] ?? 'Unnamed Product'); ?></h3>
                                <p class="product-description">
                                    <?php echo truncateText($product['description'] ?? '', 80); ?>
                                </p>
                                
                                <div class="product-meta">
                                    <span class="product-category">
                                        <?php echo htmlspecialchars($product['category'] ?? 'Uncategorized'); ?>
                                    </span>
                                    <span class="product-stock <?php echo ($product['quantity_in_stock'] ?? 0) > 0 ? 'stock-in' : 'stock-out'; ?>">
                                        <?php if(($product['quantity_in_stock'] ?? 0) > 0): ?>
                                        <i class="fas fa-check-circle me-1"></i> In Stock
                                        <?php else: ?>
                                        <i class="fas fa-times-circle me-1"></i> Out of Stock
                                        <?php endif; ?>
                                    </span>
                                </div>
                                
                                <div class="product-price">
                                    <span class="price">Ksh <?php echo number_format($product['unit_price'] ?? 0, 2); ?></span>
                                    <?php if(isset($product['cost_price']) && isset($product['unit_price']) && $product['unit_price'] < $product['cost_price'] * 1.2): ?>
                                    <small class="text-success fw-bold">Best Price</small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                <div class="col-12 text-center py-5">
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo $conn ? 'No featured products available at the moment. Please check back later.' : 'Unable to load products. Database connection issue.'; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    
    <!-- Special Offers -->
    <section class="section-padding" id="special-offers">
        <div class="container">
            <div class="row mb-5">
                <div class="col-lg-12 text-center">
                    <h2 class="section-title mb-3">Special Offers</h2>
                    <p class="text-muted">Limited time discounts and exclusive bundles</p>
                </div>
            </div>
            
            <div class="offers-grid">
                <!-- Offer 1 -->
                <div class="offer-card">
                    <div class="offer-badge">20% OFF</div>
                    <h3 class="offer-title">Immune Boost Bundle</h3>
                    <p class="text-muted mb-3">Elderberry syrup, Vitamin C complex, and Zinc supplement combo</p>
                    <div class="offer-price">
                        <span class="old-price">Ksh 3,500</span>
                        <span class="new-price">Ksh 2,800</span>
                    </div>
                    <a href="product-details.php?bundle=immune" class="btn btn-primary mt-3 w-100">
                        <i class="fas fa-shopping-basket me-2"></i> View Bundle
                    </a>
                </div>
                
                <!-- Offer 2 -->
                <div class="offer-card">
                    <div class="offer-badge">FREE SHIPPING</div>
                    <h3 class="offer-title">Orders Over Ksh 5,000</h3>
                    <p class="text-muted mb-3">Free nationwide delivery on all orders above Ksh 5,000</p>
                    <div class="offer-price">
                        <span class="new-price">Free Delivery</span>
                    </div>
                    <a href="shopping-cart.php" class="btn btn-primary mt-3 w-100">
                        <i class="fas fa-truck me-2"></i> Shop Now
                    </a>
                </div>
                
                <!-- Offer 3 -->
                <div class="offer-card">
                    <div class="offer-badge">BUY 2 GET 1 FREE</div>
                    <h3 class="offer-title">Essential Oils Collection</h3>
                    <p class="text-muted mb-3">Lavender, Tea Tree, and Eucalyptus essential oils</p>
                    <div class="offer-price">
                        <span class="new-price">Special Offer</span>
                    </div>
                    <a href="product-category.php?category=Oils" class="btn btn-primary mt-3 w-100">
                        <i class="fas fa-oil-can me-2"></i> Browse Oils
                    </a>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Why Shop With Us -->
    <section class="section-padding bg-light">
        <div class="container">
            <div class="row mb-5">
                <div class="col-lg-12 text-center">
                    <h2 class="section-title mb-3">Why Choose Our Store</h2>
                    <p class="text-muted">We're committed to your health and wellness</p>
                </div>
            </div>
            
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-seedling"></i>
                    </div>
                    <h4 class="feature-title">100% Natural Products</h4>
                    <p class="text-muted mb-0">All products are sourced from organic, sustainable sources</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-award"></i>
                    </div>
                    <h4 class="feature-title">Quality Guaranteed</h4>
                    <p class="text-muted mb-0">Rigorous testing and quality control standards</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-shipping-fast"></i>
                    </div>
                    <h4 class="feature-title">Fast & Reliable Delivery</h4>
                    <p class="text-muted mb-0">Nationwide shipping within 3-5 business days</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-headset"></i>
                    </div>
                    <h4 class="feature-title">Expert Support</h4>
                    <p class="text-muted mb-0">Free consultation with certified health practitioners</p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Newsletter -->
    <section class="newsletter-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-4 mb-lg-0">
                    <h3 class="text-white mb-3">Stay Updated</h3>
                    <p class="text-light mb-0">Subscribe to our newsletter for health tips, new products, and exclusive offers</p>
                </div>
                <div class="col-lg-6">
                    <form class="newsletter-form" id="newsletter-form">
                        <div class="input-group">
                            <input type="email" class="form-control form-control-lg" 
                                   placeholder="Enter your email address" required>
                            <button class="btn btn-light btn-lg" type="submit">
                                Subscribe
                            </button>
                        </div>
                        <div class="form-text text-light mt-2">
                            We respect your privacy. Unsubscribe at any time.
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Footer -->
    <footer class="bg-dark text-white py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <h5 class="mb-3">
                        <i class="fas fa-heartbeat me-2"></i>Philadelphia Remedies
                    </h5>
                    <p class="text-light">Natural healing through traditional remedies and modern wellness practices.</p>
                </div>
                
                <div class="col-lg-4 mb-4">
                    <h5 class="mb-3">Quick Links</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2">
                            <a href="<?php echo BASE_PATH; ?>remedies/" class="text-light text-decoration-none">
                                <i class="fas fa-chevron-right me-1"></i> Remedies Home
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="<?php echo BASE_PATH; ?>remedies/consultations/" class="text-light text-decoration-none">
                                <i class="fas fa-chevron-right me-1"></i> Book Consultation
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo BASE_PATH; ?>contact.php" class="text-light text-decoration-none">
                                <i class="fas fa-chevron-right me-1"></i> Contact Us
                            </a>
                        </li>
                    </ul>
                </div>
                
                <div class="col-lg-4 mb-4">
                    <h5 class="mb-3">Contact Information</h5>
                    <p class="mb-2">
                        <i class="fas fa-phone me-2"></i> +254 712 345 678
                    </p>
                    <p class="mb-2">
                        <i class="fas fa-envelope me-2"></i> remedies@philadelphia-ministry.org
                    </p>
                    <p class="mb-0">
                        <i class="fas fa-clock me-2"></i> Mon-Fri: 8:00 AM - 6:00 PM
                    </p>
                </div>
            </div>
            
            <hr class="bg-light my-4">
            
            <div class="row">
                <div class="col-md-12 text-center">
                    <p class="mb-0">
                        &copy; <?php echo date('Y'); ?> Philadelphia Ministry. All rights reserved.
                    </p>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    $(document).ready(function() {
        // Add to cart functionality
        $('.add-to-cart').click(function(e) {
            e.preventDefault();
            
            const productId = $(this).data('product-id');
            const button = $(this);
            
            // Check if user is logged in
            <?php if(!isset($_SESSION['user_id'])): ?>
            window.location.href = '<?php echo BASE_PATH; ?>members/login.php?redirect=' + 
                                  encodeURIComponent(window.location.pathname);
            <?php else: ?>
            
            // Show loading state
            const originalHtml = button.html();
            button.html('<i class="fas fa-spinner fa-spin"></i> Adding...');
            button.prop('disabled', true);
            
            // Add to cart via AJAX
            $.ajax({
                url: 'api/store-api.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'add_to_cart',
                    product_id: productId,
                    quantity: 1,
                    csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
                },
                success: function(response) {
                    if (response.success) {
                        // Update cart count
                        $('.cart-count').text(response.cart_count);
                        
                        // Show success message
                        button.html('<i class="fas fa-check"></i> Added to Cart');
                        button.removeClass('btn-light').addClass('btn-success');
                        
                        // Reset button after 2 seconds
                        setTimeout(function() {
                            button.html(originalHtml);
                            button.removeClass('btn-success').addClass('btn-light');
                            button.prop('disabled', false);
                        }, 2000);
                        
                        // Show toast notification
                        showToast('Success', 'Product added to cart!', 'success');
                    } else {
                        showToast('Error', response.message || 'Failed to add item to cart', 'error');
                        button.html(originalHtml);
                        button.prop('disabled', false);
                    }
                },
                error: function() {
                    showToast('Error', 'Network error. Please try again.', 'error');
                    button.html(originalHtml);
                    button.prop('disabled', false);
                }
            });
            <?php endif; ?>
        });
        
        // Newsletter form submission
        $('#newsletter-form').submit(function(e) {
            e.preventDefault();
            const email = $(this).find('input[type="email"]').val();
            const form = $(this);
            
            // Simple validation
            if (!validateEmail(email)) {
                showToast('Error', 'Please enter a valid email address', 'error');
                return;
            }
            
            // Show loading
            const button = form.find('button');
            const originalText = button.html();
            button.html('<i class="fas fa-spinner fa-spin"></i> Subscribing...');
            button.prop('disabled', true);
            
            // Simulate API call
            setTimeout(function() {
                showToast('Success', 'Thank you for subscribing!', 'success');
                form.find('input').val('');
                button.html(originalText);
                button.prop('disabled', false);
            }, 1500);
        });
        
        // Search form submission
        $('.search-form').submit(function(e) {
            const searchTerm = $(this).find('input[name="q"]').val().trim();
            if (searchTerm.length < 2) {
                e.preventDefault();
                showToast('Warning', 'Please enter at least 2 characters to search', 'warning');
            }
        });
        
        // Helper functions
        function validateEmail(email) {
            const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }
        
        function showToast(title, message, type) {
            // Create a simple alert for now
            alert(title + ': ' + message);
        }
    });
    </script>
</body>
</html>
<?php
// Clean up
if ($featuredProducts instanceof mysqli_result) {
    $featuredProducts->free();
}

if ($categories instanceof mysqli_result) {
    $categories->free();
}

if ($conn) {
    $conn->close();
}
?>