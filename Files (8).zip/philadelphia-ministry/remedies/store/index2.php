<?php
// Don't define STORE_ACCESS here - config.php will define it
// Remove this line: define('STORE_ACCESS', true);



// Rest of your code...
// Include config
require_once 'config.php';

// Get featured products
$featuredProducts = getFeaturedProducts(8);
$categories = getCategories();

// Get user info if logged in
$userName = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : '';
$userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;

// Cart count
$cartCount = getCartCount();
$cartTotal = getCartTotal();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $storeSettings['store_name']; ?> - Natural Remedies Store</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:wght@400;500;600&display=swap" rel="stylesheet">
    
    <!-- Custom CSS -->
    <style>
        :root {
            --primary-color: #1a5276;
            --secondary-color: #2c3e50;
            --accent-color: #27ae60;
            --light-color: #f8f9fa;
            --dark-color: #2c3e50;
            --text-color: #333;
            --text-light: #6c757d;
            --border-color: #dee2e6;
            --shadow: 0 4px 15px rgba(0,0,0,0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            color: var(--text-color);
            background-color: #fff;
            line-height: 1.6;
        }
        
        h1, h2, h3, h4, h5 {
            font-family: 'Playfair Display', serif;
            font-weight: 600;
            color: var(--dark-color);
        }
        
        a {
            text-decoration: none;
            color: inherit;
            transition: var(--transition);
        }
        
        a:hover {
            color: var(--accent-color);
        }
        
        .btn {
            border-radius: 8px;
            padding: 10px 24px;
            font-weight: 500;
            transition: var(--transition);
            border: none;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
            color: white;
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }
        
        .btn-accent {
            background: var(--accent-color);
            color: white;
        }
        
        .btn-accent:hover {
            background: #219653;
            color: white;
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }
        
        .btn-outline-primary {
            border: 2px solid var(--primary-color);
            color: var(--primary-color);
            background: transparent;
        }
        
        .btn-outline-primary:hover {
            background: var(--primary-color);
            color: white;
        }
        
        /* Header & Navigation */
        .store-header {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .store-navbar {
            padding: 15px 0;
        }
        
        .navbar-brand {
            font-family: 'Playfair Display', serif;
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary-color);
        }
        
        .navbar-brand i {
            color: var(--accent-color);
        }
        
        .nav-link {
            font-weight: 500;
            padding: 8px 15px !important;
            border-radius: 6px;
            margin: 0 5px;
        }
        
        .nav-link:hover, .nav-link.active {
            background: rgba(26, 82, 118, 0.1);
            color: var(--primary-color);
        }
        
        .cart-btn {
            position: relative;
            background: var(--light-color);
            border-radius: 50px;
            padding: 8px 20px;
        }
        
        .cart-count {
            position: absolute;
            top: -8px;
            right: -8px;
            background: var(--accent-color);
            color: white;
            border-radius: 50%;
            width: 22px;
            height: 22px;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }
        
        .user-dropdown {
            padding: 6px 12px;
            border-radius: 50px;
            background: var(--light-color);
        }
        
        .user-dropdown:hover {
            background: rgba(26, 82, 118, 0.1);
        }
        
        /* Hero Section */
        .hero-section {
            background: linear-gradient(135deg, rgba(26, 82, 118, 0.9), rgba(44, 62, 80, 0.9)),
                        url('<?php echo ASSETS_URL; ?>images/store-hero.jpg');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 120px 0 80px;
            margin-bottom: 60px;
        }
        
        .hero-title {
            font-size: 3.5rem;
            font-weight: 700;
            margin-bottom: 20px;
            line-height: 1.2;
        }
        
        .hero-subtitle {
            font-size: 1.2rem;
            opacity: 0.9;
            margin-bottom: 30px;
            max-width: 600px;
        }
        
        .hero-search {
            max-width: 500px;
            margin: 30px auto 0;
        }
        
        .hero-search .input-group {
            box-shadow: 0 5px 20px rgba(0,0,0,0.2);
            border-radius: 50px;
            overflow: hidden;
        }
        
        .hero-search input {
            border: none;
            padding: 15px 25px;
            font-size: 1.1rem;
        }
        
        .hero-search button {
            background: var(--accent-color);
            color: white;
            border: none;
            padding: 0 30px;
            font-weight: 600;
        }
        
        .hero-search button:hover {
            background: #219653;
        }
        
        /* Categories Section */
        .categories-section {
            padding: 80px 0;
            background: var(--light-color);
        }
        
        .section-title {
            text-align: center;
            margin-bottom: 50px;
            position: relative;
        }
        
        .section-title h2 {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }
        
        .section-title p {
            color: var(--text-light);
            max-width: 600px;
            margin: 0 auto;
        }
        
        .category-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            text-align: center;
            box-shadow: var(--shadow);
            transition: var(--transition);
            height: 100%;
            border: 2px solid transparent;
        }
        
        .category-card:hover {
            transform: translateY(-10px);
            border-color: var(--accent-color);
            box-shadow: 0 15px 30px rgba(0,0,0,0.15);
        }
        
        .category-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
        }
        
        .category-icon i {
            font-size: 2rem;
            color: white;
        }
        
        .category-card h3 {
            font-size: 1.3rem;
            margin-bottom: 10px;
        }
        
        .category-card p {
            color: var(--text-light);
            font-size: 0.9rem;
            margin-bottom: 0;
        }
        
        /* Products Section */
        .products-section {
            padding: 80px 0;
        }
        
        .product-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: var(--shadow);
            transition: var(--transition);
            height: 100%;
            margin-bottom: 30px;
        }
        
        .product-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        }
        
        .product-badge {
            position: absolute;
            top: 15px;
            left: 15px;
            z-index: 2;
        }
        
        .badge {
            padding: 6px 12px;
            font-weight: 600;
            border-radius: 20px;
            font-size: 0.8rem;
        }
        
        .product-image {
            height: 250px;
            overflow: hidden;
            position: relative;
        }
        
        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }
        
        .product-card:hover .product-image img {
            transform: scale(1.1);
        }
        
        .product-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .product-card:hover .product-overlay {
            opacity: 1;
        }
        
        .product-content {
            padding: 20px;
        }
        
        .product-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 10px;
            height: 50px;
            overflow: hidden;
        }
        
        .product-description {
            color: var(--text-light);
            font-size: 0.9rem;
            margin-bottom: 15px;
            height: 60px;
            overflow: hidden;
        }
        
        .product-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            font-size: 0.9rem;
        }
        
        .product-category {
            background: rgba(26, 82, 118, 0.1);
            color: var(--primary-color);
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
        }
        
        .product-stock {
            font-weight: 600;
        }
        
        .stock-in {
            color: var(--accent-color);
        }
        
        .stock-out {
            color: #dc3545;
        }
        
        .product-price {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 15px;
        }
        
        .product-actions {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }
        
        /* Features Section */
        .features-section {
            padding: 80px 0;
            background: var(--light-color);
        }
        
        .feature-item {
            text-align: center;
            padding: 30px 20px;
        }
        
        .feature-icon {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
        }
        
        .feature-icon i {
            font-size: 1.8rem;
            color: white;
        }
        
        .feature-title {
            font-size: 1.2rem;
            margin-bottom: 10px;
        }
        
        .feature-text {
            color: var(--text-light);
            font-size: 0.95rem;
        }
        
        /* Newsletter Section */
        .newsletter-section {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 60px 0;
            text-align: center;
        }
        
        .newsletter-title {
            font-size: 2.2rem;
            margin-bottom: 15px;
        }
        
        .newsletter-form {
            max-width: 500px;
            margin: 30px auto 0;
        }
        
        .newsletter-form .input-group {
            box-shadow: 0 5px 20px rgba(0,0,0,0.2);
            border-radius: 50px;
            overflow: hidden;
        }
        
        .newsletter-form input {
            border: none;
            padding: 15px 25px;
            font-size: 1rem;
        }
        
        .newsletter-form button {
            background: var(--accent-color);
            color: white;
            border: none;
            padding: 0 30px;
            font-weight: 600;
        }
        
        /* Footer */
        .store-footer {
            background: var(--dark-color);
            color: white;
            padding: 60px 0 30px;
        }
        
        .footer-logo {
            font-family: 'Playfair Display', serif;
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 20px;
            display: inline-block;
        }
        
        .footer-links h5 {
            color: white;
            font-size: 1.1rem;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 10px;
        }
        
        .footer-links h5:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 2px;
            background: var(--accent-color);
        }
        
        .footer-links ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .footer-links li {
            margin-bottom: 10px;
        }
        
        .footer-links a {
            color: rgba(255,255,255,0.8);
            transition: var(--transition);
        }
        
        .footer-links a:hover {
            color: white;
            padding-left: 5px;
        }
        
        .footer-contact p {
            margin-bottom: 10px;
            color: rgba(255,255,255,0.8);
        }
        
        .footer-contact i {
            color: var(--accent-color);
            margin-right: 10px;
            width: 20px;
        }
        
        .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.1);
            padding-top: 20px;
            margin-top: 40px;
            text-align: center;
            color: rgba(255,255,255,0.6);
            font-size: 0.9rem;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .hero-title {
                font-size: 2.5rem;
            }
            
            .section-title h2 {
                font-size: 2rem;
            }
            
            .navbar-nav {
                background: white;
                padding: 20px;
                border-radius: 10px;
                margin-top: 10px;
                box-shadow: var(--shadow);
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="store-header">
        <div class="container">
            <nav class="navbar navbar-expand-lg store-navbar">
                <div class="container-fluid">
                    <!-- Logo -->
                    <a class="navbar-brand" href="index.php">
                        <i class="fas fa-heartbeat me-2"></i>
                        Philadelphia Remedies
                    </a>
                    
                    <!-- Mobile Toggle -->
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
                        <i class="fas fa-bars"></i>
                    </button>
                    
                    <!-- Navigation -->
                    <div class="collapse navbar-collapse" id="mainNav">
                        <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <a class="nav-link active" href="index.php">
                                    <i class="fas fa-home me-1"></i> Home
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="products.php">
                                    <i class="fas fa-store me-1"></i> Shop
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../treatments/">
                                    <i class="fas fa-spa me-1"></i> Treatments
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../consultations/">
                                    <i class="fas fa-user-md me-1"></i> Consultations
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="about.php">
                                    <i class="fas fa-info-circle me-1"></i> About
                                </a>
                            </li>
                        </ul>
                        
                        <!-- User Actions -->
                        <div class="d-flex align-items-center gap-3">
                            <!-- Search Button -->
                            <button class="btn btn-outline-primary btn-sm" data-bs-toggle="modal" data-bs-target="#searchModal">
                                <i class="fas fa-search"></i>
                            </button>
                            
                            <!-- Cart -->
                            <a href="shopping-cart.php" class="cart-btn position-relative">
                                <i class="fas fa-shopping-cart"></i>
                                <?php if($cartCount > 0): ?>
                                <span class="cart-count"><?php echo $cartCount; ?></span>
                                <?php endif; ?>
                            </a>
                            
                            <!-- User -->
                            <?php if($userId): ?>
                            <div class="dropdown">
                                <button class="btn btn-outline-primary user-dropdown dropdown-toggle" data-bs-toggle="dropdown">
                                    <i class="fas fa-user me-2"></i>
                                    <?php echo htmlspecialchars($userName); ?>
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="my-orders.php">
                                        <i class="fas fa-box me-2"></i> My Orders
                                    </a></li>
                                    <li><a class="dropdown-item" href="my-account.php">
                                        <i class="fas fa-user-circle me-2"></i> My Account
                                    </a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item text-danger" href="<?php echo BASE_PATH; ?>members/logout.php">
                                        <i class="fas fa-sign-out-alt me-2"></i> Logout
                                    </a></li>
                                </ul>
                            </div>
                            <?php else: ?>
                            <a href="<?php echo BASE_PATH; ?>members/login.php?redirect=<?php echo urlencode($_SERVER['REQUEST_URI']); ?>" 
                               class="btn btn-primary btn-sm">
                                <i class="fas fa-sign-in-alt me-1"></i> Login
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </nav>
        </div>
    </header>
    
    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1 class="hero-title">Natural Remedies for Holistic Healing</h1>
                    <p class="hero-subtitle">
                        Discover premium herbs, supplements, and wellness products from Philadelphia Ministry. 
                        Quality natural remedies backed by faith and tradition.
                    </p>
                    <div class="d-flex flex-wrap gap-3">
                        <a href="products.php" class="btn btn-accent btn-lg">
                            <i class="fas fa-shopping-bag me-2"></i> Shop Now
                        </a>
                        <a href="../consultations/" class="btn btn-outline-light btn-lg">
                            <i class="fas fa-user-md me-2"></i> Book Consultation
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="hero-search">
                <form action="search.php" method="GET" class="search-form">
                    <div class="input-group">
                        <input type="text" name="q" class="form-control" 
                               placeholder="Search remedies, herbs, supplements..." 
                               aria-label="Search products">
                        <button class="btn btn-accent" type="submit">
                            <i class="fas fa-search me-2"></i> Search
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </section>
    
    <!-- Categories Section -->
    <section class="categories-section">
        <div class="container">
            <div class="section-title">
                <h2>Shop by Category</h2>
                <p>Browse our collection of natural healing products</p>
            </div>
            
            <div class="row">
                <?php foreach($categories as $category): ?>
                <div class="col-lg-3 col-md-6 mb-4">
                    <a href="products.php?category=<?php echo $category['id']; ?>" class="category-card">
                        <div class="category-icon">
                            <?php
                            $icon = 'fas fa-leaf'; // Default
                            switch(strtolower($category['name'])) {
                                case 'herbs': $icon = 'fas fa-leaf'; break;
                                case 'oils': $icon = 'fas fa-oil-can'; break;
                                case 'teas': $icon = 'fas fa-mug-hot'; break;
                                case 'supplements': $icon = 'fas fa-capsules'; break;
                                case 'books': $icon = 'fas fa-book'; break;
                                case 'equipment': $icon = 'fas fa-dumbbell'; break;
                            }
                            ?>
                            <i class="<?php echo $icon; ?>"></i>
                        </div>
                        <h3><?php echo htmlspecialchars($category['name']); ?></h3>
                        <p>Natural healing through traditional remedies</p>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    
    <!-- Featured Products -->
    <section class="products-section">
        <div class="container">
            <div class="section-title">
                <h2>Featured Products</h2>
                <p>Our most popular natural remedies</p>
            </div>
            
            <div class="row">
                <?php if(count($featuredProducts) > 0): ?>
                    <?php foreach($featuredProducts as $product): ?>
                    <div class="col-lg-3 col-md-6">
                        <div class="product-card">
                            <?php if($product['quantity_in_stock'] < 10): ?>
                            <div class="product-badge">
                                <span class="badge bg-warning">Low Stock</span>
                            </div>
                            <?php endif; ?>
                            
                            <div class="product-image">
                                <img src="<?php echo $product['image_url'] ?: ASSETS_URL . 'images/products/default.jpg'; ?>" 
                                     alt="<?php echo htmlspecialchars($product['name']); ?>">
                                <div class="product-overlay">
                                    <a href="product-details.php?id=<?php echo $product['id']; ?>" 
                                       class="btn btn-outline-light">
                                        <i class="fas fa-eye me-2"></i> View Details
                                    </a>
                                </div>
                            </div>
                            
                            <div class="product-content">
                                <h3 class="product-title"><?php echo htmlspecialchars($product['name']); ?></h3>
                                <p class="product-description">
                                    <?php echo substr(htmlspecialchars($product['description'] ?: ''), 0, 80); ?>...
                                </p>
                                
                                <div class="product-meta">
                                    <span class="product-category"><?php echo htmlspecialchars($product['category_name'] ?: 'General'); ?></span>
                                    <span class="product-stock <?php echo $product['quantity_in_stock'] > 0 ? 'stock-in' : 'stock-out'; ?>">
                                        <i class="fas fa-<?php echo $product['quantity_in_stock'] > 0 ? 'check' : 'times'; ?>-circle me-1"></i>
                                        <?php echo $product['quantity_in_stock'] > 0 ? 'In Stock' : 'Out of Stock'; ?>
                                    </span>
                                </div>
                                
                                <div class="product-price">
                                    <?php echo formatCurrency($product['unit_price']); ?>
                                </div>
                                
                                <div class="product-actions">
                                    <a href="product-details.php?id=<?php echo $product['id']; ?>" 
                                       class="btn btn-outline-primary btn-sm">
                                        <i class="fas fa-eye me-1"></i> View
                                    </a>
                                    <?php if($product['quantity_in_stock'] > 0): ?>
                                    <button class="btn btn-primary btn-sm add-to-cart" 
                                            data-product-id="<?php echo $product['id']; ?>"
                                            data-product-name="<?php echo htmlspecialchars($product['name']); ?>"
                                            data-product-price="<?php echo $product['unit_price']; ?>">
                                        <i class="fas fa-cart-plus me-1"></i> Add to Cart
                                    </button>
                                    <?php else: ?>
                                    <button class="btn btn-secondary btn-sm" disabled>
                                        Out of Stock
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                <div class="col-12 text-center py-5">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        No featured products available at the moment.
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="text-center mt-5">
                <a href="products.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-store me-2"></i> View All Products
                </a>
            </div>
        </div>
    </section>
    
    <!-- Features Section -->
    <section class="features-section">
        <div class="container">
            <div class="section-title">
                <h2>Why Shop With Us</h2>
                <p>Experience the Philadelphia Ministry difference</p>
            </div>
            
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="feature-item">
                        <div class="feature-icon">
                            <i class="fas fa-seedling"></i>
                        </div>
                        <h4 class="feature-title">100% Natural</h4>
                        <p class="feature-text">All products are sourced from organic, sustainable sources.</p>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6">
                    <div class="feature-item">
                        <div class="feature-icon">
                            <i class="fas fa-award"></i>
                        </div>
                        <h4 class="feature-title">Quality Guaranteed</h4>
                        <p class="feature-text">Rigorous testing and quality control standards.</p>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6">
                    <div class="feature-item">
                        <div class="feature-icon">
                            <i class="fas fa-shipping-fast"></i>
                        </div>
                        <h4 class="feature-title">Fast Delivery</h4>
                        <p class="feature-text">Nationwide shipping within 3-5 business days.</p>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6">
                    <div class="feature-item">
                        <div class="feature-icon">
                            <i class="fas fa-headset"></i>
                        </div>
                        <h4 class="feature-title">Expert Support</h4>
                        <p class="feature-text">Free consultation with certified health practitioners.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Newsletter -->
    <section class="newsletter-section">
        <div class="container">
            <h3 class="newsletter-title">Stay Updated</h3>
            <p class="mb-0">Subscribe to our newsletter for health tips, new products, and exclusive offers</p>
            
            <form class="newsletter-form">
                <div class="input-group">
                    <input type="email" class="form-control" placeholder="Enter your email address" required>
                    <button class="btn btn-accent" type="submit">
                        Subscribe
                    </button>
                </div>
                <small class="d-block mt-2 opacity-75">We respect your privacy. Unsubscribe at any time.</small>
            </form>
        </div>
    </section>
    
    <!-- Footer -->
    <footer class="store-footer">
        <div class="container">
            <div class="row">
                <!-- Logo & Description -->
                <div class="col-lg-4 mb-5 mb-lg-0">
                    <a href="index.php" class="footer-logo">
                        <i class="fas fa-heartbeat me-2"></i>Philadelphia Remedies
                    </a>
                    <p class="mb-4" style="color: rgba(255,255,255,0.8);">
                        Natural healing through traditional remedies and modern wellness practices. 
                        Part of Philadelphia Ministry's holistic health initiative.
                    </p>
                </div>
                
                <!-- Quick Links -->
                <div class="col-lg-2 col-md-6 mb-5 mb-lg-0">
                    <div class="footer-links">
                        <h5>Shop</h5>
                        <ul>
                            <li><a href="products.php">All Products</a></li>
                            <li><a href="products.php?category=herbs">Herbal Remedies</a></li>
                            <li><a href="products.php?category=oils">Essential Oils</a></li>
                            <li><a href="products.php?category=supplements">Supplements</a></li>
                            <li><a href="products.php?category=teas">Herbal Teas</a></li>
                        </ul>
                    </div>
                </div>
                
                <!-- Resources -->
                <div class="col-lg-2 col-md-6 mb-5 mb-lg-0">
                    <div class="footer-links">
                        <h5>Resources</h5>
                        <ul>
                            <li><a href="../treatments/">Treatments</a></li>
                            <li><a href="../consultations/">Consultations</a></li>
                            <li><a href="about.php">About Us</a></li>
                            <li><a href="contact.php">Contact</a></li>
                            <li><a href="faq.php">FAQ</a></li>
                        </ul>
                    </div>
                </div>
                
                <!-- Contact -->
                <div class="col-lg-4">
                    <div class="footer-contact">
                        <h5>Contact Info</h5>
                        <p><i class="fas fa-map-marker-alt"></i> Philadelphia Ministry, Nairobi, Kenya</p>
                        <p><i class="fas fa-phone"></i> +254 712 345 678</p>
                        <p><i class="fas fa-envelope"></i> remedies@philadelphia-ministry.org</p>
                        <p><i class="fas fa-clock"></i> Mon-Fri: 8:00 AM - 6:00 PM</p>
                    </div>
                </div>
            </div>
            
            <!-- Copyright -->
            <div class="footer-bottom">
                <div class="row">
                    <div class="col-md-12">
                        <p class="mb-0">
                            &copy; <?php echo date('Y'); ?> Philadelphia Ministry. All rights reserved. | 
                            <a href="privacy.php" style="color: rgba(255,255,255,0.6);">Privacy Policy</a> | 
                            <a href="terms.php" style="color: rgba(255,255,255,0.6);">Terms of Service</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Search Modal -->
    <div class="modal fade" id="searchModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Search Products</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form action="search.php" method="GET">
                        <div class="input-group">
                            <input type="text" name="q" class="form-control form-control-lg" 
                                   placeholder="What are you looking for?" autofocus>
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- Custom JS -->
    <script>
    $(document).ready(function() {
        // Add to cart functionality
        $('.add-to-cart').click(function() {
            const productId = $(this).data('product-id');
            const productName = $(this).data('product-name');
            const productPrice = $(this).data('product-price');
            
            <?php if(!$userId): ?>
            // Redirect to login if not logged in
            window.location.href = '<?php echo BASE_PATH; ?>members/login.php?redirect=' + 
                                  encodeURIComponent(window.location.pathname);
            <?php else: ?>
            
            // Show loading
            const button = $(this);
            const originalHtml = button.html();
            button.html('<i class="fas fa-spinner fa-spin"></i> Adding...');
            button.prop('disabled', true);
            
            // Add to cart via AJAX
            $.ajax({
                url: 'api/cart.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'add_to_cart',
                    product_id: productId,
                    quantity: 1,
                    csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
                },
                success: function(response) {
                    if (response.success) {
                        // Update cart count
                        $('.cart-count').text(response.cart_count);
                        
                        // Show success message
                        button.html('<i class="fas fa-check"></i> Added');
                        button.removeClass('btn-primary').addClass('btn-success');
                        
                        // Show toast
                        showToast('Success', productName + ' added to cart!', 'success');
                        
                        // Reset button after 2 seconds
                        setTimeout(function() {
                            button.html(originalHtml);
                            button.removeClass('btn-success').addClass('btn-primary');
                            button.prop('disabled', false);
                        }, 2000);
                    } else {
                        showToast('Error', response.message, 'error');
                        button.html(originalHtml);
                        button.prop('disabled', false);
                    }
                },
                error: function() {
                    showToast('Error', 'Network error. Please try again.', 'error');
                    button.html(originalHtml);
                    button.prop('disabled', false);
                }
            });
            <?php endif; ?>
        });
        
        // Newsletter form
        $('.newsletter-form').submit(function(e) {
            e.preventDefault();
            const email = $(this).find('input[type="email"]').val();
            const form = $(this);
            
            // Validate email
            if (!validateEmail(email)) {
                showToast('Error', 'Please enter a valid email address', 'error');
                return;
            }
            
            // Show loading
            const button = form.find('button');
            const originalText = button.html();
            button.html('<i class="fas fa-spinner fa-spin"></i>');
            button.prop('disabled', true);
            
            // Submit via AJAX
            $.ajax({
                url: 'api/newsletter.php',
                type: 'POST',
                data: {
                    email: email,
                    csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
                },
                success: function(response) {
                    if (response.success) {
                        showToast('Success', 'Thank you for subscribing!', 'success');
                        form.find('input').val('');
                    } else {
                        showToast('Error', response.message, 'error');
                    }
                    button.html(originalText);
                    button.prop('disabled', false);
                },
                error: function() {
                    showToast('Error', 'Network error. Please try again.', 'error');
                    button.html(originalText);
                    button.prop('disabled', false);
                }
            });
        });
        
        // Helper functions
        function validateEmail(email) {
            const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }
        
        function showToast(title, message, type) {
            // Create toast element
            const toast = $(`
                <div class="position-fixed top-0 end-0 p-3" style="z-index: 9999">
                    <div class="toast align-items-center text-white bg-${type === 'success' ? 'success' : 'danger'} border-0" 
                         role="alert" aria-live="assertive" aria-atomic="true">
                        <div class="d-flex">
                            <div class="toast-body">
                                <strong>${title}:</strong> ${message}
                            </div>
                            <button type="button" class="btn-close btn-close-white me-2 m-auto" 
                                    data-bs-dismiss="toast"></button>
                        </div>
                    </div>
                </div>
            `);
            
            $('body').append(toast);
            
            // Initialize and show toast
            const bsToast = new bootstrap.Toast(toast.find('.toast')[0]);
            bsToast.show();
            
            // Remove after hiding
            toast.find('.toast').on('hidden.bs.toast', function() {
                $(this).closest('.position-fixed').remove();
            });
        }
    });
    </script>
</body>
</html>