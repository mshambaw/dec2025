<?php
// Product card component
if (!isset($product)) return;
?>
<div class="product-card">
    <!-- Product Badges -->
    <div class="product-badge">
        <?php if(($product['quantity_in_stock'] ?? 0) < 10): ?>
        <span class="badge bg-warning">Low Stock</span>
        <?php endif; ?>
        <?php if($product['is_featured'] ?? false): ?>
        <span class="badge bg-info">Featured</span>
        <?php endif; ?>
    </div>
    
    <!-- Product Image -->
    <div class="product-image">
        <?php 
        $imageUrl = $product['image_url'] ?? '';
        if (!empty($imageUrl)): ?>
            <img src="<?php echo htmlspecialchars($imageUrl); ?>" 
                 alt="<?php echo htmlspecialchars($product['name'] ?? 'Product'); ?>"
                 loading="lazy">
        <?php else: ?>
            <div class="product-image-placeholder">
                <i class="fas <?php echo getCategoryIcon($product['category'] ?? ''); ?>"></i>
            </div>
        <?php endif; ?>
        <div class="product-overlay">
            <a href="product-details.php?id=<?php echo $product['id']; ?>" 
               class="btn btn-outline-light mb-2 w-75">
                <i class="fas fa-eye me-2"></i> View Details
            </a>
            
            <?php if(($product['quantity_in_stock'] ?? 0) > 0): ?>
            <button class="btn btn-light add-to-cart w-75" 
                    data-product-id="<?php echo $product['id']; ?>">
                <i class="fas fa-cart-plus me-2"></i> Add to Cart
            </button>
            <?php else: ?>
            <button class="btn btn-light w-75" disabled>
                <i class="fas fa-times me-2"></i> Out of Stock
            </button>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Product Info -->
    <div class="product-info">
        <h3 class="product-title"><?php echo htmlspecialchars($product['name'] ?? 'Unnamed Product'); ?></h3>
        <p class="product-description">
            <?php echo truncateText($product['description'] ?? '', 80); ?>
        </p>
        
        <div class="product-meta">
            <span class="product-category">
                <?php echo htmlspecialchars($product['category'] ?? 'Uncategorized'); ?>
            </span>
            <span class="product-stock <?php echo ($product['quantity_in_stock'] ?? 0) > 0 ? 'stock-in' : 'stock-out'; ?>">
                <?php if(($product['quantity_in_stock'] ?? 0) > 0): ?>
                <i class="fas fa-check-circle me-1"></i> In Stock
                <?php else: ?>
                <i class="fas fa-times-circle me-1"></i> Out of Stock
                <?php endif; ?>
            </span>
        </div>
        
        <div class="product-price">
            <span class="price">Ksh <?php echo number_format($product['unit_price'] ?? 0, 2); ?></span>
            <?php if(isset($product['cost_price']) && isset($product['unit_price']) && $product['unit_price'] < $product['cost_price'] * 1.2): ?>
            <small class="text-success fw-bold">Best Price</small>
            <?php endif; ?>
        </div>
    </div>
</div>