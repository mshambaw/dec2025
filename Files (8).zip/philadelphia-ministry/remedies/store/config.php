<?php
// ============================================
// STORE CONFIGURATION - FIXED VERSION
// ============================================

// Define this as a valid entry point
if (!defined('STORE_SYSTEM')) {
    define('STORE_SYSTEM', true);
}

// Configuration
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Path definitions
define('BASE_PATH', dirname(__DIR__, 2) . '/');
define('INCLUDES_PATH', BASE_PATH . 'includes/');
define('ASSETS_PATH', BASE_PATH . 'assets/');
define('STORE_PATH', dirname(__FILE__) . '/');

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database connection (same as admin but with different function name)
function getStoreConnection() {
    static $conn = null;
    
    if ($conn === null) {
        try {
            $conn = new PDO(
                "mysql:host=localhost;dbname=philadelphia_ministry;charset=utf8mb4",
                "root",
                "",
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
        } catch (PDOException $e) {
            error_log("Store DB Connection Error: " . $e->getMessage());
            // Don't die, return null so we can handle gracefully
            return null;
        }
    }
    
    return $conn;
}

// Store settings
$storeSettings = [
    'store_name' => 'Philadelphia Remedies Store',
    'currency' => 'KES',
    'currency_symbol' => 'Ksh',
    'tax_rate' => 0.16, // 16% VAT
    'shipping_fee' => 300,
    'free_shipping_threshold' => 5000,
    'store_email' => 'remedies@philadelphia-ministry.org',
    'store_phone' => '+254 712 345 678',
    'store_address' => 'Philadelphia Ministry, Nairobi, Kenya'
];

// Initialize cart if not exists
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// CSRF token for forms
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Format currency
 */
function formatCurrency($amount) {
    global $storeSettings;
    return $storeSettings['currency_symbol'] . ' ' . number_format($amount, 2);
}

/**
 * Calculate cart total
 */
function getCartTotal() {
    $total = 0;
    if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $item) {
            $total += ($item['price'] * $item['quantity']);
        }
    }
    return $total;
}

/**
 * Get cart count
 */
function getCartCount() {
    $count = 0;
    if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $item) {
            $count += $item['quantity'];
        }
    }
    return $count;
}

/**
 * Get product by ID
 */
function getProduct($productId) {
    $conn = getStoreConnection();
    if (!$conn) return null;
    
    try {
        $stmt = $conn->prepare("
            SELECT r.*, rc.name as category_name 
            FROM remedies r 
            LEFT JOIN remedy_categories rc ON r.category = rc.id
            WHERE r.id = ? AND r.is_active = 1
        ");
        $stmt->execute([$productId]);
        return $stmt->fetch();
    } catch (PDOException $e) {
        error_log("Product fetch error: " . $e->getMessage());
        return null;
    }
}

/**
 * Get featured products
 */
function getFeaturedProducts($limit = 8) {
    $conn = getStoreConnection();
    if (!$conn) return [];
    
    try {
        $stmt = $conn->prepare("
            SELECT r.*, rc.name as category_name 
            FROM remedies r 
            LEFT JOIN remedy_categories rc ON r.category = rc.id
            WHERE r.is_active = 1 AND r.quantity_in_stock > 0 
            ORDER BY RAND() 
            LIMIT ?
        ");
        $stmt->execute([$limit]);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log("Featured products error: " . $e->getMessage());
        return [];
    }
}

/**
 * Get products by category
 */
function getProductsByCategory($categoryId, $limit = 20) {
    $conn = getStoreConnection();
    if (!$conn) return [];
    
    try {
        $stmt = $conn->prepare("
            SELECT r.*, rc.name as category_name 
            FROM remedies r 
            LEFT JOIN remedy_categories rc ON r.category = rc.id
            WHERE r.is_active = 1 AND r.quantity_in_stock > 0 AND r.category = ?
            ORDER BY r.name
            LIMIT ?
        ");
        $stmt->execute([$categoryId, $limit]);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log("Category products error: " . $e->getMessage());
        return [];
    }
}

/**
 * Get all categories
 */
function getCategories() {
    $conn = getStoreConnection();
    if (!$conn) return [];
    
    try {
        $stmt = $conn->query("
            SELECT * FROM remedy_categories 
            WHERE is_active = 1 
            ORDER BY name
        ");
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log("Categories error: " . $e->getMessage());
        return [];
    }
}

/**
 * Search products
 */
function searchProducts($query, $limit = 20) {
    $conn = getStoreConnection();
    if (!$conn) return [];
    
    try {
        $searchTerm = "%" . $query . "%";
        $stmt = $conn->prepare("
            SELECT r.*, rc.name as category_name 
            FROM remedies r 
            LEFT JOIN remedy_categories rc ON r.category = rc.id
            WHERE r.is_active = 1 
            AND r.quantity_in_stock > 0 
            AND (r.name LIKE ? OR r.description LIKE ? OR r.remedy_code LIKE ?)
            ORDER BY r.name
            LIMIT ?
        ");
        $stmt->execute([$searchTerm, $searchTerm, $searchTerm, $limit]);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log("Search error: " . $e->getMessage());
        return [];
    }
}

/**
 * Create order from cart
 */
function createOrder($userId, $customerData, $cartItems) {
    $conn = getStoreConnection();
    if (!$conn) return null;
    
    try {
        $conn->beginTransaction();
        
        // Generate order number
        $orderNumber = 'ORD-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -8));
        
        // Calculate totals
        $subtotal = 0;
        foreach ($cartItems as $item) {
            $subtotal += ($item['price'] * $item['quantity']);
        }
        
        $shipping = ($subtotal >= 5000) ? 0 : 300;
        $tax = $subtotal * 0.16;
        $total = $subtotal + $shipping + $tax;
        
        // Insert order
        $stmt = $conn->prepare("
            INSERT INTO customer_orders (
                order_number, user_id, customer_name, customer_email, customer_phone,
                shipping_address, billing_address, subtotal, shipping_fee, tax_amount,
                total_amount, payment_method, status, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)
        ");
        
        $stmt->execute([
            $orderNumber,
            $userId,
            $customerData['name'],
            $customerData['email'],
            $customerData['phone'],
            $customerData['shipping_address'],
            $customerData['billing_address'] ?? $customerData['shipping_address'],
            $subtotal,
            $shipping,
            $tax,
            $total,
            $customerData['payment_method'] ?? 'mpesa',
            $customerData['notes'] ?? ''
        ]);
        
        $orderId = $conn->lastInsertId();
        
        // Insert order items and update stock
        foreach ($cartItems as $item) {
            // Insert order item
            $stmt = $conn->prepare("
                INSERT INTO order_items (order_id, remedy_id, quantity, unit_price, total_price)
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $orderId,
                $item['product_id'],
                $item['quantity'],
                $item['price'],
                $item['price'] * $item['quantity']
            ]);
            
            // Update stock
            $stmt = $conn->prepare("
                UPDATE remedies 
                SET quantity_in_stock = quantity_in_stock - ? 
                WHERE id = ? AND quantity_in_stock >= ?
            ");
            $stmt->execute([$item['quantity'], $item['product_id'], $item['quantity']]);
            
            if ($stmt->rowCount() === 0) {
                throw new Exception("Insufficient stock for product ID: " . $item['product_id']);
            }
        }
        
        $conn->commit();
        return $orderNumber;
        
    } catch (Exception $e) {
        $conn->rollBack();
        error_log("Order creation error: " . $e->getMessage());
        return null;
    }
}

/**
 * Get user orders
 */
function getUserOrders($userId) {
    $conn = getStoreConnection();
    if (!$conn) return [];
    
    try {
        $stmt = $conn->prepare("
            SELECT o.*, 
                   COUNT(oi.id) as items_count
            FROM customer_orders o
            LEFT JOIN order_items oi ON o.id = oi.order_id
            WHERE o.user_id = ?
            GROUP BY o.id
            ORDER BY o.created_at DESC
        ");
        $stmt->execute([$userId]);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log("User orders error: " . $e->getMessage());
        return [];
    }
}
?>