<?php
// Define access
define('STORE_ACCESS', true);

// Include config
require_once '../config.php';

// Set JSON header
header('Content-Type: application/json');

// Check CSRF token
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    echo json_encode(['success' => false, 'message' => 'Invalid CSRF token']);
    exit;
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Please login to add items to cart']);
    exit;
}

$action = $_POST['action'] ?? '';
$response = ['success' => false, 'message' => 'Invalid action'];

switch ($action) {
    case 'add_to_cart':
        $productId = (int)($_POST['product_id'] ?? 0);
        $quantity = (int)($_POST['quantity'] ?? 1);
        
        if ($productId <= 0) {
            $response['message'] = 'Invalid product';
            break;
        }
        
        // Get product details
        $product = getProduct($productId);
        if (!$product) {
            $response['message'] = 'Product not found';
            break;
        }
        
        if ($product['quantity_in_stock'] < $quantity) {
            $response['message'] = 'Insufficient stock';
            break;
        }
        
        // Add to cart session
        $cartKey = 'cart';
        if (!isset($_SESSION[$cartKey])) {
            $_SESSION[$cartKey] = [];
        }
        
        // Check if product already in cart
        $found = false;
        foreach ($_SESSION[$cartKey] as &$item) {
            if ($item['product_id'] == $productId) {
                $item['quantity'] += $quantity;
                $found = true;
                break;
            }
        }
        
        // Add new item if not found
        if (!$found) {
            $_SESSION[$cartKey][] = [
                'product_id' => $productId,
                'name' => $product['name'],
                'price' => $product['unit_price'],
                'quantity' => $quantity,
                'image' => $product['image_url'] ?? '',
                'max_stock' => $product['quantity_in_stock']
            ];
        }
        
        $response = [
            'success' => true,
            'message' => 'Added to cart',
            'cart_count' => getCartCount(),
            'cart_total' => getCartTotal()
        ];
        break;
        
    case 'update_cart':
        $productId = (int)($_POST['product_id'] ?? 0);
        $quantity = (int)($_POST['quantity'] ?? 0);
        
        if ($productId <= 0) {
            $response['message'] = 'Invalid product';
            break;
        }
        
        // Find and update item
        $cartKey = 'cart';
        if (isset($_SESSION[$cartKey]) && is_array($_SESSION[$cartKey])) {
            foreach ($_SESSION[$cartKey] as $index => &$item) {
                if ($item['product_id'] == $productId) {
                    if ($quantity > 0) {
                        if ($quantity <= $item['max_stock']) {
                            $item['quantity'] = $quantity;
                        } else {
                            $response['message'] = 'Exceeds available stock';
                            break 2;
                        }
                    } else {
                        // Remove item if quantity is 0
                        array_splice($_SESSION[$cartKey], $index, 1);
                    }
                    $response = [
                        'success' => true,
                        'message' => 'Cart updated',
                        'cart_count' => getCartCount(),
                        'cart_total' => getCartTotal()
                    ];
                    break 2;
                }
            }
        }
        
        $response['message'] = 'Item not found in cart';
        break;
        
    case 'remove_from_cart':
        $productId = (int)($_POST['product_id'] ?? 0);
        
        if ($productId <= 0) {
            $response['message'] = 'Invalid product';
            break;
        }
        
        // Remove item from cart
        $cartKey = 'cart';
        if (isset($_SESSION[$cartKey]) && is_array($_SESSION[$cartKey])) {
            foreach ($_SESSION[$cartKey] as $index => $item) {
                if ($item['product_id'] == $productId) {
                    array_splice($_SESSION[$cartKey], $index, 1);
                    $response = [
                        'success' => true,
                        'message' => 'Removed from cart',
                        'cart_count' => getCartCount(),
                        'cart_total' => getCartTotal()
                    ];
                    break 2;
                }
            }
        }
        
        $response['message'] = 'Item not found in cart';
        break;
        
    case 'clear_cart':
        $_SESSION['cart'] = [];
        $response = [
            'success' => true,
            'message' => 'Cart cleared',
            'cart_count' => 0,
            'cart_total' => 0
        ];
        break;
}

echo json_encode($response);
?>