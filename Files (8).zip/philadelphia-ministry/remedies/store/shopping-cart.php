<?php
// Define access
define('STORE_ACCESS', true);

// Include config
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_PATH . 'members/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    exit;
}

// Handle cart actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $productId = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 0;
    
    switch ($action) {
        case 'update':
            // Update quantity
            foreach ($_SESSION['cart'] as &$item) {
                if ($item['product_id'] == $productId) {
                    if ($quantity > 0 && $quantity <= $item['max_stock']) {
                        $item['quantity'] = $quantity;
                    } elseif ($quantity == 0) {
                        // Remove item if quantity is 0
                        $_SESSION['cart'] = array_filter($_SESSION['cart'], function($item) use ($productId) {
                            return $item['product_id'] != $productId;
                        });
                    }
                    break;
                }
            }
            break;
            
        case 'remove':
            // Remove item
            $_SESSION['cart'] = array_filter($_SESSION['cart'], function($item) use ($productId) {
                return $item['product_id'] != $productId;
            });
            break;
            
        case 'clear':
            // Clear cart
            $_SESSION['cart'] = [];
            break;
    }
    
    // Re-index array
    $_SESSION['cart'] = array_values($_SESSION['cart']);
    header('Location: shopping-cart.php');
    exit;
}

// Get cart items with product details
$cartItems = [];
$subtotal = 0;

foreach ($_SESSION['cart'] as $item) {
    $product = getProduct($item['product_id']);
    if ($product) {
        $itemTotal = $item['quantity'] * $item['price'];
        $cartItems[] = [
            'id' => $product['id'],
            'product_id' => $product['id'],
            'name' => $product['name'],
            'price' => $product['unit_price'],
            'quantity' => $item['quantity'],
            'image' => $product['image_url'] ?? ASSETS_URL . 'images/products/default.jpg',
            'stock' => $product['quantity_in_stock'],
            'unit_type' => $product['unit_type'],
            'item_total' => $itemTotal
        ];
        $subtotal += $itemTotal;
    }
}

// Calculate totals
$shipping = ($subtotal >= 5000) ? 0 : 300;
$tax = $subtotal * 0.16;
$total = $subtotal + $shipping + $tax;

// Get user info
$userName = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : '';
$userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;
$cartCount = getCartCount();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - <?php echo $storeSettings['store_name']; ?></title>
    
    <!-- Include styles -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        <?php include 'styles.php'; ?>
        
        .cart-section {
            padding: 80px 0;
        }
        
        .cart-header {
            margin-bottom: 40px;
        }
        
        .cart-table {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .cart-table th {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 20px;
            font-weight: 600;
        }
        
        .cart-table td {
            padding: 20px;
            vertical-align: middle;
        }
        
        .cart-item {
            border-bottom: 1px solid var(--border-color);
        }
        
        .cart-item:last-child {
            border-bottom: none;
        }
        
        .product-image {
            width: 100px;
            height: 100px;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .quantity-control {
            display: flex;
            align-items: center;
        }
        
        .quantity-btn {
            width: 35px;
            height: 35px;
            border: 1px solid var(--border-color);
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }
        
        .quantity-input {
            width: 50px;
            height: 35px;
            border: 1px solid var(--border-color);
            border-left: none;
            border-right: none;
            text-align: center;
        }
        
        .remove-btn {
            color: #dc3545;
            background: none;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .remove-btn:hover {
            background: rgba(220, 53, 69, 0.1);
        }
        
        .cart-summary {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            position: sticky;
            top: 100px;
        }
        
        .summary-title {
            font-size: 1.5rem;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid var(--primary-color);
        }
        
        .summary-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
        }
        
        .summary-total {
            display: flex;
            justify-content: space-between;
            font-size: 1.3rem;
            font-weight: 700;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 2px solid var(--border-color);
        }
        
        .empty-cart {
            text-align: center;
            padding: 60px 20px;
        }
        
        .empty-cart i {
            font-size: 4rem;
            color: var(--text-light);
            margin-bottom: 20px;
        }
        
        .shipping-note {
            background: rgba(39, 174, 96, 0.1);
            color: var(--accent-color);
            padding: 10px 15px;
            border-radius: 8px;
            margin-top: 20px;
            font-size: 0.9rem;
        }
        
        .mobile-cart-item {
            display: none;
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        @media (max-width: 768px) {
            .cart-table {
                display: none;
            }
            
            .mobile-cart-item {
                display: block;
            }
            
            .cart-summary {
                position: static;
                margin-top: 30px;
            }
        }
    </style>
</head>
<body>
    <!-- Include Header -->
    <?php include 'header.php'; ?>
    
    <!-- Shopping Cart -->
    <section class="cart-section">
        <div class="container">
            <div class="cart-header">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active">Shopping Cart</li>
                    </ol>
                </nav>
                
                <h1 class="mb-3"><i class="fas fa-shopping-cart me-2"></i>Shopping Cart</h1>
                <p class="text-muted">Review your items and proceed to checkout</p>
            </div>
            
            <?php if(empty($cartItems)): ?>
            <!-- Empty Cart -->
            <div class="empty-cart">
                <i class="fas fa-shopping-cart"></i>
                <h3>Your cart is empty</h3>
                <p class="text-muted mb-4">Looks like you haven't added any items to your cart yet.</p>
                <a href="products.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-store me-2"></i>Continue Shopping
                </a>
            </div>
            <?php else: ?>
            
            <div class="row">
                <!-- Cart Items -->
                <div class="col-lg-8">
                    <!-- Desktop Table -->
                    <div class="cart-table">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($cartItems as $item): ?>
                                <tr class="cart-item">
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="product-image me-3">
                                                <img src="<?php echo htmlspecialchars($item['image']); ?>" 
                                                     alt="<?php echo htmlspecialchars($item['name']); ?>">
                                            </div>
                                            <div>
                                                <h6 class="mb-1"><?php echo htmlspecialchars($item['name']); ?></h6>
                                                <small class="text-muted"><?php echo htmlspecialchars($item['unit_type']); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo formatCurrency($item['price']); ?></td>
                                    <td>
                                        <form method="POST" class="d-inline update-form">
                                            <input type="hidden" name="action" value="update">
                                            <input type="hidden" name="product_id" value="<?php echo $item['product_id']; ?>">
                                            <div class="quantity-control">
                                                <button type="button" class="quantity-btn decrease" 
                                                        onclick="updateQuantity(this, -1)">-</button>
                                                <input type="number" name="quantity" class="quantity-input" 
                                                       value="<?php echo $item['quantity']; ?>" min="0" 
                                                       max="<?php echo $item['stock']; ?>">
                                                <button type="button" class="quantity-btn increase" 
                                                        onclick="updateQuantity(this, 1)">+</button>
                                            </div>
                                        </form>
                                    </td>
                                    <td class="fw-bold"><?php echo formatCurrency($item['item_total']); ?></td>
                                    <td>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="action" value="remove">
                                            <input type="hidden" name="product_id" value="<?php echo $item['product_id']; ?>">
                                            <button type="submit" class="remove-btn" onclick="return confirm('Remove this item from cart?')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                
                                <!-- Mobile Item -->
                                <div class="mobile-cart-item">
                                    <div class="row">
                                        <div class="col-4">
                                            <div class="product-image">
                                                <img src="<?php echo htmlspecialchars($item['image']); ?>" 
                                                     alt="<?php echo htmlspecialchars($item['name']); ?>">
                                            </div>
                                        </div>
                                        <div class="col-8">
                                            <h6 class="mb-2"><?php echo htmlspecialchars($item['name']); ?></h6>
                                            <p class="mb-2">Price: <?php echo formatCurrency($item['price']); ?></p>
                                            
                                            <form method="POST" class="update-form mb-3">
                                                <input type="hidden" name="action" value="update">
                                                <input type="hidden" name="product_id" value="<?php echo $item['product_id']; ?>">
                                                <div class="quantity-control">
                                                    <button type="button" class="quantity-btn decrease" 
                                                            onclick="updateQuantity(this, -1)">-</button>
                                                    <input type="number" name="quantity" class="quantity-input" 
                                                           value="<?php echo $item['quantity']; ?>" min="0" 
                                                           max="<?php echo $item['stock']; ?>">
                                                    <button type="button" class="quantity-btn increase" 
                                                            onclick="updateQuantity(this, 1)">+</button>
                                                </div>
                                            </form>
                                            
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="fw-bold"><?php echo formatCurrency($item['item_total']); ?></span>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="action" value="remove">
                                                    <input type="hidden" name="product_id" value="<?php echo $item['product_id']; ?>">
                                                    <button type="submit" class="remove-btn" 
                                                            onclick="return confirm('Remove this item from cart?')">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Cart Actions -->
                    <div class="d-flex justify-content-between mt-4">
                        <a href="products.php" class="btn btn-outline-primary">
                            <i class="fas fa-arrow-left me-2"></i>Continue Shopping
                        </a>
                        <form method="POST">
                            <input type="hidden" name="action" value="clear">
                            <button type="submit" class="btn btn-outline-danger" 
                                    onclick="return confirm('Clear all items from cart?')">
                                <i class="fas fa-trash-alt me-2"></i>Clear Cart
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- Order Summary -->
                <div class="col-lg-4">
                    <div class="cart-summary">
                        <h3 class="summary-title">Order Summary</h3>
                        
                        <div class="summary-item">
                            <span>Subtotal</span>
                            <span><?php echo formatCurrency($subtotal); ?></span>
                        </div>
                        
                        <div class="summary-item">
                            <span>Shipping</span>
                            <span><?php echo $shipping == 0 ? 'FREE' : formatCurrency($shipping); ?></span>
                        </div>
                        
                        <div class="summary-item">
                            <span>Tax (16%)</span>
                            <span><?php echo formatCurrency($tax); ?></span>
                        </div>
                        
                        <div class="summary-total">
                            <span>Total</span>
                            <span><?php echo formatCurrency($total); ?></span>
                        </div>
                        
                        <?php if($subtotal < 5000): ?>
                        <div class="shipping-note">
                            <i class="fas fa-info-circle me-2"></i>
                            Add <?php echo formatCurrency(5000 - $subtotal); ?> more to get FREE shipping!
                        </div>
                        <?php endif; ?>
                        
                        <a href="checkout.php" class="btn btn-primary btn-lg w-100 mt-4">
                            <i class="fas fa-lock me-2"></i>Proceed to Checkout
                        </a>
                        
                        <div class="text-center mt-3">
                            <small class="text-muted">
                                <i class="fas fa-lock me-1"></i>Secure checkout
                            </small>
                        </div>
                    </div>
                    
                    <!-- Payment Methods -->
                    <div class="card mt-4">
                        <div class="card-body">
                            <h6 class="card-title mb-3">Accepted Payment Methods</h6>
                            <div class="d-flex justify-content-around">
                                <i class="fab fa-cc-mastercard fa-2x text-dark"></i>
                                <i class="fab fa-cc-visa fa-2x text-dark"></i>
                                <i class="fas fa-mobile-alt fa-2x text-success"></i>
                                <i class="fas fa-money-bill-wave fa-2x text-success"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </section>
    
    <!-- Include Footer -->
    <?php include 'footer.php'; ?>
    
    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    function updateQuantity(button, change) {
        const form = button.closest('.update-form');
        const input = form.querySelector('.quantity-input');
        let value = parseInt(input.value) + change;
        const max = parseInt(input.max);
        const min = parseInt(input.min);
        
        if (value < min) value = min;
        if (value > max) value = max;
        
        input.value = value;
        
        // Auto-submit on quantity change
        setTimeout(() => {
            form.submit();
        }, 500);
    }
    
    // Update cart count in header
    function updateCartCount() {
        $.ajax({
            url: 'api/cart.php',
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'get_cart_count',
                csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
            },
            success: function(response) {
                if (response.success) {
                    const cartCount = document.querySelector('.cart-count');
                    if (cartCount) {
                        cartCount.textContent = response.cart_count;
                    }
                }
            }
        });
    }
    
    // Update cart count on page load
    updateCartCount();
    </script>
</body>
</html>