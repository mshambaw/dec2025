<?php
require_once '../includes/header.php';
require_once '../includes/db_connect.php';
require_once 'includes/remedies-functions.php';
require_once 'includes/email-functions.php';
require_once 'includes/sms-functions.php';

// Only admin can access
if (!isRemediesAdmin($_SESSION['user_id'] ?? 0)) {
    header('Location: ../members/login.php');
    exit();
}

$testResults = [];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'test_email') {
        $testEmail = $_POST['test_email'] ?? 'test@example.com';
        $testName = $_POST['test_name'] ?? 'Test User';
        
        $subject = "Test Email from Philadelphia Remedies";
        $body = "
        <h2>Test Email Successful!</h2>
        <p>This is a test email sent from the Philadelphia Remedies Department system.</p>
        <p>If you can read this, your email configuration is working correctly.</p>
        <p><strong>Date:</strong> " . date('Y-m-d H:i:s') . "</p>
        <p><strong>System:</strong> Remedies Department v1.0</p>
        ";
        
        $testResults['email'] = sendRemediesEmail($testEmail, $testName, $subject, $body);
        
    } elseif ($action === 'test_sms') {
        $testPhone = $_POST['test_phone'] ?? '';
        
        if ($testPhone) {
            $message = "Test SMS from Philadelphia Remedies. If you receive this, SMS is working correctly! Sent at: " . date('H:i:s');
            $testResults['sms'] = sendSMS($testPhone, $message);
        }
        
    } elseif ($action === 'test_all') {
        $testResults = testCommunicationSystems();
    }
}
?>

<div class="container mt-5">
    <h2>Email & SMS Configuration Test</h2>
    <p class="lead">Test your email and SMS setup to ensure they're working correctly.</p>
    
    <!-- Test Results -->
    <?php if (!empty($testResults)): ?>
    <div class="alert alert-info">
        <h4>Test Results:</h4>
        <ul>
            <?php foreach ($testResults as $type => $result): ?>
            <li>
                <strong><?php echo strtoupper($type); ?>:</strong> 
                <?php echo $result ? '✅ SUCCESS' : '❌ FAILED'; ?>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>
    
    <div class="row">
        <!-- Email Test -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4>Test Email Configuration</h4>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <input type="hidden" name="action" value="test_email">
                        
                        <div class="form-group">
                            <label>Test Email Address:</label>
                            <input type="email" name="test_email" class="form-control" 
                                   value="<?php echo $_SESSION['email'] ?? ''; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label>Test Name:</label>
                            <input type="text" name="test_name" class="form-control" 
                                   value="<?php echo $_SESSION['full_name'] ?? 'Test User'; ?>" required>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-envelope"></i> Send Test Email
                        </button>
                    </form>
                    
                    <hr>
                    
                    <h5>Current Email Configuration:</h5>
                    <ul class="list-group">
                        <li class="list-group-item">
                            <strong>SMTP Host:</strong> <?php echo SMTP_HOST; ?>
                        </li>
                        <li class="list-group-item">
                            <strong>SMTP Port:</strong> <?php echo SMTP_PORT; ?>
                        </li>
                        <li class="list-group-item">
                            <strong>From Email:</strong> <?php echo EMAIL_FROM; ?>
                        </li>
                        <li class="list-group-item">
                            <strong>Email Enabled:</strong> <?php echo EMAIL_ENABLED ? 'Yes' : 'No'; ?>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        
        <!-- SMS Test -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4>Test SMS Configuration</h4>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <input type="hidden" name="action" value="test_sms">
                        
                        <div class="form-group">
                            <label>Test Phone Number (Kenya):</label>
                            <input type="text" name="test_phone" class="form-control" 
                                   placeholder="07XXXXXXXX" pattern="[0-9]{10}" required>
                            <small class="text-muted">Format: 07XXXXXXXX (10 digits)</small>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-sms"></i> Send Test SMS
                        </button>
                    </form>
                    
                    <hr>
                    
                    <h5>Current SMS Configuration:</h5>
                    <ul class="list-group">
                        <li class="list-group-item">
                            <strong>SMS Provider:</strong> <?php echo SMS_PROVIDER; ?>
                        </li>
                        <li class="list-group-item">
                            <strong>Sender ID:</strong> <?php echo SMS_SENDER_ID; ?>
                        </li>
                        <li class="list-group-item">
                            <strong>SMS Enabled:</strong> <?php echo SMS_ENABLED ? 'Yes' : 'No'; ?>
                        </li>
                        <li class="list-group-item">
                            <strong>Username:</strong> <?php echo SMS_USERNAME; ?>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Configuration Status -->
    <div class="card mt-4">
        <div class="card-header">
            <h4>System Configuration Status</h4>
        </div>
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>Service</th>
                        <th>Status</th>
                        <th>Configuration</th>
                        <th>Test</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Email</td>
                        <td>
                            <?php if (EMAIL_ENABLED): ?>
                            <span class="badge badge-success">Enabled</span>
                            <?php else: ?>
                            <span class="badge badge-warning">Disabled</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo SMTP_HOST . ':' . SMTP_PORT; ?>
                        </td>
                        <td>
                            <a href="mailto:<?php echo EMAIL_FROM; ?>" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-paper-plane"></i> Quick Test
                            </a>
                        </td>
                    </tr>
                    <tr>
                        <td>SMS</td>
                        <td>
                            <?php if (SMS_ENABLED): ?>
                            <span class="badge badge-success">Enabled</span>
                            <?php else: ?>
                            <span class="badge badge-warning">Disabled</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo SMS_PROVIDER . ' via ' . SMS_SENDER_ID; ?>
                        </td>
                        <td>
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="action" value="test_sms">
                                <input type="hidden" name="test_phone" value="0712345678">
                                <button type="submit" class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-mobile-alt"></i> Test
                                </button>
                            </form>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Troubleshooting Guide -->
    <div class="card mt-4">
        <div class="card-header">
            <h4>Troubleshooting Guide</h4>
        </div>
        <div class="card-body">
            <h5>Email Not Working?</h5>
            <ol>
                <li><strong>For Gmail:</strong> Make sure you're using App Password, not your regular password</li>
                <li><strong>For XAMPP:</strong> Start Mercury Mail service from XAMPP Control Panel</li>
                <li><strong>Check credentials:</strong> Verify username/password in config file</li>
                <li><strong>Test with simple mail():</strong> Try <code>mail('test@test.com', 'Test', 'Test message')</code></li>
            </ol>
            
            <h5>SMS Not Working?</h5>
            <ol>
                <li><strong>For Africa's Talking:</strong> Check your account balance</li>
                <li><strong>Verify API key:</strong> Make sure API key is correct in config</li>
                <li><strong>Sender ID:</strong> Must be approved (takes 1-2 days)</li>
                <li><strong>Phone format:</strong> Must be +2547XXXXXXXX (Kenya format)</li>
            </ol>
            
            <h5>Need Help?</h5>
            <p>Check the log files:</p>
            <ul>
                <li><code>logs/remedies/activity.log</code> - General system activities</li>
                <li><code>logs/remedies/email.log</code> - Email sending attempts</li>
                <li><code>logs/remedies/sms.log</code> - SMS sending attempts</li>
            </ul>
        </div>
    </div>
</div>

<style>
.card {
    margin-bottom: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.card-header {
    background: #3498db;
    color: white;
}

.list-group-item {
    border-left: none;
    border-right: none;
}

.badge-success {
    background: #27ae60;
}

.badge-warning {
    background: #f39c12;
}
</style>

<?php require_once '../includes/footer.php'; ?>