<?php
require_once '../../../includes/header.php';
require_once '../../../includes/db_connect.php';
require_once '../../includes/remedies-functions.php';

// Check if user is admin
if (!isset($_SESSION['user_id']) || !isRemediesAdmin($_SESSION['user_id'])) {
    header('Location: ../../../admin/index.php?error=access_denied');
    exit();
}

$adminId = $_SESSION['user_id'];

// Get statistics
$today = date('Y-m-d');

// Today's bookings
$todayBookingsQuery = "SELECT COUNT(*) as count FROM remedies_bookings WHERE booking_date = ?";
$stmt = $conn->prepare($todayBookingsQuery);
$stmt->bind_param("s", $today);
$stmt->execute();
$todayBookingsResult = $stmt->get_result();
$todayBookings = $todayBookingsResult->fetch_assoc()['count'];

// Today's sales
$todaySalesQuery = "SELECT SUM(net_amount) as total FROM remedies_sales WHERE DATE(created_at) = ?";
$stmt = $conn->prepare($todaySalesQuery);
$stmt->bind_param("s", $today);
$stmt->execute();
$todaySalesResult = $stmt->get_result();
$todaySales = $todaySalesResult->fetch_assoc()['total'] ?? 0;

// Active patients (last 30 days)
$activePatientsQuery = "SELECT COUNT(DISTINCT patient_id) as count FROM remedies_bookings 
                        WHERE booking_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
$activePatientsResult = $conn->query($activePatientsQuery);
$activePatients = $activePatientsResult->fetch_assoc()['count'];

// Low stock products
$lowStockQuery = "SELECT COUNT(*) as count FROM remedies_products 
                  WHERE quantity_in_stock <= reorder_level AND is_active = 1";
$lowStockResult = $conn->query($lowStockQuery);
$lowStockCount = $lowStockResult->fetch_assoc()['count'];

// Recent bookings
$recentBookingsQuery = "SELECT b.*, m.full_name as patient_name, t.name as treatment_name 
                        FROM remedies_bookings b
                        JOIN members m ON b.patient_id = m.id
                        JOIN remedies_treatments t ON b.treatment_id = t.id
                        ORDER BY b.created_at DESC LIMIT 10";
$recentBookingsResult = $conn->query($recentBookingsQuery);

// Recent sales
$recentSalesQuery = "SELECT s.*, COUNT(si.id) as item_count 
                     FROM remedies_sales s
                     LEFT JOIN remedies_sale_items si ON s.id = si.sale_id
                     GROUP BY s.id
                     ORDER BY s.created_at DESC LIMIT 10";
$recentSalesResult = $conn->query($recentSalesQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Remedies Admin Dashboard</title>
    <link rel="stylesheet" href="../../../assets/css/admin.css">
    <link rel="stylesheet" href="../../../assets/css/remedies.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="admin-body">
    
    <!-- Admin Header -->
    <nav class="admin-navbar">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="../../../assets/images/logo-icon.png" alt="Logo" height="40">
                <span>Remedies Admin</span>
            </a>
            
            <div class="admin-user">
                <span>Welcome, <?php echo $_SESSION['full_name'] ?? 'Admin'; ?></span>
                <div class="dropdown">
                    <button class="btn btn-light dropdown-toggle" type="button" data-toggle="dropdown">
                        <i class="fas fa-user-cog"></i>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item" href="profile.php">
                            <i class="fas fa-user"></i> Profile
                        </a>
                        <a class="dropdown-item" href="settings.php">
                            <i class="fas fa-cog"></i> Settings
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="../../../admin/logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    
    <div class="admin-container">
        <!-- Sidebar -->
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <h3>Remedies Admin</h3>
            </div>
            
            <ul class="sidebar-menu">
                <li class="active">
                    <a href="index.php">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                
                <li class="menu-section">Bookings & Appointments</li>
                <li>
                    <a href="manage-bookings.php">
                        <i class="fas fa-calendar-check"></i>
                        <span>Manage Bookings</span>
                    </a>
                </li>
                <li>
                    <a href="manage-consultations.php">
                        <i class="fas fa-stethoscope"></i>
                        <span>Consultations</span>
                    </a>
                </li>
                
                <li class="menu-section">Store & Inventory</li>
                <li>
                    <a href="manage-products.php">
                        <i class="fas fa-box"></i>
                        <span>Products</span>
                    </a>
                </li>
                <li>
                    <a href="inventory-management.php">
                        <i class="fas fa-warehouse"></i>
                        <span>Inventory</span>
                    </a>
                </li>
                <li>
                    <a href="sales-report.php">
                        <i class="fas fa-chart-line"></i>
                        <span>Sales Report</span>
                    </a>
                </li>
                
                <li class="menu-section">Education & Missions</li>
                <li>
                    <a href="education-management.php">
                        <i class="fas fa-graduation-cap"></i>
                        <span>Education</span>
                    </a>
                </li>
                <li>
                    <a href="mission-management.php">
                        <i class="fas fa-hands-helping"></i>
                        <span>Medical Missions</span>
                    </a>
                </li>
                
                <li class="menu-section">Patient Management</li>
                <li>
                    <a href="patient-management.php">
                        <i class="fas fa-users"></i>
                        <span>Patients</span>
                    </a>
                </li>
                <li>
                    <a href="practitioner-management.php">
                        <i class="fas fa-user-md"></i>
                        <span>Practitioners</span>
                    </a>
                </li>
                
                <li class="menu-section">Reports</li>
                <li>
                    <a href="financial-reports.php">
                        <i class="fas fa-money-bill-wave"></i>
                        <span>Financial Reports</span>
                    </a>
                </li>
                <li>
                    <a href="health-reports.php">
                        <i class="fas fa-heartbeat"></i>
                        <span>Health Reports</span>
                    </a>
                </li>
                
                <li class="menu-section">Settings</li>
                <li>
                    <a href="manage-treatments.php">
                        <i class="fas fa-spa"></i>
                        <span>Treatments</span>
                    </a>
                </li>
                <li>
                    <a href="system-settings.php">
                        <i class="fas fa-cogs"></i>
                        <span>System Settings</span>
                    </a>
                </li>
            </ul>
        </aside>
        
        <!-- Main Content -->
        <main class="admin-main">
            <div class="container-fluid">
                <!-- Page Header -->
                <div class="page-header">
                    <h1>Remedies Admin Dashboard</h1>
                    <p>Manage all aspects of the Remedies Department</p>
                </div>
                
                <!-- Stats Cards -->
                <div class="row stats-row">
                    <div class="col-lg-3 col-md-6">
                        <div class="stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-calendar-check"></i>
                            </div>
                            <div class="stat-content">
                                <h3><?php echo $todayBookings; ?></h3>
                                <p>Today's Appointments</p>
                            </div>
                            <div class="stat-trend up">
                                <i class="fas fa-arrow-up"></i> 12%
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-3 col-md-6">
                        <div class="stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-money-bill-wave"></i>
                            </div>
                            <div class="stat-content">
                                <h3>Ksh <?php echo number_format($todaySales, 2); ?></h3>
                                <p>Today's Sales</p>
                            </div>
                            <div class="stat-trend up">
                                <i class="fas fa-arrow-up"></i> 18%
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-3 col-md-6">
                        <div class="stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-users"></i>
                            </div>
                            <div class="stat-content">
                                <h3><?php echo $activePatients; ?></h3>
                                <p>Active Patients (30 days)</p>
                            </div>
                            <div class="stat-trend up">
                                <i class="fas fa-arrow-up"></i> 8%
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-3 col-md-6">
                        <div class="stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-exclamation-triangle"></i>
                            </div>
                            <div class="stat-content">
                                <h3><?php echo $lowStockCount; ?></h3>
                                <p>Low Stock Items</p>
                            </div>
                            <div class="stat-trend down">
                                <i class="fas fa-arrow-down"></i> Need restock
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Charts Row -->
                <div class="row charts-row">
                    <div class="col-lg-8">
                        <div class="chart-card">
                            <div class="card-header">
                                <h3>Monthly Revenue Trend</h3>
                                <select class="form-control form-control-sm" style="width: auto;">
                                    <option>Last 6 months</option>
                                    <option>Last 12 months</option>
                                    <option>Year to date</option>
                                </select>
                            </div>
                            <div class="card-body">
                                <canvas id="revenueChart"></canvas>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4">
                        <div class="chart-card">
                            <div class="card-header">
                                <h3>Appointment Status</h3>
                            </div>
                            <div class="card-body">
                                <canvas id="appointmentsChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Tables Row -->
                <div class="row tables-row">
                    <div class="col-lg-6">
                        <div class="table-card">
                            <div class="card-header">
                                <h3>Recent Bookings</h3>
                                <a href="manage-bookings.php" class="btn btn-primary btn-sm">View All</a>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Patient</th>
                                                <th>Treatment</th>
                                                <th>Date</th>
                                                <th>Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php while($booking = $recentBookingsResult->fetch_assoc()): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($booking['patient_name']); ?></td>
                                                <td><?php echo htmlspecialchars($booking['treatment_name']); ?></td>
                                                <td>
                                                    <?php echo date('M j', strtotime($booking['booking_date'])); ?><br>
                                                    <small><?php echo date('h:i A', strtotime($booking['booking_time'])); ?></small>
                                                </td>
                                                <td>
                                                    <span class="status-badge status-<?php echo $booking['status']; ?>">
                                                        <?php echo ucfirst($booking['status']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <a href="booking-details.php?id=<?php echo $booking['id']; ?>" 
                                                       class="btn btn-sm btn-outline-primary">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php endwhile; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-6">
                        <div class="table-card">
                            <div class="card-header">
                                <h3>Recent Sales</h3>
                                <a href="sales-report.php" class="btn btn-primary btn-sm">View All</a>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Reference</th>
                                                <th>Customer</th>
                                                <th>Items</th>
                                                <th>Amount</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php while($sale = $recentSalesResult->fetch_assoc()): ?>
                                            <tr>
                                                <td><?php echo $sale['sale_reference']; ?></td>
                                                <td><?php echo htmlspecialchars($sale['customer_name']); ?></td>
                                                <td><?php echo $sale['item_count']; ?> items</td>
                                                <td>Ksh <?php echo number_format($sale['net_amount'], 2); ?></td>
                                                <td>
                                                    <span class="status-badge status-<?php echo $sale['payment_status']; ?>">
                                                        <?php echo ucfirst($sale['payment_status']); ?>
                                                    </span>
                                                </td>
                                            </tr>
                                            <?php endwhile; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="row quick-actions-row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h3>Quick Actions</h3>
                            </div>
                            <div class="card-body">
                                <div class="quick-actions">
                                    <a href="manage-bookings.php" class="action-btn">
                                        <i class="fas fa-calendar-plus"></i>
                                        <span>Add New Booking</span>
                                    </a>
                                    <a href="manage-products.php?action=add" class="action-btn">
                                        <i class="fas fa-plus-circle"></i>
                                        <span>Add New Product</span>
                                    </a>
                                    <a href="inventory-management.php" class="action-btn">
                                        <i class="fas fa-clipboard-list"></i>
                                        <span>Check Inventory</span>
                                    </a>
                                    <a href="patient-management.php?action=add" class="action-btn">
                                        <i class="fas fa-user-plus"></i>
                                        <span>Add New Patient</span>
                                    </a>
                                    <a href="education-management.php?action=add" class="action-btn">
                                        <i class="fas fa-chalkboard-teacher"></i>
                                        <span>Add Course</span>
                                    </a>
                                    <a href="mission-management.php?action=add" class="action-btn">
                                        <i class="fas fa-plane-departure"></i>
                                        <span>Plan Mission</span>
                                    </a>
                                    <a href="reports/generate-report.php" class="action-btn">
                                        <i class="fas fa-file-export"></i>
                                        <span>Generate Report</span>
                                    </a>
                                    <a href="system-settings.php" class="action-btn">
                                        <i class="fas fa-cogs"></i>
                                        <span>System Settings</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <style>
    .admin-body {
        background: #f5f7fa;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    .admin-navbar {
        background: #2c3e50;
        color: white;
        padding: 0 20px;
        height: 60px;
        display: flex;
        align-items: center;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        z-index: 1000;
    }
    
    .navbar-brand {
        display: flex;
        align-items: center;
        color: white;
        text-decoration: none;
        font-weight: 600;
        font-size: 1.2rem;
    }
    
    .navbar-brand img {
        margin-right: 10px;
    }
    
    .admin-user {
        margin-left: auto;
        display: flex;
        align-items: center;
        gap: 15px;
    }
    
    .admin-container {
        display: flex;
        margin-top: 60px;
    }
    
    .admin-sidebar {
        width: 250px;
        background: white;
        height: calc(100vh - 60px);
        position: fixed;
        left: 0;
        top: 60px;
        box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        overflow-y: auto;
    }
    
    .sidebar-header {
        padding: 20px;
        border-bottom: 1px solid #eee;
    }
    
    .sidebar-header h3 {
        margin: 0;
        color: #2c3e50;
        font-size: 1.2rem;
    }
    
    .sidebar-menu {
        list-style: none;
        padding: 0;
        margin: 0;
    }
    
    .sidebar-menu li {
        border-bottom: 1px solid #f8f9fa;
    }
    
    .sidebar-menu li a {
        display: flex;
        align-items: center;
        padding: 15px 20px;
        color: #5d6d7e;
        text-decoration: none;
        transition: all 0.3s ease;
    }
    
    .sidebar-menu li a:hover {
        background: #f8f9fa;
        color: #3498db;
    }
    
    .sidebar-menu li.active a {
        background: #e8f4fc;
        color: #3498db;
        border-left: 3px solid #3498db;
    }
    
    .sidebar-menu li a i {
        width: 25px;
        margin-right: 10px;
        font-size: 1.1rem;
    }
    
    .menu-section {
        padding: 10px 20px;
        color: #95a5a6;
        font-size: 0.85rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 1px;
        background: #f8f9fa;
    }
    
    .admin-main {
        flex: 1;
        margin-left: 250px;
        padding: 20px;
    }
    
    .page-header {
        margin-bottom: 30px;
    }
    
    .page-header h1 {
        color: #2c3e50;
        margin-bottom: 10px;
        font-size: 1.8rem;
    }
    
    .page-header p {
        color: #7f8c8d;
        margin: 0;
    }
    
    .stat-card {
        background: white;
        border-radius: 10px;
        padding: 25px;
        display: flex;
        align-items: center;
        box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        margin-bottom: 30px;
        transition: transform 0.3s ease;
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
    }
    
    .stat-icon {
        width: 60px;
        height: 60px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 20px;
        font-size: 1.5rem;
        color: white;
    }
    
    .stat-card:nth-child(1) .stat-icon {
        background: linear-gradient(135deg, #3498db, #2980b9);
    }
    
    .stat-card:nth-child(2) .stat-icon {
        background: linear-gradient(135deg, #2ecc71, #27ae60);
    }
    
    .stat-card:nth-child(3) .stat-icon {
        background: linear-gradient(135deg, #9b59b6, #8e44ad);
    }
    
    .stat-card:nth-child(4) .stat-icon {
        background: linear-gradient(135deg, #e74c3c, #c0392b);
    }
    
    .stat-content {
        flex: 1;
    }
    
    .stat-content h3 {
        color: #2c3e50;
        margin: 0;
        font-size: 1.8rem;
    }
    
    .stat-content p {
        color: #7f8c8d;
        margin: 5px 0 0;
        font-size: 0.95rem;
    }
    
    .stat-trend {
        font-size: 0.85rem;
        font-weight: 600;
        padding: 5px 10px;
        border-radius: 50px;
    }
    
    .stat-trend.up {
        background: #d4edda;
        color: #155724;
    }
    
    .stat-trend.down {
        background: #f8d7da;
        color: #721c24;
    }
    
    .chart-card, .table-card {
        background: white;
        border-radius: 10px;
        box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        margin-bottom: 30px;
    }
    
    .card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 20px;
        border-bottom: 1px solid #eee;
    }
    
    .card-header h3 {
        color: #2c3e50;
        margin: 0;
        font-size: 1.2rem;
    }
    
    .card-body {
        padding: 20px;
    }
    
    .status-badge {
        padding: 5px 12px;
        border-radius: 50px;
        font-size: 0.8rem;
        font-weight: 600;
    }
    
    .status-pending {
        background: #fff3cd;
        color: #856404;
    }
    
    .status-confirmed {
        background: #d1ecf1;
        color: #0c5460;
    }
    
    .status-paid {
        background: #d4edda;
        color: #155724;
    }
    
    .status-cancelled {
        background: #f8d7da;
        color: #721c24;
    }
    
    .table th {
        color: #5d6d7e;
        font-weight: 600;
        font-size: 0.9rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-top: none;
    }
    
    .table td {
        vertical-align: middle;
        color: #5d6d7e;
    }
    
    .quick-actions {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 15px;
    }
    
    .action-btn {
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 20px;
        background: #f8f9fa;
        border-radius: 8px;
        text-decoration: none;
        color: #5d6d7e;
        transition: all 0.3s ease;
    }
    
    .action-btn:hover {
        background: #3498db;
        color: white;
        transform: translateY(-2px);
    }
    
    .action-btn i {
        font-size: 1.5rem;
        margin-bottom: 10px;
    }
    
    .action-btn span {
        font-size: 0.9rem;
        font-weight: 500;
        text-align: center;
    }
    </style>

    <script>
    $(document).ready(function() {
        // Revenue Chart
        var revenueCtx = document.getElementById('revenueChart').getContext('2d');
        var revenueChart = new Chart(revenueCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Revenue (Ksh)',
                    data: [120000, 150000, 180000, 140000, 200000, 220000],
                    borderColor: '#3498db',
                    backgroundColor: 'rgba(52, 152, 219, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'Ksh ' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
        
        // Appointments Chart
        var appointmentsCtx = document.getElementById('appointmentsChart').getContext('2d');
        var appointmentsChart = new Chart(appointmentsCtx, {
            type: 'doughnut',
            data: {
                labels: ['Confirmed', 'Pending', 'Completed', 'Cancelled'],
                datasets: [{
                    data: [45, 20, 25, 10],
                    backgroundColor: [
                        '#2ecc71',
                        '#f39c12',
                        '#3498db',
                        '#e74c3c'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    });
    </script>

</body>
</html>