# Remedies Department Installation Guide

## Prerequisites
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Apache/Nginx web server
- Composer (for dependencies)
- Git (optional)

## Installation Steps

### Step 1: Database Setup
1. Run the complete database script:
   ```sql
   mysql -u username -p database_name < database/complete_remedies.sql