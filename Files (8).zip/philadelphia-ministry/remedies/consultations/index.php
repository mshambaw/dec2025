<?php
require_once '../../includes/header.php';
require_once '../../includes/db_connect.php';
require_once '../includes/remedies-functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../members/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    exit();
}

$userId = $_SESSION['user_id'];
?>

<div class="main-banner" id="top">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="header-text">
                    <h2>Health Consultations</h2>
                    <p>Personalized natural health consultations with certified practitioners</p>
                </div>
            </div>
        </div>
    </div>
</div>

<section class="consultations-section section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h2>Our Consultation Services</h2>
                    <p>Choose the consultation type that fits your needs</p>
                </div>
            </div>
        </div>

        <div class="row mb-5">
            <div class="col-lg-4 col-md-6">
                <div class="consultation-type-card">
                    <div class="type-icon">
                        <i class="fas fa-user-md"></i>
                    </div>
                    <h3>Initial Consultation</h3>
                    <p class="price">Ksh 2,000</p>
                    <p class="duration">60-90 minutes</p>
                    <ul>
                        <li>Comprehensive health assessment</li>
                        <li>Medical history review</li>
                        <li>Personalized health plan</li>
                        <li>Dietary recommendations</li>
                    </ul>
                    <a href="book-consultation.php?type=initial" class="btn btn-primary">Book Initial Consultation</a>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="consultation-type-card">
                    <div class="type-icon">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <h3>Follow-up Consultation</h3>
                    <p class="price">Ksh 1,500</p>
                    <p class="duration">30-45 minutes</p>
                    <ul>
                        <li>Progress evaluation</li>
                        <li>Plan adjustment</li>
                        <li>Answer questions</li>
                        <li>Support & motivation</li>
                    </ul>
                    <a href="book-consultation.php?type=followup" class="btn btn-primary">Book Follow-up</a>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="consultation-type-card">
                    <div class="type-icon">
                        <i class="fas fa-video"></i>
                    </div>
                    <h3>Online Consultation</h3>
                    <p class="price">Ksh 1,500</p>
                    <p class="duration">45-60 minutes</p>
                    <ul>
                        <li>Remote video consultation</li>
                        <li>Convenient from home</li>
                        <li>Digital prescriptions</li>
                        <li>Email follow-up</li>
                    </ul>
                    <a href="book-consultation.php?type=online" class="btn btn-primary">Book Online</a>
                </div>
            </div>
        </div>

        <!-- Practitioner Profiles -->
        <div class="row mb-5">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h3>Meet Our Practitioners</h3>
                    <p>Certified natural health experts</p>
                </div>
            </div>

            <?php
            $practitionersQuery = "SELECT * FROM remedies_practitioners WHERE is_active = 1 ORDER BY full_name";
            $practitionersResult = $conn->query($practitionersQuery);
            
            while($practitioner = $practitionersResult->fetch_assoc()):
            ?>
            <div class="col-lg-4 col-md-6">
                <div class="practitioner-card">
                    <div class="practitioner-img">
                        <img src="<?php echo $practitioner['profile_image'] ?? '../../assets/images/remedies/practitioner-default.jpg'; ?>" 
                             alt="<?php echo htmlspecialchars($practitioner['full_name']); ?>">
                    </div>
                    <div class="practitioner-info">
                        <h3><?php echo htmlspecialchars($practitioner['full_name']); ?></h3>
                        <p class="specialization"><?php echo $practitioner['specialization']; ?></p>
                        <p class="qualifications"><?php echo truncateText($practitioner['qualifications'], 100); ?></p>
                        <div class="practitioner-actions">
                            <a href="practitioner-profile.php?id=<?php echo $practitioner['id']; ?>" 
                               class="btn btn-outline-primary btn-sm">View Profile</a>
                            <a href="book-consultation.php?practitioner=<?php echo $practitioner['id']; ?>" 
                               class="btn btn-primary btn-sm">Book Consultation</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>

        <!-- Consultation Process -->
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h3>How Our Consultations Work</h3>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="process-steps">
                    <div class="step">
                        <div class="step-number">1</div>
                        <h4>Book Appointment</h4>
                        <p>Schedule your consultation online or by phone</p>
                    </div>
                    <div class="step">
                        <div class="step-number">2</div>
                        <h4>Complete Health Form</h4>
                        <p>Fill out our comprehensive health history form</p>
                    </div>
                    <div class="step">
                        <div class="step-number">3</div>
                        <h4>Consultation Session</h4>
                        <p>Meet with practitioner for detailed assessment</p>
                    </div>
                    <div class="step">
                        <div class="step-number">4</div>
                        <h4>Receive Your Plan</h4>
                        <p>Get personalized health recommendations</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Health Benefits Section -->
<section class="health-benefits section-padding bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h2>Benefits of Natural Health Consultations</h2>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="benefit-card">
                    <i class="fas fa-heartbeat"></i>
                    <h4>Holistic Approach</h4>
                    <p>We look at your whole health - body, mind, and spirit - not just symptoms.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="benefit-card">
                    <i class="fas fa-user-clock"></i>
                    <h4>Personalized Attention</h4>
                    <p>Each consultation is tailored to your unique health needs and goals.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="benefit-card">
                    <i class="fas fa-seedling"></i>
                    <h4>Natural Solutions</h4>
                    <p>Focus on natural remedies, nutrition, and lifestyle changes.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="benefit-card">
                    <i class="fas fa-book-medical"></i>
                    <h4>Education & Empowerment</h4>
                    <p>Learn how to take control of your health through education.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="benefit-card">
                    <i class="fas fa-chart-line"></i>
                    <h4>Progress Tracking</h4>
                    <p>Regular follow-ups to track progress and adjust plans.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="benefit-card">
                    <i class="fas fa-hands-helping"></i>
                    <h4>Ongoing Support</h4>
                    <p>Continuous support through your health journey.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="consultation-cta section-padding">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h2>Ready to Take Control of Your Health?</h2>
                <p>Book a consultation with our natural health experts and start your journey to better health today.</p>
            </div>
            <div class="col-lg-4 text-right">
                <a href="book-consultation.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-calendar-plus"></i> Book Consultation Now
                </a>
            </div>
        </div>
    </div>
</section>

<style>
.consultation-type-card {
    background: white;
    border-radius: 10px;
    padding: 30px;
    text-align: center;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    margin-bottom: 30px;
    transition: transform 0.3s ease;
    height: 100%;
}

.consultation-type-card:hover {
    transform: translateY(-5px);
}

.type-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, #27ae60, #219653);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 25px;
}

.type-icon i {
    font-size: 2.5rem;
    color: white;
}

.consultation-type-card h3 {
    color: #2c3e50;
    margin-bottom: 15px;
    font-size: 1.5rem;
}

.consultation-type-card .price {
    font-size: 2rem;
    color: #e74c3c;
    font-weight: 700;
    margin-bottom: 5px;
}

.consultation-type-card .duration {
    color: #7f8c8d;
    margin-bottom: 20px;
}

.consultation-type-card ul {
    list-style: none;
    padding-left: 0;
    margin-bottom: 25px;
    text-align: left;
}

.consultation-type-card ul li {
    padding: 5px 0;
    color: #5d6d7e;
    position: relative;
    padding-left: 25px;
}

.consultation-type-card ul li:before {
    content: '✓';
    position: absolute;
    left: 0;
    color: #27ae60;
    font-weight: bold;
}

.practitioner-card {
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    margin-bottom: 30px;
    transition: transform 0.3s ease;
}

.practitioner-card:hover {
    transform: translateY(-5px);
}

.practitioner-img {
    height: 250px;
    overflow: hidden;
}

.practitioner-img img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.practitioner-info {
    padding: 25px;
}

.practitioner-info h3 {
    color: #2c3e50;
    margin-bottom: 5px;
    font-size: 1.3rem;
}

.specialization {
    color: #3498db;
    font-weight: 600;
    margin-bottom: 10px;
    font-size: 1rem;
}

.qualifications {
    color: #7f8c8d;
    margin-bottom: 20px;
    line-height: 1.6;
    font-size: 0.95rem;
}

.practitioner-actions {
    display: flex;
    gap: 10px;
}

.process-steps {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    margin-top: 40px;
}

.step {
    flex: 1;
    min-width: 200px;
    text-align: center;
    padding: 20px;
    position: relative;
}

.step-number {
    width: 60px;
    height: 60px;
    background: #3498db;
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.8rem;
    font-weight: 700;
    margin: 0 auto 20px;
}

.step h4 {
    color: #2c3e50;
    margin-bottom: 10px;
    font-size: 1.2rem;
}

.step p {
    color: #7f8c8d;
}

.benefit-card {
    text-align: center;
    padding: 30px 20px;
    margin-bottom: 30px;
}

.benefit-card i {
    font-size: 3rem;
    color: #3498db;
    margin-bottom: 25px;
}

.benefit-card h4 {
    color: #2c3e50;
    margin-bottom: 15px;
    font-size: 1.3rem;
}

.benefit-card p {
    color: #7f8c8d;
    line-height: 1.6;
}

.consultation-cta {
    background: linear-gradient(135deg, #27ae60, #219653);
    color: white;
}

.consultation-cta h2 {
    color: white;
    margin-bottom: 15px;
}

.consultation-cta p {
    font-size: 1.2rem;
    opacity: 0.9;
}

.consultation-cta .btn-lg {
    padding: 15px 40px;
    border-radius: 50px;
    font-size: 1.2rem;
    background: white;
    color: #27ae60;
    border: none;
}

.consultation-cta .btn-lg:hover {
    background: #f8f9fa;
}
</style>

<?php require_once '../../includes/footer.php'; ?>