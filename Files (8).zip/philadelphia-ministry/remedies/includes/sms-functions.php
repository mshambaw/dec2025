<?php
/**
 * SMS Functions for Remedies Department
 */

// Prevent direct access
if (!defined('BASE_PATH')) {
    die('Direct access not permitted');
}

/**
 * Send SMS using Africa's Talking API
 */
function sendSMS($phoneNumber, $message) {
    // Check if SMS is enabled
    if (!SMS_ENABLED) {
        logRemediesActivity('sms_disabled', [
            'phone' => $phoneNumber,
            'message' => substr($message, 0, 50) . '...'
        ]);
        return false;
    }
    
    // Format phone number (Kenya)
    $phoneNumber = formatPhoneNumber($phoneNumber);
    
    if (!$phoneNumber) {
        logRemediesActivity('sms_invalid_phone', ['phone' => $phoneNumber]);
        return false;
    }
    
    // Choose SMS provider
    switch (SMS_PROVIDER) {
        case 'africastalking':
            return sendViaAfricaTalking($phoneNumber, $message);
            
        case 'nexmo':
            return sendViaNexmo($phoneNumber, $message);
            
        case 'twilio':
            return sendViaTwilio($phoneNumber, $message);
            
        default:
            return sendViaAfricaTalking($phoneNumber, $message);
    }
}

/**
 * Format Kenyan phone number
 */
function formatPhoneNumber($phone) {
    // Remove any spaces, dashes, plus signs
    $phone = preg_replace('/[^0-9]/', '', $phone);
    
    // If starts with 0, convert to +254
    if (preg_match('/^0/', $phone)) {
        $phone = '254' . substr($phone, 1);
    }
    
    // If starts with 254, add plus
    if (preg_match('/^254/', $phone) && strlen($phone) == 12) {
        return '+' . $phone;
    }
    
    // If already has +254
    if (preg_match('/^\+254/', $phone) && strlen($phone) == 13) {
        return $phone;
    }
    
    return false;
}

/**
 * Send SMS via Africa's Talking (Recommended for Kenya)
 */
function sendViaAfricaTalking($phoneNumber, $message) {
    // Africa's Talking API credentials
    $username = SMS_USERNAME;  // Your Africa's Talking username
    $apiKey   = SMS_API_KEY;   // Your Africa's Talking API key
    $senderId = SMS_SENDER_ID; // Your shortcode or alphanumeric
    
    // Prepare the data
    $postData = [
        'username' => $username,
        'to' => $phoneNumber,
        'message' => $message,
        'from' => $senderId
    ];
    
    // API endpoint
    $url = 'https://api.africastalking.com/version1/messaging';
    
    // Prepare headers
    $headers = [
        'Accept: application/json',
        'Content-Type: application/x-www-form-urlencoded',
        'apiKey: ' . $apiKey
    ];
    
    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    
    // Execute and get response
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    // Check for errors
    if (curl_errno($ch)) {
        $error = curl_error($ch);
        curl_close($ch);
        
        logRemediesActivity('sms_curl_error', [
            'phone' => $phoneNumber,
            'error' => $error
        ]);
        
        return false;
    }
    
    curl_close($ch);
    
    // Parse response
    $result = json_decode($response, true);
    
    if ($httpCode == 201 && isset($result['SMSMessageData']['Recipients'][0]['status'])) {
        $status = $result['SMSMessageData']['Recipients'][0]['status'];
        $messageId = $result['SMSMessageData']['Recipients'][0]['messageId'];
        
        // Log success
        logRemediesActivity('sms_sent', [
            'phone' => $phoneNumber,
            'message_id' => $messageId,
            'status' => $status,
            'provider' => 'africastalking'
        ]);
        
        return true;
    } else {
        // Log failure
        logRemediesActivity('sms_failed', [
            'phone' => $phoneNumber,
            'response' => $response,
            'provider' => 'africastalking'
        ]);
        
        return false;
    }
}

/**
 * Send SMS via Nexmo (Now Vonage)
 */
function sendViaNexmo($phoneNumber, $message) {
    $apiKey = 'your_nexmo_api_key';
    $apiSecret = 'your_nexmo_api_secret';
    $from = 'Philadelphia';
    
    $url = 'https://rest.nexmo.com/sms/json';
    
    $postData = [
        'api_key' => $apiKey,
        'api_secret' => $apiSecret,
        'to' => $phoneNumber,
        'from' => $from,
        'text' => $message
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    $result = json_decode($response, true);
    
    if (isset($result['messages'][0]['status']) && $result['messages'][0]['status'] == '0') {
        logRemediesActivity('sms_sent', [
            'phone' => $phoneNumber,
            'provider' => 'nexmo',
            'message_id' => $result['messages'][0]['message-id']
        ]);
        return true;
    }
    
    return false;
}

/**
 * Send SMS via Twilio
 */
function sendViaTwilio($phoneNumber, $message) {
    $accountSid = 'your_twilio_account_sid';
    $authToken = 'your_twilio_auth_token';
    $fromNumber = '+1234567890'; // Your Twilio phone number
    
    $url = "https://api.twilio.com/2010-04-01/Accounts/{$accountSid}/Messages.json";
    
    $postData = [
        'To' => $phoneNumber,
        'From' => $fromNumber,
        'Body' => $message
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_USERPWD, "{$accountSid}:{$authToken}");
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    $result = json_decode($response, true);
    
    if (isset($result['sid'])) {
        logRemediesActivity('sms_sent', [
            'phone' => $phoneNumber,
            'provider' => 'twilio',
            'message_id' => $result['sid']
        ]);
        return true;
    }
    
    return false;
}

/**
 * Send appointment reminder SMS
 */
function sendAppointmentReminderSMS($bookingId) {
    global $conn;
    
    $query = "SELECT b.*, m.full_name, m.phone, t.name as treatment_name 
              FROM remedies_bookings b
              JOIN members m ON b.patient_id = m.id
              JOIN remedies_treatments t ON b.treatment_id = t.id
              WHERE b.id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $bookingId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($booking = $result->fetch_assoc()) {
        $phone = $booking['phone'];
        $name = $booking['full_name'];
        $date = date('l, F j', strtotime($booking['booking_date']));
        $time = date('h:i A', strtotime($booking['booking_time']));
        
        $message = "Hi {$name}, reminder: Your {$booking['treatment_name']} appointment is tomorrow ({$date}) at {$time}. Please arrive 10 mins early. Ref: {$booking['booking_reference']}. Call " . REMEDIES_PHONE . " if any changes.";
        
        return sendSMS($phone, $message);
    }
    
    return false;
}

/**
 * Send payment confirmation SMS
 */
function sendPaymentConfirmationSMS($saleId) {
    global $conn;
    
    $query = "SELECT s.*, m.phone, m.full_name 
              FROM remedies_sales s
              LEFT JOIN members m ON s.customer_id = m.id
              WHERE s.id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $saleId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($sale = $result->fetch_assoc()) {
        $phone = $sale['customer_phone'] ?? $sale['phone'];
        $name = $sale['customer_name'] ?? $sale['full_name'];
        
        $message = "Hi {$name}, thank you for your order #{$sale['sale_reference']} of Ksh " . number_format($sale['net_amount'], 2) . ". Your order is being processed. We'll notify you when it's shipped.";
        
        return sendSMS($phone, $message);
    }
    
    return false;
}

/**
 * Test SMS function (for debugging)
 */
function testSMS() {
    $testPhone = '0712345678'; // Your test phone number
    $testMessage = 'Test SMS from Philadelphia Remedies Department. If you receive this, SMS is working correctly!';
    
    return sendSMS($testPhone, $testMessage);
}
?>