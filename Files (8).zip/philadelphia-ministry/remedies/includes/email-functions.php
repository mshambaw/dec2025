<?php
/**
 * Email Functions for Remedies Department
 */

// Prevent direct access
if (!defined('BASE_PATH')) {
    die('Direct access not permitted');
}

// Import PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

/**
 * Send an email using PHPMailer
 */
function sendRemediesEmail($toEmail, $toName, $subject, $body, $attachments = []) {
    global $conn;
    
    // Check if email is enabled
    if (!EMAIL_ENABLED) {
        logRemediesActivity('email_disabled', ['to' => $toEmail, 'subject' => $subject]);
        return false;
    }
    
    try {
        // Create PHPMailer instance
        $mail = new PHPMailer(true);
        
        // Server settings
        $mail->isSMTP();                            // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';      // Gmail SMTP server
        $mail->SMTPAuth   = true;                  // Enable SMTP authentication
        $mail->Username   = 'your-email@gmail.com'; // Your Gmail address
        $mail->Password   = 'your-app-password';   // Your Gmail app password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // TLS encryption
        $mail->Port       = 587;                   // TCP port
        
        // Alternative: For Outlook/Hotmail
        /*
        $mail->Host       = 'smtp.office365.com';
        $mail->Port       = 587;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        */
        
        // Alternative: For localhost testing (XAMPP)
        /*
        $mail->isSMTP();
        $mail->Host = 'localhost';
        $mail->SMTPAuth = false;
        $mail->Port = 25;
        */
        
        // Recipients
        $mail->setFrom(EMAIL_FROM, EMAIL_FROM_NAME);
        $mail->addAddress($toEmail, $toName);      // Add recipient
        $mail->addReplyTo(EMAIL_REPLY_TO, EMAIL_FROM_NAME);
        
        // Attachments (if any)
        foreach ($attachments as $attachment) {
            $mail->addAttachment($attachment['path'], $attachment['name']);
        }
        
        // Content
        $mail->isHTML(true);                       // Set email format to HTML
        $mail->Subject = $subject;
        $mail->Body    = $body;
        $mail->AltBody = strip_tags($body);        // Plain text version
        
        // Send email
        $mail->send();
        
        // Log success
        logRemediesActivity('email_sent', [
            'to' => $toEmail,
            'subject' => $subject,
            'status' => 'success'
        ]);
        
        return true;
        
    } catch (Exception $e) {
        // Log error
        logRemediesActivity('email_failed', [
            'to' => $toEmail,
            'subject' => $subject,
            'error' => $mail->ErrorInfo
        ]);
        
        return false;
    }
}

/**
 * Send appointment confirmation email
 */
function sendAppointmentConfirmation($bookingId) {
    global $conn;
    
    // Get booking details
    $query = "SELECT b.*, m.full_name, m.email, t.name as treatment_name 
              FROM remedies_bookings b
              JOIN members m ON b.patient_id = m.id
              JOIN remedies_treatments t ON b.treatment_id = t.id
              WHERE b.id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $bookingId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($booking = $result->fetch_assoc()) {
        $toEmail = $booking['email'];
        $toName = $booking['full_name'];
        $subject = "Appointment Confirmation - " . $booking['treatment_name'];
        
        // Email body/template
        $body = "
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #3498db; color: white; padding: 20px; text-align: center; }
                .content { padding: 30px; background: #f9f9f9; }
                .details { background: white; padding: 20px; border-radius: 5px; margin: 20px 0; }
                .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
                .button { background: #27ae60; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>Philadelphia Ministry - Remedies Department</h2>
                </div>
                
                <div class='content'>
                    <h3>Appointment Confirmed!</h3>
                    <p>Dear {$booking['full_name']},</p>
                    <p>Your appointment has been successfully booked.</p>
                    
                    <div class='details'>
                        <h4>Appointment Details:</h4>
                        <p><strong>Treatment:</strong> {$booking['treatment_name']}</p>
                        <p><strong>Date:</strong> " . date('l, F j, Y', strtotime($booking['booking_date'])) . "</p>
                        <p><strong>Time:</strong> " . date('h:i A', strtotime($booking['booking_time'])) . "</p>
                        <p><strong>Reference Number:</strong> {$booking['booking_reference']}</p>
                    </div>
                    
                    <p><strong>Important Notes:</strong></p>
                    <ul>
                        <li>Please arrive 10 minutes before your appointment</li>
                        <li>Bring your ID and any medical records</li>
                        <li>Wear comfortable clothing</li>
                        <li>Call us at " . REMEDIES_PHONE . " if you need to reschedule</li>
                    </ul>
                    
                    <p style='text-align: center; margin-top: 30px;'>
                        <a href='http://yourdomain.com/remedies/patient-portal/my-appointments.php' class='button'>
                            View My Appointments
                        </a>
                    </p>
                </div>
                
                <div class='footer'>
                    <p>Philadelphia Ministry Natural Remedies & Wellness Center</p>
                    <p>" . REMEDIES_ADDRESS . "</p>
                    <p>Phone: " . REMEDIES_PHONE . " | Email: " . REMEDIES_EMAIL . "</p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        // Send email
        return sendRemediesEmail($toEmail, $toName, $subject, $body);
    }
    
    return false;
}

/**
 * Send consultation reminder email
 */
function sendConsultationReminder($consultationId) {
    global $conn;
    
    // Similar to appointment confirmation, but for consultations
    // Implementation similar to above
}

/**
 * Send order confirmation email
 */
function sendOrderConfirmation($saleId) {
    global $conn;
    
    // Get sale details
    $query = "SELECT s.*, m.full_name, m.email 
              FROM remedies_sales s
              LEFT JOIN members m ON s.customer_id = m.id
              WHERE s.id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $saleId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($sale = $result->fetch_assoc()) {
        $toEmail = $sale['customer_email'] ?? $sale['email'];
        $toName = $sale['customer_name'] ?? $sale['full_name'];
        $subject = "Order Confirmation - " . $sale['sale_reference'];
        
        // Get order items
        $itemsQuery = "SELECT si.*, p.name, p.image_url 
                       FROM remedies_sale_items si
                       JOIN remedies_products p ON si.product_id = p.id
                       WHERE si.sale_id = ?";
        
        $stmt = $conn->prepare($itemsQuery);
        $stmt->bind_param("i", $saleId);
        $stmt->execute();
        $itemsResult = $stmt->get_result();
        
        $itemsHtml = "";
        while ($item = $itemsResult->fetch_assoc()) {
            $itemsHtml .= "
            <tr>
                <td>{$item['name']}</td>
                <td>{$item['quantity']}</td>
                <td>" . CURRENCY . " " . number_format($item['unit_price'], 2) . "</td>
                <td>" . CURRENCY . " " . number_format($item['total_price'], 2) . "</td>
            </tr>
            ";
        }
        
        $body = "
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; }
                .container { max-width: 600px; margin: 0 auto; }
                .header { background: #2c3e50; color: white; padding: 20px; }
                .content { padding: 30px; background: #f8f9fa; }
                table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                th { background: #3498db; color: white; padding: 10px; text-align: left; }
                td { padding: 10px; border-bottom: 1px solid #ddd; }
                .total { font-weight: bold; font-size: 18px; color: #e74c3c; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>Order Confirmation</h2>
                </div>
                
                <div class='content'>
                    <p>Dear {$toName},</p>
                    <p>Thank you for your order! Here are your order details:</p>
                    
                    <table>
                        <tr>
                            <th>Product</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Total</th>
                        </tr>
                        {$itemsHtml}
                        <tr>
                            <td colspan='3' style='text-align: right;'><strong>Total Amount:</strong></td>
                            <td class='total'>" . CURRENCY . " " . number_format($sale['net_amount'], 2) . "</td>
                        </tr>
                    </table>
                    
                    <p><strong>Order Reference:</strong> {$sale['sale_reference']}</p>
                    <p><strong>Payment Method:</strong> " . ucfirst($sale['payment_method']) . "</p>
                    <p><strong>Status:</strong> " . ucfirst($sale['payment_status']) . "</p>
                    
                    <p>Your order will be processed within 24 hours. You will receive another email when your order is shipped.</p>
                    
                    <p>Thank you for choosing Philadelphia Remedies!</p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        return sendRemediesEmail($toEmail, $toName, $subject, $body);
    }
    
    return false;
}

/**
 * Simple email function (for testing)
 */
function sendSimpleEmail($to, $subject, $message) {
    // Basic PHP mail() function - works on localhost
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: " . EMAIL_FROM . "\r\n";
    $headers .= "Reply-To: " . EMAIL_REPLY_TO . "\r\n";
    
    return mail($to, $subject, $message, $headers);
}
?>