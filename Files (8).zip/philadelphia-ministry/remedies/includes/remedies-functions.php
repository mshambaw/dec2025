<?php
/**
 * Remedies Department Common Functions
 */

// Prevent direct access
if (!defined('BASE_PATH')) {
    die('Direct access not permitted');
}

/**
 * Get popular treatments
 */
function getPopularTreatments($limit = 6) {
    global $conn;
    
    $treatments = [];
    $query = "SELECT * FROM remedies_treatments 
              WHERE is_active = 1 
              ORDER BY (SELECT COUNT(*) FROM remedies_bookings WHERE treatment_id = remedies_treatments.id) DESC 
              LIMIT ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        $treatments[] = $row;
    }
    
    $stmt->close();
    return $treatments;
}

/**
 * Get upcoming remedies events
 */
function getUpcomingRemediesEvents($limit = 3) {
    global $conn;
    
    $events = [];
    $query = "SELECT * FROM remedies_education 
              WHERE status = 'upcoming' AND start_date >= CURDATE() 
              ORDER BY start_date ASC 
              LIMIT ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        $events[] = $row;
    }
    
    $stmt->close();
    return $events;
}

/**
 * Get testimonials
 */
function getTestimonials($limit = 5) {
    // For now, return dummy data
    // In production, this would come from database
    return [
        [
            'patient_name' => 'John Mwangi',
            'testimonial' => 'The herbal treatment completely healed my chronic arthritis. After 3 months, I can walk without pain for the first time in 10 years!',
            'condition' => 'Arthritis Patient',
            'rating' => 5,
            'avatar' => '../assets/images/members/avatar1.jpg'
        ],
        [
            'patient_name' => 'Mary Wambui',
            'testimonial' => 'The detox program transformed my health. I lost 15kg and my blood pressure normalized without medication.',
            'condition' => 'Weight Management',
            'rating' => 5,
            'avatar' => '../assets/images/members/avatar2.jpg'
        ],
        [
            'patient_name' => 'Robert Ochieng',
            'testimonial' => 'The stress management workshop gave me practical tools to manage my anxiety. I\'m sleeping better and feel more peaceful.',
            'condition' => 'Stress Management',
            'rating' => 4,
            'avatar' => '../assets/images/members/avatar3.jpg'
        ]
    ];
}

/**
 * Truncate text
 */
function truncateText($text, $length = 100) {
    if (strlen($text) <= $length) {
        return $text;
    }
    return substr($text, 0, $length) . '...';
}

/**
 * Check if user is remedies admin
 */
function isRemediesAdmin($userId) {
    global $conn;
    
    $query = "SELECT role FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        return in_array($row['role'], ['admin', 'remedies_admin', 'super_admin']);
    }
    
    return false;
}

/**
 * Generate booking reference
 */
function generateBookingReference() {
    return 'BOOK-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), 7, 6));
}

/**
 * Generate sale reference
 */
function generateSaleReference() {
    return 'SALE-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), 7, 6));
}

/**
 * Send appointment reminder
 */
function sendAppointmentReminder($bookingId) {
    global $conn;
    
    $query = "SELECT b.*, m.full_name, m.email, m.phone, t.name as treatment_name 
              FROM remedies_bookings b
              JOIN members m ON b.patient_id = m.id
              JOIN remedies_treatments t ON b.treatment_id = t.id
              WHERE b.id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $bookingId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($booking = $result->fetch_assoc()) {
        // Send SMS reminder
        $message = "Reminder: Your {$booking['treatment_name']} appointment is scheduled for " . 
                   date('l, F j, Y', strtotime($booking['booking_date'])) . 
                   " at " . date('h:i A', strtotime($booking['booking_time'])) . 
                   ". Please arrive 10 minutes early.";
        
        // sendSMS($booking['phone'], $message);
        
        // Send email reminder
        $emailSubject = "Appointment Reminder - " . date('M j, Y', strtotime($booking['booking_date']));
        $emailBody = "
            <h3>Appointment Reminder</h3>
            <p>Dear {$booking['full_name']},</p>
            <p>This is a reminder for your upcoming appointment:</p>
            <ul>
                <li><strong>Treatment:</strong> {$booking['treatment_name']}</li>
                <li><strong>Date:</strong> " . date('l, F j, Y', strtotime($booking['booking_date'])) . "</li>
                <li><strong>Time:</strong> " . date('h:i A', strtotime($booking['booking_time'])) . "</li>
                <li><strong>Reference:</strong> {$booking['booking_reference']}</li>
            </ul>
            <p>Please arrive 10 minutes before your scheduled time.</p>
            <p>To reschedule or cancel, please call us at +254712345678.</p>
        ";
        
        // sendEmail($booking['email'], $emailSubject, $emailBody);
        
        return true;
    }
    
    return false;
}

/**
 * Validate phone number (Kenya format)
 */
function validateKenyanPhone($phone) {
    $pattern = '/^(07\d{8}|01\d{8}|\+2547\d{8}|\+2541\d{8})$/';
    return preg_match($pattern, $phone);
}

/**
 * Get available time slots for a date
 */
function getAvailableTimeSlots($date, $practitionerId = null) {
    global $conn;
    
    // Default time slots
    $slots = [
        '09:00:00', '10:00:00', '11:00:00', '12:00:00',
        '14:00:00', '15:00:00', '16:00:00', '17:00:00'
    ];
    
    // Get booked slots
    $query = "SELECT booking_time FROM remedies_bookings 
              WHERE booking_date = ? AND status IN ('confirmed', 'pending')";
    
    if ($practitionerId) {
        $query .= " AND practitioner_id = ?";
    }
    
    $stmt = $conn->prepare($query);
    
    if ($practitionerId) {
        $stmt->bind_param("si", $date, $practitionerId);
    } else {
        $stmt->bind_param("s", $date);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $bookedSlots = [];
    while($row = $result->fetch_assoc()) {
        $bookedSlots[] = $row['booking_time'];
    }
    
    $stmt->close();
    
    // Remove booked slots
    $availableSlots = array_diff($slots, $bookedSlots);
    
    return array_values($availableSlots);
}

/**
 * Format time for display
 */
function formatTimeForDisplay($time) {
    return date('h:i A', strtotime($time));
}
// Include email and SMS functions
require_once 'email-functions.php';
require_once 'sms-functions.php';

/**
 * Send booking confirmation (both email and SMS)
 */
function sendBookingConfirmation($bookingId) {
    global $conn;
    
    // Get booking details
    $query = "SELECT b.*, m.full_name, m.email, m.phone, t.name as treatment_name 
              FROM remedies_bookings b
              JOIN members m ON b.patient_id = m.id
              JOIN remedies_treatments t ON b.treatment_id = t.id
              WHERE b.id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $bookingId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($booking = $result->fetch_assoc()) {
        $results = [];
        
        // Send email
        $results['email'] = sendAppointmentConfirmation($bookingId);
        
        // Send SMS
        $results['sms'] = sendAppointmentReminderSMS($bookingId);
        
        // Update booking to mark reminder sent
        $updateQuery = "UPDATE remedies_bookings SET reminder_sent = TRUE WHERE id = ?";
        $updateStmt = $conn->prepare($updateQuery);
        $updateStmt->bind_param("i", $bookingId);
        $updateStmt->execute();
        
        return $results;
    }
    
    return false;
}

/**
 * Send order confirmation (both email and SMS)
 */
function sendOrderConfirmationComplete($saleId) {
    $results = [];
    
    // Send email
    $results['email'] = sendOrderConfirmation($saleId);
    
    // Send SMS
    $results['sms'] = sendPaymentConfirmationSMS($saleId);
    
    return $results;
}

/**
 * Test communication systems
 */
function testCommunicationSystems() {
    $testResults = [];
    
    // Test email
    $testEmail = "test@example.com";
    $testSubject = "Test Email from Remedies System";
    $testBody = "<h1>Test Email</h1><p>If you receive this, email is working!</p>";
    
    $testResults['email'] = sendRemediesEmail($testEmail, "Test User", $testSubject, $testBody);
    
    // Test SMS
    $testResults['sms'] = testSMS();
    
    return $testResults;
}
?>