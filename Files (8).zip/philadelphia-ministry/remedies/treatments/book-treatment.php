<?php
require_once '../../includes/header.php';
require_once '../../includes/db_connect.php';
require_once '../includes/remedies-functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
    header('Location: ../../members/login.php');
    exit();
}

$userId = $_SESSION['user_id'];
$userName = $_SESSION['full_name'] ?? '';
$userEmail = $_SESSION['email'] ?? '';
$userPhone = $_SESSION['phone'] ?? '';

// Get treatment details if treatment ID is provided
$treatmentId = $_GET['treatment'] ?? 0;
$treatment = null;

if ($treatmentId) {
    $query = "SELECT * FROM remedies_treatments WHERE id = ? AND is_active = 1";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $treatmentId);
    $stmt->execute();
    $result = $stmt->get_result();
    $treatment = $result->fetch_assoc();
    $stmt->close();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $treatmentId = $_POST['treatment_id'];
    $bookingDate = $_POST['booking_date'];
    $bookingTime = $_POST['booking_time'];
    $notes = $_POST['notes'] ?? '';
    $practitionerId = $_POST['practitioner_id'] ?? null;
    
    // Validate required fields
    if (empty($treatmentId) || empty($bookingDate) || empty($bookingTime)) {
        $error = "Please fill all required fields";
    } else {
        // Generate booking reference
        $bookingReference = generateBookingReference();
        
        // Insert booking
        $query = "INSERT INTO remedies_bookings (booking_reference, patient_id, treatment_id, practitioner_id, 
                  booking_date, booking_time, notes, status) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')";
        
        $stmt = $conn->prepare($query);
        $stmt->bind_param("siiisss", $bookingReference, $userId, $treatmentId, $practitionerId, 
                         $bookingDate, $bookingTime, $notes);
        
        if ($stmt->execute()) {
            $bookingId = $stmt->insert_id;
            $success = "Appointment booked successfully! Your booking reference is: <strong>$bookingReference</strong>";
            
            // Send confirmation email/SMS
            // sendAppointmentConfirmation($bookingId);
            
            // Clear form
            $treatment = null;
            $treatmentId = 0;
        } else {
            $error = "Failed to book appointment. Please try again.";
        }
        $stmt->close();
    }
}

// Get available practitioners
$practitionersQuery = "SELECT * FROM remedies_practitioners WHERE is_active = 1 ORDER BY full_name";
$practitionersResult = $conn->query($practitionersQuery);
?>

<div class="main-banner" id="top">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="header-text">
                    <h2>Book Treatment</h2>
                    <p>Schedule your natural healing appointment</p>
                </div>
            </div>
        </div>
    </div>
</div>

<section class="booking-section section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="booking-form-container">
                    <div class="form-header">
                        <h3><i class="fas fa-calendar-check"></i> Book Your Appointment</h3>
                        <p>Fill in the details below to schedule your treatment</p>
                    </div>
                    
                    <?php if(isset($success)): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                        <p class="mt-2">
                            <a href="my-appointments.php" class="btn btn-outline-success btn-sm">View My Appointments</a>
                            <a href="book-treatment.php" class="btn btn-success btn-sm">Book Another</a>
                        </p>
                    </div>
                    <?php endif; ?>
                    
                    <?php if(isset($error)): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                    </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" id="bookingForm">
                        <!-- Step 1: Select Treatment -->
                        <div class="form-step active" id="step1">
                            <h4>Step 1: Select Treatment</h4>
                            <div class="form-group">
                                <label for="treatment_id">Select Treatment *</label>
                                <select name="treatment_id" id="treatment_id" class="form-control" required 
                                        onchange="window.location.href='?treatment='+this.value">
                                    <option value="">-- Choose Treatment --</option>
                                    <?php
                                    $treatmentsQuery = "SELECT * FROM remedies_treatments WHERE is_active = 1 ORDER BY name";
                                    $treatmentsResult = $conn->query($treatmentsQuery);
                                    while($t = $treatmentsResult->fetch_assoc()): ?>
                                        <option value="<?php echo $t['id']; ?>" 
                                                <?php echo ($treatmentId == $t['id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($t['name']); ?> 
                                            (Ksh <?php echo number_format($t['price'], 2); ?> - <?php echo $t['duration_minutes']; ?> mins)
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            
                            <?php if($treatment): ?>
                            <div class="selected-treatment">
                                <div class="treatment-preview">
                                    <h5>Selected Treatment:</h5>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <img src="<?php echo $treatment['image_url'] ?? '../../assets/images/remedies/treatment-default.jpg'; ?>" 
                                                 alt="<?php echo htmlspecialchars($treatment['name']); ?>" 
                                                 class="img-fluid rounded">
                                        </div>
                                        <div class="col-md-9">
                                            <h4><?php echo htmlspecialchars($treatment['name']); ?></h4>
                                            <p><?php echo $treatment['description']; ?></p>
                                            <div class="treatment-meta">
                                                <span><i class="far fa-clock"></i> <?php echo $treatment['duration_minutes']; ?> minutes</span>
                                                <span><i class="fas fa-money-bill-wave"></i> Ksh <?php echo number_format($treatment['price'], 2); ?></span>
                                                <span><i class="fas fa-tag"></i> <?php echo ucfirst($treatment['category']); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <button type="button" class="btn btn-primary next-step" data-next="step2">
                                    Next: Select Date & Time <i class="fas fa-arrow-right"></i>
                                </button>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Step 2: Date & Time -->
                        <div class="form-step" id="step2" style="display: none;">
                            <h4>Step 2: Select Date & Time</h4>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="booking_date">Select Date *</label>
                                        <input type="date" name="booking_date" id="booking_date" 
                                               class="form-control" min="<?php echo date('Y-m-d'); ?>" 
                                               max="<?php echo date('Y-m-d', strtotime('+30 days')); ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="booking_time">Select Time *</label>
                                        <select name="booking_time" id="booking_time" class="form-control" required>
                                            <option value="">-- Select Time --</option>
                                            <!-- Time slots will be populated by JavaScript -->
                                        </select>
                                        <small class="text-muted">Available time slots will appear after selecting a date</small>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="practitioner_id">Preferred Practitioner (Optional)</label>
                                <select name="practitioner_id" id="practitioner_id" class="form-control">
                                    <option value="">-- Any Available Practitioner --</option>
                                    <?php while($practitioner = $practitionersResult->fetch_assoc()): ?>
                                        <option value="<?php echo $practitioner['id']; ?>">
                                            <?php echo htmlspecialchars($practitioner['full_name']); ?> 
                                            (<?php echo $practitioner['specialization']; ?>)
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            
                            <div class="form-actions">
                                <button type="button" class="btn btn-outline-secondary prev-step" data-prev="step1">
                                    <i class="fas fa-arrow-left"></i> Back
                                </button>
                                <button type="button" class="btn btn-primary next-step" data-next="step3">
                                    Next: Your Details <i class="fas fa-arrow-right"></i>
                                </button>
                            </div>
                        </div>
                        
                        <!-- Step 3: Your Details -->
                        <div class="form-step" id="step3" style="display: none;">
                            <h4>Step 3: Your Information</h4>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="patient_name">Full Name *</label>
                                        <input type="text" name="patient_name" id="patient_name" 
                                               class="form-control" value="<?php echo htmlspecialchars($userName); ?>" 
                                               readonly required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="patient_email">Email *</label>
                                        <input type="email" name="patient_email" id="patient_email" 
                                               class="form-control" value="<?php echo htmlspecialchars($userEmail); ?>" 
                                               readonly required>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="patient_phone">Phone Number *</label>
                                        <input type="tel" name="patient_phone" id="patient_phone" 
                                               class="form-control" value="<?php echo htmlspecialchars($userPhone); ?>" 
                                               pattern="[0-9]{10}" required>
                                        <small class="text-muted">Format: 07XXXXXXXX</small>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="emergency_phone">Emergency Contact</label>
                                        <input type="tel" name="emergency_phone" id="emergency_phone" 
                                               class="form-control" pattern="[0-9]{10}">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="notes">Additional Notes (Optional)</label>
                                <textarea name="notes" id="notes" class="form-control" rows="3" 
                                          placeholder="Any special requirements, medical conditions, or questions..."></textarea>
                            </div>
                            
                            <div class="form-group">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="terms" required>
                                    <label class="form-check-label" for="terms">
                                        I agree to the <a href="#" data-toggle="modal" data-target="#termsModal">Terms & Conditions</a> 
                                        and understand that late cancellation (less than 24 hours) may incur a fee.
                                    </label>
                                </div>
                            </div>
                            
                            <div class="form-actions">
                                <button type="button" class="btn btn-outline-secondary prev-step" data-prev="step2">
                                    <i class="fas fa-arrow-left"></i> Back
                                </button>
                                <button type="submit" class="btn btn-success">
                                    <i class="fas fa-calendar-check"></i> Confirm Booking
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="col-lg-4">
                <!-- Booking Summary -->
                <div class="booking-summary">
                    <h4><i class="fas fa-receipt"></i> Booking Summary</h4>
                    
                    <?php if($treatment): ?>
                    <div class="summary-content">
                        <div class="summary-item">
                            <span>Treatment:</span>
                            <strong><?php echo htmlspecialchars($treatment['name']); ?></strong>
                        </div>
                        <div class="summary-item">
                            <span>Duration:</span>
                            <strong><?php echo $treatment['duration_minutes']; ?> minutes</strong>
                        </div>
                        <div class="summary-item">
                            <span>Price:</span>
                            <strong class="price">Ksh <?php echo number_format($treatment['price'], 2); ?></strong>
                        </div>
                        <div class="summary-item">
                            <span>Category:</span>
                            <strong><?php echo ucfirst($treatment['category']); ?></strong>
                        </div>
                        <hr>
                        <div class="summary-total">
                            <span>Total Amount:</span>
                            <strong class="total-price">Ksh <?php echo number_format($treatment['price'], 2); ?></strong>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="summary-empty">
                        <p>Select a treatment to see booking details</p>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Important Information -->
                    <div class="booking-info">
                        <h5><i class="fas fa-info-circle"></i> Important Information</h5>
                        <ul>
                            <li>Please arrive 10 minutes before your appointment</li>
                            <li>Bring your ID and any medical records</li>
                            <li>Wear comfortable clothing</li>
                            <li>Cancel at least 24 hours in advance to avoid fees</li>
                            <li>Payment is due at the time of service</li>
                        </ul>
                    </div>
                    
                    <!-- Need Help? -->
                    <div class="help-box">
                        <h5><i class="fas fa-question-circle"></i> Need Help?</h5>
                        <p>Call us at: <strong>+254712345678</strong></p>
                        <p>Email: <strong>remedies@philadelphia-ministry.org</strong></p>
                        <p>Hours: Mon-Sat, 8:00 AM - 6:00 PM</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Terms & Conditions Modal -->
<div class="modal fade" id="termsModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Terms & Conditions</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h6>Appointment Policy</h6>
                <p>1. Appointments must be cancelled at least 24 hours in advance.</p>
                <p>2. Late cancellations or no-shows may incur a fee of 50% of the treatment cost.</p>
                
                <h6>Payment Policy</h6>
                <p>1. Payment is due at the time of service.</p>
                <p>2. We accept cash, mobile money, and credit/debit cards.</p>
                
                <h6>Health & Safety</h6>
                <p>1. Please inform us of any medical conditions before treatment.</p>
                <p>2. Our treatments are complementary and not a substitute for medical care.</p>
                
                <h6>Privacy Policy</h6>
                <p>Your personal and medical information is kept confidential and secure.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<style>
.booking-form-container {
    background: white;
    border-radius: 10px;
    padding: 30px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
}

.form-header {
    margin-bottom: 30px;
    padding-bottom: 20px;
    border-bottom: 2px solid #f8f9fa;
}

.form-header h3 {
    color: #2c3e50;
    margin-bottom: 10px;
}

.form-header h3 i {
    color: #3498db;
    margin-right: 10px;
}

.form-step {
    padding: 20px 0;
}

.form-step h4 {
    color: #3498db;
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 1px solid #eee;
}

.selected-treatment {
    margin: 25px 0;
    padding: 20px;
    background: #f8f9fa;
    border-radius: 8px;
    border-left: 4px solid #3498db;
}

.treatment-preview h5 {
    color: #2c3e50;
    margin-bottom: 15px;
}

.treatment-meta {
    display: flex;
    gap: 20px;
    margin-top: 15px;
    flex-wrap: wrap;
}

.treatment-meta span {
    color: #7f8c8d;
}

.treatment-meta span i {
    margin-right: 5px;
    color: #3498db;
}

.form-actions {
    display: flex;
    justify-content: space-between;
    margin-top: 30px;
    padding-top: 20px;
    border-top: 1px solid #eee;
}

.next-step, .prev-step {
    min-width: 150px;
}

.booking-summary {
    background: white;
    border-radius: 10px;
    padding: 30px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    position: sticky;
    top: 20px;
}

.booking-summary h4 {
    color: #2c3e50;
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 1px solid #eee;
}

.booking-summary h4 i {
    color: #3498db;
    margin-right: 10px;
}

.summary-content {
    margin-bottom: 30px;
}

.summary-item {
    display: flex;
    justify-content: space-between;
    margin-bottom: 15px;
    padding-bottom: 15px;
    border-bottom: 1px dashed #eee;
}

.summary-item span {
    color: #7f8c8d;
}

.summary-item strong {
    color: #2c3e50;
}

.summary-item .price {
    color: #e74c3c;
    font-size: 1.1rem;
}

.summary-total {
    display: flex;
    justify-content: space-between;
    margin-top: 20px;
    padding-top: 20px;
    border-top: 2px solid #3498db;
}

.summary-total span {
    color: #2c3e50;
    font-size: 1.2rem;
    font-weight: 600;
}

.total-price {
    color: #e74c3c;
    font-size: 1.5rem;
    font-weight: 700;
}

.summary-empty {
    text-align: center;
    padding: 40px 20px;
    color: #95a5a6;
}

.booking-info {
    margin: 30px 0;
    padding: 20px;
    background: #e8f4fc;
    border-radius: 8px;
}

.booking-info h5 {
    color: #2c3e50;
    margin-bottom: 15px;
}

.booking-info h5 i {
    color: #3498db;
    margin-right: 10px;
}

.booking-info ul {
    list-style: none;
    padding-left: 0;
    margin-bottom: 0;
}

.booking-info ul li {
    padding: 5px 0;
    color: #5d6d7e;
    position: relative;
    padding-left: 25px;
}

.booking-info ul li:before {
    content: '•';
    position: absolute;
    left: 10px;
    color: #3498db;
    font-weight: bold;
}

.help-box {
    padding: 20px;
    background: #f8f9fa;
    border-radius: 8px;
    border-left: 4px solid #27ae60;
}

.help-box h5 {
    color: #2c3e50;
    margin-bottom: 15px;
}

.help-box h5 i {
    color: #27ae60;
    margin-right: 10px;
}

.help-box p {
    margin-bottom: 10px;
    color: #5d6d7e;
}

.form-group label {
    font-weight: 600;
    color: #5d6d7e;
    margin-bottom: 8px;
}

.form-control {
    padding: 12px 15px;
    border: 2px solid #e9ecef;
    border-radius: 8px;
    transition: all 0.3s ease;
}

.form-control:focus {
    border-color: #3498db;
    box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
}
</style>

<script>
$(document).ready(function() {
    // Step navigation
    $('.next-step').click(function() {
        var currentStep = $(this).closest('.form-step');
        var nextStepId = $(this).data('next');
        
        // Validate current step
        var isValid = validateStep(currentStep);
        if (isValid) {
            currentStep.hide();
            $('#' + nextStepId).show();
        }
    });
    
    $('.prev-step').click(function() {
        var prevStepId = $(this).data('prev');
        $(this).closest('.form-step').hide();
        $('#' + prevStepId).show();
    });
    
    // Get available time slots when date is selected
    $('#booking_date').change(function() {
        var selectedDate = $(this).val();
        var treatmentId = $('#treatment_id').val();
        
        if (selectedDate && treatmentId) {
            $('#booking_time').html('<option value="">Loading available slots...</option>');
            
            $.ajax({
                url: '../api/booking-api.php',
                type: 'GET',
                data: {
                    action: 'get_time_slots',
                    date: selectedDate,
                    treatment_id: treatmentId
                },
                success: function(response) {
                    if (response.success) {
                        var options = '<option value="">-- Select Time --</option>';
                        $.each(response.slots, function(index, slot) {
                            options += '<option value="' + slot + '">' + 
                                     formatTimeForDisplay(slot) + '</option>';
                        });
                        $('#booking_time').html(options);
                    } else {
                        $('#booking_time').html('<option value="">No slots available</option>');
                    }
                }
            });
        }
    });
    
    function validateStep(step) {
        var isValid = true;
        step.find('input[required], select[required], textarea[required]').each(function() {
            if (!$(this).val().trim()) {
                $(this).addClass('is-invalid');
                isValid = false;
            } else {
                $(this).removeClass('is-invalid');
            }
        });
        return isValid;
    }
    
    // Phone number validation
    $('#patient_phone, #emergency_phone').on('input', function() {
        var phone = $(this).val();
        var isValid = validateKenyanPhone(phone);
        
        if (phone && !isValid) {
            $(this).addClass('is-invalid');
            $(this).next('.invalid-feedback').remove();
            $(this).after('<div class="invalid-feedback">Please enter a valid Kenyan phone number (07XXXXXXXX)</div>');
        } else {
            $(this).removeClass('is-invalid');
            $(this).next('.invalid-feedback').remove();
        }
    });
    
    function validateKenyanPhone(phone) {
        var pattern = /^(07\d{8}|01\d{8}|\+2547\d{8}|\+2541\d{8})$/;
        return pattern.test(phone);
    }
    
    function formatTimeForDisplay(time) {
        var timeParts = time.split(':');
        var hours = parseInt(timeParts[0]);
        var minutes = timeParts[1];
        var ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12;
        return hours + ':' + minutes + ' ' + ampm;
    }
});
</script>

<?php require_once '../../includes/footer.php'; ?>