<?php
require_once '../../includes/header.php';
require_once '../../includes/db_connect.php';
require_once '../includes/remedies-functions.php';

// Get all active treatments
$query = "SELECT * FROM remedies_treatments WHERE is_active = 1 ORDER BY name ASC";
$result = $conn->query($query);
?>

<div class="main-banner" id="top">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="header-text">
                    <h2>Natural Treatments</h2>
                    <p>Explore our range of natural healing therapies</p>
                </div>
            </div>
        </div>
    </div>
</div>

<section class="treatments-listing section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h2>Available Treatments</h2>
                    <p>Select from our comprehensive range of natural therapies</p>
                </div>
            </div>
        </div>
        
        <!-- Search and Filter -->
        <div class="row mb-5">
            <div class="col-lg-12">
                <div class="treatment-filters">
                    <div class="row">
                        <div class="col-lg-4 col-md-6">
                            <div class="search-box">
                                <input type="text" id="treatmentSearch" class="form-control" placeholder="Search treatments...">
                                <i class="fas fa-search"></i>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <select id="categoryFilter" class="form-control">
                                <option value="">All Categories</option>
                                <option value="herbal">Herbal Medicine</option>
                                <option value="hydrotherapy">Hydrotherapy</option>
                                <option value="massage">Massage Therapy</option>
                                <option value="detox">Detoxification</option>
                                <option value="therapy">Physical Therapy</option>
                            </select>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <select id="priceFilter" class="form-control">
                                <option value="">All Prices</option>
                                <option value="low">Under Ksh 1,000</option>
                                <option value="medium">Ksh 1,000 - 3,000</option>
                                <option value="high">Over Ksh 3,000</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Treatments Grid -->
        <div class="row" id="treatmentsContainer">
            <?php if($result->num_rows > 0): ?>
                <?php while($treatment = $result->fetch_assoc()): ?>
                <div class="col-lg-4 col-md-6 mb-4" data-category="<?php echo $treatment['category']; ?>" 
                     data-price="<?php echo $treatment['price'] < 1000 ? 'low' : ($treatment['price'] < 3000 ? 'medium' : 'high'); ?>">
                    <div class="treatment-item">
                        <div class="treatment-img">
                            <img src="<?php echo $treatment['image_url'] ?? '../../assets/images/remedies/treatment-default.jpg'; ?>" 
                                 alt="<?php echo htmlspecialchars($treatment['name']); ?>">
                            <div class="treatment-badge">
                                <?php echo ucfirst($treatment['category']); ?>
                            </div>
                        </div>
                        <div class="treatment-info">
                            <h3><?php echo htmlspecialchars($treatment['name']); ?></h3>
                            <p class="treatment-desc"><?php echo truncateText($treatment['description'], 120); ?></p>
                            <div class="treatment-details">
                                <span><i class="far fa-clock"></i> <?php echo $treatment['duration_minutes']; ?> mins</span>
                                <span><i class="fas fa-money-bill-wave"></i> Ksh <?php echo number_format($treatment['price'], 2); ?></span>
                            </div>
                            <div class="treatment-actions">
                                <a href="treatment-details.php?id=<?php echo $treatment['id']; ?>" 
                                   class="btn btn-outline-primary">View Details</a>
                                <a href="book-treatment.php?treatment=<?php echo $treatment['id']; ?>" 
                                   class="btn btn-primary">Book Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-lg-12">
                    <div class="alert alert-info">
                        <h4>No treatments available at the moment.</h4>
                        <p>Please check back later or contact us for more information.</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Treatment Categories -->
<section class="treatment-categories section-padding bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h2>Treatment Categories</h2>
                    <p>Browse treatments by category</p>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <a href="?category=herbal" class="category-card">
                    <div class="category-icon">
                        <i class="fas fa-leaf"></i>
                    </div>
                    <h3>Herbal Medicine</h3>
                    <p>Natural plant-based remedies and herbal preparations</p>
                    <span class="treatment-count">12 Treatments</span>
                </a>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <a href="?category=hydrotherapy" class="category-card">
                    <div class="category-icon">
                        <i class="fas fa-water"></i>
                    </div>
                    <h3>Hydrotherapy</h3>
                    <p>Water-based treatments for healing and relaxation</p>
                    <span class="treatment-count">8 Treatments</span>
                </a>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <a href="?category=massage" class="category-card">
                    <div class="category-icon">
                        <i class="fas fa-spa"></i>
                    </div>
                    <h3>Massage Therapy</h3>
                    <p>Therapeutic massage for pain relief and relaxation</p>
                    <span class="treatment-count">15 Treatments</span>
                </a>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <a href="?category=detox" class="category-card">
                    <div class="category-icon">
                        <i class="fas fa-recycle"></i>
                    </div>
                    <h3>Detoxification</h3>
                    <p>Cleansing treatments to remove toxins from body</p>
                    <span class="treatment-count">6 Treatments</span>
                </a>
            </div>
        </div>
    </div>
</section>

<!-- FAQ Section -->
<section class="treatment-faq section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h2>Frequently Asked Questions</h2>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-lg-6">
                <div class="faq-item">
                    <h4><i class="fas fa-question-circle"></i> How do I book a treatment?</h4>
                    <p>You can book treatments online through our booking system, by calling our office at +254712345678, or by visiting our center in person.</p>
                </div>
                
                <div class="faq-item">
                    <h4><i class="fas fa-question-circle"></i> What should I bring to my appointment?</h4>
                    <p>Please bring your ID, any previous medical records, and wear comfortable clothing. For some treatments, you may need to bring a change of clothes.</p>
                </div>
                
                <div class="faq-item">
                    <h4><i class="fas fa-question-circle"></i> Are the treatments covered by insurance?</h4>
                    <p>Some insurance companies cover natural treatments. Please check with your provider. We provide receipts that can be submitted for reimbursement.</p>
                </div>
            </div>
            
            <div class="col-lg-6">
                <div class="faq-item">
                    <h4><i class="fas fa-question-circle"></i> How early should I arrive?</h4>
                    <p>Please arrive 10-15 minutes before your scheduled appointment time to complete any necessary paperwork and prepare for your treatment.</p>
                </div>
                
                <div class="faq-item">
                    <h4><i class="fas fa-question-circle"></i> Can I cancel or reschedule?</h4>
                    <p>Yes, you can cancel or reschedule up to 24 hours before your appointment without any charges. Late cancellations may incur a fee.</p>
                </div>
                
                <div class="faq-item">
                    <h4><i class="fas fa-question-circle"></i> Are there any side effects?</h4>
                    <p>Natural treatments are generally safe with minimal side effects. However, some people may experience mild reactions. Our practitioners will guide you through any precautions.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="treatment-cta section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2>Ready to Begin Your Healing Journey?</h2>
                <p>Book your first treatment today and experience the power of natural healing</p>
                <a href="book-treatment.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-calendar-check"></i> Book Your Treatment Now
                </a>
                <p class="mt-3">
                    <small>Have questions? Call us at <strong>+254712345678</strong> or email <strong>remedies@philadelphia-ministry.org</strong></small>
                </p>
            </div>
        </div>
    </div>
</section>

<style>
/* Additional Styles for Treatments Page */
.treatment-item {
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    transition: all 0.3s ease;
    height: 100%;
}

.treatment-item:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(0,0,0,0.15);
}

.treatment-img {
    position: relative;
    height: 200px;
    overflow: hidden;
}

.treatment-img img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.5s ease;
}

.treatment-item:hover .treatment-img img {
    transform: scale(1.05);
}

.treatment-badge {
    position: absolute;
    top: 15px;
    right: 15px;
    background: #3498db;
    color: white;
    padding: 5px 15px;
    border-radius: 50px;
    font-size: 0.8rem;
    font-weight: 600;
}

.treatment-info {
    padding: 25px;
}

.treatment-info h3 {
    color: #2c3e50;
    margin-bottom: 10px;
    font-size: 1.3rem;
    min-height: 60px;
}

.treatment-desc {
    color: #7f8c8d;
    margin-bottom: 20px;
    line-height: 1.6;
}

.treatment-details {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    color: #95a5a6;
    font-size: 0.9rem;
    padding: 10px 0;
    border-top: 1px solid #eee;
    border-bottom: 1px solid #eee;
}

.treatment-actions {
    display: flex;
    gap: 10px;
}

.treatment-actions .btn {
    flex: 1;
    border-radius: 50px;
    padding: 10px;
    font-weight: 600;
}

.search-box {
    position: relative;
}

.search-box input {
    padding-left: 40px;
}

.search-box i {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: #95a5a6;
}

.category-card {
    display: block;
    background: white;
    padding: 30px;
    border-radius: 10px;
    text-align: center;
    text-decoration: none;
    color: inherit;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    transition: all 0.3s ease;
    height: 100%;
    margin-bottom: 30px;
}

.category-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(0,0,0,0.15);
    color: inherit;
}

.category-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, #3498db, #2980b9);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 25px;
}

.category-icon i {
    font-size: 2.5rem;
    color: white;
}

.category-card h3 {
    color: #2c3e50;
    margin-bottom: 15px;
    font-size: 1.5rem;
}

.category-card p {
    color: #7f8c8d;
    margin-bottom: 20px;
    line-height: 1.6;
}

.treatment-count {
    display: inline-block;
    background: #e8f4fc;
    color: #3498db;
    padding: 5px 15px;
    border-radius: 50px;
    font-size: 0.9rem;
    font-weight: 600;
}

.faq-item {
    margin-bottom: 25px;
    padding: 20px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.05);
}

.faq-item h4 {
    color: #2c3e50;
    margin-bottom: 10px;
    font-size: 1.2rem;
}

.faq-item h4 i {
    color: #3498db;
    margin-right: 10px;
}

.faq-item p {
    color: #7f8c8d;
    line-height: 1.6;
}

.treatment-cta {
    background: linear-gradient(135deg, #3498db, #2980b9);
    color: white;
}

.treatment-cta h2 {
    color: white;
    margin-bottom: 20px;
}

.treatment-cta p {
    font-size: 1.2rem;
    margin-bottom: 30px;
    opacity: 0.9;
}

.treatment-cta .btn-lg {
    padding: 15px 40px;
    border-radius: 50px;
    font-size: 1.2rem;
}

.treatment-cta .btn-primary {
    background: white;
    color: #3498db;
    border: none;
}

.treatment-cta .btn-primary:hover {
    background: #f8f9fa;
}
</style>

<script>
$(document).ready(function() {
    // Search functionality
    $('#treatmentSearch').on('keyup', function() {
        var searchText = $(this).val().toLowerCase();
        filterTreatments();
    });

    // Category filter
    $('#categoryFilter').on('change', function() {
        filterTreatments();
    });

    // Price filter
    $('#priceFilter').on('change', function() {
        filterTreatments();
    });

    function filterTreatments() {
        var searchText = $('#treatmentSearch').val().toLowerCase();
        var category = $('#categoryFilter').val();
        var price = $('#priceFilter').val();
        
        $('.treatment-item').parent().each(function() {
            var $this = $(this);
            var treatmentText = $this.find('h3').text().toLowerCase() + ' ' + 
                               $this.find('.treatment-desc').text().toLowerCase();
            var treatmentCategory = $this.data('category');
            var treatmentPrice = $this.data('price');
            
            var matchesSearch = searchText === '' || treatmentText.indexOf(searchText) > -1;
            var matchesCategory = category === '' || treatmentCategory === category;
            var matchesPrice = price === '' || treatmentPrice === price;
            
            if (matchesSearch && matchesCategory && matchesPrice) {
                $this.show();
            } else {
                $this.hide();
            }
        });
    }
});
</script>

<?php require_once '../../includes/footer.php'; ?>