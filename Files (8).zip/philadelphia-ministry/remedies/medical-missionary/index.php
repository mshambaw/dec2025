<?php
require_once '../../includes/header.php';
require_once '../../includes/db_connect.php';
require_once '../includes/remedies-functions.php';

// Get upcoming missions
$missionsQuery = "SELECT m.*, p.full_name as coordinator_name 
                  FROM remedies_missions m 
                  LEFT JOIN remedies_practitioners p ON m.coordinator_id = p.id 
                  WHERE m.status IN ('planning', 'active') 
                  ORDER BY m.start_date ASC 
                  LIMIT 6";
$missionsResult = $conn->query($missionsQuery);

// Get completed missions count
$completedQuery = "SELECT COUNT(*) as count FROM remedies_missions WHERE status = 'completed'";
$completedResult = $conn->query($completedQuery);
$completedCount = $completedResult->fetch_assoc()['count'];

// Get volunteer count
$volunteerQuery = "SELECT COUNT(DISTINCT participant_id) as count FROM remedies_mission_participants";
$volunteerResult = $conn->query($volunteerQuery);
$volunteerCount = $volunteerResult->fetch_assoc()['count'];
?>

<div class="main-banner" id="top">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="header-text">
                    <h2>Medical Missionary Service</h2>
                    <p>Bringing health and hope to communities in need</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Mission Stats -->
<section class="mission-stats section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="stat-card">
                    <i class="fas fa-hands-helping"></i>
                    <h3><?php echo $completedCount; ?>+</h3>
                    <p>Missions Completed</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="stat-card">
                    <i class="fas fa-users"></i>
                    <h3><?php echo $volunteerCount; ?>+</h3>
                    <p>Volunteers</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="stat-card">
                    <i class="fas fa-heartbeat"></i>
                    <h3>15,000+</h3>
                    <p>People Served</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="stat-card">
                    <i class="fas fa-map-marked-alt"></i>
                    <h3>50+</h3>
                    <p>Communities Reached</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Our Mission -->
<section class="our-mission section-padding bg-light">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="mission-content">
                    <h2>Our Mission & Vision</h2>
                    <p class="lead">To provide accessible natural healthcare and health education to underserved communities while sharing the love of Christ.</p>
                    
                    <div class="mission-points">
                        <div class="point">
                            <i class="fas fa-cross"></i>
                            <div>
                                <h4>Christ-Centered Service</h4>
                                <p>Serving with compassion as an expression of God's love.</p>
                            </div>
                        </div>
                        <div class="point">
                            <i class="fas fa-stethoscope"></i>
                            <div>
                                <h4>Holistic Healthcare</h4>
                                <p>Addressing physical, mental, and spiritual health needs.</p>
                            </div>
                        </div>
                        <div class="point">
                            <i class="fas fa-graduation-cap"></i>
                            <div>
                                <h4>Community Empowerment</h4>
                                <p>Teaching communities to care for their own health.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="mission-image">
                    <img src="../../assets/images/remedies/mission-team.jpg" alt="Mission Team" class="img-fluid rounded">
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Upcoming Missions -->
<section class="upcoming-missions section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h2>Upcoming Missions</h2>
                    <p>Join our next outreach programs</p>
                </div>
            </div>
        </div>
        
        <div class="row">
            <?php while($mission = $missionsResult->fetch_assoc()): ?>
            <div class="col-lg-4 col-md-6">
                <div class="mission-card">
                    <div class="mission-header">
                        <h3><?php echo htmlspecialchars($mission['mission_name']); ?></h3>
                        <span class="mission-status status-<?php echo $mission['status']; ?>">
                            <?php echo ucfirst($mission['status']); ?>
                        </span>
                    </div>
                    
                    <div class="mission-body">
                        <div class="mission-info">
                            <p><i class="fas fa-map-marker-alt"></i> <?php echo $mission['location']; ?></p>
                            <p><i class="far fa-calendar"></i> 
                                <?php echo date('M j', strtotime($mission['start_date'])); ?>
                                <?php if($mission['end_date']): ?>
                                - <?php echo date('M j', strtotime($mission['end_date'])); ?>
                                <?php endif; ?>
                            </p>
                            <p><i class="fas fa-users"></i> 
                                <?php 
                                $participantsQuery = "SELECT COUNT(*) as count FROM remedies_mission_participants 
                                                     WHERE mission_id = ? AND status IN ('confirmed', 'active')";
                                $stmt = $conn->prepare($participantsQuery);
                                $stmt->bind_param("i", $mission['id']);
                                $stmt->execute();
                                $participantsResult = $stmt->get_result();
                                $participants = $participantsResult->fetch_assoc();
                                echo $participants['count'];
                                ?> volunteers
                            </p>
                            <p><i class="fas fa-hand-holding-medical"></i> 
                                <?php echo ucfirst(str_replace('_', ' ', $mission['mission_type'])); ?>
                            </p>
                        </div>
                        
                        <p class="mission-desc"><?php echo truncateText($mission['description'], 120); ?></p>
                        
                        <div class="mission-needs">
                            <h5>Needed:</h5>
                            <div class="needs-tags">
                                <span class="tag">Medical Volunteers</span>
                                <span class="tag">Supplies</span>
                                <span class="tag">Transport</span>
                            </div>
                        </div>
                        
                        <div class="mission-actions">
                            <a href="mission-details.php?id=<?php echo $mission['id']; ?>" 
                               class="btn btn-outline-primary">View Details</a>
                            <a href="volunteer.php?mission=<?php echo $mission['id']; ?>" 
                               class="btn btn-primary">Volunteer</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
        
        <div class="row mt-5">
            <div class="col-lg-12 text-center">
                <a href="missions.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-globe-africa"></i> View All Missions
                </a>
            </div>
        </div>
    </div>
</section>

<!-- How It Works -->
<section class="mission-process section-padding bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h2>How Medical Missions Work</h2>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="process-step">
                    <div class="step-number">1</div>
                    <h4>Community Assessment</h4>
                    <p>Identify community needs and plan appropriate interventions</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="process-step">
                    <div class="step-number">2</div>
                    <h4>Team Preparation</h4>
                    <p>Train volunteers and gather necessary supplies</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="process-step">
                    <div class="step-number">3</div>
                    <h4>Mission Execution</h4>
                    <p>Provide healthcare services and health education</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="process-step">
                    <div class="step-number">4</div>
                    <h4>Follow-up & Evaluation</h4>
                    <p>Monitor progress and plan future interventions</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Mission Types -->
<section class="mission-types section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h2>Types of Medical Missions</h2>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="type-card">
                    <div class="type-icon">
                        <i class="fas fa-heartbeat"></i>
                    </div>
                    <h3>Health Screening Camps</h3>
                    <p>Free health checkups and basic treatments for communities without access to healthcare.</p>
                    <ul>
                        <li>Blood Pressure Checks</li>
                        <li>Blood Sugar Testing</li>
                        <li>Basic Consultations</li>
                        <li>Health Education</li>
                    </ul>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6">
                <div class="type-card">
                    <div class="type-icon">
                        <i class="fas fa-graduation-cap"></i>
                    </div>
                    <h3>Health Education Programs</h3>
                    <p>Teaching communities about preventive healthcare and natural remedies.</p>
                    <ul>
                        <li>Nutrition Workshops</li>
                        <li>Hygiene Education</li>
                        <li>First Aid Training</li>
                        <li>Home Remedies</li>
                    </ul>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6">
                <div class="type-card">
                    <div class="type-icon">
                        <i class="fas fa-hand-holding-heart"></i>
                    </div>
                    <h3>Treatment & Care Camps</h3>
                    <p>Providing treatments and follow-up care for specific health conditions.</p>
                    <ul>
                        <li>Chronic Disease Management</li>
                        <li>Wound Care</li>
                        <li>Physical Therapy</li>
                        <li>Counseling Services</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Volunteer Call -->
<section class="volunteer-call section-padding bg-primary text-white">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h2>Become a Medical Missionary Volunteer</h2>
                <p>Join our team and make a difference in people's lives. No medical background required - we need all kinds of skills!</p>
            </div>
            <div class="col-lg-4 text-right">
                <a href="volunteer.php" class="btn btn-light btn-lg">
                    <i class="fas fa-hands-helping"></i> Volunteer Now
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Support Missions -->
<section class="support-missions section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h2>Support Our Missions</h2>
                    <p>You can help even if you can't join physically</p>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="support-card">
                    <i class="fas fa-donate"></i>
                    <h3>Financial Support</h3>
                    <p>Your donations help purchase medical supplies, transportation, and mission logistics.</p>
                    <a href="donate.php" class="btn btn-primary">Donate Now</a>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6">
                <div class="support-card">
                    <i class="fas fa-box-open"></i>
                    <h3>Supply Donations</h3>
                    <p>Donate medical supplies, equipment, or other necessary items for our missions.</p>
                    <a href="supplies.php" class="btn btn-primary">View Needed Items</a>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6">
                <div class="support-card">
                    <i class="fas fa-praying-hands"></i>
                    <h3>Prayer Support</h3>
                    <p>Join our prayer network to intercede for our missions and the people we serve.</p>
                    <a href="prayer.php" class="btn btn-primary">Join Prayer Team</a>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
.mission-stats {
    background: linear-gradient(135deg, #2c3e50, #34495e);
    color: white;
}

.stat-card {
    text-align: center;
    padding: 30px 20px;
}

.stat-card i {
    font-size: 3rem;
    color: #3498db;
    margin-bottom: 20px;
}

.stat-card h3 {
    font-size: 2.5rem;
    margin-bottom: 10px;
    color: white;
}

.stat-card p {
    opacity: 0.8;
    font-size: 1.1rem;
}

.mission-content h2 {
    color: #2c3e50;
    margin-bottom: 20px;
}

.mission-content .lead {
    font-size: 1.2rem;
    color: #5d6d7e;
    margin-bottom: 30px;
}

.mission-points .point {
    display: flex;
    align-items: flex-start;
    margin-bottom: 25px;
}

.mission-points .point i {
    font-size: 1.8rem;
    color: #3498db;
    margin-right: 15px;
    margin-top: 5px;
}

.mission-points .point h4 {
    color: #2c3e50;
    margin-bottom: 5px;
    font-size: 1.2rem;
}

.mission-points .point p {
    color: #7f8c8d;
    line-height: 1.6;
}

.mission-image img {
    box-shadow: 0 20px 40px rgba(0,0,0,0.1);
}

.mission-card {
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    margin-bottom: 30px;
    transition: transform 0.3s ease;
}

.mission-card:hover {
    transform: translateY(-5px);
}

.mission-header {
    background: linear-gradient(135deg, #27ae60, #219653);
    color: white;
    padding: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.mission-header h3 {
    color: white;
    margin: 0;
    font-size: 1.3rem;
}

.mission-status {
    padding: 5px 15px;
    border-radius: 50px;
    font-size: 0.8rem;
    font-weight: 600;
}

.status-planning {
    background: #f39c12;
    color: white;
}

.status-active {
    background: #2ecc71;
    color: white;
}

.mission-body {
    padding: 25px;
}

.mission-info p {
    color: #5d6d7e;
    margin-bottom: 10px;
    font-size: 0.95rem;
}

.mission-info p i {
    color: #3498db;
    margin-right: 10px;
    width: 20px;
}

.mission-desc {
    color: #7f8c8d;
    margin: 20px 0;
    line-height: 1.6;
}

.mission-needs h5 {
    color: #2c3e50;
    margin-bottom: 10px;
}

.needs-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-bottom: 20px;
}

.needs-tags .tag {
    background: #e8f4fc;
    color: #3498db;
    padding: 5px 12px;
    border-radius: 50px;
    font-size: 0.85rem;
}

.mission-actions {
    display: flex;
    gap: 10px;
}

.mission-actions .btn {
    flex: 1;
}

.process-step {
    text-align: center;
    padding: 20px;
    margin-bottom: 30px;
}

.process-step .step-number {
    width: 60px;
    height: 60px;
    background: #e74c3c;
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.8rem;
    font-weight: 700;
    margin: 0 auto 20px;
}

.process-step h4 {
    color: #2c3e50;
    margin-bottom: 10px;
    font-size: 1.2rem;
}

.process-step p {
    color: #7f8c8d;
    line-height: 1.6;
}

.type-card {
    background: white;
    border-radius: 10px;
    padding: 30px;
    margin-bottom: 30px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    transition: transform 0.3s ease;
    height: 100%;
}

.type-card:hover {
    transform: translateY(-5px);
}

.type-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, #9b59b6, #8e44ad);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 25px;
}

.type-icon i {
    font-size: 2.5rem;
    color: white;
}

.type-card h3 {
    color: #2c3e50;
    margin-bottom: 15px;
    font-size: 1.5rem;
}

.type-card p {
    color: #7f8c8d;
    margin-bottom: 20px;
    line-height: 1.6;
}

.type-card ul {
    list-style: none;
    padding-left: 0;
    margin-bottom: 0;
}

.type-card ul li {
    padding: 5px 0;
    color: #5d6d7e;
    position: relative;
    padding-left: 25px;
}

.type-card ul li:before {
    content: '•';
    position: absolute;
    left: 10px;
    color: #9b59b6;
    font-weight: bold;
}

.volunteer-call h2 {
    color: white;
    margin-bottom: 15px;
}

.volunteer-call p {
    font-size: 1.2rem;
    opacity: 0.9;
}

.support-card {
    text-align: center;
    padding: 30px;
    margin-bottom: 30px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    transition: transform 0.3s ease;
    height: 100%;
}

.support-card:hover {
    transform: translateY(-5px);
}

.support-card i {
    font-size: 3rem;
    color: #e74c3c;
    margin-bottom: 25px;
}

.support-card h3 {
    color: #2c3e50;
    margin-bottom: 15px;
    font-size: 1.5rem;
}

.support-card p {
    color: #7f8c8d;
    margin-bottom: 25px;
    line-height: 1.6;
}

.support-card .btn {
    border-radius: 50px;
    padding: 10px 25px;
}
</style>

<?php require_once '../../includes/footer.php'; ?>