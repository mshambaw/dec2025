<?php
/**
 * Generate daily reports and backup
 * Run daily at 11 PM: 0 23 * * * php /path/to/generate-daily-report.php
 */

require_once '../../includes/db_connect.php';

$yesterday = date('Y-m-d', strtotime('-1 day'));
$reportDate = date('Y-m-d');

echo "Generating daily report for: $yesterday\n";

// Get daily statistics
$report = [];

// Sales report
$query = "SELECT 
            COUNT(*) as sales_count,
            SUM(net_amount) as total_revenue,
            AVG(net_amount) as average_sale,
            COUNT(DISTINCT customer_id) as unique_customers
          FROM remedies_sales 
          WHERE DATE(created_at) = ? 
          AND payment_status = 'paid'";

$stmt = $conn->prepare($query);
$stmt->bind_param("s", $yesterday);
$stmt->execute();
$salesReport = $stmt->get_result()->fetch_assoc();
$report['sales'] = $salesReport;

// Appointments report
$query = "SELECT 
            COUNT(*) as total_bookings,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
            SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
            SUM(CASE WHEN status = 'no-show' THEN 1 ELSE 0 END) as no_show
          FROM remedies_bookings 
          WHERE booking_date = ?";

$stmt = $conn->prepare($query);
$stmt->bind_param("s", $yesterday);
$stmt->execute();
$appointmentsReport = $stmt->get_result()->fetch_assoc();
$report['appointments'] = $appointmentsReport;

// New patients
$query = "SELECT COUNT(DISTINCT patient_id) as new_patients 
          FROM remedies_bookings 
          WHERE booking_date = ? 
          AND patient_id NOT IN (
            SELECT DISTINCT patient_id FROM remedies_bookings WHERE booking_date < ?
          )";

$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $yesterday, $yesterday);
$stmt->execute();
$newPatients = $stmt->get_result()->fetch_assoc();
$report['new_patients'] = $newPatients['new_patients'];

// Store report in database
$reportJson = json_encode($report);
$query = "INSERT INTO remedies_daily_reports (report_date, report_data) VALUES (?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $reportDate, $reportJson);
$stmt->execute();

echo "Daily report generated and saved.\n";

// Create backup of critical tables (simplified version)
$backupDir = BACKUP_DIR . date('Y/m/');
if (!is_dir($backupDir)) {
    mkdir($backupDir, 0777, true);
}

$backupFile = $backupDir . 'backup-' . date('Y-m-d') . '.sql';
$tables = ['remedies_sales', 'remedies_bookings', 'remedies_consultations'];

$backupContent = "-- Daily Backup - " . date('Y-m-d H:i:s') . "\n";
$backupContent .= "-- Philadelphia Ministry Remedies Department\n\n";

foreach ($tables as $table) {
    $backupContent .= "-- Table: $table\n";
    
    // Get table structure
    $result = $conn->query("SHOW CREATE TABLE $table");
    $row = $result->fetch_assoc();
    $backupContent .= $row['Create Table'] . ";\n\n";
    
    // Get data
    $result = $conn->query("SELECT * FROM $table WHERE DATE(created_at) = '$yesterday'");
    if ($result->num_rows > 0) {
        $backupContent .= "INSERT INTO $table VALUES \n";
        $rows = [];
        while ($row = $result->fetch_assoc()) {
            $values = array_map(function($value) use ($conn) {
                return $conn->real_escape_string($value);
            }, array_values($row));
            $rows[] = "('" . implode("','", $values) . "')";
        }
        $backupContent .= implode(",\n", $rows) . ";\n\n";
    }
}

file_put_contents($backupFile, $backupContent);
echo "Backup created: $backupFile\n";

// Log the report generation
logRemediesActivity('daily_report_generated', [
    'date' => $yesterday,
    'sales' => $salesReport['total_revenue'] ?? 0,
    'appointments' => $appointmentsReport['total_bookings'] ?? 0
]);
?>