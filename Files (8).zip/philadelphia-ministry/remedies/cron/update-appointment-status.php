<?php
/**
 * Update appointment statuses (complete past appointments)
 * Run hourly: 0 * * * * php /path/to/update-appointment-status.php
 */

require_once '../../includes/db_connect.php';

$today = date('Y-m-d');

// Complete appointments from previous days
$query = "UPDATE remedies_bookings 
          SET status = 'completed' 
          WHERE booking_date < ? 
          AND status IN ('confirmed', 'pending')";

$stmt = $conn->prepare($query);
$stmt->bind_param("s", $today);
$stmt->execute();
$updated = $stmt->affected_rows;

echo "Updated $completed appointments to 'completed' status\n";

// Mark no-show appointments (missed appointments)
$query = "UPDATE remedies_bookings 
          SET status = 'no-show' 
          WHERE booking_date = ? 
          AND booking_time < ? 
          AND status = 'confirmed'";

$currentTime = date('H:i:s');
$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $today, $currentTime);
$stmt->execute();
$noShows = $stmt->affected_rows;

echo "Marked $noShows appointments as 'no-show'\n";

// Log the update
if ($updated > 0 || $noShows > 0) {
    logRemediesActivity('appointment_status_updated', [
        'completed' => $updated,
        'no_show' => $noShows,
        'date' => $today
    ]);
}
?>