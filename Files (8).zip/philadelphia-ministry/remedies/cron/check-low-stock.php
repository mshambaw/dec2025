<?php
/**
 * Check for low stock items and send alerts
 * Run daily at 9 AM: 0 9 * * * php /path/to/check-low-stock.php
 */

require_once '../../includes/db_connect.php';
require_once '../includes/remedies-functions.php';

// Get low stock items
$query = "SELECT p.*, s.supplier, s.email as supplier_email 
          FROM remedies_products p
          LEFT JOIN suppliers s ON p.supplier = s.name
          WHERE p.quantity_in_stock <= p.reorder_level 
          AND p.is_active = 1";

$result = $conn->query($query);
$lowStockItems = [];

while ($product = $result->fetch_assoc()) {
    $lowStockItems[] = $product;
}

if (!empty($lowStockItems)) {
    echo "Low stock alert! " . count($lowStockItems) . " items need restocking:\n";
    
    // Send email to admin
    $emailSubject = "Low Stock Alert - " . date('Y-m-d');
    $emailBody = "<h3>Low Stock Items Requiring Attention</h3>";
    $emailBody .= "<table border='1' cellpadding='5'>";
    $emailBody .= "<tr><th>Product</th><th>SKU</th><th>Current Stock</th><th>Reorder Level</th><th>Supplier</th></tr>";
    
    foreach ($lowStockItems as $item) {
        echo "- {$item['name']} (SKU: {$item['sku']}): {$item['quantity_in_stock']} left, reorder at {$item['reorder_level']}\n";
        
        $emailBody .= "<tr>";
        $emailBody .= "<td>{$item['name']}</td>";
        $emailBody .= "<td>{$item['sku']}</td>";
        $emailBody .= "<td>{$item['quantity_in_stock']}</td>";
        $emailBody .= "<td>{$item['reorder_level']}</td>";
        $emailBody .= "<td>{$item['supplier']}</td>";
        $emailBody .= "</tr>";
    }
    
    $emailBody .= "</table>";
    
    // Send to admin
    // sendEmail(ADMIN_EMAIL, $emailSubject, $emailBody);
    
    // Log the alert
    logRemediesActivity('low_stock_alert', [
        'item_count' => count($lowStockItems),
        'items' => array_column($lowStockItems, 'sku')
    ]);
    
    echo "Alert sent to admin\n";
} else {
    echo "All products are sufficiently stocked.\n";
}
?>