<?php
/**
 * Send appointment reminders via SMS and email
 * Run daily at 8 AM: 0 8 * * * php /path/to/appointment-reminders.php
 */

require_once '../../includes/db_connect.php';
require_once '../includes/remedies-functions.php';

// Get tomorrow's appointments
$tomorrow = date('Y-m-d', strtotime('+1 day'));
echo "Sending reminders for appointments on: $tomorrow\n";

// Get appointments
$query = "SELECT b.*, m.full_name, m.email, m.phone, t.name as treatment_name 
          FROM remedies_bookings b
          JOIN members m ON b.patient_id = m.id
          JOIN remedies_treatments t ON b.treatment_id = t.id
          WHERE b.booking_date = ? 
          AND b.status IN ('confirmed', 'pending')";

$stmt = $conn->prepare($query);
$stmt->bind_param("s", $tomorrow);
$stmt->execute();
$result = $stmt->get_result();

$remindersSent = 0;
$errors = [];

while ($booking = $result->fetch_assoc()) {
    try {
        // Send SMS reminder
        $message = "Reminder: Your {$booking['treatment_name']} appointment is tomorrow at " . 
                   date('h:i A', strtotime($booking['booking_time'])) . 
                   ". Please arrive 10 minutes early. Ref: {$booking['booking_reference']}";
        
        // Uncomment when SMS is configured
        // if (sendSMS($booking['phone'], $message)) {
        //     echo "SMS sent to {$booking['phone']}\n";
        // }
        
        // Send email reminder
        $emailSubject = "Appointment Reminder - " . date('D, M j', strtotime($booking['booking_date']));
        $emailBody = "
            <h3>Appointment Reminder</h3>
            <p>Dear {$booking['full_name']},</p>
            <p>This is a reminder for your upcoming appointment:</p>
            <ul>
                <li><strong>Treatment:</strong> {$booking['treatment_name']}</li>
                <li><strong>Date:</strong> " . date('l, F j, Y', strtotime($booking['booking_date'])) . "</li>
                <li><strong>Time:</strong> " . date('h:i A', strtotime($booking['booking_time'])) . "</li>
                <li><strong>Reference:</strong> {$booking['booking_reference']}</li>
            </ul>
            <p>Please arrive 10 minutes before your scheduled time.</p>
            <p>To reschedule or cancel, please call us at " . REMEDIES_PHONE . ".</p>
        ";
        
        // Uncomment when email is configured
        // if (sendEmail($booking['email'], $emailSubject, $emailBody)) {
        //     echo "Email sent to {$booking['email']}\n";
        // }
        
        // Log the reminder
        logRemediesActivity('appointment_reminder_sent', [
            'booking_id' => $booking['id'],
            'patient_id' => $booking['patient_id'],
            'appointment_date' => $booking['booking_date']
        ]);
        
        $remindersSent++;
        
    } catch (Exception $e) {
        $errors[] = "Failed to send reminder for booking {$booking['id']}: " . $e->getMessage();
    }
}

echo "\nReminders sent: $remindersSent\n";
if (!empty($errors)) {
    echo "Errors:\n";
    foreach ($errors as $error) {
        echo "- $error\n";
    }
}
?>