<?php
// Turn on ALL errors
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h1>Remedies Department Debug</h1>";
echo "<p>Current directory: " . __DIR__ . "</p>";
echo "<p>Document root: " . $_SERVER['DOCUMENT_ROOT'] . "</p>";

// Check all required files
echo "<h2>1. Checking Required Files</h2>";
$required_files = [
    '../includes/header.php' => 'Header',
    '../includes/footer.php' => 'Footer',
    '../includes/db_connect.php' => 'Database Connection',
    '../includes/functions.php' => 'Functions',
    'includes/remedies-functions.php' => 'Remedies Functions',
    '../config/database.php' => 'Database Config'
];

foreach ($required_files as $file => $name) {
    $full_path = __DIR__ . '/' . $file;
    echo "<p><strong>$name:</strong> $file<br>";
    echo "Full path: $full_path<br>";
    
    if (file_exists($full_path)) {
        echo "<span style='color:green;'>✅ Exists</span><br>";
        
        // Check if readable
        if (is_readable($full_path)) {
            echo "<span style='color:green;'>✅ Readable</span>";
        } else {
            echo "<span style='color:red;'>❌ Not readable (check permissions)</span>";
        }
    } else {
        echo "<span style='color:red;'>❌ Not found!</span><br>";
        
        // Try alternative
        $alt_path = $_SERVER['DOCUMENT_ROOT'] . '/philadelphia-ministry/' . $file;
        echo "Trying: $alt_path<br>";
        if (file_exists($alt_path)) {
            echo "<span style='color:orange;'>⚠️ Found at alternative location</span>";
        }
    }
    echo "</p><hr>";
}

// Test database
echo "<h2>2. Testing Database Connection</h2>";
try {
    $conn = new mysqli('localhost', 'root', '', 'philadelphia_ministry');
    if ($conn->connect_error) {
        echo "<p style='color:red;'>❌ Database Error: " . $conn->connect_error . "</p>";
    } else {
        echo "<p style='color:green;'>✅ Database connected successfully</p>";
        
        // Check remedies tables
        $result = $conn->query("SHOW TABLES LIKE 'remedies_%'");
        echo "<p>Found " . $result->num_rows . " remedies tables</p>";
        
        if ($result->num_rows > 0) {
            echo "<ul>";
            while ($row = $result->fetch_array()) {
                echo "<li>" . $row[0] . "</li>";
            }
            echo "</ul>";
        }
        $conn->close();
    }
} catch (Exception $e) {
    echo "<p style='color:red;'>❌ Exception: " . $e->getMessage() . "</p>";
}

// Test session
echo "<h2>3. Testing Session</h2>";
session_start();
echo "<p>Session ID: " . session_id() . "</p>";
echo "<p>Session status: " . session_status() . "</p>";
echo "<p>Session data: ";
print_r($_SESSION);
echo "</p>";

// Test PHP configuration
echo "<h2>4. PHP Configuration</h2>";
echo "<p>PHP Version: " . phpversion() . "</p>";
echo "<p>Memory Limit: " . ini_get('memory_limit') . "</p>";
echo "<p>Max Execution Time: " . ini_get('max_execution_time') . "</p>";

// Test includes
echo "<h2>5. Testing Header Include</h2>";
ob_start();
try {
    include __DIR__ . '/../includes/header.php';
    $header_output = ob_get_contents();
    echo "<p style='color:green;'>✅ Header included without errors</p>";
    echo "<textarea style='width:100%;height:100px;'>" . htmlspecialchars(substr($header_output, 0, 500)) . "...</textarea>";
} catch (Exception $e) {
    echo "<p style='color:red;'>❌ Error including header: " . $e->getMessage() . "</p>";
}
ob_end_clean();

// Show final message
echo "<h2 style='color:green;'>6. Debug Complete!</h2>";
echo "<p>If you can see this whole page, PHP is working correctly.</p>";
echo "<p>The issue is likely in your includes or database connection.</p>";
?>