<?php
require_once '../../includes/header.php';
require_once '../../includes/db_connect.php';
require_once '../includes/remedies-functions.php';

// Get upcoming courses
$upcomingQuery = "SELECT e.*, p.full_name as instructor_name 
                  FROM remedies_education e 
                  LEFT JOIN remedies_practitioners p ON e.instructor_id = p.id 
                  WHERE e.status = 'upcoming' AND e.start_date >= CURDATE() 
                  ORDER BY e.start_date ASC 
                  LIMIT 6";
$upcomingResult = $conn->query($upcomingQuery);

// Get active workshops
$workshopsQuery = "SELECT * FROM remedies_education 
                   WHERE type = 'workshop' AND status = 'upcoming' 
                   ORDER BY start_date ASC LIMIT 4";
$workshopsResult = $conn->query($workshopsQuery);

// Get categories
$categoriesQuery = "SELECT DISTINCT type FROM remedies_education ORDER BY type";
$categoriesResult = $conn->query($categoriesQuery);
?>

<div class="main-banner" id="top">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="header-text">
                    <h2>Health Education</h2>
                    <p>Empower yourself with knowledge for better health</p>
                </div>
            </div>
        </div>
    </div>
</div>

<section class="education-hero section-padding">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="hero-content">
                    <h1>Learn Natural Health & Wellness</h1>
                    <p class="lead">Join our courses, workshops, and seminars to learn practical natural health solutions for you and your family.</p>
                    <div class="hero-stats">
                        <div class="stat">
                            <h3>50+</h3>
                            <p>Courses Available</p>
                        </div>
                        <div class="stat">
                            <h3>2,000+</h3>
                            <p>Students Trained</p>
                        </div>
                        <div class="stat">
                            <h3>15</h3>
                            <p>Certified Instructors</p>
                        </div>
                    </div>
                    <a href="#courses" class="btn btn-primary btn-lg">
                        <i class="fas fa-graduation-cap"></i> Browse Courses
                    </a>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="hero-image">
                    <img src="../../assets/images/remedies/education-hero.jpg" alt="Health Education" class="img-fluid rounded">
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Course Categories -->
<section class="education-categories section-padding bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h2>Learning Formats</h2>
                    <p>Choose how you want to learn</p>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <a href="?type=course" class="format-card">
                    <div class="format-icon">
                        <i class="fas fa-book-open"></i>
                    </div>
                    <h3>Courses</h3>
                    <p>Structured learning programs with certificates</p>
                    <span class="format-count">12 Available</span>
                </a>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <a href="?type=workshop" class="format-card">
                    <div class="format-icon">
                        <i class="fas fa-hand-holding-heart"></i>
                    </div>
                    <h3>Workshops</h3>
                    <p>Hands-on practical sessions</p>
                    <span class="format-count">8 Upcoming</span>
                </a>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <a href="?type=webinar" class="format-card">
                    <div class="format-icon">
                        <i class="fas fa-video"></i>
                    </div>
                    <h3>Webinars</h3>
                    <p>Live online learning sessions</p>
                    <span class="format-count">6 Scheduled</span>
                </a>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <a href="?type=seminar" class="format-card">
                    <div class="format-icon">
                        <i class="fas fa-chalkboard-teacher"></i>
                    </div>
                    <h3>Seminars</h3>
                    <p>Expert-led health talks</p>
                    <span class="format-count">10 Planned</span>
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Featured Courses -->
<section class="featured-courses section-padding" id="courses">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h2>Upcoming Courses</h2>
                    <p>Join our next learning sessions</p>
                </div>
            </div>
        </div>
        
        <div class="row">
            <?php while($course = $upcomingResult->fetch_assoc()): ?>
            <div class="col-lg-4 col-md-6">
                <div class="course-card">
                    <div class="course-image">
                        <img src="<?php echo $course['image_url'] ?? '../../assets/images/remedies/course-default.jpg'; ?>" 
                             alt="<?php echo htmlspecialchars($course['title']); ?>">
                        <div class="course-badge">
                            <span class="badge badge-primary"><?php echo ucfirst($course['type']); ?></span>
                            <?php if($course['is_certified']): ?>
                            <span class="badge badge-success">Certificate</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="course-content">
                        <div class="course-meta">
                            <span><i class="far fa-calendar"></i> <?php echo date('M j', strtotime($course['start_date'])); ?></span>
                            <span><i class="far fa-clock"></i> <?php echo $course['duration_hours']; ?> hrs</span>
                            <span><i class="fas fa-user-graduate"></i> <?php echo $course['instructor_name'] ?? 'TBA'; ?></span>
                        </div>
                        
                        <h3><?php echo htmlspecialchars($course['title']); ?></h3>
                        <p class="course-desc"><?php echo truncateText($course['description'], 100); ?></p>
                        
                        <div class="course-info">
                            <div class="course-price">
                                <?php if($course['registration_fee'] > 0): ?>
                                <strong>Ksh <?php echo number_format($course['registration_fee'], 2); ?></strong>
                                <?php else: ?>
                                <strong class="text-success">FREE</strong>
                                <?php endif; ?>
                            </div>
                            <div class="course-slots">
                                <i class="fas fa-users"></i> 
                                <?php 
                                $registeredQuery = "SELECT COUNT(*) as count FROM remedies_education_registrations 
                                                   WHERE education_id = ?";
                                $stmt = $conn->prepare($registeredQuery);
                                $stmt->bind_param("i", $course['id']);
                                $stmt->execute();
                                $registeredResult = $stmt->get_result();
                                $registered = $registeredResult->fetch_assoc();
                                $stmt->close();
                                
                                echo $registered['count'] . '/' . $course['max_participants'];
                                ?> slots
                            </div>
                        </div>
                        
                        <div class="course-actions">
                            <a href="course-details.php?id=<?php echo $course['id']; ?>" 
                               class="btn btn-outline-primary">View Details</a>
                            <a href="register-course.php?id=<?php echo $course['id']; ?>" 
                               class="btn btn-primary">Register Now</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</section>

<!-- Workshops Section -->
<section class="workshops-section section-padding bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h2>Upcoming Workshops</h2>
                    <p>Hands-on practical learning sessions</p>
                </div>
            </div>
        </div>
        
        <div class="row">
            <?php while($workshop = $workshopsResult->fetch_assoc()): ?>
            <div class="col-lg-3 col-md-6">
                <div class="workshop-card">
                    <div class="workshop-date">
                        <span class="day"><?php echo date('d', strtotime($workshop['start_date'])); ?></span>
                        <span class="month"><?php echo date('M', strtotime($workshop['start_date'])); ?></span>
                    </div>
                    <div class="workshop-content">
                        <h3><?php echo htmlspecialchars($workshop['title']); ?></h3>
                        <p class="workshop-time">
                            <i class="far fa-clock"></i> 
                            <?php echo date('h:i A', strtotime($workshop['schedule_time'])); ?>
                        </p>
                        <p class="workshop-location">
                            <i class="fas fa-map-marker-alt"></i> <?php echo $workshop['location']; ?>
                        </p>
                        <div class="workshop-price">
                            <?php if($workshop['registration_fee'] > 0): ?>
                            <strong>Ksh <?php echo number_format($workshop['registration_fee'], 2); ?></strong>
                            <?php else: ?>
                            <strong class="text-success">FREE</strong>
                            <?php endif; ?>
                        </div>
                        <a href="register-course.php?id=<?php echo $workshop['id']; ?>" 
                           class="btn btn-primary btn-block">Register</a>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</section>

<!-- Learning Paths -->
<section class="learning-paths section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h2>Learning Paths</h2>
                    <p>Structured programs for specific goals</p>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="path-card">
                    <div class="path-header">
                        <i class="fas fa-utensils"></i>
                        <h3>Nutrition & Cooking</h3>
                    </div>
                    <div class="path-content">
                        <p>Learn healthy cooking and nutrition principles</p>
                        <ul>
                            <li>Plant-based Cooking</li>
                            <li>Meal Planning</li>
                            <li>Nutrition Basics</li>
                            <li>Special Diets</li>
                        </ul>
                        <a href="courses.php?path=nutrition" class="btn btn-outline-primary">Explore Path</a>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6">
                <div class="path-card">
                    <div class="path-header">
                        <i class="fas fa-spa"></i>
                        <h3>Herbal Medicine</h3>
                    </div>
                    <div class="path-content">
                        <p>Master the art of herbal remedies</p>
                        <ul>
                            <li>Herb Identification</li>
                            <li>Remedy Preparation</li>
                            <li>Dosage Guidelines</li>
                            <li>Safety Protocols</li>
                        </ul>
                        <a href="courses.php?path=herbal" class="btn btn-outline-primary">Explore Path</a>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6">
                <div class="path-card">
                    <div class="path-header">
                        <i class="fas fa-hands-helping"></i>
                        <h3>Family Health</h3>
                    </div>
                    <div class="path-content">
                        <p>Health management for the whole family</p>
                        <ul>
                            <li>Child Health</li>
                            <li>Elderly Care</li>
                            <li>First Aid</li>
                            <li>Home Remedies</li>
                        </ul>
                        <a href="courses.php?path=family" class="btn btn-outline-primary">Explore Path</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials -->
<section class="education-testimonials section-padding bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h2>What Our Students Say</h2>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-lg-12">
                <div class="testimonial-slider">
                    <div class="testimonial-item">
                        <div class="testimonial-text">
                            <p>"The herbal medicine course transformed how I care for my family. I now make my own remedies at home!"</p>
                        </div>
                        <div class="testimonial-author">
                            <img src="../../assets/images/members/avatar1.jpg" alt="Sarah M.">
                            <div class="author-info">
                                <h4>Sarah M.</h4>
                                <p>Herbal Medicine Graduate</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="testimonial-item">
                        <div class="testimonial-text">
                            <p>"As a nurse, this education complemented my medical training with natural health knowledge."</p>
                        </div>
                        <div class="testimonial-author">
                            <img src="../../assets/images/members/avatar2.jpg" alt="John K.">
                            <div class="author-info">
                                <h4>John K.</h4>
                                <p>Registered Nurse</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="testimonial-item">
                        <div class="testimonial-text">
                            <p>"The nutrition workshop helped me reverse my diabetes through diet changes. Life-changing!"</p>
                        </div>
                        <div class="testimonial-author">
                            <img src="../../assets/images/members/avatar3.jpg" alt="Mary W.">
                            <div class="author-info">
                                <h4>Mary W.</h4>
                                <p>Nutrition Course Participant</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA -->
<section class="education-cta section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto text-center">
                <h2>Start Your Health Education Journey Today</h2>
                <p class="lead">Join thousands who have transformed their health through education</p>
                <div class="cta-buttons">
                    <a href="courses.php" class="btn btn-primary btn-lg">
                        <i class="fas fa-book-open"></i> Browse All Courses
                    </a>
                    <a href="contact.php" class="btn btn-outline-light btn-lg">
                        <i class="fas fa-question-circle"></i> Have Questions?
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
.education-hero {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
}

.education-hero .hero-content h1 {
    color: white;
    margin-bottom: 20px;
    font-size: 3rem;
}

.education-hero .hero-content .lead {
    font-size: 1.2rem;
    opacity: 0.9;
    margin-bottom: 30px;
}

.hero-stats {
    display: flex;
    gap: 30px;
    margin-bottom: 30px;
}

.hero-stats .stat h3 {
    font-size: 2.5rem;
    margin-bottom: 5px;
    color: white;
}

.hero-stats .stat p {
    opacity: 0.8;
    font-size: 0.9rem;
}

.hero-image img {
    box-shadow: 0 20px 40px rgba(0,0,0,0.2);
}

.format-card {
    display: block;
    background: white;
    padding: 30px 20px;
    border-radius: 10px;
    text-align: center;
    text-decoration: none;
    color: inherit;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    transition: all 0.3s ease;
    margin-bottom: 30px;
    height: 100%;
}

.format-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(0,0,0,0.15);
    color: inherit;
}

.format-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 25px;
}

.format-icon i {
    font-size: 2.5rem;
    color: white;
}

.format-card h3 {
    color: #2c3e50;
    margin-bottom: 15px;
    font-size: 1.5rem;
}

.format-card p {
    color: #7f8c8d;
    margin-bottom: 15px;
    line-height: 1.6;
}

.format-count {
    display: inline-block;
    background: #e8f4fc;
    color: #3498db;
    padding: 5px 15px;
    border-radius: 50px;
    font-size: 0.9rem;
    font-weight: 600;
}

.course-card {
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    margin-bottom: 30px;
    transition: transform 0.3s ease;
    height: 100%;
}

.course-card:hover {
    transform: translateY(-5px);
}

.course-image {
    position: relative;
    height: 200px;
    overflow: hidden;
}

.course-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.course-badge {
    position: absolute;
    top: 15px;
    right: 15px;
}

.course-badge .badge {
    margin-left: 5px;
}

.course-content {
    padding: 25px;
}

.course-meta {
    display: flex;
    justify-content: space-between;
    margin-bottom: 15px;
    color: #95a5a6;
    font-size: 0.9rem;
    flex-wrap: wrap;
    gap: 10px;
}

.course-meta span i {
    margin-right: 5px;
}

.course-content h3 {
    color: #2c3e50;
    margin-bottom: 15px;
    font-size: 1.3rem;
    height: 60px;
    overflow: hidden;
}

.course-desc {
    color: #7f8c8d;
    margin-bottom: 20px;
    line-height: 1.6;
    height: 80px;
    overflow: hidden;
}

.course-info {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding: 15px 0;
    border-top: 1px solid #eee;
    border-bottom: 1px solid #eee;
}

.course-price strong {
    font-size: 1.5rem;
    color: #e74c3c;
}

.course-slots {
    color: #7f8c8d;
    font-size: 0.9rem;
}

.course-slots i {
    margin-right: 5px;
}

.course-actions {
    display: flex;
    gap: 10px;
}

.course-actions .btn {
    flex: 1;
}

.workshop-card {
    background: white;
    border-radius: 10px;
    padding: 25px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    margin-bottom: 30px;
    position: relative;
    transition: transform 0.3s ease;
}

.workshop-card:hover {
    transform: translateY(-5px);
}

.workshop-date {
    position: absolute;
    top: -20px;
    left: 20px;
    background: #3498db;
    color: white;
    width: 60px;
    height: 60px;
    border-radius: 10px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
}

.workshop-date .day {
    font-size: 1.5rem;
    font-weight: 700;
    line-height: 1;
}

.workshop-date .month {
    font-size: 0.9rem;
    font-weight: 600;
}

.workshop-content {
    margin-top: 15px;
}

.workshop-content h3 {
    color: #2c3e50;
    margin-bottom: 10px;
    font-size: 1.2rem;
    height: 60px;
    overflow: hidden;
}

.workshop-time, .workshop-location {
    color: #7f8c8d;
    margin-bottom: 10px;
    font-size: 0.95rem;
}

.workshop-time i, .workshop-location i {
    margin-right: 8px;
    color: #3498db;
}

.workshop-price {
    margin: 15px 0;
}

.workshop-price strong {
    font-size: 1.3rem;
    color: #e74c3c;
}

.path-card {
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    margin-bottom: 30px;
    transition: transform 0.3s ease;
}

.path-card:hover {
    transform: translateY(-5px);
}

.path-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 30px;
    text-align: center;
}

.path-header i {
    font-size: 3rem;
    margin-bottom: 20px;
}

.path-header h3 {
    color: white;
    font-size: 1.5rem;
}

.path-content {
    padding: 25px;
}

.path-content p {
    color: #7f8c8d;
    margin-bottom: 20px;
    line-height: 1.6;
}

.path-content ul {
    list-style: none;
    padding-left: 0;
    margin-bottom: 25px;
}

.path-content ul li {
    padding: 5px 0;
    color: #5d6d7e;
    position: relative;
    padding-left: 25px;
}

.path-content ul li:before {
    content: '✓';
    position: absolute;
    left: 0;
    color: #27ae60;
    font-weight: bold;
}

.education-testimonials .testimonial-item {
    background: white;
    border-radius: 10px;
    padding: 30px;
    margin: 0 15px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
}

.testimonial-text p {
    font-size: 1.1rem;
    color: #5d6d7e;
    font-style: italic;
    line-height: 1.8;
    margin-bottom: 25px;
}

.testimonial-author {
    display: flex;
    align-items: center;
}

.testimonial-author img {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    object-fit: cover;
    margin-right: 15px;
    border: 3px solid #3498db;
}

.author-info h4 {
    color: #2c3e50;
    margin-bottom: 5px;
    font-size: 1.1rem;
}

.author-info p {
    color: #7f8c8d;
    font-size: 0.9rem;
}

.education-cta {
    background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    color: white;
    text-align: center;
}

.education-cta h2 {
    color: white;
    margin-bottom: 20px;
}

.education-cta .lead {
    font-size: 1.3rem;
    opacity: 0.9;
    margin-bottom: 30px;
}

.cta-buttons {
    display: flex;
    gap: 20px;
    justify-content: center;
    flex-wrap: wrap;
}

.cta-buttons .btn-lg {
    padding: 15px 40px;
    border-radius: 50px;
    font-size: 1.1rem;
    min-width: 200px;
}
</style>

<?php require_once '../../includes/footer.php'; ?>