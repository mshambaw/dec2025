<?php
/**
 * Insert Sample Data for Remedies Department
 * Run this once after database setup
 */

require_once '../../includes/db_connect.php';
require_once '../config/remedies-config.php';

// Security check - only run in local environment or with admin access
if (!defined('DEBUG_MODE') || !DEBUG_MODE) {
    die('Sample data insertion only allowed in debug mode');
}

// Start transaction
$conn->begin_transaction();

try {
    echo "<h2>Inserting Sample Data for Remedies Department</h2>";
    echo "<pre>";
    
    // ==================== INSERT TREATMENTS ====================
    echo "Inserting treatments...\n";
    $treatments = [
        [
            'name' => 'Herbal Massage Therapy',
            'description' => 'Therapeutic massage using herbal oils for relaxation, pain relief, and improved circulation. Our therapists use a blend of traditional herbs and modern techniques.',
            'duration_minutes' => 60,
            'price' => 2500.00,
            'category' => 'massage',
            'image_url' => '../../assets/images/remedies/massage.jpg'
        ],
        [
            'name' => 'Hydrotherapy Session',
            'description' => 'Water-based treatment using alternating hot and cold water applications to improve circulation, reduce inflammation, and promote detoxification.',
            'duration_minutes' => 45,
            'price' => 1800.00,
            'category' => 'hydrotherapy',
            'image_url' => '../../assets/images/remedies/hydrotherapy.jpg'
        ],
        [
            'name' => 'Acupuncture Treatment',
            'description' => 'Traditional Chinese medicine technique using fine needles to stimulate specific points on the body for pain relief and overall wellness.',
            'duration_minutes' => 60,
            'price' => 3000.00,
            'category' => 'acupuncture',
            'image_url' => '../../assets/images/remedies/acupuncture.jpg'
        ],
        [
            'name' => 'Cupping Therapy',
            'description' => 'Suction therapy using cups to increase blood flow, relieve muscle tension, and promote healing. Effective for pain management and relaxation.',
            'duration_minutes' => 30,
            'price' => 1500.00,
            'category' => 'cupping',
            'image_url' => '../../assets/images/remedies/cupping.jpg'
        ],
        [
            'name' => 'Reflexology Session',
            'description' => 'Foot massage targeting specific reflex points that correspond to different body organs and systems for whole-body wellness.',
            'duration_minutes' => 45,
            'price' => 2000.00,
            'category' => 'massage',
            'image_url' => '../../assets/images/remedies/reflexology.jpg'
        ],
        [
            'name' => 'Aromatherapy Treatment',
            'description' => 'Therapeutic use of essential oils through inhalation or topical application for stress relief, mood enhancement, and relaxation.',
            'duration_minutes' => 60,
            'price' => 2200.00,
            'category' => 'aromatherapy',
            'image_url' => '../../assets/images/remedies/aromatherapy.jpg'
        ],
        [
            'name' => 'Detox Foot Bath',
            'description' => 'Ionic foot bath that draws out toxins through the feet, promoting detoxification, improved energy, and better sleep.',
            'duration_minutes' => 30,
            'price' => 1200.00,
            'category' => 'detox',
            'image_url' => '../../assets/images/remedies/footbath.jpg'
        ],
        [
            'name' => 'Herbal Steam Therapy',
            'description' => 'Steam treatment infused with medicinal herbs to open pores, promote sweating, and aid in detoxification and respiratory health.',
            'duration_minutes' => 40,
            'price' => 1700.00,
            'category' => 'detox',
            'image_url' => '../../assets/images/remedies/steam.jpg'
        ],
        [
            'name' => 'Chiropractic Adjustment',
            'description' => 'Manual manipulation of the spine to improve alignment, relieve pain, and enhance nervous system function.',
            'duration_minutes' => 45,
            'price' => 2800.00,
            'category' => 'chiropractic',
            'image_url' => '../../assets/images/remedies/chiropractic.jpg'
        ],
        [
            'name' => 'Nutritional Consultation',
            'description' => 'Personalized dietary assessment and planning based on individual health needs, lifestyle, and goals.',
            'duration_minutes' => 60,
            'price' => 1500.00,
            'category' => 'consultation',
            'image_url' => '../../assets/images/remedies/nutrition.jpg'
        ]
    ];
    
    foreach ($treatments as $treatment) {
        $query = "INSERT INTO remedies_treatments (name, description, duration_minutes, price, category, image_url) 
                  VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssidss", 
            $treatment['name'],
            $treatment['description'],
            $treatment['duration_minutes'],
            $treatment['price'],
            $treatment['category'],
            $treatment['image_url']
        );
        $stmt->execute();
        $stmt->close();
    }
    echo "✓ Inserted " . count($treatments) . " treatments\n";
    
    // ==================== INSERT PRACTITIONERS ====================
    echo "\nInserting practitioners...\n";
    $practitioners = [
        [
            'full_name' => 'Dr. Jane Wambui',
            'specialization' => 'Herbal Medicine & Nutrition',
            'qualifications' => 'PhD in Natural Medicine, Certified Herbalist, Nutrition Specialist',
            'bio' => 'With over 15 years of experience in natural healing, Dr. Wambui specializes in herbal medicine formulations and nutritional therapy. She has helped hundreds of patients achieve better health through natural means.',
            'contact_phone' => '0712345678',
            'contact_email' => 'jane.wambui@philadelphia-ministry.org',
            'profile_image' => '../../assets/images/remedies/practitioners/jane.jpg'
        ],
        [
            'full_name' => 'John Mwangi',
            'specialization' => 'Massage & Physical Therapy',
            'qualifications' => 'Certified Massage Therapist, Physical Therapy Diploma, Reflexology Expert',
            'bio' => 'John is a certified massage therapist with 10 years of experience. He specializes in therapeutic massage, deep tissue work, and reflexology for pain management and relaxation.',
            'contact_phone' => '0723456789',
            'contact_email' => 'john.mwangi@philadelphia-ministry.org',
            'profile_image' => '../../assets/images/remedies/practitioners/john.jpg'
        ],
        [
            'full_name' => 'Mary Atieno',
            'specialization' => 'Hydrotherapy & Detox',
            'qualifications' => 'Hydrotherapy Certification, Detox Specialist, Wellness Coach',
            'bio' => 'Mary is an expert in water-based treatments and detox programs. She combines traditional hydrotherapy with modern wellness techniques to help clients achieve optimal health.',
            'contact_phone' => '0734567890',
            'contact_email' => 'mary.atieno@philadelphia-ministry.org',
            'profile_image' => '../../assets/images/remedies/practitioners/mary.jpg'
        ],
        [
            'full_name' => 'Dr. Robert Ochieng',
            'specialization' => 'Traditional Medicine',
            'qualifications' => 'MD, Traditional Medicine Specialist, Acupuncture Certification',
            'bio' => 'Dr. Ochieng combines modern medical knowledge with traditional healing practices. He is certified in acupuncture and specializes in integrative medicine approaches.',
            'contact_phone' => '0745678901',
            'contact_email' => 'robert.ochieng@philadelphia-ministry.org',
            'profile_image' => '../../assets/images/remedies/practitioners/robert.jpg'
        ],
        [
            'full_name' => 'Sarah Kamau',
            'specialization' => 'Aromatherapy & Stress Management',
            'qualifications' => 'Certified Aromatherapist, Stress Management Coach, Yoga Instructor',
            'bio' => 'Sarah specializes in aromatherapy and stress reduction techniques. She helps clients manage anxiety, improve sleep, and enhance overall wellbeing through natural methods.',
            'contact_phone' => '0756789012',
            'contact_email' => 'sarah.kamau@philadelphia-ministry.org',
            'profile_image' => '../../assets/images/remedies/practitioners/sarah.jpg'
        ]
    ];
    
    foreach ($practitioners as $practitioner) {
        $query = "INSERT INTO remedies_practitioners (full_name, specialization, qualifications, bio, contact_phone, contact_email, profile_image) 
                  VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssssss",
            $practitioner['full_name'],
            $practitioner['specialization'],
            $practitioner['qualifications'],
            $practitioner['bio'],
            $practitioner['contact_phone'],
            $practitioner['contact_email'],
            $practitioner['profile_image']
        );
        $stmt->execute();
        $stmt->close();
    }
    echo "✓ Inserted " . count($practitioners) . " practitioners\n";
    
    // ==================== INSERT PRODUCTS ====================
    echo "\nInserting products...\n";
    $products = [
        [
            'sku' => 'HERB-001',
            'name' => 'Organic Moringa Powder',
            'description' => '100% pure organic moringa leaf powder. Rich in vitamins, minerals, and antioxidants. Supports immune function, energy levels, and overall wellness.',
            'category' => 'Herbs',
            'subcategory' => 'Powders',
            'unit_price' => 800.00,
            'cost_price' => 400.00,
            'quantity_in_stock' => 50,
            'unit_of_measure' => '100g pack',
            'supplier' => 'Organic Farms Kenya',
            'benefits' => 'Boosts immunity, Rich in antioxidants, Supports digestion, Increases energy',
            'usage_instructions' => 'Mix 1 teaspoon with water, juice, or smoothie daily',
            'precautions' => 'Consult doctor if pregnant or on medication',
            'image_url' => '../../assets/images/remedies/products/moringa.jpg'
        ],
        [
            'sku' => 'HERB-002',
            'name' => 'Neem Leaves',
            'description' => 'Dried neem leaves for skin care, detoxification, and immune support. Natural antibacterial and antifungal properties.',
            'category' => 'Herbs',
            'subcategory' => 'Leaves',
            'unit_price' => 500.00,
            'cost_price' => 250.00,
            'quantity_in_stock' => 30,
            'unit_of_measure' => '200g pack',
            'supplier' => 'Herbal Gardens Ltd',
            'benefits' => 'Skin health, Blood purification, Immune support, Dental health',
            'usage_instructions' => 'Steep in hot water for tea or use in skin preparations',
            'precautions' => 'Not recommended for children under 12',
            'image_url' => '../../assets/images/remedies/products/neem.jpg'
        ],
        [
            'sku' => 'SUPP-001',
            'name' => 'Vitamin C 1000mg',
            'description' => 'Natural vitamin C supplement from acerola cherry. Supports immune function, collagen production, and antioxidant protection.',
            'category' => 'Supplements',
            'subcategory' => 'Vitamins',
            'unit_price' => 1200.00,
            'cost_price' => 600.00,
            'quantity_in_stock' => 100,
            'unit_of_measure' => '60 tablets',
            'supplier' => 'Natural Health Supplements',
            'benefits' => 'Immune support, Skin health, Antioxidant protection, Wound healing',
            'usage_instructions' => 'Take 1 tablet daily with meals',
            'precautions' => 'Do not exceed recommended dosage',
            'image_url' => '../../assets/images/remedies/products/vitamin-c.jpg'
        ],
        [
            'sku' => 'SUPP-002',
            'name' => 'Zinc 50mg',
            'description' => 'High-quality zinc supplement for immune function, wound healing, and cellular health. Essential mineral for overall wellness.',
            'category' => 'Supplements',
            'subcategory' => 'Minerals',
            'unit_price' => 900.00,
            'cost_price' => 450.00,
            'quantity_in_stock' => 75,
            'unit_of_measure' => '90 capsules',
            'supplier' => 'Natural Health Supplements',
            'benefits' => 'Immune function, Wound healing, Skin health, Enzyme support',
            'usage_instructions' => 'Take 1 capsule daily with food',
            'precautions' => 'Take with food to avoid stomach upset',
            'image_url' => '../../assets/images/remedies/products/zinc.jpg'
        ],
        [
            'sku' => 'OIL-001',
            'name' => 'Lavender Essential Oil',
            'description' => 'Pure lavender essential oil for relaxation, sleep support, and skin care. Calming aroma with therapeutic benefits.',
            'category' => 'Oils',
            'subcategory' => 'Essential Oils',
            'unit_price' => 1500.00,
            'cost_price' => 750.00,
            'quantity_in_stock' => 40,
            'unit_of_measure' => '15ml',
            'supplier' => 'Pure Essentials Kenya',
            'benefits' => 'Promotes relaxation, Improves sleep, Skin healing, Reduces anxiety',
            'usage_instructions' => 'Diffuse 3-5 drops or dilute with carrier oil for topical use',
            'precautions' => 'Do not ingest. Dilute before skin application',
            'image_url' => '../../assets/images/remedies/products/lavender.jpg'
        ],
        [
            'sku' => 'OIL-002',
            'name' => 'Tea Tree Oil',
            'description' => 'Pure tea tree essential oil with antibacterial and antifungal properties. Excellent for skin care and household cleaning.',
            'category' => 'Oils',
            'subcategory' => 'Essential Oils',
            'unit_price' => 1200.00,
            'cost_price' => 600.00,
            'quantity_in_stock' => 35,
            'unit_of_measure' => '15ml',
            'supplier' => 'Pure Essentials Kenya',
            'benefits' => 'Antibacterial, Antifungal, Skin care, Household cleaning',
            'usage_instructions' => 'Dilute with carrier oil for skin use or add to cleaning solutions',
            'precautions' => 'Always dilute before skin application',
            'image_url' => '../../assets/images/remedies/products/tea-tree.jpg'
        ],
        [
            'sku' => 'TEA-001',
            'name' => 'Detox Herbal Tea',
            'description' => 'Herbal tea blend for detoxification, digestion, and liver support. Contains dandelion, ginger, and milk thistle.',
            'category' => 'Teas',
            'subcategory' => 'Herbal Teas',
            'unit_price' => 600.00,
            'cost_price' => 300.00,
            'quantity_in_stock' => 60,
            'unit_of_measure' => '20 tea bags',
            'supplier' => 'Herbal Teas Kenya',
            'benefits' => 'Liver detoxification, Digestive support, Antioxidant protection, Hydration',
            'usage_instructions' => 'Steep 1 tea bag in hot water for 5-7 minutes',
            'precautions' => 'Consult doctor if pregnant or have liver conditions',
            'image_url' => '../../assets/images/remedies/products/detox-tea.jpg'
        ],
        [
            'sku' => 'EQP-001',
            'name' => 'Acupressure Mat',
            'description' => 'Therapeutic acupressure mat for pain relief, relaxation, and improved circulation. Stimulates pressure points for whole-body benefits.',
            'category' => 'Equipment',
            'subcategory' => 'Therapy Tools',
            'unit_price' => 2500.00,
            'cost_price' => 1250.00,
            'quantity_in_stock' => 20,
            'unit_of_measure' => 'piece',
            'supplier' => 'Health Equipment Ltd',
            'benefits' => 'Pain relief, Relaxation, Improved circulation, Stress reduction',
            'usage_instructions' => 'Lie on mat for 15-30 minutes daily',
            'precautions' => 'Start with short sessions and gradually increase time',
            'image_url' => '../../assets/images/remedies/products/acupressure-mat.jpg'
        ],
        [
            'sku' => 'BOOK-001',
            'name' => 'Natural Remedies Handbook',
            'description' => 'Comprehensive guide to natural remedies for common ailments. Includes herbal preparations, dietary advice, and lifestyle recommendations.',
            'category' => 'Books',
            'subcategory' => 'Health Guides',
            'unit_price' => 1500.00,
            'cost_price' => 750.00,
            'quantity_in_stock' => 25,
            'unit_of_measure' => 'copy',
            'supplier' => 'Health Publications',
            'benefits' => 'Educational resource, Home remedy guide, Health empowerment, Preventive care',
            'usage_instructions' => 'Reference book for natural health information',
            'precautions' => 'Consult healthcare provider for serious conditions',
            'image_url' => '../../assets/images/remedies/products/health-book.jpg'
        ],
        [
            'sku' => 'KIT-001',
            'name' => 'First Aid Herbal Kit',
            'description' => 'Complete herbal first aid kit with essential oils, salves, and remedies for common injuries and ailments.',
            'category' => 'Kits',
            'subcategory' => 'First Aid',
            'unit_price' => 3500.00,
            'cost_price' => 1750.00,
            'quantity_in_stock' => 15,
            'unit_of_measure' => 'kit',
            'supplier' => 'Herbal Solutions Ltd',
            'benefits' => 'Natural first aid, Emergency preparedness, Home healthcare, Travel safety',
            'usage_instructions' => 'Follow included guide for specific conditions',
            'precautions' => 'Store in cool, dry place. Keep away from children',
            'image_url' => '../../assets/images/remedies/products/first-aid-kit.jpg'
        ]
    ];
    
    foreach ($products as $product) {
        $query = "INSERT INTO remedies_products (sku, name, description, category, subcategory, unit_price, cost_price, quantity_in_stock, unit_of_measure, supplier, benefits, usage_instructions, precautions, image_url) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssssddiisssss",
            $product['sku'],
            $product['name'],
            $product['description'],
            $product['category'],
            $product['subcategory'],
            $product['unit_price'],
            $product['cost_price'],
            $product['quantity_in_stock'],
            $product['unit_of_measure'],
            $product['supplier'],
            $product['benefits'],
            $product['usage_instructions'],
            $product['precautions'],
            $product['image_url']
        );
        $stmt->execute();
        $stmt->close();
    }
    echo "✓ Inserted " . count($products) . " products\n";
    
    // ==================== INSERT EDUCATION PROGRAMS ====================
    echo "\nInserting education programs...\n";
    $education = [
        [
            'title' => 'Herbal Medicine Fundamentals',
            'description' => 'Learn the basics of herbal medicine including plant identification, remedy preparation, and safe usage for common health conditions.',
            'type' => 'course',
            'instructor_id' => 1,
            'start_date' => date('Y-m-d', strtotime('+7 days')),
            'end_date' => date('Y-m-d', strtotime('+14 days')),
            'schedule_time' => '10:00:00',
            'duration_hours' => 12,
            'location' => 'Training Room, Philadelphia Ministry',
            'max_participants' => 20,
            'registration_fee' => 5000.00,
            'is_certified' => true,
            'image_url' => '../../assets/images/remedies/education/herbal-course.jpg'
        ],
        [
            'title' => 'Healthy Cooking Workshop',
            'description' => 'Hands-on workshop teaching how to prepare nutritious, delicious meals using whole foods and natural ingredients.',
            'type' => 'workshop',
            'instructor_id' => 1,
            'start_date' => date('Y-m-d', strtotime('+3 days')),
            'end_date' => null,
            'schedule_time' => '14:00:00',
            'duration_hours' => 4,
            'location' => 'Kitchen Lab, Philadelphia Ministry',
            'max_participants' => 15,
            'registration_fee' => 2000.00,
            'is_certified' => false,
            'image_url' => '../../assets/images/remedies/education/cooking-workshop.jpg'
        ],
        [
            'title' => 'Stress Management Through Natural Methods',
            'description' => 'Learn practical techniques for managing stress using meditation, breathing exercises, herbal remedies, and lifestyle changes.',
            'type' => 'seminar',
            'instructor_id' => 5,
            'start_date' => date('Y-m-d', strtotime('+5 days')),
            'end_date' => null,
            'schedule_time' => '18:00:00',
            'duration_hours' => 3,
            'location' => 'Conference Hall, Philadelphia Ministry',
            'max_participants' => 50,
            'registration_fee' => 0.00,
            'is_certified' => false,
            'image_url' => '../../assets/images/remedies/education/stress-seminar.jpg'
        ],
        [
            'title' => 'First Aid with Natural Remedies',
            'description' => 'Learn how to handle common emergencies using natural remedies and herbs. Certification provided upon completion.',
            'type' => 'course',
            'instructor_id' => 1,
            'start_date' => date('Y-m-d', strtotime('+10 days')),
            'end_date' => date('Y-m-d', strtotime('+17 days')),
            'schedule_time' => '09:00:00',
            'duration_hours' => 8,
            'location' => 'Training Room, Philadelphia Ministry',
            'max_participants' => 25,
            'registration_fee' => 4000.00,
            'is_certified' => true,
            'image_url' => '../../assets/images/remedies/education/first-aid.jpg'
        ],
        [
            'title' => 'Introduction to Aromatherapy',
            'description' => 'Online webinar teaching the basics of aromatherapy, essential oil safety, and practical applications for home use.',
            'type' => 'webinar',
            'instructor_id' => 5,
            'start_date' => date('Y-m-d', strtotime('+2 days')),
            'end_date' => null,
            'schedule_time' => '19:00:00',
            'duration_hours' => 2,
            'location' => 'Online (Zoom)',
            'max_participants' => 100,
            'registration_fee' => 1000.00,
            'is_certified' => false,
            'image_url' => '../../assets/images/remedies/education/aromatherapy-webinar.jpg'
        ]
    ];
    
    foreach ($education as $program) {
        $query = "INSERT INTO remedies_education (title, description, type, instructor_id, start_date, end_date, schedule_time, duration_hours, location, max_participants, registration_fee, is_certified, image_url) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssisssisidis",
            $program['title'],
            $program['description'],
            $program['type'],
            $program['instructor_id'],
            $program['start_date'],
            $program['end_date'],
            $program['schedule_time'],
            $program['duration_hours'],
            $program['location'],
            $program['max_participants'],
            $program['registration_fee'],
            $program['is_certified'],
            $program['image_url']
        );
        $stmt->execute();
        $stmt->close();
    }
    echo "✓ Inserted " . count($education) . " education programs\n";
    
    // ==================== INSERT MISSIONS ====================
    echo "\nInserting medical missions...\n";
    $missions = [
        [
            'mission_name' => 'Rural Health Screening - Kajiado',
            'description' => 'Free health screening and basic treatment camp for rural communities in Kajiado County. Focus on maternal health, child wellness, and chronic disease screening.',
            'location' => 'Kajiado County, Kenya',
            'start_date' => date('Y-m-d', strtotime('+14 days')),
            'end_date' => date('Y-m-d', strtotime('+16 days')),
            'mission_type' => 'health_screening',
            'target_beneficiaries' => 500,
            'budget' => 150000.00,
            'coordinator_id' => 1,
            'image_url' => '../../assets/images/remedies/missions/kajiado.jpg'
        ],
        [
            'mission_name' => 'Urban Slum Health Camp - Kibera',
            'description' => 'Medical camp providing free consultations, basic treatments, and health education in Kibera slums. Focus on hygiene, nutrition, and preventive care.',
            'location' => 'Kibera, Nairobi',
            'start_date' => date('Y-m-d', strtotime('+21 days')),
            'end_date' => date('Y-m-d', strtotime('+22 days')),
            'mission_type' => 'treatment_camp',
            'target_beneficiaries' => 300,
            'budget' => 100000.00,
            'coordinator_id' => 2,
            'image_url' => '../../assets/images/remedies/missions/kibera.jpg'
        ],
        [
            'mission_name' => 'School Health Education Program',
            'description' => 'Health education program for primary school children focusing on hygiene, nutrition, and basic first aid training.',
            'location' => 'Machakos County',
            'start_date' => date('Y-m-d', strtotime('+28 days')),
            'end_date' => null,
            'mission_type' => 'education',
            'target_beneficiaries' => 200,
            'budget' => 50000.00,
            'coordinator_id' => 3,
            'image_url' => '../../assets/images/remedies/missions/school-health.jpg'
        ],
        [
            'mission_name' => 'Mobile Clinic - Turkana County',
            'description' => 'Mobile medical clinic providing healthcare services to remote communities in Turkana County. Focus on maternal health and childhood illnesses.',
            'location' => 'Turkana County',
            'start_date' => date('Y-m-d', strtotime('+35 days')),
            'end_date' => date('Y-m-d', strtotime('+40 days')),
            'mission_type' => 'treatment_camp',
            'target_beneficiaries' => 800,
            'budget' => 300000.00,
            'coordinator_id' => 1,
            'image_url' => '../../assets/images/remedies/missions/turkana.jpg'
        ]
    ];
    
    foreach ($missions as $mission) {
        $query = "INSERT INTO remedies_missions (mission_name, description, location, start_date, end_date, mission_type, target_beneficiaries, budget, coordinator_id, image_url) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssssssidiis",
            $mission['mission_name'],
            $mission['description'],
            $mission['location'],
            $mission['start_date'],
            $mission['end_date'],
            $mission['mission_type'],
            $mission['target_beneficiaries'],
            $mission['budget'],
            $mission['coordinator_id'],
            $mission['image_url']
        );
        $stmt->execute();
        $stmt->close();
    }
    echo "✓ Inserted " . count($missions) . " medical missions\n";
    
    // ==================== INSERT SAMPLE BOOKINGS ====================
    echo "\nInserting sample bookings...\n";
    
    // Get a sample patient (assuming member ID 2 exists)
    $patientId = 2; // Adjust based on your members table
    
    $bookings = [];
    for ($i = 1; $i <= 5; $i++) {
        $bookingDate = date('Y-m-d', strtotime("+$i days"));
        $bookingTime = ['09:00', '10:00', '11:00', '14:00', '15:00'][$i-1];
        $treatmentId = $i;
        $practitionerId = ($i % 4) + 1;
        
        $bookings[] = [
            'patient_id' => $patientId,
            'treatment_id' => $treatmentId,
            'practitioner_id' => $practitionerId,
            'booking_date' => $bookingDate,
            'booking_time' => $bookingTime . ':00'
        ];
    }
    
    foreach ($bookings as $booking) {
        $reference = 'BOOK-' . date('Ymd') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
        
        $query = "INSERT INTO remedies_bookings (booking_reference, patient_id, treatment_id, practitioner_id, booking_date, booking_time, status) 
                  VALUES (?, ?, ?, ?, ?, ?, 'confirmed')";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("siiiss",
            $reference,
            $booking['patient_id'],
            $booking['treatment_id'],
            $booking['practitioner_id'],
            $booking['booking_date'],
            $booking['booking_time']
        );
        $stmt->execute();
        $stmt->close();
    }
    echo "✓ Inserted " . count($bookings) . " sample bookings\n";
    
    // ==================== INSERT SAMPLE SALES ====================
    echo "\nInserting sample sales...\n";
    
    $sales = [
        [
            'customer_id' => $patientId,
            'customer_name' => 'John Doe',
            'customer_phone' => '0712345678',
            'customer_email' => 'john@example.com',
            'total_amount' => 3500.00,
            'net_amount' => 3500.00,
            'payment_method' => 'mobile_money',
            'payment_status' => 'paid'
        ],
        [
            'customer_id' => $patientId,
            'customer_name' => 'John Doe',
            'customer_phone' => '0712345678',
            'customer_email' => 'john@example.com',
            'total_amount' => 1200.00,
            'net_amount' => 1200.00,
            'payment_method' => 'cash',
            'payment_status' => 'paid'
        ]
    ];
    
    foreach ($sales as $sale) {
        $reference = 'SALE-' . date('Ymd') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
        
        $query = "INSERT INTO remedies_sales (sale_reference, customer_id, customer_name, customer_phone, customer_email, total_amount, net_amount, payment_method, payment_status) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sisssddss",
            $reference,
            $sale['customer_id'],
            $sale['customer_name'],
            $sale['customer_phone'],
            $sale['customer_email'],
            $sale['total_amount'],
            $sale['net_amount'],
            $sale['payment_method'],
            $sale['payment_status']
        );
        $stmt->execute();
        $saleId = $stmt->insert_id;
        $stmt->close();
        
        // Add sale items
        if ($sale['total_amount'] == 3500.00) {
            $items = [
                ['product_id' => 1, 'quantity' => 2, 'unit_price' => 800.00],
                ['product_id' => 3, 'quantity' => 1, 'unit_price' => 1200.00],
                ['product_id' => 7, 'quantity' => 1, 'unit_price' => 600.00]
            ];
        } else {
            $items = [
                ['product_id' => 5, 'quantity' => 1, 'unit_price' => 1200.00]
            ];
        }
        
        foreach ($items as $item) {
            $total = $item['unit_price'] * $item['quantity'];
            $query = "INSERT INTO remedies_sale_items (sale_id, product_id, quantity, unit_price, total_price) 
                      VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("iiidd", $saleId, $item['product_id'], $item['quantity'], $item['unit_price'], $total);
            $stmt->execute();
            $stmt->close();
        }
    }
    echo "✓ Inserted " . count($sales) . " sample sales\n";
    
    // Commit transaction
    $conn->commit();
    
    echo "\n===========================================\n";
    echo "✅ SAMPLE DATA INSERTION COMPLETE!\n";
    echo "===========================================\n";
    echo "Inserted:\n";
    echo "- " . count($treatments) . " treatments\n";
    echo "- " . count($practitioners) . " practitioners\n";
    echo "- " . count($products) . " products\n";
    echo "- " . count($education) . " education programs\n";
    echo "- " . count($missions) . " medical missions\n";
    echo "- " . count($bookings) . " sample bookings\n";
    echo "- " . count($sales) . " sample sales\n";
    echo "\nRemedies department is now ready for use!\n";
    
} catch (Exception $e) {
    $conn->rollback();
    echo "\n❌ ERROR: " . $e->getMessage() . "\n";
    echo "Transaction rolled back.\n";
}

echo "</pre>";
?>