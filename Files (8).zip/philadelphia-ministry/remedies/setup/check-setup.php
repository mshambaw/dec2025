<?php
/**
 * Remedies Department Setup Checklist
 * Run this to verify everything is set up correctly
 */

require_once '../../includes/db_connect.php';
require_once '../config/remedies-config.php';

echo "<h2>Remedies Department Setup Checklist</h2>";
echo "<pre>";

$checks = [];
$errors = [];

// Check 1: Database connection
try {
    $conn->ping();
    $checks[] = "✅ Database connection: OK";
} catch (Exception $e) {
    $errors[] = "❌ Database connection failed: " . $e->getMessage();
}

// Check 2: Required tables exist
$requiredTables = [
    'remedies_treatments',
    'remedies_practitioners',
    'remedies_bookings',
    'remedies_products',
    'remedies_sales',
    'remedies_education',
    'remedies_missions'
];

foreach ($requiredTables as $table) {
    $result = $conn->query("SHOW TABLES LIKE '$table'");
    if ($result->num_rows > 0) {
        $checks[] = "✅ Table '$table': EXISTS";
    } else {
        $errors[] = "❌ Table '$table': MISSING";
    }
}

// Check 3: Directories exist and are writable
$requiredDirs = [
    UPLOAD_DIR,
    REPORT_DIR,
    BACKUP_DIR,
    LOG_DIR,
    CACHE_DIR
];

foreach ($requiredDirs as $dir) {
    if (is_dir($dir) && is_writable($dir)) {
        $checks[] = "✅ Directory '$dir': WRITABLE";
    } else {
        if (!is_dir($dir)) {
            if (mkdir($dir, 0777, true)) {
                $checks[] = "✅ Directory '$dir': CREATED";
            } else {
                $errors[] = "❌ Directory '$dir': CANNOT CREATE";
            }
        } else {
            $errors[] = "❌ Directory '$dir': NOT WRITABLE";
        }
    }
}

// Check 4: Configuration constants are defined
$requiredConstants = [
    'REMEDIES_ENABLED',
    'REMEDIES_EMAIL',
    'REMEDIES_PHONE',
    'BUSINESS_OPEN',
    'BUSINESS_CLOSE',
    'CURRENCY',
    'TAX_RATE'
];

foreach ($requiredConstants as $constant) {
    if (defined($constant)) {
        $checks[] = "✅ Constant '$constant': DEFINED";
    } else {
        $errors[] = "❌ Constant '$constant': UNDEFINED";
    }
}

// Check 5: Sample data exists
$result = $conn->query("SELECT COUNT(*) as count FROM remedies_treatments");
$treatmentCount = $result->fetch_assoc()['count'];

$result = $conn->query("SELECT COUNT(*) as count FROM remedies_products");
$productCount = $result->fetch_assoc()['count'];

if ($treatmentCount > 0) {
    $checks[] = "✅ Treatments data: $treatmentCount records";
} else {
    $warnings[] = "⚠️ No treatment data found. Run insert-sample-data.php";
}

if ($productCount > 0) {
    $checks[] = "✅ Products data: $productCount records";
} else {
    $warnings[] = "⚠️ No product data found. Run insert-sample-data.php";
}

// Display results
echo "===========================================\n";
echo "SETUP CHECK RESULTS\n";
echo "===========================================\n\n";

echo "CHECKS PASSED:\n";
foreach ($checks as $check) {
    echo "$check\n";
}

echo "\n";

if (!empty($warnings)) {
    echo "WARNINGS:\n";
    foreach ($warnings as $warning) {
        echo "$warning\n";
    }
    echo "\n";
}

if (!empty($errors)) {
    echo "ERRORS:\n";
    foreach ($errors as $error) {
        echo "$error\n";
    }
    echo "\n";
    echo "❌ SETUP INCOMPLETE - Please fix errors above\n";
} else {
    echo "===========================================\n";
    echo "✅ SETUP COMPLETE - Remedies Department is ready!\n";
    echo "===========================================\n";
}

// Test database procedures
echo "\nTesting database procedures...\n";
try {
    // Test low stock procedure
    $result = $conn->query("CALL CheckLowStock()");
    if ($result) {
        $lowStock = $result->num_rows;
        echo "✅ Low stock check: $lowStock items need restocking\n";
    }
    
    // Test get daily appointments
    $tomorrow = date('Y-m-d', strtotime('+1 day'));
    $stmt = $conn->prepare("CALL GetDailyAppointments(?)");
    $stmt->bind_param("s", $tomorrow);
    $stmt->execute();
    $result = $stmt->get_result();
    $appointments = $result->num_rows;
    echo "✅ Daily appointments procedure: OK ($appointments appointments tomorrow)\n";
    
} catch (Exception $e) {
    echo "⚠️ Procedure test failed: " . $e->getMessage() . "\n";
}

// Check file permissions
echo "\nFile permissions check:\n";
$files = [
    '../config/remedies-config.php' => 'config file',
    '../includes/remedies-functions.php' => 'functions file',
    '../../includes/db_connect.php' => 'database connection'
];

foreach ($files as $file => $description) {
    if (file_exists($file)) {
        if (is_readable($file)) {
            echo "✅ $description: READABLE\n";
        } else {
            echo "❌ $description: NOT READABLE\n";
        }
    } else {
        echo "❌ $description: MISSING\n";
    }
}

echo "\n===========================================\n";
echo "NEXT STEPS:\n";
echo "1. Add remedies admin user to members table\n";
echo "2. Configure email/SMS settings in config\n";
echo "3. Set up cron jobs for automated tasks\n";
echo "4. Test booking and store functionality\n";
echo "5. Train staff on admin panel usage\n";
echo "===========================================\n";

echo "</pre>";
?>