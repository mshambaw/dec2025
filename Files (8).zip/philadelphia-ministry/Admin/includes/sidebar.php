<a href="reports.php" class="d-block text-white mb-2">
    <i class="fas fa-chart-bar me-2"></i>Reports
</a>