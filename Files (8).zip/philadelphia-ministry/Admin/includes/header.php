<?php
// admin/includes/header.php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - <?php echo $page_title ?? 'Philadelphia Ministry'; ?></title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- DataTables CSS (conditionally included) -->
    <?php if (isset($include_datatables) && $include_datatables === true): ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <?php endif; ?>
    
    <!-- Custom Admin Styles -->
    <style>
        :root {
            --primary-color: #1a5276;
            --secondary-color: #2c3e50;
            --accent-color: #e67e22;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7fa;
            font-size: 0.95rem;
        }
        
        /* Navbar Styles */
        .navbar-admin {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 0.8rem 1rem;
        }
        
        .navbar-brand-admin {
            font-weight: 700;
            font-size: 1.3rem;
        }
        
        /* Sidebar Styles */
        .sidebar-wrapper {
            background: white;
            border-right: 1px solid #dee2e6;
            min-height: calc(100vh - 70px);
            box-shadow: 1px 0 5px rgba(0,0,0,0.05);
        }
        
        .sidebar-header {
            padding: 1.5rem 1rem;
            border-bottom: 1px solid #dee2e6;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
        }
        
        .sidebar-menu {
            padding: 1rem 0;
        }
        
        .nav-link-sidebar {
            color: #495057;
            padding: 0.75rem 1.5rem;
            margin: 0.2rem 0.5rem;
            border-radius: 8px;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .nav-link-sidebar:hover {
            background-color: rgba(26, 82, 118, 0.1);
            color: var(--primary-color);
            transform: translateX(5px);
        }
        
        .nav-link-sidebar.active {
            background-color: var(--primary-color);
            color: white;
            box-shadow: 0 4px 12px rgba(26, 82, 118, 0.2);
        }
        
        .nav-link-sidebar i {
            width: 20px;
            text-align: center;
            margin-right: 10px;
        }
        
        /* Main Content Area */
        .main-content {
            padding: 1.5rem;
            background-color: #f8f9fa;
            min-height: calc(100vh - 70px);
        }
        
        .content-header {
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #dee2e6;
        }
        
        /* Card Styles */
        .admin-card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            transition: transform 0.3s ease;
            margin-bottom: 1.5rem;
        }
        
        .admin-card:hover {
            transform: translateY(-5px);
        }
        
        .card-header-admin {
            background: linear-gradient(135deg, var(--primary-color) 0%, #2c3e50 100%);
            color: white;
            border-radius: 12px 12px 0 0 !important;
            padding: 1rem 1.5rem;
            font-weight: 600;
            border: none;
        }
        
        /* Button Styles */
        .btn-admin {
            border-radius: 8px;
            padding: 0.5rem 1.5rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .btn-admin-primary {
            background: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-admin-primary:hover {
            background: #154360;
            border-color: #154360;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(26, 82, 118, 0.3);
        }
        
        /* Table Styles */
        .admin-table {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .admin-table th {
            background-color: #f8f9fa;
            border-bottom: 2px solid var(--primary-color);
            font-weight: 600;
            color: var(--secondary-color);
            padding: 1rem;
        }
        
        .admin-table td {
            padding: 0.75rem 1rem;
            vertical-align: middle;
        }
        
        /* Badge Styles */
        .badge-admin {
            padding: 0.4em 0.8em;
            font-size: 0.85em;
            font-weight: 500;
            border-radius: 20px;
        }
        
        /* Footer Styles */
        .footer {
            background: white;
            border-top: 1px solid #dee2e6;
            margin-top: auto;
        }
        
        /* Responsive Adjustments */
        @media (max-width: 768px) {
            .sidebar-wrapper {
                min-height: auto;
                border-right: none;
                border-bottom: 1px solid #dee2e6;
            }
            
            .main-content {
                padding: 1rem;
            }
            
            .navbar-brand-admin {
                font-size: 1.1rem;
            }
        }
        
        /* Animation for alerts */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .alert-animated {
            animation: fadeIn 0.3s ease;
        }
        
        /* Loading spinner */
        .spinner-admin {
            color: var(--primary-color);
        }
    </style>
    
    <!-- Page-specific CSS -->
    <?php if (isset($page_styles)): ?>
        <style><?php echo $page_styles; ?></style>
    <?php endif; ?>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-admin">
        <div class="container-fluid">
            <!-- Brand/Logo -->
            <a class="navbar-brand navbar-brand-admin" href="dashboard.php">
                <i class="fas fa-church me-2"></i>
                Philadelphia Ministry
                <small class="opacity-75 ms-2 d-none d-md-inline">Admin Panel</small>
            </a>
            
            <!-- Mobile Toggle Button -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <!-- Navbar Links -->
            <div class="collapse navbar-collapse" id="adminNavbar">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i>
                            <?php echo htmlspecialchars($_SESSION['admin_name'] ?? 'Administrator'); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php">
                                <i class="fas fa-user me-2"></i>My Profile
                            </a></li>
                            <li><a class="dropdown-item" href="settings.php">
                                <i class="fas fa-cog me-2"></i>Settings
                            </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php">
                                <i class="fas fa-sign-out-alt me-2"></i>Logout
                            </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <!-- Main Container -->
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-lg-2 col-md-3 px-0 d-print-none">
                <div class="sidebar-wrapper">
                    <!-- Sidebar Header -->
                    <div class="sidebar-header">
                        <div class="text-center">
                            <div class="mb-2">
                                <i class="fas fa-user-shield fa-2x text-primary"></i>
                            </div>
                            <h6 class="mb-0">Administrator</h6>
                            <small class="text-muted">Full Access</small>
                        </div>
                    </div>
                    
                    <!-- Sidebar Menu -->
                    <div class="sidebar-menu">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link nav-link-sidebar <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>" 
                                   href="dashboard.php">
                                    <i class="fas fa-tachometer-alt"></i>
                                    Dashboard
                                </a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link nav-link-sidebar <?php echo basename($_SERVER['PHP_SELF']) == 'registrations.php' ? 'active' : ''; ?>" 
                                   href="registrations.php">
                                    <i class="fas fa-user-plus"></i>
                                    Registrations
                                    <span class="badge bg-primary badge-admin float-end mt-1" id="reg-count">
                                        <?php
                                        // Quick registration count
                                        try {
                                            require_once '../config/database.php';
                                            $db = new Database();
                                            $conn = $db->getConnection();
                                            $count = $conn->query("SELECT COUNT(*) as cnt FROM event_registrations")->fetch()['cnt'];
                                            echo $count;
                                        } catch(Exception $e) {
                                            echo '0';
                                        }
                                        ?>
                                    </span>
                                </a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link nav-link-sidebar <?php echo basename($_SERVER['PHP_SELF']) == 'events_admin.php' ? 'active' : ''; ?>" 
                                   href="events_admin.php">
                                    <i class="fas fa-calendar-alt"></i>
                                    Events
                                </a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link nav-link-sidebar <?php echo basename($_SERVER['PHP_SELF']) == 'members.php' ? 'active' : ''; ?>" 
                                   href="members.php">
                                    <i class="fas fa-users"></i>
                                    Members
                                </a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link nav-link-sidebar" href="../index.php" target="_blank">
                                    <i class="fas fa-external-link-alt"></i>
                                    View Site
                                </a>
                            </li>
                            
                            <li class="nav-item mt-3">
                                <div class="px-3">
                                    <small class="text-muted text-uppercase">Tools</small>
                                </div>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link nav-link-sidebar" href="reports.php">
                                    <i class="fas fa-chart-bar"></i>
                                    Reports
                                </a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link nav-link-sidebar" href="backup.php">
                                    <i class="fas fa-database"></i>
                                    Backup
                                </a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link nav-link-sidebar" href="settings.php">
                                    <i class="fas fa-cogs"></i>
                                    Settings
                                </a>
                            </li>
                        </ul>
                    </div>
                    
                    <!-- Sidebar Footer -->
                    <div class="sidebar-footer mt-auto p-3 border-top">
                        <div class="text-center">
                            <small class="text-muted">
                                <i class="fas fa-server me-1"></i>
                                Server Time: <?php echo date('H:i:s'); ?>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Main Content Area -->
            <div class="col-lg-10 col-md-9 px-0">
                <div class="main-content">