<?php
// admin/includes/header_simple.php - NO DATABASE CALLS
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Philadelphia Ministry</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom Admin CSS -->
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        .navbar {
            background: #1a5276 !important;
        }
        
        .sidebar {
            background: #2c3e50;
            min-height: 100vh;
            color: white;
        }
        
        .sidebar a {
            color: #ddd;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
            border-left: 3px solid transparent;
        }
        
        .sidebar a:hover, .sidebar a.active {
            background: rgba(255,255,255,0.1);
            border-left-color: #1a5276;
            color: white;
        }
        
        .main-content {
            padding: 20px;
        }
    </style>
</head>
<body>
    <!-- Simple Navbar -->
    <nav class="navbar navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-church me-2"></i>
                Philadelphia Ministry Admin
            </a>
            <div class="navbar-text text-white">
                Welcome, <?php echo $_SESSION['admin_name'] ?? 'Admin'; ?>
                | <a href="logout.php" class="text-warning">Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container-fluid">
        <div class="row">
            <!-- Simple Sidebar -->
            <div class="col-md-3 col-lg-2 px-0">
                <div class="sidebar p-3">
                    <h5 class="mb-3">Navigation</h5>
                    <a href="dashboard.php" class="mb-2">
                        <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                    </a>
                    <a href="registrations.php" class="mb-2 active">
                        <i class="fas fa-user-plus me-2"></i>Registrations
                    </a>
                    <a href="events_admin.php" class="mb-2">
                        <i class="fas fa-calendar-alt me-2"></i>Events
                    </a>
                    <a href="../index.php" target="_blank" class="mb-2">
                        <i class="fas fa-external-link-alt me-2"></i>View Site
                    </a>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 px-4 py-3">