<?php
// admin/members.php - FIXED SIMPLE VERSION
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit();
}

// Simple database connection
function connectDB() {
    $host = 'localhost';
    $dbname = 'philadelphia_ministry';
    $username = 'root';
    $password = '';
    
    try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch(PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
}

$conn = connectDB();

// Handle add member
if(isset($_POST['action']) && $_POST['action'] == 'add') {
    $member_id = 'PM' . date('Y') . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
    
    // FIXED: Use first_name and last_name instead of full_name
    $stmt = $conn->prepare("INSERT INTO members (membership_number, first_name, last_name, phone, gender, year_group, registration_date) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $member_id,
        $_POST['first_name'],
        $_POST['last_name'],
        $_POST['phone'],
        $_POST['gender'],
        $_POST['year_group'],
        date('Y-m-d')
    ]);
    
    $success = "Member added successfully! ID: " . $member_id;
}

// Get all members - FIXED: Use CONCAT for full name
$search = isset($_GET['search']) ? $_GET['search'] : '';
$year_group = isset($_GET['year_group']) ? $_GET['year_group'] : '';

// FIXED: Use CONCAT to combine first_name and last_name
$query = "SELECT *, CONCAT(first_name, ' ', last_name) as full_name FROM members WHERE 1=1";
$params = [];

if($search) {
    $query .= " AND (first_name LIKE ? OR last_name LIKE ? OR phone LIKE ? OR membership_number LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

if($year_group) {
    $query .= " AND year_group = ?";
    $params[] = $year_group;
}

// FIXED: Order by first_name instead of full_name
$query .= " ORDER BY first_name, last_name";

$stmt = $conn->prepare($query);
$stmt->execute($params);
$members = $stmt->fetchAll();
$total_members = count($members);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Members Management - Philadelphia Ministry</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body { background-color: #f8f9fa; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .navbar { background: linear-gradient(135deg, #1a5276 0%, #2c3e50 100%); }
        .main-content { padding: 25px; }
        .table th { background-color: #f8f9fa; border-bottom: 2px solid #1a5276; }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-church me-2"></i>
                Philadelphia Ministry - Members
            </a>
            <div class="navbar-text text-white">
                <a href="dashboard.php" class="text-white text-decoration-none me-3">Dashboard</a>
                | <a href="logout.php" class="text-warning text-decoration-none">Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container-fluid">
        <div class="row">
            <!-- Simple Sidebar -->
            <div class="col-md-3 col-lg-2 px-0">
                <div class="bg-dark text-white p-3" style="min-height: calc(100vh - 56px);">
                    <h5 class="mb-4">Navigation</h5>
                    <a href="dashboard.php" class="d-block text-white mb-2">Dashboard</a>
                    <a href="registrations.php" class="d-block text-white mb-2">Registrations</a>
                    <a href="members.php" class="d-block text-white mb-2 text-primary">Members</a>
                    <a href="events_admin.php" class="d-block text-white mb-2">Events</a>
                    <hr class="bg-light">
                    <a href="../index.php" target="_blank" class="d-block text-white mb-2">View Site</a>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 px-0">
                <div class="main-content">
                    <h2 class="mb-4"><i class="fas fa-users me-2"></i>Members (<?php echo $total_members; ?>)</h2>
                    
                    <?php if(isset($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    
                    <!-- Search and Add -->
                    <div class="row mb-4">
                        <div class="col-md-8">
                            <form method="GET" class="input-group">
                                <input type="text" class="form-control" name="search" placeholder="Search by name, phone, or member ID..." value="<?php echo htmlspecialchars($search); ?>">
                                <button class="btn btn-primary" type="submit">
                                    <i class="fas fa-search me-2"></i>Search
                                </button>
                            </form>
                        </div>
                        <div class="col-md-4 text-end">
                            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addModal">
                                <i class="fas fa-plus me-2"></i>Add Member
                            </button>
                        </div>
                    </div>
                    
                    <!-- Members Table -->
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Member ID</th>
                                            <th>Name</th>
                                            <th>Phone</th>
                                            <th>Year Group</th>
                                            <th>Gender</th>
                                            <th>Joined</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(count($members) > 0): ?>
                                            <?php foreach($members as $member): ?>
                                            <tr>
                                                <td>
                                                    <span class="badge bg-secondary">
                                                        <?php echo htmlspecialchars($member['membership_number'] ?? 'N/A'); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo htmlspecialchars($member['full_name'] ?? $member['first_name'] . ' ' . $member['last_name']); ?></td>
                                                <td><?php echo htmlspecialchars($member['phone'] ?? ''); ?></td>
                                                <td>
                                                    <?php if(!empty($member['year_group'])): ?>
                                                        <span class="badge bg-info"><?php echo htmlspecialchars($member['year_group']); ?></span>
                                                    <?php else: ?>
                                                        <span class="text-muted">N/A</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo htmlspecialchars($member['gender'] ?? ''); ?></td>
                                                <td>
                                                    <?php if(!empty($member['registration_date'])): ?>
                                                        <?php echo date('M d, Y', strtotime($member['registration_date'])); ?>
                                                    <?php else: ?>
                                                        <span class="text-muted">N/A</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <button class="btn btn-sm btn-primary me-1">
                                                        <i class="fas fa-eye"></i>
                                                    </button>
                                                    <button class="btn btn-sm btn-warning">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="7" class="text-center py-4">
                                                    <i class="fas fa-user-slash fa-2x text-muted mb-3"></i>
                                                    <h5 class="text-muted">No Members Found</h5>
                                                    <p class="text-muted">Add your first member using the "Add Member" button.</p>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Add Modal -->
    <div class="modal fade" id="addModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">Add New Member</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">First Name *</label>
                                <input type="text" name="first_name" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Last Name *</label>
                                <input type="text" name="last_name" class="form-control" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Phone *</label>
                            <input type="tel" name="phone" class="form-control" required>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Gender *</label>
                                <select name="gender" class="form-select" required>
                                    <option value="">Select Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Year Group</label>
                                <select name="year_group" class="form-select">
                                    <option value="">Select Year Group</option>
                                    <option value="Year 1">Year 1</option>
                                    <option value="Year 2">Year 2</option>
                                    <option value="Year 3">Year 3</option>
                                    <option value="Year 4">Year 4</option>
                                    <option value="Continuing">Continuing</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save Member</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Auto-focus first name field when modal opens
        document.getElementById('addModal').addEventListener('shown.bs.modal', function () {
            document.querySelector('input[name="first_name"]').focus();
        });
    </script>
</body>
</html>