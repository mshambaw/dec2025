<?php
// admin/reports.php - Simple Reports Page
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit();
}

// Simple database connection
function connectDB() {
    $host = 'localhost';
    $dbname = 'philadelphia_ministry';
    $username = 'root';
    $password = '';
    
    try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch(PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
}

$conn = connectDB();

// Get date range
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');

// Get statistics
$stats = [];

// Total members
$stmt = $conn->query("SELECT COUNT(*) as total FROM members WHERE is_active = 1");
$stats['total_members'] = $stmt->fetch()['total'];

// New members this month
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM members WHERE registration_date >= ?");
$stmt->execute([date('Y-m-01')]);
$stats['new_members_month'] = $stmt->fetch()['total'];

// Total registrations
$stmt = $conn->query("SELECT COUNT(*) as total FROM event_registrations");
$stats['total_registrations'] = $stmt->fetch()['total'];

// Recent registrations (last 30 days)
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM event_registrations WHERE registration_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
$stmt->execute();
$stats['recent_registrations'] = $stmt->fetch()['total'];

// Total events
$stmt = $conn->query("SELECT COUNT(*) as total FROM ministry_events");
$stats['total_events'] = $stmt->fetch()['total'];

// Upcoming events
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM ministry_events WHERE start_date >= CURDATE()");
$stmt->execute();
$stats['upcoming_events'] = $stmt->fetch()['total'];

// Get event registrations by event
$stmt = $conn->prepare("
    SELECT e.title, COUNT(r.id) as registrations, 
           e.start_date, e.location
    FROM ministry_events e
    LEFT JOIN event_registrations r ON e.id = r.event_id
    WHERE e.start_date BETWEEN ? AND ?
    GROUP BY e.id
    ORDER BY e.start_date
");
$stmt->execute([$start_date, $end_date]);
$event_registrations = $stmt->fetchAll();

// Get members by year group
$stmt = $conn->query("
    SELECT year_group, COUNT(*) as count 
    FROM members 
    WHERE is_active = 1 AND year_group IS NOT NULL AND year_group != ''
    GROUP BY year_group
    ORDER BY year_group
");
$members_by_year = $stmt->fetchAll();

// Get registration trends (last 6 months)
$stmt = $conn->prepare("
    SELECT DATE_FORMAT(registration_date, '%Y-%m') as month,
           COUNT(*) as registrations
    FROM event_registrations
    WHERE registration_date >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(registration_date, '%Y-%m')
    ORDER BY month
");
$stmt->execute();
$registration_trends = $stmt->fetchAll();

// Get payment status summary
$stmt = $conn->query("
    SELECT payment_status, COUNT(*) as count 
    FROM event_registrations 
    GROUP BY payment_status
");
$payment_summary = $stmt->fetchAll();

// Get gender distribution
$stmt = $conn->query("
    SELECT gender, COUNT(*) as count 
    FROM members 
    WHERE gender IS NOT NULL AND gender != ''
    GROUP BY gender
");
$gender_distribution = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Philadelphia Ministry</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Chart.js for graphs -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        body { background-color: #f8f9fa; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .navbar { background: linear-gradient(135deg, #1a5276 0%, #2c3e50 100%); }
        .main-content { padding: 25px; }
        .stat-card { border-radius: 12px; border: none; box-shadow: 0 4px 15px rgba(0,0,0,0.08); margin-bottom: 1.5rem; }
        .stat-card .card-body { padding: 1.5rem; }
        .stat-number { font-size: 2.5rem; font-weight: bold; margin-bottom: 0.5rem; }
        .stat-label { color: #6c757d; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 1px; }
        .chart-container { height: 300px; margin-bottom: 2rem; }
        .report-section { margin-bottom: 3rem; }
        .table th { background-color: #f8f9fa; border-bottom: 2px solid #1a5276; }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-church me-2"></i>
                Philadelphia Ministry - Reports
            </a>
            <div class="navbar-text text-white">
                <a href="dashboard.php" class="text-white text-decoration-none me-3">Dashboard</a>
                | <a href="logout.php" class="text-warning text-decoration-none">Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container-fluid">
        <div class="row">
            <!-- Simple Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 d-print-none">
                <div class="bg-dark text-white p-3" style="min-height: calc(100vh - 56px);">
                    <h5 class="mb-4">Navigation</h5>
                    <a href="dashboard.php" class="d-block text-white mb-2">Dashboard</a>
                    <a href="registrations.php" class="d-block text-white mb-2">Registrations</a>
                    <a href="members.php" class="d-block text-white mb-2">Members</a>
                    <a href="events_admin.php" class="d-block text-white mb-2">Events</a>
                    <a href="reports.php" class="d-block text-white mb-2 text-primary">Reports</a>
                    <hr class="bg-light">
                    <a href="../index.php" target="_blank" class="d-block text-white mb-2">View Site</a>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 px-0">
                <div class="main-content">
                    <!-- Page Header -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div>
                            <h2 class="mb-1"><i class="fas fa-chart-bar text-primary me-2"></i>Reports & Analytics</h2>
                            <p class="text-muted mb-0">Ministry performance and statistics</p>
                        </div>
                        <div>
                            <button class="btn btn-success" onclick="window.print()">
                                <i class="fas fa-print me-2"></i>Print Report
                            </button>
                            <button class="btn btn-primary" onclick="exportReport()">
                                <i class="fas fa-download me-2"></i>Export
                            </button>
                        </div>
                    </div>
                    
                    <!-- Date Range Filter -->
                    <div class="card stat-card mb-4">
                        <div class="card-body">
                            <h5 class="card-title mb-3"><i class="fas fa-calendar-alt me-2"></i>Date Range</h5>
                            <form method="GET" class="row g-3">
                                <div class="col-md-4">
                                    <label class="form-label">Start Date</label>
                                    <input type="date" class="form-control" name="start_date" value="<?php echo $start_date; ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">End Date</label>
                                    <input type="date" class="form-control" name="end_date" value="<?php echo $end_date; ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">&nbsp;</label>
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="fas fa-filter me-2"></i>Apply Filter
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <!-- Summary Statistics -->
                    <div class="report-section">
                        <h4 class="mb-4"><i class="fas fa-chart-pie me-2"></i>Summary Statistics</h4>
                        <div class="row">
                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="stat-card bg-primary text-white">
                                    <div class="card-body text-center">
                                        <div class="stat-number"><?php echo $stats['total_members']; ?></div>
                                        <div class="stat-label">Total Members</div>
                                        <div class="small mt-2">
                                            <i class="fas fa-user-plus me-1"></i>
                                            +<?php echo $stats['new_members_month']; ?> this month
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="stat-card bg-success text-white">
                                    <div class="card-body text-center">
                                        <div class="stat-number"><?php echo $stats['total_registrations']; ?></div>
                                        <div class="stat-label">Total Registrations</div>
                                        <div class="small mt-2">
                                            <i class="fas fa-chart-line me-1"></i>
                                            +<?php echo $stats['recent_registrations']; ?> recent
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="stat-card bg-info text-white">
                                    <div class="card-body text-center">
                                        <div class="stat-number"><?php echo $stats['total_events']; ?></div>
                                        <div class="stat-label">Total Events</div>
                                        <div class="small mt-2">
                                            <i class="fas fa-calendar me-1"></i>
                                            <?php echo $stats['upcoming_events']; ?> upcoming
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="stat-card bg-warning text-white">
                                    <div class="card-body text-center">
                                        <div class="stat-number">
                                            <?php 
                                            if($stats['total_members'] > 0) {
                                                echo round(($stats['total_registrations'] / $stats['total_members']) * 100, 1);
                                            } else {
                                                echo '0';
                                            }
                                            ?>%
                                        </div>
                                        <div class="stat-label">Participation Rate</div>
                                        <div class="small mt-2">
                                            <i class="fas fa-percentage me-1"></i>
                                            Member engagement
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Charts -->
                    <div class="row report-section">
                        <div class="col-lg-6 mb-4">
                            <div class="card stat-card">
                                <div class="card-body">
                                    <h5 class="card-title"><i class="fas fa-chart-line me-2"></i>Registration Trends (Last 6 Months)</h5>
                                    <div class="chart-container">
                                        <canvas id="registrationTrendsChart"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-lg-6 mb-4">
                            <div class="card stat-card">
                                <div class="card-body">
                                    <h5 class="card-title"><i class="fas fa-users me-2"></i>Members by Year Group</h5>
                                    <div class="chart-container">
                                        <canvas id="yearGroupChart"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Event Registrations Report -->
                    <div class="report-section">
                        <h4 class="mb-4"><i class="fas fa-calendar-check me-2"></i>Event Registrations</h4>
                        <div class="card stat-card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Event</th>
                                                <th>Date</th>
                                                <th>Location</th>
                                                <th>Registrations</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if(count($event_registrations) > 0): ?>
                                                <?php foreach($event_registrations as $event): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($event['title']); ?></td>
                                                    <td><?php echo date('M d, Y', strtotime($event['start_date'])); ?></td>
                                                    <td><?php echo htmlspecialchars($event['location']); ?></td>
                                                    <td>
                                                        <span class="badge bg-primary"><?php echo $event['registrations']; ?></span>
                                                    </td>
                                                    <td>
                                                        <?php 
                                                        $event_date = strtotime($event['start_date']);
                                                        $today = time();
                                                        if($event_date > $today) {
                                                            echo '<span class="badge bg-success">Upcoming</span>';
                                                        } elseif($event_date == $today) {
                                                            echo '<span class="badge bg-warning">Today</span>';
                                                        } else {
                                                            echo '<span class="badge bg-secondary">Past</span>';
                                                        }
                                                        ?>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            <?php else: ?>
                                                <tr>
                                                    <td colspan="5" class="text-center py-4">
                                                        <i class="fas fa-calendar-times fa-2x text-muted mb-3"></i>
                                                        <p class="text-muted">No events found in the selected date range.</p>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Detailed Statistics -->
                    <div class="row report-section">
                        <div class="col-md-6 mb-4">
                            <div class="card stat-card">
                                <div class="card-body">
                                    <h5 class="card-title"><i class="fas fa-credit-card me-2"></i>Payment Status Summary</h5>
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <tbody>
                                                <?php foreach($payment_summary as $payment): ?>
                                                <tr>
                                                    <td><?php echo ucfirst($payment['payment_status']); ?></td>
                                                    <td class="text-end">
                                                        <span class="badge bg-secondary"><?php echo $payment['count']; ?></span>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-4">
                            <div class="card stat-card">
                                <div class="card-body">
                                    <h5 class="card-title"><i class="fas fa-venus-mars me-2"></i>Gender Distribution</h5>
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <tbody>
                                                <?php foreach($gender_distribution as $gender): ?>
                                                <tr>
                                                    <td><?php echo $gender['gender']; ?></td>
                                                    <td class="text-end">
                                                        <span class="badge bg-info"><?php echo $gender['count']; ?></span>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Quick Insights -->
                    <div class="report-section">
                        <h4 class="mb-4"><i class="fas fa-lightbulb me-2"></i>Quick Insights</h4>
                        <div class="card stat-card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="d-flex mb-3">
                                            <div class="flex-shrink-0">
                                                <i class="fas fa-calendar-alt fa-2x text-primary"></i>
                                            </div>
                                            <div class="flex-grow-1 ms-3">
                                                <h6>Most Active Month</h6>
                                                <p class="text-muted mb-0">
                                                    <?php 
                                                    if(count($registration_trends) > 0) {
                                                        $max = max(array_column($registration_trends, 'registrations'));
                                                        foreach($registration_trends as $trend) {
                                                            if($trend['registrations'] == $max) {
                                                                echo date('F Y', strtotime($trend['month'] . '-01')) . ' (' . $max . ' registrations)';
                                                                break;
                                                            }
                                                        }
                                                    } else {
                                                        echo 'No data available';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="d-flex mb-3">
                                            <div class="flex-shrink-0">
                                                <i class="fas fa-users fa-2x text-success"></i>
                                            </div>
                                            <div class="flex-grow-1 ms-3">
                                                <h6>Largest Year Group</h6>
                                                <p class="text-muted mb-0">
                                                    <?php 
                                                    if(count($members_by_year) > 0) {
                                                        $max = max(array_column($members_by_year, 'count'));
                                                        foreach($members_by_year as $group) {
                                                            if($group['count'] == $max) {
                                                                echo $group['year_group'] . ' (' . $max . ' members)';
                                                                break;
                                                            }
                                                        }
                                                    } else {
                                                        echo 'No data available';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="d-flex mb-3">
                                            <div class="flex-shrink-0">
                                                <i class="fas fa-chart-line fa-2x text-warning"></i>
                                            </div>
                                            <div class="flex-grow-1 ms-3">
                                                <h6>Growth Rate</h6>
                                                <p class="text-muted mb-0">
                                                    <?php 
                                                    if(count($registration_trends) >= 2) {
                                                        $current = end($registration_trends)['registrations'];
                                                        $previous = prev($registration_trends)['registrations'];
                                                        if($previous > 0) {
                                                            $growth = (($current - $previous) / $previous) * 100;
                                                            echo round($growth, 1) . '% from last month';
                                                        } else {
                                                            echo 'New growth started';
                                                        }
                                                    } else {
                                                        echo 'Insufficient data for growth analysis';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="d-flex mb-3">
                                            <div class="flex-shrink-0">
                                                <i class="fas fa-check-circle fa-2x text-info"></i>
                                            </div>
                                            <div class="flex-grow-1 ms-3">
                                                <h6>Completion Rate</h6>
                                                <p class="text-muted mb-0">
                                                    <?php 
                                                    foreach($payment_summary as $payment) {
                                                        if($payment['payment_status'] == 'paid') {
                                                            $paid = $payment['count'];
                                                            break;
                                                        }
                                                    }
                                                    $total_paid = $paid ?? 0;
                                                    if($stats['total_registrations'] > 0) {
                                                        $completion_rate = ($total_paid / $stats['total_registrations']) * 100;
                                                        echo round($completion_rate, 1) . '% of registrations paid';
                                                    } else {
                                                        echo 'No payment data available';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Report Footer -->
                    <div class="text-center text-muted mt-5 pt-4 border-top">
                        <p>
                            <i class="fas fa-clock me-1"></i>
                            Report generated on <?php echo date('F d, Y \a\t H:i:s'); ?>
                        </p>
                        <p class="small">
                            <i class="fas fa-database me-1"></i>
                            Data Source: Philadelphia Ministry Database
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Registration Trends Chart
        const trendsCtx = document.getElementById('registrationTrendsChart').getContext('2d');
        const trendsChart = new Chart(trendsCtx, {
            type: 'line',
            data: {
                labels: [
                    <?php foreach($registration_trends as $trend): ?>
                    '<?php echo date('M Y', strtotime($trend['month'] . '-01')); ?>',
                    <?php endforeach; ?>
                ],
                datasets: [{
                    label: 'Registrations',
                    data: [
                        <?php foreach($registration_trends as $trend): ?>
                        <?php echo $trend['registrations']; ?>,
                        <?php endforeach; ?>
                    ],
                    borderColor: '#1a5276',
                    backgroundColor: 'rgba(26, 82, 118, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            display: true
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
        
        // Year Group Chart
        const yearCtx = document.getElementById('yearGroupChart').getContext('2d');
        const yearChart = new Chart(yearCtx, {
            type: 'doughnut',
            data: {
                labels: [
                    <?php foreach($members_by_year as $group): ?>
                    '<?php echo $group['year_group']; ?>',
                    <?php endforeach; ?>
                ],
                datasets: [{
                    data: [
                        <?php foreach($members_by_year as $group): ?>
                        <?php echo $group['count']; ?>,
                        <?php endforeach; ?>
                    ],
                    backgroundColor: [
                        '#1a5276', '#2c3e50', '#3498db', '#2ecc71', '#e67e22',
                        '#9b59b6', '#34495e', '#16a085', '#f39c12', '#d35400'
                    ],
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    }
                }
            }
        });
        
        // Export Report Function
        function exportReport() {
            const printWindow = window.open('', '_blank');
            printWindow.document.write(`
                <html>
                <head>
                    <title>Philadelphia Ministry Report - <?php echo date('Y-m-d'); ?></title>
                    <style>
                        body { font-family: Arial, sans-serif; padding: 20px; }
                        h1 { color: #1a5276; }
                        .report-header { margin-bottom: 30px; }
                        .stat-box { display: inline-block; margin: 10px; padding: 15px; background: #f8f9fa; border-radius: 8px; }
                        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                        th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
                        th { background-color: #f8f9fa; }
                        .footer { margin-top: 50px; text-align: center; color: #666; }
                    </style>
                </head>
                <body>
                    <div class="report-header">
                        <h1>Philadelphia Ministry Report</h1>
                        <p>Generated on: <?php echo date('F d, Y \a\t H:i:s'); ?></p>
                        <p>Date Range: <?php echo date('M d, Y', strtotime($start_date)); ?> to <?php echo date('M d, Y', strtotime($end_date)); ?></p>
                    </div>
                    
                    <h3>Summary Statistics</h3>
                    <div class="stat-box">Total Members: <?php echo $stats['total_members']; ?></div>
                    <div class="stat-box">Total Registrations: <?php echo $stats['total_registrations']; ?></div>
                    <div class="stat-box">Total Events: <?php echo $stats['total_events']; ?></div>
                    
                    <h3>Event Registrations</h3>
                    <table>
                        <tr>
                            <th>Event</th>
                            <th>Date</th>
                            <th>Registrations</th>
                            <th>Status</th>
                        </tr>
                        <?php foreach($event_registrations as $event): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($event['title']); ?></td>
                            <td><?php echo date('M d, Y', strtotime($event['start_date'])); ?></td>
                            <td><?php echo $event['registrations']; ?></td>
                            <td><?php echo strtotime($event['start_date']) > time() ? 'Upcoming' : 'Past'; ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                    
                    <div class="footer">
                        <p>© <?php echo date('Y'); ?> Philadelphia Ministry. All rights reserved.</p>
                    </div>
                </body>
                </html>
            `);
            printWindow.document.close();
            printWindow.print();
        }
        
        // Auto-refresh page every 5 minutes
        setTimeout(function() {
            window.location.reload();
        }, 300000);
    </script>
</body>
</html>