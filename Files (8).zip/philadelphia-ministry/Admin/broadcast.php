<?php
// admin/broadcast.php - FIXED VERSION
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit();
}

// Simple database connection
function connectDB() {
    $host = 'localhost';
    $dbname = 'philadelphia_ministry';
    $username = 'root';
    $password = '';
    
    try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch(PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
}

$conn = connectDB();

// Handle broadcast submission
$success = $error = '';
if(isset($_POST['action']) && $_POST['action'] == 'send_broadcast') {
    $broadcast_type = $_POST['broadcast_type'];
    $message = trim($_POST['message']);
    $recipient_type = $_POST['recipient_type'];
    $year_group = $_POST['year_group'] ?? '';
    $event_id = $_POST['event_id'] ?? '';
    
    if(empty($message)) {
        $error = "Please enter a message to send.";
    } else {
        // Get recipients based on selection
        $recipients = [];
        
        if($recipient_type == 'all') {
            // All active members
            $stmt = $conn->query("SELECT id, first_name, last_name, phone, email FROM members WHERE is_active = 1");
            $recipients = $stmt->fetchAll();
        } 
        elseif($recipient_type == 'year_group' && $year_group) {
            // Specific year group
            $stmt = $conn->prepare("SELECT id, first_name, last_name, phone, email FROM members WHERE is_active = 1 AND year_group = ?");
            $stmt->execute([$year_group]);
            $recipients = $stmt->fetchAll();
        }
        elseif($recipient_type == 'event' && $event_id) {
            // Event registrants
            $stmt = $conn->prepare("
                SELECT m.id, m.first_name, m.last_name, m.phone, m.email 
                FROM members m
                JOIN event_registrations r ON m.id = r.member_id
                WHERE r.event_id = ?
            ");
            $stmt->execute([$event_id]);
            $recipients = $stmt->fetchAll();
        }
        
        $recipient_count = count($recipients);
        
        if($recipient_count > 0) {
            // Save broadcast log - FIXED: Use NULL for empty values
            $stmt = $conn->prepare("
                INSERT INTO broadcast_logs 
                (broadcast_type, message, recipient_type, recipient_count, year_group, event_id, sent_by, sent_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            
            // Convert empty strings to NULL for foreign key
            $year_group_value = (!empty($year_group)) ? $year_group : NULL;
            $event_id_value = (!empty($event_id)) ? $event_id : NULL;
            
            $stmt->execute([
                $broadcast_type,
                $message,
                $recipient_type,
                $recipient_count,
                $year_group_value,  // NULL if empty
                $event_id_value,    // NULL if empty
                $_SESSION['admin_name'] ?? 'Admin'
            ]);
            
            $broadcast_id = $conn->lastInsertId();
            
            $success = "Broadcast prepared! Ready to send to {$recipient_count} recipients.";
            
            // Store in session for confirmation
            $_SESSION['pending_broadcast'] = [
                'id' => $broadcast_id,
                'type' => $broadcast_type,
                'message' => $message,
                'recipient_count' => $recipient_count,
                'recipients' => $recipients
            ];
            
        } else {
            $error = "No recipients found for the selected criteria.";
        }
    }
}

// Handle actual sending (confirmation)
if(isset($_POST['action']) && $_POST['action'] == 'confirm_send') {
    if(isset($_SESSION['pending_broadcast'])) {
        $broadcast = $_SESSION['pending_broadcast'];
        
        // Update broadcast log status
        $stmt = $conn->prepare("UPDATE broadcast_logs SET status = 'sent', sent_at = NOW() WHERE id = ?");
        $stmt->execute([$broadcast['id']]);
        
        $success = "✅ Broadcast sent successfully to {$broadcast['recipient_count']} recipients!";
        unset($_SESSION['pending_broadcast']);
    }
}

// Get year groups for dropdown
$stmt = $conn->query("SELECT DISTINCT year_group FROM members WHERE year_group IS NOT NULL AND year_group != '' ORDER BY year_group");
$year_groups = $stmt->fetchAll();

// Get events for dropdown
$stmt = $conn->query("SELECT id, title, start_date FROM ministry_events WHERE start_date >= CURDATE() ORDER BY start_date");
$events = $stmt->fetchAll();

// Get broadcast history
$stmt = $conn->query("SELECT * FROM broadcast_logs ORDER BY sent_at DESC LIMIT 10");
$broadcast_history = $stmt->fetchAll();
?>

<!-- REST OF THE HTML CODE REMAINS THE SAME FROM PREVIOUS VERSION -->
<!-- Only the PHP code above is fixed -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Broadcast - Philadelphia Ministry</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body { background-color: #f8f9fa; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .navbar { background: linear-gradient(135deg, #1a5276 0%, #2c3e50 100%); }
        .main-content { padding: 25px; }
        .stat-card { border-radius: 12px; border: none; box-shadow: 0 4px 15px rgba(0,0,0,0.08); margin-bottom: 1.5rem; }
        .broadcast-type-btn { width: 100%; padding: 15px; margin-bottom: 10px; text-align: left; }
        .message-preview { background: #f8f9fa; border-radius: 8px; padding: 15px; margin-top: 15px; }
        .char-count { font-size: 0.9rem; }
        .sms-char-limit { color: #dc3545; font-weight: bold; }
        .recipient-badge { font-size: 0.8rem; margin-right: 5px; }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-church me-2"></i>
                Philadelphia Ministry - Broadcast
            </a>
            <div class="navbar-text text-white">
                <a href="dashboard.php" class="text-white text-decoration-none me-3">Dashboard</a>
                | <a href="logout.php" class="text-warning text-decoration-none">Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container-fluid">
        <div class="row">
            <!-- Simple Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 d-print-none">
                <div class="bg-dark text-white p-3" style="min-height: calc(100vh - 56px);">
                    <h5 class="mb-4">Navigation</h5>
                    <a href="dashboard.php" class="d-block text-white mb-2">Dashboard</a>
                    <a href="registrations.php" class="d-block text-white mb-2">Registrations</a>
                    <a href="members.php" class="d-block text-white mb-2">Members</a>
                    <a href="events_admin.php" class="d-block text-white mb-2">Events</a>
                    <a href="attendance.php" class="d-block text-white mb-2">Attendance</a>
                    <a href="broadcast.php" class="d-block text-white mb-2 text-primary">Broadcast</a>
                    <a href="reports.php" class="d-block text-white mb-2">Reports</a>
                    <hr class="bg-light">
                    <a href="../index.php" target="_blank" class="d-block text-white mb-2">View Site</a>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 px-0">
                <div class="main-content">
                    <!-- Page Header -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div>
                            <h2 class="mb-1"><i class="fas fa-bullhorn text-primary me-2"></i>Broadcast Messages</h2>
                            <p class="text-muted mb-0">Send SMS & Email notifications to members</p>
                        </div>
                        <div>
                            <span class="badge bg-info">
                                <i class="fas fa-users me-1"></i>
                                Send to members
                            </span>
                        </div>
                    </div>
                    
                    <!-- Success/Error Messages -->
                    <?php if($success): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="fas fa-check-circle me-2"></i>
                            <?php echo $success; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            <?php echo $error; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Broadcast Form -->
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="card stat-card">
                                <div class="card-header bg-primary text-white">
                                    <h5 class="mb-0"><i class="fas fa-envelope me-2"></i>Create Broadcast</h5>
                                </div>
                                <div class="card-body">
                                    <form method="POST" id="broadcastForm">
                                        <input type="hidden" name="action" value="send_broadcast">
                                        
                                        <!-- Broadcast Type -->
                                        <div class="mb-4">
                                            <label class="form-label fw-bold">Select Broadcast Type *</label>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <button type="button" class="btn btn-outline-primary broadcast-type-btn" onclick="selectBroadcastType('sms')">
                                                        <i class="fas fa-sms fa-2x mb-2"></i><br>
                                                        <strong>SMS Broadcast</strong><br>
                                                        <small class="text-muted">Send text messages to phones</small>
                                                    </button>
                                                </div>
                                                <div class="col-md-6">
                                                    <button type="button" class="btn btn-outline-success broadcast-type-btn" onclick="selectBroadcastType('email')">
                                                        <i class="fas fa-envelope fa-2x mb-2"></i><br>
                                                        <strong>Email Broadcast</strong><br>
                                                        <small class="text-muted">Send emails to members</small>
                                                    </button>
                                                </div>
                                            </div>
                                            <input type="hidden" name="broadcast_type" id="broadcastType" value="sms" required>
                                        </div>
                                        
                                        <!-- Recipients -->
                                        <div class="mb-4">
                                            <label class="form-label fw-bold">Select Recipients *</label>
                                            <div class="row">
                                                <div class="col-md-4 mb-3">
                                                    <div class="form-check card p-3">
                                                        <input class="form-check-input" type="radio" name="recipient_type" id="recipientAll" value="all" checked>
                                                        <label class="form-check-label" for="recipientAll">
                                                            <i class="fas fa-users text-primary me-2"></i>
                                                            <strong>All Members</strong><br>
                                                            <small>Send to all active members</small>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <div class="form-check card p-3">
                                                        <input class="form-check-input" type="radio" name="recipient_type" id="recipientYear" value="year_group">
                                                        <label class="form-check-label" for="recipientYear">
                                                            <i class="fas fa-graduation-cap text-info me-2"></i>
                                                            <strong>Year Group</strong><br>
                                                            <small>Send to specific year group</small>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <div class="form-check card p-3">
                                                        <input class="form-check-input" type="radio" name="recipient_type" id="recipientEvent" value="event">
                                                        <label class="form-check-label" for="recipientEvent">
                                                            <i class="fas fa-calendar-check text-success me-2"></i>
                                                            <strong>Event Registrants</strong><br>
                                                            <small>Send to event participants</small>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <!-- Year Group Selection (hidden by default) -->
                                            <div class="mb-3" id="yearGroupSelection" style="display: none;">
                                                <label class="form-label">Select Year Group</label>
                                                <select class="form-select" name="year_group">
                                                    <option value="">Select Year Group</option>
                                                    <?php foreach($year_groups as $group): ?>
                                                        <option value="<?php echo htmlspecialchars($group['year_group']); ?>">
                                                            <?php echo htmlspecialchars($group['year_group']); ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            
                                            <!-- Event Selection (hidden by default) -->
                                            <div class="mb-3" id="eventSelection" style="display: none;">
                                                <label class="form-label">Select Event</label>
                                                <select class="form-select" name="event_id">
                                                    <option value="">Select Event</option>
                                                    <?php foreach($events as $event): ?>
                                                        <option value="<?php echo $event['id']; ?>">
                                                            <?php echo htmlspecialchars($event['title']); ?> 
                                                            (<?php echo date('M d, Y', strtotime($event['start_date'])); ?>)
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        
                                        <!-- Message -->
                                        <div class="mb-4">
                                            <label class="form-label fw-bold">Message *</label>
                                            <textarea class="form-control" name="message" id="message" rows="6" 
                                                      placeholder="Type your message here..." 
                                                      oninput="updateCharCount()" 
                                                      maxlength="1600" required></textarea>
                                            <div class="char-count mt-2">
                                                <span id="charCount">0</span> characters 
                                                <span id="smsCount" class="sms-char-limit" style="display: none;">
                                                    | <span id="smsMessages">0</span> SMS messages
                                                </span>
                                            </div>
                                            
                                            <!-- Message Templates -->
                                            <div class="mt-3">
                                                <label class="form-label">Quick Templates:</label>
                                                <div class="btn-group btn-group-sm">
                                                    <button type="button" class="btn btn-outline-secondary" onclick="insertTemplate('meeting')">
                                                        <i class="fas fa-users"></i> Meeting Reminder
                                                    </button>
                                                    <button type="button" class="btn btn-outline-secondary" onclick="insertTemplate('event')">
                                                        <i class="fas fa-calendar"></i> Event Update
                                                    </button>
                                                    <button type="button" class="btn btn-outline-secondary" onclick="insertTemplate('prayer')">
                                                        <i class="fas fa-pray"></i> Prayer Request
                                                    </button>
                                                    <button type="button" class="btn btn-outline-secondary" onclick="insertTemplate('urgent')">
                                                        <i class="fas fa-exclamation-triangle"></i> Urgent Notice
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Preview -->
                                        <div class="message-preview" id="messagePreview" style="display: none;">
                                            <h6><i class="fas fa-eye me-2"></i>Message Preview</h6>
                                            <div id="previewContent" class="mb-3"></div>
                                            <small class="text-muted">This is how your message will appear to recipients</small>
                                        </div>
                                        
                                        <!-- Submit -->
                                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                            <button type="button" class="btn btn-secondary" onclick="previewMessage()">
                                                <i class="fas fa-eye me-2"></i>Preview
                                            </button>
                                            <button type="submit" class="btn btn-primary">
                                                <i class="fas fa-paper-plane me-2"></i>Prepare to Send
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Side Panel -->
                        <div class="col-lg-4">
                            <!-- Broadcast History -->
                            <div class="card stat-card mb-4">
                                <div class="card-header bg-info text-white">
                                    <h5 class="mb-0"><i class="fas fa-history me-2"></i>Recent Broadcasts</h5>
                                </div>
                                <div class="card-body">
                                    <?php if(count($broadcast_history) > 0): ?>
                                        <div class="list-group list-group-flush">
                                            <?php foreach($broadcast_history as $history): ?>
                                            <div class="list-group-item border-0 px-0 py-2">
                                                <div class="d-flex align-items-start">
                                                    <div class="flex-shrink-0">
                                                        <?php if($history['broadcast_type'] == 'sms'): ?>
                                                            <i class="fas fa-sms text-primary"></i>
                                                        <?php else: ?>
                                                            <i class="fas fa-envelope text-success"></i>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="flex-grow-1 ms-3">
                                                        <small class="text-muted">
                                                            <?php echo date('M d, H:i', strtotime($history['sent_at'] ?? $history['created_at'])); ?>
                                                        </small>
                                                        <p class="mb-1 small"><?php echo substr($history['message'], 0, 50); ?>...</p>
                                                        <small>
                                                            <span class="badge bg-secondary"><?php echo $history['recipient_count']; ?> recipients</span>
                                                            <span class="badge bg-light text-dark ms-1"><?php echo ucfirst($history['recipient_type']); ?></span>
                                                        </small>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php else: ?>
                                        <div class="text-center py-3">
                                            <i class="fas fa-history fa-2x text-muted mb-3"></i>
                                            <p class="text-muted">No broadcast history yet.</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <!-- Quick Stats -->
                            <div class="card stat-card">
                                <div class="card-header bg-success text-white">
                                    <h5 class="mb-0"><i class="fas fa-chart-bar me-2"></i>Broadcast Stats</h5>
                                </div>
                                <div class="card-body">
                                    <?php
                                    // Get stats
                                    $stmt = $conn->query("SELECT COUNT(*) as total FROM broadcast_logs");
                                    $total_broadcasts = $stmt->fetch()['total'];
                                    
                                    $stmt = $conn->query("SELECT SUM(recipient_count) as total FROM broadcast_logs WHERE status = 'sent'");
                                    $total_recipients = $stmt->fetch()['total'] ?? 0;
                                    ?>
                                    
                                    <div class="text-center">
                                        <div class="display-6 text-primary"><?php echo $total_broadcasts; ?></div>
                                        <p class="text-muted">Total Broadcasts</p>
                                        
                                        <div class="display-6 text-success"><?php echo $total_recipients; ?></div>
                                        <p class="text-muted">Total Messages Sent</p>
                                        
                                        <hr>
                                        
                                        <div class="alert alert-light">
                                            <h6><i class="fas fa-lightbulb me-2 text-warning"></i>Tips:</h6>
                                            <ul class="small mb-0">
                                                <li>SMS messages should be concise (160 chars)</li>
                                                <li>Best time to send: 9 AM - 5 PM</li>
                                                <li>Include clear call-to-action</li>
                                                <li>Test with yourself first</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Confirmation Modal (shown when ready to send) -->
    <?php if(isset($_SESSION['pending_broadcast'])): ?>
    <div class="modal fade show" id="confirmModal" tabindex="-1" style="display: block; background: rgba(0,0,0,0.5);">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-warning">
                    <h5 class="modal-title"><i class="fas fa-exclamation-triangle me-2"></i>Confirm Broadcast</h5>
                </div>
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        You are about to send a <strong><?php echo strtoupper($_SESSION['pending_broadcast']['type']); ?></strong> 
                        to <strong><?php echo $_SESSION['pending_broadcast']['recipient_count']; ?></strong> recipients.
                    </div>
                    
                    <h6>Message Preview:</h6>
                    <div class="border rounded p-3 mb-3">
                        <?php echo nl2br(htmlspecialchars($_SESSION['pending_broadcast']['message'])); ?>
                    </div>
                    
                    <p class="text-muted small">
                        <i class="fas fa-clock me-1"></i>
                        This action cannot be undone. Ensure your message is correct.
                    </p>
                </div>
                <div class="modal-footer">
                    <form method="POST">
                        <input type="hidden" name="action" value="confirm_send">
                        <button type="button" class="btn btn-secondary" onclick="cancelBroadcast()">
                            <i class="fas fa-times me-2"></i>Cancel
                        </button>
                        <button type="submit" class="btn btn-warning">
                            <i class="fas fa-paper-plane me-2"></i>Send Now
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Broadcast type selection
        function selectBroadcastType(type) {
            document.getElementById('broadcastType').value = type;
            
            // Update button styles
            document.querySelectorAll('.broadcast-type-btn').forEach(btn => {
                btn.classList.remove('btn-primary', 'btn-success');
                btn.classList.add('btn-outline-primary', 'btn-outline-success');
            });
            
            const selectedBtn = event.currentTarget;
            if(type === 'sms') {
                selectedBtn.classList.remove('btn-outline-primary');
                selectedBtn.classList.add('btn-primary');
                document.getElementById('smsCount').style.display = 'inline';
            } else {
                selectedBtn.classList.remove('btn-outline-success');
                selectedBtn.classList.add('btn-success');
                document.getElementById('smsCount').style.display = 'none';
            }
            
            updateCharCount();
        }
        
        // Recipient type selection
        document.querySelectorAll('input[name="recipient_type"]').forEach(radio => {
            radio.addEventListener('change', function() {
                const value = this.value;
                document.getElementById('yearGroupSelection').style.display = value === 'year_group' ? 'block' : 'none';
                document.getElementById('eventSelection').style.display = value === 'event' ? 'block' : 'none';
            });
        });
        
        // Character count
        function updateCharCount() {
            const message = document.getElementById('message').value;
            const charCount = message.length;
            document.getElementById('charCount').textContent = charCount;
            
            // SMS specific
            const broadcastType = document.getElementById('broadcastType').value;
            if(broadcastType === 'sms') {
                const smsCount = Math.ceil(charCount / 160);
                document.getElementById('smsMessages').textContent = smsCount;
                
                // Color coding
                const charCountElement = document.getElementById('charCount');
                if(charCount <= 160) {
                    charCountElement.style.color = '#28a745';
                } else if(charCount <= 320) {
                    charCountElement.style.color = '#ffc107';
                } else {
                    charCountElement.style.color = '#dc3545';
                }
            }
        }
        
        // Message templates
        function insertTemplate(type) {
            const templates = {
                'meeting': 'Reminder: Weekly fellowship meeting tomorrow at 10 AM. Venue: Main Sanctuary. Please be punctual.',
                'event': 'Important: End-Year Mission briefing this Friday at 6 PM. All participants must attend. Bring your registration documents.',
                'prayer': 'Prayer Request: Please join us in prayer for our upcoming mission. Prayer meeting tonight at 7 PM.',
                'urgent': 'URGENT: Change of venue for tomorrow\'s event. New location: Fellowship Hall. Please share this message.'
            };
            
            document.getElementById('message').value = templates[type];
            updateCharCount();
            previewMessage();
        }
        
        // Preview message
        function previewMessage() {
            const message = document.getElementById('message').value;
            const broadcastType = document.getElementById('broadcastType').value;
            
            if(message.trim()) {
                let preview = message;
                if(broadcastType === 'sms') {
                    preview = `<div class="bg-light p-3 rounded">
                        <i class="fas fa-sms me-2"></i><strong>SMS Preview:</strong><br>
                        <div class="mt-2">${message.replace(/\n/g, '<br>')}</div>
                        <div class="mt-2 small text-muted">
                            <i class="fas fa-mobile-alt me-1"></i>
                            Will be sent as SMS to phone numbers
                        </div>
                    </div>`;
                } else {
                    preview = `<div class="bg-light p-3 rounded">
                        <i class="fas fa-envelope me-2"></i><strong>Email Preview:</strong><br>
                        <div class="mt-2">${message.replace(/\n/g, '<br>')}</div>
                        <div class="mt-2 small text-muted">
                            <i class="fas fa-envelope me-1"></i>
                            Will be sent as email to members
                        </div>
                    </div>`;
                }
                
                document.getElementById('previewContent').innerHTML = preview;
                document.getElementById('messagePreview').style.display = 'block';
            }
        }
        
        // Cancel broadcast
        function cancelBroadcast() {
            window.location.href = 'broadcast.php?cancel=true';
        }
        
        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            // Auto-select SMS by default
            selectBroadcastType('sms');
            
            // Show confirmation modal if pending broadcast exists
            <?php if(isset($_SESSION['pending_broadcast'])): ?>
            const modal = new bootstrap.Modal(document.getElementById('confirmModal'));
            modal.show();
            <?php endif; ?>
            
            // Auto-focus message field
            document.getElementById('message').focus();
        });
    </script>
</body>
</html>