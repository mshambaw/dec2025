<?php
// admin/remedies_inventory.php - Inventory Management
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit();
}

function connectDB() {
    $host = 'localhost';
    $dbname = 'philadelphia_ministry';
    $username = 'root';
    $password = '';
    
    try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch(PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
}

$conn = connectDB();

// Get inventory with filters
$category = $_GET['category'] ?? '';
$stock_status = $_GET['stock_status'] ?? '';

$query = "SELECT * FROM remedies WHERE is_active = 1";
$params = [];

if($category) {
    $query .= " AND category = ?";
    $params[] = $category;
}

if($stock_status == 'low') {
    $query .= " AND quantity_in_stock <= reorder_level";
} elseif($stock_status == 'out') {
    $query .= " AND quantity_in_stock = 0";
}

$query .= " ORDER BY quantity_in_stock ASC, name";

$stmt = $conn->prepare($query);
$stmt->execute($params);
$inventory = $stmt->fetchAll();

// Get categories for filter
$stmt = $conn->query("SELECT DISTINCT category FROM remedies WHERE category IS NOT NULL ORDER BY category");
$categories = $stmt->fetchAll();

// Calculate total value
$total_value = 0;
$total_items = 0;
foreach($inventory as $item) {
    $total_value += $item['quantity_in_stock'] * $item['cost_price'];
    $total_items += $item['quantity_in_stock'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory - Remedies Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        .inventory-table th { background-color: #f8f9fa; }
        .stock-low { background-color: #fff3cd !important; }
        .stock-out { background-color: #f8d7da !important; }
        .stock-ok { background-color: #d1e7dd !important; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0">
                <div class="bg-dark text-white p-3" style="min-height: 100vh;">
                    <h5 class="mb-4">Remedies</h5>
                    <a href="remedies.php" class="d-block text-white mb-2">Dashboard</a>
                    <a href="remedies_inventory.php" class="d-block text-white mb-2 text-primary">Inventory</a>
                    <a href="remedies_reports.php" class="d-block text-white mb-2">Reports</a>
                    <hr class="bg-light">
                    <a href="dashboard.php" class="d-block text-white mb-2">Main Dashboard</a>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-4">
                <h2><i class="fas fa-boxes me-2"></i>Inventory Management</h2>
                
                <!-- Filters -->
                <div class="card mb-4">
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-4">
                                <label>Category</label>
                                <select class="form-select" name="category">
                                    <option value="">All Categories</option>
                                    <?php foreach($categories as $cat): ?>
                                        <option value="<?php echo $cat['category']; ?>" <?php echo $category == $cat['category'] ? 'selected' : ''; ?>>
                                            <?php echo ucfirst($cat['category']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label>Stock Status</label>
                                <select class="form-select" name="stock_status">
                                    <option value="">All Items</option>
                                    <option value="low" <?php echo $stock_status == 'low' ? 'selected' : ''; ?>>Low Stock</option>
                                    <option value="out" <?php echo $stock_status == 'out' ? 'selected' : ''; ?>>Out of Stock</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label>&nbsp;</label>
                                <button type="submit" class="btn btn-primary w-100">Filter</button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Summary -->
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="card bg-primary text-white">
                            <div class="card-body text-center">
                                <h5><?php echo count($inventory); ?></h5>
                                <p>Total Items</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card bg-success text-white">
                            <div class="card-body text-center">
                                <h5><?php echo $total_items; ?></h5>
                                <p>Total Units</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card bg-info text-white">
                            <div class="card-body text-center">
                                <h5>KES <?php echo number_format($total_value, 0); ?></h5>
                                <p>Total Value</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Inventory Table -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table inventory-table">
                                <thead>
                                    <tr>
                                        <th>Code</th>
                                        <th>Name</th>
                                        <th>Category</th>
                                        <th>Stock</th>
                                        <th>Reorder Level</th>
                                        <th>Unit Price</th>
                                        <th>Cost Price</th>
                                        <th>Stock Value</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($inventory as $item): 
                                        $stock_class = '';
                                        if($item['quantity_in_stock'] == 0) {
                                            $stock_class = 'stock-out';
                                        } elseif($item['quantity_in_stock'] <= $item['reorder_level']) {
                                            $stock_class = 'stock-low';
                                        } else {
                                            $stock_class = 'stock-ok';
                                        }
                                        
                                        $stock_value = $item['quantity_in_stock'] * $item['cost_price'];
                                    ?>
                                    <tr class="<?php echo $stock_class; ?>">
                                        <td><?php echo $item['remedy_code']; ?></td>
                                        <td><?php echo htmlspecialchars($item['name']); ?></td>
                                        <td><?php echo ucfirst($item['category']); ?></td>
                                        <td><?php echo $item['quantity_in_stock']; ?></td>
                                        <td><?php echo $item['reorder_level']; ?></td>
                                        <td>KES <?php echo number_format($item['unit_price'], 0); ?></td>
                                        <td>KES <?php echo number_format($item['cost_price'], 0); ?></td>
                                        <td>KES <?php echo number_format($stock_value, 0); ?></td>
                                        <td>
                                            <?php if($item['quantity_in_stock'] == 0): ?>
                                                <span class="badge bg-danger">Out of Stock</span>
                                            <?php elseif($item['quantity_in_stock'] <= $item['reorder_level']): ?>
                                                <span class="badge bg-warning">Low Stock</span>
                                            <?php else: ?>
                                                <span class="badge bg-success">In Stock</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>