<?php
// admin/ajax/get-registration-details.php
session_start();
require_once '../../config/database.php';

$db = new Database();
$conn = $db->getConnection();

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    $stmt = $conn->prepare("SELECT r.*, e.title as event_title, e.start_date, e.end_date, e.location, e.time 
                           FROM event_registrations r
                           JOIN ministry_events e ON r.event_id = e.id
                           WHERE r.id = ?");
    $stmt->execute([$id]);
    $registration = $stmt->fetch();
    
    if ($registration) {
        ?>
        <div class="modal-header bg-primary text-white">
            <h5 class="modal-title">Registration Details</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
            <div class="row">
                <div class="col-md-6">
                    <h6 class="border-bottom pb-2 mb-3">Personal Information</h6>
                    <table class="table table-sm">
                        <tr><th>Full Name:</th><td><?php echo htmlspecialchars($registration['full_name']); ?></td></tr>
                        <tr><th>Email:</th><td><?php echo htmlspecialchars($registration['email']); ?></td></tr>
                        <tr><th>Phone:</th><td><?php echo htmlspecialchars($registration['phone']); ?></td></tr>
                        <tr><th>Gender:</th><td><?php echo htmlspecialchars($registration['gender']) ?: 'Not specified'; ?></td></tr>
                        <tr><th>Age Group:</th><td><?php echo htmlspecialchars($registration['age_group']) ?: 'Not specified'; ?></td></tr>
                        <tr><th>Year Group:</th><td><?php echo htmlspecialchars($registration['year_group']) ?: 'Not specified'; ?></td></tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <h6 class="border-bottom pb-2 mb-3">Registration Details</h6>
                    <table class="table table-sm">
                        <tr><th>Event:</th><td><?php echo htmlspecialchars($registration['event_title']); ?></td></tr>
                        <tr><th>Registration Code:</th><td><span class="badge bg-primary"><?php echo $registration['registration_code']; ?></span></td></tr>
                        <tr><th>Date:</th><td><?php echo date('F d, Y', strtotime($registration['start_date'])); ?></td></tr>
                        <tr><th>Time:</th><td><?php echo date('g:i A', strtotime($registration['time'])); ?></td></tr>
                        <tr><th>Location:</th><td><?php echo htmlspecialchars($registration['location']); ?></td></tr>
                    </table>
                </div>
            </div>
            
            <div class="row mt-3">
                <div class="col-md-6">
                    <h6 class="border-bottom pb-2 mb-3">Status Information</h6>
                    <table class="table table-sm">
                        <tr>
                            <th>Registration Status:</th>
                            <td>
                                <?php 
                                $statusColors = [
                                    'pending' => 'warning',
                                    'confirmed' => 'success',
                                    'cancelled' => 'danger',
                                    'attended' => 'info'
                                ];
                                $statusColor = $statusColors[$registration['status']] ?? 'secondary';
                                ?>
                                <span class="badge bg-<?php echo $statusColor; ?>">
                                    <?php echo ucfirst($registration['status']); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <th>Payment Status:</th>
                            <td>
                                <?php 
                                $paymentColors = [
                                    'pending' => 'warning',
                                    'paid' => 'success',
                                    'partial' => 'info',
                                    'waived' => 'secondary'
                                ];
                                $paymentColor = $paymentColors[$registration['payment_status']] ?? 'secondary';
                                ?>
                                <span class="badge bg-<?php echo $paymentColor; ?>">
                                    <?php echo ucfirst($registration['payment_status']); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <th>Amount Paid:</th>
                            <td>KES <?php echo number_format($registration['amount_paid'], 2); ?></td>
                        </tr>
                        <tr>
                            <th>Registration Date:</th>
                            <td><?php echo date('F d, Y H:i', strtotime($registration['registration_date'])); ?></td>
                        </tr>
                    </table>
                </div>
                
                <div class="col-md-6">
                    <h6 class="border-bottom pb-2 mb-3">Additional Information</h6>
                    <table class="table table-sm">
                        <tr><th>Emergency Contact:</th><td><?php echo htmlspecialchars($registration['emergency_contact']) ?: 'Not provided'; ?></td></tr>
                        <tr><th>Dietary Requirements:</th><td><?php echo htmlspecialchars($registration['dietary_requirements']) ?: 'None'; ?></td></tr>
                        <tr><th>Special Needs:</th><td><?php echo htmlspecialchars($registration['special_needs']) ?: 'None'; ?></td></tr>
                        <tr><th>Church Member:</th><td><?php echo ucfirst($registration['church_member']); ?></td></tr>
                        <tr><th>Previous Mission:</th><td><?php echo ucfirst($registration['previous_mission']); ?></td></tr>
                    </table>
                </div>
            </div>
            
            <?php if (!empty($registration['expectations'])): ?>
            <div class="row mt-3">
                <div class="col-12">
                    <h6 class="border-bottom pb-2 mb-3">Expectations</h6>
                    <div class="alert alert-light">
                        <?php echo nl2br(htmlspecialchars($registration['expectations'])); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($registration['notes'])): ?>
            <div class="row mt-3">
                <div class="col-12">
                    <h6 class="border-bottom pb-2 mb-3">Admin Notes</h6>
                    <div class="alert alert-info">
                        <?php echo nl2br(htmlspecialchars($registration['notes'])); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <a href="print-registration.php?id=<?php echo $registration['id']; ?>" 
               target="_blank" class="btn btn-primary">
                <i class="fas fa-print me-1"></i>Print
            </a>
            <a href="edit-registration.php?id=<?php echo $registration['id']; ?>" 
               class="btn btn-warning">
                <i class="fas fa-edit me-1"></i>Edit
            </a>
        </div>
        <?php
    } else {
        echo '<div class="alert alert-danger m-3">Registration not found.</div>';
    }
} else {
    echo '<div class="alert alert-danger m-3">No registration ID provided.</div>';
}
?>