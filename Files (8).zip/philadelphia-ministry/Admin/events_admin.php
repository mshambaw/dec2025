<?php
// admin/events_admin.php
session_start();
require_once 'includes/auth_check.php';
require_once '../config/database.php';

$db = new Database();
$conn = $db->getConnection();

// Get all events
$stmt = $conn->query("SELECT * FROM ministry_events ORDER BY start_date DESC");
$events = $stmt->fetchAll();
?>
<?php include 'includes/header.php'; ?>

<div class="container-fluid">
    <h1 class="h3 mb-4">Events Management</h1>
    
    <div class="card shadow">
        <div class="card-header py-3">
            <div class="d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-primary">All Events</h6>
                <a href="add-event.php" class="btn btn-primary btn-sm">
                    <i class="fas fa-plus me-1"></i>Add New Event
                </a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Type</th>
                            <th>Date</th>
                            <th>Location</th>
                            <th>Status</th>
                            <th>Registrations</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($events as $event): ?>
                        <tr>
                            <td><?php echo $event['id']; ?></td>
                            <td><?php echo htmlspecialchars($event['title']); ?></td>
                            <td>
                                <span class="badge bg-info"><?php echo ucfirst($event['event_type']); ?></span>
                            </td>
                            <td><?php echo date('M d, Y', strtotime($event['start_date'])); ?></td>
                            <td><?php echo htmlspecialchars($event['location']); ?></td>
                            <td>
                                <span class="badge bg-<?php 
                                    echo $event['status'] == 'upcoming' ? 'success' : 
                                          ($event['status'] == 'ongoing' ? 'primary' : 'secondary'); 
                                ?>">
                                    <?php echo ucfirst($event['status']); ?>
                                </span>
                            </td>
                            <td>
                                <span class="badge bg-primary"><?php echo $event['registered_count']; ?></span>
                                <?php if($event['max_participants'] > 0): ?>
                                    / <?php echo $event['max_participants']; ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <a href="edit-event.php?id=<?php echo $event['id']; ?>" 
                                       class="btn btn-warning">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="event-registrations.php?event_id=<?php echo $event['id']; ?>" 
                                       class="btn btn-info">
                                        <i class="fas fa-users"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>