<?php
// admin/dashboard.php - SIMPLE VERSION
session_start();

// Check if logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit();
}

// Include database connection
require_once '../config/database.php';

// Connect to database
try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get statistics
    $totalReg = $conn->query("SELECT COUNT(*) as count FROM event_registrations")->fetch()['count'];
    $pendingReg = $conn->query("SELECT COUNT(*) as count FROM event_registrations WHERE status = 'pending'")->fetch()['count'];
    $todayReg = $conn->query("SELECT COUNT(*) as count FROM event_registrations WHERE DATE(registration_date) = CURDATE()")->fetch()['count'];
    
} catch(Exception $e) {
    $totalReg = $pendingReg = $todayReg = 0;
    $error = "Database error: " . $e->getMessage();
}
?>

<?php include 'includes/header_simple.php'; ?>

<div class="container-fluid">
    <h1 class="h3 mb-4">Dashboard</h1>
    
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <!-- Statistics Cards -->
    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h5 class="card-title">Total Registrations</h5>
                    <h2 class="card-text"><?php echo $totalReg; ?></h2>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 mb-4">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <h5 class="card-title">Pending</h5>
                    <h2 class="card-text"><?php echo $pendingReg; ?></h2>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 mb-4">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h5 class="card-title">Today's Registrations</h5>
                    <h2 class="card-text"><?php echo $todayReg; ?></h2>
                </div>
            </div>
        </div>
    </div>
    
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">Quick Actions</h5>
        </div>
        <div class="card-body">
            <a href="registrations.php" class="btn btn-primary me-2">
                <i class="fas fa-users me-1"></i>View Registrations
            </a>
            <a href="events_admin.php" class="btn btn-success me-2">
                <i class="fas fa-calendar me-1"></i>Manage Events
            </a>
            <a href="../events/register.php" class="btn btn-info" target="_blank">
                <i class="fas fa-user-plus me-1"></i>Test Registration
            </a>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>