<?php
// admin/backup.php
session_start();
require_once '../config/database.php';
require_once 'includes/auth_check.php';

$db = new Database();
$conn = $db->getConnection();

// Handle backup request
if(isset($_POST['create_backup'])) {
    $backup_type = $_POST['backup_type'];
    
    if($backup_type == 'database') {
        $filename = $db->backupDatabase();
        if($filename) {
            $_SESSION['message'] = "Database backup created: $filename";
        } else {
            $_SESSION['error'] = "Failed to create backup";
        }
    } elseif($backup_type == 'full') {
        // Create zip of database and files
        $zip = new ZipArchive();
        $zip_filename = 'full-backup-' . date('Y-m-d-H-i-s') . '.zip';
        $zip_path = '../backup/' . $zip_filename;
        
        if($zip->open($zip_path, ZipArchive::CREATE) === TRUE) {
            // Add database backup
            $db_backup = $db->backupDatabase('../backup/temp/');
            if($db_backup) {
                $zip->addFile("../backup/temp/$db_backup", "database/$db_backup");
            }
            
            // Add important files
            $files_to_backup = [
                '../config/database.php',
                '../api/',
                '../admin/'
            ];
            
            foreach($files_to_backup as $file) {
                if(is_dir($file)) {
                    $this->addFolderToZip($file, $zip, $file);
                } elseif(file_exists($file)) {
                    $zip->addFile($file, basename($file));
                }
            }
            
            $zip->close();
            
            // Log backup
            $stmt = $conn->prepare("INSERT INTO backup_logs (backup_type, file_path, file_size, status, created_by) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute(['Full', $zip_filename, filesize($zip_path), 'Success', $_SESSION['user_id']]);
            
            $_SESSION['message'] = "Full backup created: $zip_filename";
        }
    }
}

// Get backup logs
$stmt = $conn->query("SELECT * FROM backup_logs ORDER BY created_at DESC LIMIT 50");
$backups = $stmt->fetchAll();
?>