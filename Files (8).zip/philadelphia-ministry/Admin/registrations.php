<?php
// admin/registrations.php
session_start();
require_once 'includes/auth_check.php';
require_once '../config/database.php';  // This should work

$db = new Database();
$conn = $db->getConnection();

// Get all registrations with event details
$stmt = $conn->prepare("SELECT r.*, e.title as event_title, e.start_date 
                       FROM event_registrations r
                       JOIN ministry_events e ON r.event_id = e.id
                       ORDER BY r.registration_date DESC");
$stmt->execute();
$registrations = $stmt->fetchAll();

// Get statistics
$stmt = $conn->query("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) as confirmed,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
    SUM(CASE WHEN payment_status = 'paid' THEN 1 ELSE 0 END) as paid
    FROM event_registrations");
$stats = $stmt->fetch();
?>

<?php include 'includes/header.php'; ?>

<!-- ... rest of registrations.php code remains the same ... -->

<!-- Rest of the code remains the same -->
<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0">Event Registrations</h1>
            <p class="text-muted mb-0">Manage all event registrations and confirmations</p>
        </div>
        <div>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exportModal">
                <i class="fas fa-download me-2"></i>Export
            </button>
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addRegistrationModal">
                <i class="fas fa-plus me-2"></i>Add Manual
            </button>
        </div>
    </div>
    
    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-start border-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs fw-bold text-primary text-uppercase mb-1">
                                Total Registrations</div>
                            <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $stats['total']; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-users fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-start border-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs fw-bold text-success text-uppercase mb-1">
                                Confirmed</div>
                            <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $stats['confirmed']; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-start border-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs fw-bold text-warning text-uppercase mb-1">
                                Pending</div>
                            <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $stats['pending']; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clock fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-start border-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs fw-bold text-info text-uppercase mb-1">
                                Paid</div>
                            <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $stats['paid']; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-money-bill-wave fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Registrations Table -->
    <div class="card shadow">
        <div class="card-header py-3">
            <h6 class="m-0 fw-bold text-primary">All Registrations</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="registrationsTable">
                    <thead class="table-light">
                        <tr>
                            <th>Code</th>
                            <th>Name</th>
                            <th>Event</th>
                            <th>Date</th>
                            <th>Phone</th>
                            <th>Status</th>
                            <th>Payment</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($registrations as $reg): ?>
                        <tr>
                            <td>
                                <span class="badge bg-primary"><?php echo $reg['registration_code']; ?></span>
                            </td>
                            <td><?php echo htmlspecialchars($reg['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($reg['event_title']); ?></td>
                            <td><?php echo date('M d, Y', strtotime($reg['registration_date'])); ?></td>
                            <td><?php echo htmlspecialchars($reg['phone']); ?></td>
                            <td>
                                <?php 
                                $status_badges = [
                                    'pending' => 'warning',
                                    'confirmed' => 'success',
                                    'cancelled' => 'danger',
                                    'attended' => 'info'
                                ];
                                ?>
                                <span class="badge bg-<?php echo $status_badges[$reg['status']] ?? 'secondary'; ?>">
                                    <?php echo ucfirst($reg['status']); ?>
                                </span>
                            </td>
                            <td>
                                <?php 
                                $payment_badges = [
                                    'pending' => 'warning',
                                    'paid' => 'success',
                                    'partial' => 'info',
                                    'waived' => 'secondary'
                                ];
                                ?>
                                <span class="badge bg-<?php echo $payment_badges[$reg['payment_status']] ?? 'secondary'; ?>">
                                    <?php echo ucfirst($reg['payment_status']); ?>
                                </span>
                            </td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <button class="btn btn-info btn-sm view-registration" 
                                            data-id="<?php echo $reg['id']; ?>"
                                            data-bs-toggle="modal" 
                                            data-bs-target="#viewModal">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="btn btn-warning btn-sm edit-registration"
                                            data-id="<?php echo $reg['id']; ?>"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editModal">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <a href="print-registration.php?id=<?php echo $reg['id']; ?>" 
                                       target="_blank"
                                       class="btn btn-secondary btn-sm">
                                        <i class="fas fa-print"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- View Registration Modal -->
<div class="modal fade" id="viewModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Registration Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="registrationDetails">
                <!-- Details loaded via AJAX -->
            </div>
        </div>
    </div>
</div>

<!-- Export Modal -->
<div class="modal fade" id="exportModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Export Registrations</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="exportForm" method="POST" action="export-registrations.php">
                    <div class="mb-3">
                        <label for="exportFormat" class="form-label">Format</label>
                        <select class="form-select" id="exportFormat" name="format">
                            <option value="csv">CSV (Excel)</option>
                            <option value="pdf">PDF Document</option>
                            <option value="excel">Excel File</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="exportEvent" class="form-label">Event Filter</label>
                        <select class="form-select" id="exportEvent" name="event_id">
                            <option value="all">All Events</option>
                            <?php 
                            $stmt = $conn->query("SELECT id, title FROM ministry_events ORDER BY start_date DESC");
                            while($event = $stmt->fetch()): ?>
                                <option value="<?php echo $event['id']; ?>"><?php echo htmlspecialchars($event['title']); ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="exportStatus" class="form-label">Status Filter</label>
                        <select class="form-select" id="exportStatus" name="status">
                            <option value="all">All Statuses</option>
                            <option value="confirmed">Confirmed Only</option>
                            <option value="pending">Pending Only</option>
                            <option value="attended">Attended Only</option>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" form="exportForm" class="btn btn-primary">Export</button>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>

<style>
    .table th {
        font-weight: 600;
        font-size: 0.85rem;
        text-transform: uppercase;
        color: #6c757d;
    }
    
    .badge {
        font-size: 0.75rem;
        padding: 0.35em 0.65em;
    }
</style>

<script>
$(document).ready(function() {
    // Initialize DataTable
    $('#registrationsTable').DataTable({
        pageLength: 25,
        order: [[3, 'desc']],
        language: {
            search: "Search registrations:",
            lengthMenu: "Show _MENU_ entries",
            info: "Showing _START_ to _END_ of _TOTAL_ entries"
        }
    });
    
    // View registration details
    $('.view-registration').click(function() {
        var regId = $(this).data('id');
        
        $.ajax({
            url: 'ajax/get-registration-details.php',
            type: 'GET',
            data: { id: regId },
            success: function(response) {
                $('#registrationDetails').html(response);
            },
            error: function() {
                $('#registrationDetails').html('<div class="alert alert-danger">Failed to load details</div>');
            }
        });
    });
    
    // Edit registration
    $('.edit-registration').click(function() {
        var regId = $(this).data('id');
        // Load edit form via AJAX
        // Similar to view but with form
    });
    
    // Export functionality
    $('#exportForm').submit(function(e) {
        // You can add processing indicator here
        $('#exportModal').modal('hide');
    });
});
</script>