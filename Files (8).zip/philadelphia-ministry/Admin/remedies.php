<?php
// admin/remedies.php - Remedies Management System
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit();
}

// Database connection
function connectDB() {
    $host = 'localhost';
    $dbname = 'philadelphia_ministry';
    $username = 'root';
    $password = '';
    
    try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch(PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
}

$conn = connectDB();

// Handle actions
$success = $error = '';
if(isset($_POST['action'])) {
    $action = $_POST['action'];
    
    if($action == 'add_remedy') {
        $remedy_code = 'REM-' . strtoupper(uniqid());
        
        $stmt = $conn->prepare("
            INSERT INTO remedies (remedy_code, name, description, category, unit_price, cost_price, 
                                  unit_type, quantity_in_stock, reorder_level, batch_number, expiry_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $remedy_code,
            $_POST['name'],
            $_POST['description'],
            $_POST['category'],
            $_POST['unit_price'],
            $_POST['cost_price'],
            $_POST['unit_type'],
            $_POST['initial_stock'] ?? 0,
            $_POST['reorder_level'] ?? 10,
            $_POST['batch_number'] ?? '',
            $_POST['expiry_date'] ?? NULL
        ]);
        
        $success = "Remedy added successfully! Code: $remedy_code";
    }
    
    elseif($action == 'sell_remedy') {
        $sale_code = 'SALE-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
        $remedy_id = $_POST['remedy_id'];
        $quantity = $_POST['quantity'];
        
        // Get remedy details
        $stmt = $conn->prepare("SELECT unit_price, quantity_in_stock FROM remedies WHERE id = ?");
        $stmt->execute([$remedy_id]);
        $remedy = $stmt->fetch();
        
        if($remedy['quantity_in_stock'] >= $quantity) {
            $total = $remedy['unit_price'] * $quantity;
            
            $stmt = $conn->prepare("
                INSERT INTO remedy_sales (sale_code, remedy_id, quantity_sold, unit_price, total_amount, 
                                          customer_name, customer_phone, payment_method, sold_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $sale_code,
                $remedy_id,
                $quantity,
                $remedy['unit_price'],
                $total,
                $_POST['customer_name'],
                $_POST['customer_phone'],
                $_POST['payment_method'],
                $_SESSION['admin_name'] ?? 'Admin'
            ]);
            
            // Update stock
            $stmt = $conn->prepare("UPDATE remedies SET quantity_in_stock = quantity_in_stock - ? WHERE id = ?");
            $stmt->execute([$quantity, $remedy_id]);
            
            $success = "Sale completed! Sale Code: $sale_code | Amount: KES " . number_format($total, 2);
        } else {
            $error = "Insufficient stock! Available: " . $remedy['quantity_in_stock'];
        }
    }
    
    elseif($action == 'restock_remedy') {
        $restock_code = 'RST-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
        
        $stmt = $conn->prepare("
            INSERT INTO remedy_restocks (restock_code, remedy_id, quantity_added, unit_cost, total_cost,
                                         supplier_name, supplier_contact, batch_number, expiry_date, received_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $total_cost = $_POST['quantity_added'] * $_POST['unit_cost'];
        
        $stmt->execute([
            $restock_code,
            $_POST['remedy_id'],
            $_POST['quantity_added'],
            $_POST['unit_cost'],
            $total_cost,
            $_POST['supplier_name'],
            $_POST['supplier_contact'],
            $_POST['batch_number'] ?? '',
            $_POST['expiry_date'] ?? NULL,
            $_SESSION['admin_name'] ?? 'Admin'
        ]);
        
        // Update stock
        $stmt = $conn->prepare("UPDATE remedies SET quantity_in_stock = quantity_in_stock + ? WHERE id = ?");
        $stmt->execute([$_POST['quantity_added'], $_POST['remedy_id']]);
        
        $success = "Restock completed! Code: $restock_code";
    }
}

// Get statistics
$stats = [];

// Total remedies
$stmt = $conn->query("SELECT COUNT(*) as count FROM remedies WHERE is_active = 1");
$stats['total_remedies'] = $stmt->fetch()['count'];

// Low stock items
$stmt = $conn->query("SELECT COUNT(*) as count FROM remedies WHERE quantity_in_stock <= reorder_level AND is_active = 1");
$stats['low_stock'] = $stmt->fetch()['count'];

// Total sales today
$stmt = $conn->query("SELECT COUNT(*) as count, SUM(total_amount) as total FROM remedy_sales WHERE DATE(sale_date) = CURDATE()");
$today = $stmt->fetch();
$stats['today_sales'] = $today['count'];
$stats['today_revenue'] = $today['total'] ?? 0;

// Total inventory value
$stmt = $conn->query("SELECT SUM(quantity_in_stock * cost_price) as value FROM remedies WHERE is_active = 1");
$stats['inventory_value'] = $stmt->fetch()['value'] ?? 0;

// Get all remedies
$stmt = $conn->query("SELECT * FROM remedies WHERE is_active = 1 ORDER BY name");
$remedies = $stmt->fetchAll();

// Get recent sales
$stmt = $conn->query("SELECT s.*, r.name as remedy_name FROM remedy_sales s JOIN remedies r ON s.remedy_id = r.id ORDER BY s.sale_date DESC LIMIT 10");
$recent_sales = $stmt->fetchAll();

// Get categories
$stmt = $conn->query("SELECT * FROM remedy_categories WHERE is_active = 1 ORDER BY name");
$categories = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Remedies Management - Philadelphia Ministry</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        :root {
            --primary-color: #1a5276;
            --secondary-color: #2c3e50;
            --success-color: #28a745;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
        }
        
        body { 
            background-color: #f8f9fa; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar { 
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
        }
        
        .stat-card {
            border-radius: 12px;
            border: none;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            margin-bottom: 1.5rem;
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-icon {
            font-size: 2.5rem;
            opacity: 0.8;
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            margin: 10px 0;
        }
        
        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .remedy-card {
            border-radius: 10px;
            border: 1px solid #e9ecef;
            transition: all 0.3s;
            height: 100%;
        }
        
        .remedy-card:hover {
            border-color: var(--primary-color);
            box-shadow: 0 5px 15px rgba(26, 82, 118, 0.1);
        }
        
        .stock-low {
            color: var(--danger-color);
            font-weight: bold;
        }
        
        .stock-ok {
            color: var(--success-color);
        }
        
        .badge-category {
            font-size: 0.8rem;
            padding: 5px 10px;
            border-radius: 20px;
        }
        
        .modal-content {
            border-radius: 15px;
            border: none;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        .btn-remedy {
            border-radius: 8px;
            padding: 10px 20px;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .btn-remedy-primary {
            background: var(--primary-color);
            color: white;
            border: none;
        }
        
        .btn-remedy-primary:hover {
            background: #154360;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(26, 82, 118, 0.3);
        }
        
        .chart-container {
            height: 250px;
            margin: 20px 0;
        }
        
        .action-buttons .btn {
            padding: 5px 10px;
            margin: 2px;
            font-size: 0.85rem;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-church me-2"></i>
                <strong>Philadelphia Ministry</strong>
                <small class="ms-2 opacity-75">Remedies Management</small>
            </a>
            <div class="navbar-text text-white">
                <i class="fas fa-user-circle me-1"></i>
                <?php echo htmlspecialchars($_SESSION['admin_name'] ?? 'Admin'); ?>
                | <a href="dashboard.php" class="text-white text-decoration-none me-3">Dashboard</a>
                | <a href="logout.php" class="text-warning text-decoration-none">Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 d-print-none">
                <div class="bg-dark text-white p-3" style="min-height: calc(100vh - 56px);">
                    <h5 class="mb-4"><i class="fas fa-capsules me-2"></i>Remedies</h5>
                    
                    <a href="remedies.php" class="d-block text-white mb-2 p-2 rounded bg-primary">
                        <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                    </a>
                    
                    <a href="#" class="d-block text-white mb-2 p-2 rounded" data-bs-toggle="modal" data-bs-target="#addRemedyModal">
                        <i class="fas fa-plus-circle me-2"></i>Add New Remedy
                    </a>
                    
                    <a href="#" class="d-block text-white mb-2 p-2 rounded" data-bs-toggle="modal" data-bs-target="#sellRemedyModal">
                        <i class="fas fa-shopping-cart me-2"></i>Sell Remedy
                    </a>
                    
                    <a href="#" class="d-block text-white mb-2 p-2 rounded" data-bs-toggle="modal" data-bs-target="#restockModal">
                        <i class="fas fa-boxes me-2"></i>Restock
                    </a>
                    
                    <a href="remedies_inventory.php" class="d-block text-white mb-2 p-2 rounded">
                        <i class="fas fa-clipboard-list me-2"></i>Inventory
                    </a>
                    
                    <a href="remedies_reports.php" class="d-block text-white mb-2 p-2 rounded">
                        <i class="fas fa-chart-bar me-2"></i>Reports
                    </a>
                    
                    <hr class="bg-light my-3">
                    
                    <div class="text-center small text-muted mt-4">
                        <i class="fas fa-heartbeat me-1"></i>
                        Healing through faith
                    </div>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 px-0">
                <div class="main-content p-4">
                    <!-- Page Header -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div>
                            <h2 class="mb-1"><i class="fas fa-heartbeat text-primary me-2"></i>Remedies Management</h2>
                            <p class="text-muted mb-0">Manage ministry remedies inventory and sales</p>
                        </div>
                        <div class="btn-group">
                            <button class="btn btn-remedy btn-remedy-primary" data-bs-toggle="modal" data-bs-target="#sellRemedyModal">
                                <i class="fas fa-cash-register me-2"></i>Quick Sale
                            </button>
                            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#restockModal">
                                <i class="fas fa-truck-loading me-2"></i>Restock
                            </button>
                        </div>
                    </div>
                    
                    <!-- Success/Error Messages -->
                    <?php if($success): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="fas fa-check-circle me-2"></i>
                            <?php echo $success; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            <?php echo $error; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Statistics Cards -->
                    <div class="row mb-4">
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="stat-card bg-primary text-white">
                                <div class="card-body text-center">
                                    <i class="fas fa-capsules stat-icon"></i>
                                    <div class="stat-number"><?php echo $stats['total_remedies']; ?></div>
                                    <div class="stat-label">Total Remedies</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="stat-card bg-warning text-white">
                                <div class="card-body text-center">
                                    <i class="fas fa-exclamation-triangle stat-icon"></i>
                                    <div class="stat-number"><?php echo $stats['low_stock']; ?></div>
                                    <div class="stat-label">Low Stock Items</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="stat-card bg-success text-white">
                                <div class="card-body text-center">
                                    <i class="fas fa-shopping-cart stat-icon"></i>
                                    <div class="stat-number"><?php echo $stats['today_sales']; ?></div>
                                    <div class="stat-label">Today's Sales</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="stat-card bg-info text-white">
                                <div class="card-body text-center">
                                    <i class="fas fa-coins stat-icon"></i>
                                    <div class="stat-number">KES <?php echo number_format($stats['inventory_value'], 0); ?></div>
                                    <div class="stat-label">Inventory Value</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Remedies Grid -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h4><i class="fas fa-box-open me-2"></i>Available Remedies</h4>
                                <span class="badge bg-primary"><?php echo count($remedies); ?> items</span>
                            </div>
                        </div>
                        
                        <?php foreach($remedies as $remedy): ?>
                        <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                            <div class="remedy-card">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <div>
                                            <h5 class="card-title mb-1"><?php echo htmlspecialchars($remedy['name']); ?></h5>
                                            <span class="badge bg-secondary"><?php echo htmlspecialchars($remedy['remedy_code']); ?></span>
                                        </div>
                                        <div class="text-end">
                                            <div class="h4 text-primary">KES <?php echo number_format($remedy['unit_price'], 0); ?></div>
                                            <small class="text-muted">per <?php echo $remedy['unit_type']; ?></small>
                                        </div>
                                    </div>
                                    
                                    <p class="card-text small text-muted mb-3">
                                        <?php echo substr(htmlspecialchars($remedy['description'] ?? 'No description'), 0, 80); ?>...
                                    </p>
                                    
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <span class="badge-category bg-info text-white">
                                                <?php echo ucfirst($remedy['category']); ?>
                                            </span>
                                        </div>
                                        <div>
                                            <span class="<?php echo $remedy['quantity_in_stock'] <= $remedy['reorder_level'] ? 'stock-low' : 'stock-ok'; ?>">
                                                <i class="fas fa-box me-1"></i>
                                                <?php echo $remedy['quantity_in_stock']; ?> in stock
                                            </span>
                                        </div>
                                    </div>
                                    
                                    <div class="action-buttons mt-3">
                                        <button class="btn btn-sm btn-success" 
                                                onclick="quickSell(<?php echo $remedy['id']; ?>, '<?php echo htmlspecialchars($remedy['name']); ?>')">
                                            <i class="fas fa-cart-plus"></i> Sell
                                        </button>
                                        <button class="btn btn-sm btn-warning" 
                                                onclick="quickRestock(<?php echo $remedy['id']; ?>, '<?php echo htmlspecialchars($remedy['name']); ?>')">
                                            <i class="fas fa-boxes"></i> Restock
                                        </button>
                                        <button class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i> View
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Recent Sales & Quick Stats -->
                    <div class="row">
                        <!-- Recent Sales -->
                        <div class="col-lg-8 mb-4">
                            <div class="card stat-card">
                                <div class="card-body">
                                    <h5 class="card-title mb-3">
                                        <i class="fas fa-history me-2"></i>Recent Sales
                                        <span class="badge bg-primary float-end">Today: KES <?php echo number_format($stats['today_revenue'], 0); ?></span>
                                    </h5>
                                    
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Sale Code</th>
                                                    <th>Remedy</th>
                                                    <th>Qty</th>
                                                    <th>Amount</th>
                                                    <th>Customer</th>
                                                    <th>Time</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if(count($recent_sales) > 0): ?>
                                                    <?php foreach($recent_sales as $sale): ?>
                                                    <tr>
                                                        <td><span class="badge bg-secondary"><?php echo $sale['sale_code']; ?></span></td>
                                                        <td><?php echo htmlspecialchars($sale['remedy_name']); ?></td>
                                                        <td><?php echo $sale['quantity_sold']; ?></td>
                                                        <td class="text-success">KES <?php echo number_format($sale['total_amount'], 0); ?></td>
                                                        <td><?php echo htmlspecialchars($sale['customer_name'] ?: 'Walk-in'); ?></td>
                                                        <td><?php echo date('H:i', strtotime($sale['sale_date'])); ?></td>
                                                    </tr>
                                                    <?php endforeach; ?>
                                                <?php else: ?>
                                                    <tr>
                                                        <td colspan="6" class="text-center py-3">
                                                            <i class="fas fa-shopping-cart fa-2x text-muted mb-3"></i>
                                                            <p class="text-muted">No sales today yet.</p>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Quick Stats -->
                        <div class="col-lg-4 mb-4">
                            <div class="card stat-card">
                                <div class="card-body">
                                    <h5 class="card-title mb-3"><i class="fas fa-chart-pie me-2"></i>Quick Stats</h5>
                                    
                                    <div class="chart-container">
                                        <canvas id="stockChart"></canvas>
                                    </div>
                                    
                                    <div class="list-group list-group-flush">
                                        <div class="list-group-item d-flex justify-content-between align-items-center">
                                            <span>Total Sales Today</span>
                                            <span class="badge bg-primary rounded-pill">
                                                KES <?php echo number_format($stats['today_revenue'], 0); ?>
                                            </span>
                                        </div>
                                        <div class="list-group-item d-flex justify-content-between align-items-center">
                                            <span>Low Stock Items</span>
                                            <span class="badge bg-warning rounded-pill"><?php echo $stats['low_stock']; ?></span>
                                        </div>
                                        <div class="list-group-item d-flex justify-content-between align-items-center">
                                            <span>Total Inventory Value</span>
                                            <span class="badge bg-info rounded-pill">
                                                KES <?php echo number_format($stats['inventory_value'], 0); ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Add Remedy Modal -->
    <div class="modal fade" id="addRemedyModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fas fa-plus-circle me-2"></i>Add New Remedy</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add_remedy">
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Remedy Name *</label>
                                <input type="text" class="form-control" name="name" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Category *</label>
                                <select class="form-select" name="category" required>
                                    <option value="herbal">Herbal Remedy</option>
                                    <option value="oil">Anointing Oil</option>
                                    <option value="ointment">Healing Ointment</option>
                                    <option value="tea">Herbal Tea</option>
                                    <option value="supplement">Supplement</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" rows="3"></textarea>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <label class="form-label">Unit Price (KES) *</label>
                                <input type="number" class="form-control" name="unit_price" step="0.01" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Cost Price (KES) *</label>
                                <input type="number" class="form-control" name="cost_price" step="0.01" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Unit Type *</label>
                                <select class="form-select" name="unit_type" required>
                                    <option value="bottle">Bottle</option>
                                    <option value="packet">Packet</option>
                                    <option value="jar">Jar</option>
                                    <option value="sachet">Sachet</option>
                                    <option value="piece">Piece</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Initial Stock</label>
                                <input type="number" class="form-control" name="initial_stock" value="0">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Reorder Level</label>
                                <input type="number" class="form-control" name="reorder_level" value="10">
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Batch Number</label>
                                <input type="text" class="form-control" name="batch_number">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Expiry Date</label>
                                <input type="date" class="form-control" name="expiry_date">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save Remedy</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Sell Remedy Modal -->
    <div class="modal fade" id="sellRemedyModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title"><i class="fas fa-cash-register me-2"></i>Sell Remedy</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="sell_remedy">
                        <input type="hidden" name="remedy_id" id="sellRemedyId">
                        
                        <div class="mb-3">
                            <label class="form-label">Select Remedy *</label>
                            <select class="form-select" id="sellRemedySelect" required>
                                <option value="">Choose a remedy...</option>
                                <?php foreach($remedies as $remedy): ?>
                                    <option value="<?php echo $remedy['id']; ?>" 
                                            data-price="<?php echo $remedy['unit_price']; ?>"
                                            data-stock="<?php echo $remedy['quantity_in_stock']; ?>">
                                        <?php echo htmlspecialchars($remedy['name']); ?> 
                                        (KES <?php echo number_format($remedy['unit_price'], 0); ?> | 
                                        Stock: <?php echo $remedy['quantity_in_stock']; ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Quantity *</label>
                                <input type="number" class="form-control" name="quantity" id="sellQuantity" value="1" min="1" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Unit Price</label>
                                <input type="text" class="form-control" id="unitPriceDisplay" readonly>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Total Amount</label>
                            <div class="h4 text-success" id="totalAmount">KES 0.00</div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Customer Name</label>
                                <input type="text" class="form-control" name="customer_name">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Customer Phone</label>
                                <input type="tel" class="form-control" name="customer_phone">
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Payment Method</label>
                            <select class="form-select" name="payment_method">
                                <option value="cash">Cash</option>
                                <option value="mpesa">M-Pesa</option>
                                <option value="card">Card</option>
                                <option value="bank_transfer">Bank Transfer</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Complete Sale</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Restock Modal -->
    <div class="modal fade" id="restockModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-warning">
                    <h5 class="modal-title"><i class="fas fa-truck-loading me-2"></i>Restock Remedy</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="restock_remedy">
                        <input type="hidden" name="remedy_id" id="restockRemedyId">
                        
                        <div class="mb-3">
                            <label class="form-label">Select Remedy *</label>
                            <select class="form-select" id="restockRemedySelect" required>
                                <option value="">Choose a remedy...</option>
                                <?php foreach($remedies as $remedy): ?>
                                    <option value="<?php echo $remedy['id']; ?>">
                                        <?php echo htmlspecialchars($remedy['name']); ?> 
                                        (Current Stock: <?php echo $remedy['quantity_in_stock']; ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Quantity to Add *</label>
                                <input type="number" class="form-control" name="quantity_added" value="1" min="1" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Unit Cost (KES) *</label>
                                <input type="number" class="form-control" name="unit_cost" step="0.01" required>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Supplier Name</label>
                                <input type="text" class="form-control" name="supplier_name">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Supplier Contact</label>
                                <input type="text" class="form-control" name="supplier_contact">
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Batch Number</label>
                                <input type="text" class="form-control" name="batch_number">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Expiry Date</label>
                                <input type="date" class="form-control" name="expiry_date">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-warning">Restock</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Stock Chart
        const stockCtx = document.getElementById('stockChart').getContext('2d');
        const stockChart = new Chart(stockCtx, {
            type: 'doughnut',
            data: {
                labels: ['In Stock', 'Low Stock', 'Out of Stock'],
                datasets: [{
                    data: [
                        <?php echo $stats['total_remedies'] - $stats['low_stock']; ?>,
                        <?php echo $stats['low_stock']; ?>,
                        0
                    ],
                    backgroundColor: ['#28a745', '#ffc107', '#dc3545'],
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20
                        }
                    }
                }
            }
        });
        
        // Quick Sell function
        function quickSell(remedyId, remedyName) {
            document.getElementById('sellRemedyId').value = remedyId;
            const modal = new bootstrap.Modal(document.getElementById('sellRemedyModal'));
            modal.show();
            
            // Select the remedy in dropdown
            const select = document.getElementById('sellRemedySelect');
            for(let option of select.options) {
                if(option.value == remedyId) {
                    option.selected = true;
                    updateSaleCalculation();
                    break;
                }
            }
        }
        
        // Quick Restock function
        function quickRestock(remedyId, remedyName) {
            document.getElementById('restockRemedyId').value = remedyId;
            const modal = new bootstrap.Modal(document.getElementById('restockModal'));
            modal.show();
            
            // Select the remedy in dropdown
            const select = document.getElementById('restockRemedySelect');
            for(let option of select.options) {
                if(option.value == remedyId) {
                    option.selected = true;
                    break;
                }
            }
        }
        
        // Sale calculation
        function updateSaleCalculation() {
            const select = document.getElementById('sellRemedySelect');
            const selectedOption = select.options[select.selectedIndex];
            const unitPrice = selectedOption.dataset.price || 0;
            const stock = selectedOption.dataset.stock || 0;
            const quantity = document.getElementById('sellQuantity').value;
            
            document.getElementById('unitPriceDisplay').value = 'KES ' + parseFloat(unitPrice).toFixed(2);
            document.getElementById('totalAmount').textContent = 'KES ' + (unitPrice * quantity).toFixed(2);
            
            // Show stock warning
            if(quantity > stock) {
                document.getElementById('sellQuantity').classList.add('is-invalid');
            } else {
                document.getElementById('sellQuantity').classList.remove('is-invalid');
            }
        }
        
        // Initialize event listeners
        document.addEventListener('DOMContentLoaded', function() {
            // Sale calculation listeners
            document.getElementById('sellRemedySelect').addEventListener('change', updateSaleCalculation);
            document.getElementById('sellQuantity').addEventListener('input', updateSaleCalculation);
            
            // Form validation
            document.getElementById('sellRemedyModal').addEventListener('shown.bs.modal', function() {
                document.getElementById('sellRemedySelect').focus();
            });
            
            document.getElementById('addRemedyModal').addEventListener('shown.bs.modal', function() {
                document.querySelector('input[name="name"]').focus();
            });
        });
        
        // Auto-refresh every 60 seconds
        setTimeout(function() {
            window.location.reload();
        }, 60000);
    </script>
</body>
</html>