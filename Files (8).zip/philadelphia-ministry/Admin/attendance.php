<?php
// admin/attendance.php - Simple Attendance Tracking
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit();
}

// Simple database connection
function connectDB() {
    $host = 'localhost';
    $dbname = 'philadelphia_ministry';
    $username = 'root';
    $password = '';
    
    try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch(PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
}

$conn = connectDB();

// Handle attendance marking
if(isset($_POST['action'])) {
    if($_POST['action'] == 'mark_attendance') {
        $event_id = $_POST['event_id'];
        $member_id = $_POST['member_id'];
        $status = $_POST['status'];
        
        // Check if attendance already exists
        $stmt = $conn->prepare("SELECT * FROM attendance WHERE event_id = ? AND member_id = ?");
        $stmt->execute([$event_id, $member_id]);
        
        if($stmt->rowCount() > 0) {
            // Update existing
            $stmt = $conn->prepare("UPDATE attendance SET status = ?, checked_in = NOW() WHERE event_id = ? AND member_id = ?");
            $stmt->execute([$status, $event_id, $member_id]);
        } else {
            // Insert new
            $stmt = $conn->prepare("INSERT INTO attendance (event_id, member_id, status, checked_in) VALUES (?, ?, ?, NOW())");
            $stmt->execute([$event_id, $member_id, $status]);
        }
        
        $success = "Attendance marked successfully!";
    }
}

// Get events for dropdown - FIXED: Use ministry_events table
$stmt = $conn->query("SELECT id, title, start_date FROM ministry_events WHERE start_date >= CURDATE() ORDER BY start_date");
$events = $stmt->fetchAll();

// Get members
$stmt = $conn->query("SELECT id, CONCAT(first_name, ' ', last_name) as full_name, membership_number FROM members WHERE is_active = 1 ORDER BY first_name");
$members = $stmt->fetchAll();

// Get attendance records
$selected_event = isset($_GET['event_id']) ? $_GET['event_id'] : (count($events) > 0 ? $events[0]['id'] : 0);
$attendance_records = [];

if($selected_event) {
    $stmt = $conn->prepare("
        SELECT a.*, m.first_name, m.last_name, m.membership_number, 
               CONCAT(m.first_name, ' ', m.last_name) as full_name
        FROM attendance a
        LEFT JOIN members m ON a.member_id = m.id
        WHERE a.event_id = ?
        ORDER BY a.checked_in DESC
    ");
    $stmt->execute([$selected_event]);
    $attendance_records = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance - Philadelphia Ministry</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body { background-color: #f8f9fa; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .navbar { background: linear-gradient(135deg, #1a5276 0%, #2c3e50 100%); }
        .main-content { padding: 25px; }
        .stat-card { border-radius: 12px; border: none; box-shadow: 0 4px 15px rgba(0,0,0,0.08); margin-bottom: 1.5rem; }
        .table th { background-color: #f8f9fa; border-bottom: 2px solid #1a5276; }
        .badge-present { background-color: #28a745; }
        .badge-absent { background-color: #dc3545; }
        .badge-late { background-color: #ffc107; color: #000; }
        .attendance-btn { width: 100px; }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-church me-2"></i>
                Philadelphia Ministry - Attendance
            </a>
            <div class="navbar-text text-white">
                <a href="dashboard.php" class="text-white text-decoration-none me-3">Dashboard</a>
                | <a href="logout.php" class="text-warning text-decoration-none">Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container-fluid">
        <div class="row">
            <!-- Simple Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 d-print-none">
                <div class="bg-dark text-white p-3" style="min-height: calc(100vh - 56px);">
                    <h5 class="mb-4">Navigation</h5>
                    <a href="dashboard.php" class="d-block text-white mb-2">Dashboard</a>
                    <a href="registrations.php" class="d-block text-white mb-2">Registrations</a>
                    <a href="members.php" class="d-block text-white mb-2">Members</a>
                    <a href="events_admin.php" class="d-block text-white mb-2">Events</a>
                    <a href="attendance.php" class="d-block text-white mb-2 text-primary">Attendance</a>
                    <a href="reports.php" class="d-block text-white mb-2">Reports</a>
                    <hr class="bg-light">
                    <a href="../index.php" target="_blank" class="d-block text-white mb-2">View Site</a>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 px-0">
                <div class="main-content">
                    <!-- Page Header -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div>
                            <h2 class="mb-1"><i class="fas fa-clipboard-check text-primary me-2"></i>Attendance Tracking</h2>
                            <p class="text-muted mb-0">Track member attendance for events</p>
                        </div>
                        <div>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#markAttendanceModal">
                                <i class="fas fa-user-check me-2"></i>Mark Attendance
                            </button>
                        </div>
                    </div>
                    
                    <?php if(isset($success)): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <?php echo $success; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Event Selection -->
                    <div class="card stat-card mb-4">
                        <div class="card-body">
                            <h5 class="card-title mb-3"><i class="fas fa-calendar-alt me-2"></i>Select Event</h5>
                            <form method="GET" class="row g-3">
                                <div class="col-md-8">
                                    <select class="form-select" name="event_id" onchange="this.form.submit()">
                                        <option value="">Select an event...</option>
                                        <?php foreach($events as $event): ?>
                                            <option value="<?php echo $event['id']; ?>" <?php echo $selected_event == $event['id'] ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($event['title']); ?> 
                                                (<?php echo date('M d, Y', strtotime($event['start_date'])); ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="fas fa-filter me-2"></i>View Attendance
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <!-- Attendance Summary -->
                    <?php if($selected_event): ?>
                        <?php
                        // Get event details
                        $stmt = $conn->prepare("SELECT title, start_date, location FROM ministry_events WHERE id = ?");
                        $stmt->execute([$selected_event]);
                        $event_details = $stmt->fetch();
                        
                        // Calculate attendance stats
                        $present = $absent = $late = 0;
                        foreach($attendance_records as $record) {
                            switch($record['status']) {
                                case 'present': $present++; break;
                                case 'absent': $absent++; break;
                                case 'late': $late++; break;
                            }
                        }
                        $total_marked = $present + $absent + $late;
                        ?>
                        
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <div class="card stat-card">
                                    <div class="card-body">
                                        <h5 class="card-title">
                                            <i class="fas fa-calendar-check me-2"></i>
                                            <?php echo htmlspecialchars($event_details['title'] ?? 'Selected Event'); ?>
                                            <small class="text-muted ms-2">
                                                <?php echo date('M d, Y', strtotime($event_details['start_date'] ?? '')); ?>
                                            </small>
                                        </h5>
                                        <div class="row text-center">
                                            <div class="col-md-3">
                                                <div class="stat-number text-success"><?php echo $present; ?></div>
                                                <div class="stat-label">Present</div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="stat-number text-danger"><?php echo $absent; ?></div>
                                                <div class="stat-label">Absent</div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="stat-number text-warning"><?php echo $late; ?></div>
                                                <div class="stat-label">Late</div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="stat-number text-primary"><?php echo $total_marked; ?></div>
                                                <div class="stat-label">Total Marked</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Attendance Records Table -->
                        <div class="card stat-card">
                            <div class="card-body">
                                <h5 class="card-title mb-3">
                                    <i class="fas fa-list-check me-2"></i>
                                    Attendance Records
                                    <span class="badge bg-primary"><?php echo count($attendance_records); ?></span>
                                </h5>
                                
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Member ID</th>
                                                <th>Name</th>
                                                <th>Status</th>
                                                <th>Checked In</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if(count($attendance_records) > 0): ?>
                                                <?php foreach($attendance_records as $record): ?>
                                                <tr>
                                                    <td>
                                                        <span class="badge bg-secondary">
                                                            <?php echo htmlspecialchars($record['membership_number'] ?? 'N/A'); ?>
                                                        </span>
                                                    </td>
                                                    <td><?php echo htmlspecialchars($record['full_name']); ?></td>
                                                    <td>
                                                        <?php
                                                        $badge_class = '';
                                                        switch($record['status']) {
                                                            case 'present': $badge_class = 'bg-success'; break;
                                                            case 'absent': $badge_class = 'bg-danger'; break;
                                                            case 'late': $badge_class = 'bg-warning'; break;
                                                            default: $badge_class = 'bg-secondary';
                                                        }
                                                        ?>
                                                        <span class="badge <?php echo $badge_class; ?>">
                                                            <?php echo ucfirst($record['status']); ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <?php if($record['checked_in']): ?>
                                                            <?php echo date('M d, Y h:i A', strtotime($record['checked_in'])); ?>
                                                        <?php else: ?>
                                                            <span class="text-muted">Not checked in</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <button class="btn btn-sm btn-warning" onclick="editAttendance(<?php echo $record['id']; ?>)">
                                                            <i class="fas fa-edit"></i> Edit
                                                        </button>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            <?php else: ?>
                                                <tr>
                                                    <td colspan="5" class="text-center py-4">
                                                        <i class="fas fa-clipboard-list fa-2x text-muted mb-3"></i>
                                                        <h5 class="text-muted">No Attendance Records</h5>
                                                        <p class="text-muted">Mark attendance for members using the "Mark Attendance" button.</p>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="card stat-card">
                            <div class="card-body text-center py-5">
                                <i class="fas fa-calendar-alt fa-3x text-muted mb-3"></i>
                                <h4 class="text-muted">Select an Event</h4>
                                <p class="text-muted">Choose an event from the dropdown above to view and manage attendance.</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Mark Attendance Modal -->
    <div class="modal fade" id="markAttendanceModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fas fa-user-check me-2"></i>Mark Attendance</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="mark_attendance">
                        
                        <div class="mb-3">
                            <label class="form-label">Event *</label>
                            <select class="form-select" name="event_id" required>
                                <option value="">Select Event</option>
                                <?php foreach($events as $event): ?>
                                    <option value="<?php echo $event['id']; ?>">
                                        <?php echo htmlspecialchars($event['title']); ?> 
                                        (<?php echo date('M d, Y', strtotime($event['start_date'])); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Member *</label>
                            <select class="form-select" name="member_id" required>
                                <option value="">Select Member</option>
                                <?php foreach($members as $member): ?>
                                    <option value="<?php echo $member['id']; ?>">
                                        <?php echo htmlspecialchars($member['full_name']); ?> 
                                        (<?php echo htmlspecialchars($member['membership_number']); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Status *</label>
                            <select class="form-select" name="status" required>
                                <option value="present">Present</option>
                                <option value="absent">Absent</option>
                                <option value="late">Late</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Mark Attendance</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        function editAttendance(attendanceId) {
            // For now, just show a message
            alert('Edit functionality will be added here. Attendance ID: ' + attendanceId);
            // In a full implementation, you would:
            // 1. Fetch attendance details via AJAX
            // 2. Populate an edit modal
            // 3. Submit changes
        }
        
        // Auto-refresh attendance list every 30 seconds
        setInterval(function() {
            if(window.location.search.includes('event_id=')) {
                window.location.reload();
            }
        }, 30000);
    </script>
</body>
</html>