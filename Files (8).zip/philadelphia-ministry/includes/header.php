<?php
// includes/header.php
session_start();

// Define a constant to allow access from valid entry points
// Only define it if not already defined
if (!defined('ALLOW_INCLUDE')) {
    // Check if this is being accessed directly
    $direct_access = strpos($_SERVER['PHP_SELF'], basename(__FILE__)) !== false;
    if ($direct_access) {
        die('Direct access not permitted');
    }
}

// Simple database connection for testing
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'philadelphia_ministry';

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    // Don't die, just show error in development
    if (isset($_GET['debug'])) {
        die("Database connection failed: " . $conn->connect_error);
    } else {
        // Silent failure for production
        error_log("Database connection failed: " . $conn->connect_error);
    }
} else {
    $conn->set_charset("utf8mb4");
}


// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Debug: Check if we can see this
echo "<!-- Header.php loaded successfully -->";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Philadelphia Ministry</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar-brand {
            font-weight: bold;
        }
        .main-banner {
            background: linear-gradient(135deg, #3498db, #2980b9);
            color: white;
            padding: 100px 0;
            text-align: center;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="../">
                <i class="fas fa-church text-primary"></i>
                Philadelphia Ministry
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../">Nyumbani</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../remedies/">Remedies</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../pages/about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../pages/contact.php">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../members/login.php">
                            <i class="fas fa-sign-in-alt"></i> Login
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <!-- Debug info -->
    <div style="display:none;">
        <p>Session ID: <?php echo session_id(); ?></p>
        <p>User ID: <?php echo $_SESSION['user_id'] ?? 'Not logged in'; ?></p>
    </div>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Philadelphia Ministry - A community of believers dedicated to serving God and transforming lives">
    <meta name="author" content="Philadelphia Ministry">
    
    <title>Philadelphia Ministry - <?php echo isset($pageTitle) ? $pageTitle : 'Home'; ?></title>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Playfair+Display:wght@400;500;600&display=swap" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom Styles -->
    <style>
        :root {
            --primary-color: #1a4a8f;
            --secondary-color: #2a6fdb;
            --accent-color: #f8c300;
            --light-color: #f8f9fa;
            --dark-color: #343a40;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            padding-top: 80px;
        }
        
        /* Professional Header */
        .main-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1030;
            padding: 15px 0;
            transition: all 0.3s ease;
        }
        
        .header-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .navbar-brand {
            font-family: 'Playfair Display', serif;
            font-size: 28px;
            font-weight: 600;
            color: white !important;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .navbar-brand .church-icon {
            background: var(--accent-color);
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-color);
            font-size: 20px;
        }
        
        .navbar-brand .brand-text {
            display: flex;
            flex-direction: column;
            line-height: 1.2;
        }
        
        .navbar-brand .brand-main {
            font-size: 24px;
            font-weight: 700;
        }
        
        .navbar-brand .brand-sub {
            font-size: 12px;
            opacity: 0.9;
            font-weight: 300;
            font-family: 'Poppins', sans-serif;
        }
        
        .nav-link {
            color: rgba(255,255,255,0.9) !important;
            font-weight: 500;
            padding: 8px 16px !important;
            margin: 0 5px;
            border-radius: 6px;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .nav-link:hover, .nav-link.active {
            color: white !important;
            background: rgba(255,255,255,0.1);
            transform: translateY(-2px);
        }
        
        .nav-link::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 2px;
            background: var(--accent-color);
            transition: width 0.3s ease;
        }
        
        .nav-link:hover::after, .nav-link.active::after {
            width: 20px;
        }
        
        .dropdown-menu {
            background: white;
            border: none;
            border-radius: 8px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            margin-top: 10px;
            padding: 10px 0;
            animation: fadeIn 0.3s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .dropdown-item {
            color: var(--dark-color);
            padding: 10px 20px;
            font-weight: 500;
            transition: all 0.2s ease;
            border-left: 3px solid transparent;
        }
        
        .dropdown-item:hover {
            background: var(--light-color);
            color: var(--primary-color);
            border-left-color: var(--accent-color);
            padding-left: 25px;
        }
        
        .dropdown-item i {
            width: 20px;
            text-align: center;
            margin-right: 10px;
            color: var(--secondary-color);
        }
        
        .quick-actions {
            display: flex;
            gap: 10px;
            margin-left: 20px;
        }
        
        .btn-header {
            padding: 8px 20px;
            border-radius: 6px;
            font-weight: 500;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }
        
        .btn-login {
            background: var(--accent-color);
            color: var(--primary-color);
            border: none;
        }
        
        .btn-login:hover {
            background: white;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .btn-register {
            background: transparent;
            color: white;
            border: 2px solid white;
        }
        
        .btn-register:hover {
            background: white;
            color: var(--primary-color);
            transform: translateY(-2px);
        }
        
        /* Mobile Menu Button */
        .navbar-toggler {
            border: none;
            padding: 8px;
            color: white;
            font-size: 24px;
            background: transparent;
        }
        
        .navbar-toggler:focus {
            box-shadow: none;
            outline: none;
        }
        
        /* Mobile Menu */
        @media (max-width: 991px) {
            body {
                padding-top: 70px;
            }
            
            .navbar-collapse {
                background: white;
                padding: 20px;
                border-radius: 10px;
                margin-top: 15px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            }
            
            .nav-link {
                color: var(--dark-color) !important;
                padding: 12px 0 !important;
                border-bottom: 1px solid #eee;
            }
            
            .dropdown-menu {
                box-shadow: none;
                border-left: 3px solid var(--accent-color);
                margin: 10px 0;
                padding-left: 20px;
            }
            
            .quick-actions {
                margin: 20px 0 0 0;
                flex-direction: column;
            }
        }
        
        /* Header Scrolled Effect */
        .main-header.scrolled {
            padding: 10px 0;
            backdrop-filter: blur(10px);
            background: rgba(26, 74, 143, 0.95);
        }
    </style>
    
    <!-- Page-specific CSS -->
    <?php if(isset($pageStyles)) echo $pageStyles; ?>
</head>
<body>
    <!-- Professional Header -->
    <header class="main-header">
        <div class="header-container">
            <nav class="navbar navbar-expand-lg">
                <div class="container-fluid">
                    <!-- Logo -->
                    <a class="navbar-brand" href="index.php">
                        <div class="church-icon">
                            <i class="fas fa-church"></i>
                        </div>
                        <div class="brand-text">
                            <span class="brand-main">Philadelphia Ministry</span>
                            <span class="brand-sub">"A community of faith and service"</span>
                        </div>
                    </a>
                    
                    <!-- Mobile Toggle -->
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
                        <i class="fas fa-bars"></i>
                    </button>
                    
                    <!-- Navigation Menu -->
                    <div class="collapse navbar-collapse" id="mainNavbar">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>" href="index.php">
                                    <i class="fas fa-home"></i> Home
                                </a>
                            </li>
                            
                            <!-- About Us Dropdown -->
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                    <i class="fas fa-info-circle"></i> About Us
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="pages/about.php"><i class="fas fa-church"></i> About Our Ministry</a></li>
                                    <li><a class="dropdown-item" href="pages/leadership.php"><i class="fas fa-users"></i> Leadership Team</a></li>
                                    <li><a class="dropdown-item" href="pages/vision.php"><i class="fas fa-eye"></i> Vision & Mission</a></li>
                                    <li><a class="dropdown-item" href="pages/gallery.php"><i class="fas fa-images"></i> Photo Gallery</a></li>
                                </ul>
                            </li>
                            
                            <!-- Ministries Dropdown -->
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                    <i class="fas fa-hands-praying"></i> Ministries
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="pages/ministry.php"><i class="fas fa-compass"></i> All Ministries</a></li>
                                    <li><a class="dropdown-item" href="music/"><i class="fas fa-music"></i> Music Ministry</a></li>
                                    <li><a class="dropdown-item" href="pages/bible-studies.php"><i class="fas fa-bible"></i> Bible Studies</a></li>
                                    <li><a class="dropdown-item" href="pages/outreach.php"><i class="fas fa-hands-helping"></i> Outreach</a></li>
                                    <li><a class="dropdown-item" href="pages/youth.php"><i class="fas fa-child"></i> Youth Ministry</a></li>
                                </ul>
                            </li>
                            
                            <!-- Events -->
                            <li class="nav-item">
                                <a class="nav-link" href="events/">
                                    <i class="fas fa-calendar-alt"></i> Events
                                </a>
                            </li>
                            
                            <!-- Resources Dropdown -->
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                    <i class="fas fa-book"></i> Resources
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="pages/songs.php"><i class="fas fa-music"></i> Songs & Hymns</a></li>
                                    <li><a class="dropdown-item" href="pages/bible-studies.php"><i class="fas fa-book-open"></i> Bible Studies</a></li>
                                    <li><a class="dropdown-item" href="pages/publications.php"><i class="fas fa-newspaper"></i> Publications</a></li>
                                    <li><a class="dropdown-item" href="pages/contributions.php"><i class="fas fa-hand-holding-heart"></i> Giving</a></li>
                                </ul>
                            </li>
                            
                            <!-- Contact -->
                            <li class="nav-item">
                                <a class="nav-link" href="pages/contact.php">
                                    <i class="fas fa-envelope"></i> Contact
                                </a>
                            </li>
                        </ul>
                        
                        <!-- Quick Action Buttons -->
                        <div class="quick-actions">
                            <?php if (isset($_SESSION['user_id'])): ?>
                                <a href="members/dashboard.php" class="btn btn-header btn-login">
                                    <i class="fas fa-user-circle"></i> My Account
                                </a>
                            <?php else: ?>
                                <a href="members/login.php" class="btn btn-header btn-login">
                                    <i class="fas fa-sign-in-alt"></i> Member Login
                                </a>
                            <?php endif; ?>
                            
                            <a href="events/register.php" class="btn btn-header btn-register">
                                <i class="fas fa-calendar-plus"></i> Register
                            </a>
                        </div>
                    </div>
                </div>
            </nav>
        </div>
    </header>

    <!-- Main Content Area -->
    <main class="main-content">
    
    <!-- JavaScript for Header Effects -->
    <script>
    // Header scroll effect
    window.addEventListener('scroll', function() {
        const header = document.querySelector('.main-header');
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
    
    // Close mobile menu when clicking outside
    document.addEventListener('click', function(event) {
        const navbar = document.getElementById('mainNavbar');
        const toggler = document.querySelector('.navbar-toggler');
        
        if (navbar.classList.contains('show') && 
            !navbar.contains(event.target) && 
            !toggler.contains(event.target)) {
            const bsCollapse = new bootstrap.Collapse(navbar);
            bsCollapse.hide();
        }
    });
    
    // Active menu item highlight
    document.addEventListener('DOMContentLoaded', function() {
        const currentPage = window.location.pathname.split('/').pop();
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            const linkPage = link.getAttribute('href');
            if (linkPage === currentPage || 
                (currentPage === '' && linkPage === 'index.php')) {
                link.classList.add('active');
            }
        });
    });
    </script>