<?php
// includes/footer.php
?>
    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>Philadelphia Ministry</h5>
                    <p>Transforming lives through Christ's love since 2021. A community dedicated to discipleship, fellowship, and service.</p>
                </div>
                <div class="col-md-4">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="events/index.php">Events</a></li>
                        <li><a href="members/login.php">Members</a></li>
                        <li><a href="pages/contributions.php">Give</a></li>
                        <li><a href="pages/contact.php">Contact</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Connect With Us</h5>
                    <p><i class="fas fa-envelope"></i> info@philadelphiaministry.org</p>
                    <p><i class="fas fa-phone"></i> +254 769 228 426</p>
                    <p><i class="fas fa-map-marker-alt"></i> Ministry Headquarters</p>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-12 text-center">
                    <p><i class="fa fa-copyright"></i> <?php echo date('Y'); ?> Philadelphia Ministry</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
    
    <?php if(isset($pageScripts)) echo $pageScripts; ?>
    
</body>
</html>