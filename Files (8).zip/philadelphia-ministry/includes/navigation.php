<!-- Add this to your existing navigation menu -->
<li class="nav-item">
    <a class="nav-link" href="/philadelphia-ministry/pages/music.php">
        <i class="fas fa-music"></i> Music Department
    </a>
</li>
<li class="nav-item">
    <a class="nav-link" href="/philadelphia-ministry/remedies/">Remedies</a>
</li>
<!-- Add this to your main navigation -->
<li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="remediesDropdown" role="button" 
       data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Remedies
    </a>
    <div class="dropdown-menu" aria-labelledby="remediesDropdown">
        <a class="dropdown-item" href="/philadelphia-ministry/remedies/">Overview</a>
        <a class="dropdown-item" href="/philadelphia-ministry/remedies/treatments/">Treatments</a>
        <a class="dropdown-item" href="/philadelphia-ministry/remedies/consultations/">Consultations</a>
        <a class="dropdown-item" href="/philadelphia-ministry/remedies/store/">Remedies Store</a>
        <a class="dropdown-item" href="/philadelphia-ministry/remedies/education/">Health Education</a>
        <a class="dropdown-item" href="/philadelphia-ministry/remedies/medical-missionary/">Medical Missionary</a>
        <a class="dropdown-item" href="/philadelphia-ministry/remedies/patient-portal/">Patient Portal</a>
        <?php if(isRemediesAdmin($_SESSION['user_id'] ?? 0)): ?>
        <div class="dropdown-divider"></div>
        <a class="dropdown-item" href="/philadelphia-ministry/remedies/admin/">
            <i class="fas fa-cog"></i> Admin Panel
        </a>
        <?php endif; ?>
    </div>
    <?php
/**
 * Main Navigation File
 * Updated to include Remedies Department
 */

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);
$userRole = $_SESSION['user_role'] ?? 'guest';
$userName = $_SESSION['full_name'] ?? '';

// Function to check if user is remedies admin
function isRemediesAdmin($userId) {
    global $conn;
    if (!$userId) return false;
    
    $query = "SELECT role FROM members WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        return in_array($row['role'], ['admin', 'super_admin', 'remedies_admin']);
    }
    
    return false;
}

// Check remedies access
$hasRemediesAccess = $isLoggedIn && validateRemediesAccess($_SESSION['user_id'] ?? 0, 'patient');
$isRemediesAdminUser = $isLoggedIn && isRemediesAdmin($_SESSION['user_id'] ?? 0);
?>

<!-- Main Navigation -->
<nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top">
    <div class="container">
        <!-- Logo -->
        <a class="navbar-brand" href="/philadelphia-ministry/">
            <img src="assets/images/logo.png" alt="Philadelphia Ministry" height="50">
        </a>
        
        <!-- Mobile Toggle -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mainNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <!-- Navigation Links -->
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav ml-auto">
                <!-- Home -->
                <li class="nav-item">
                    <a class="nav-link" href="/philadelphia-ministry/">Home</a>
                </li>
                
                <!-- About -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="aboutDropdown" data-toggle="dropdown">
                        About Us
                    </a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="/philadelphia-ministry/pages/about.php">Our Story</a>
                        <a class="dropdown-item" href="/philadelphia-ministry/pages/vision.php">Vision & Mission</a>
                        <a class="dropdown-item" href="/philadelphia-ministry/pages/leadership.php">Leadership</a>
                        <a class="dropdown-item" href="/philadelphia-ministry/pages/ministry.php">Ministries</a>
                    </div>
                </li>
                
                <!-- Ministries -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="ministryDropdown" data-toggle="dropdown">
                        Ministries
                    </a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="/philadelphia-ministry/pages/bible-studies.php">Bible Studies</a>
                        <a class="dropdown-item" href="/philadelphia-ministry/pages/mentorship.php">Mentorship</a>
                        <a class="dropdown-item" href="/philadelphia-ministry/pages/outreach.php">Outreach</a>
                        <a class="dropdown-item" href="/philadelphia-ministry/pages/worship.php">Worship</a>
                    </div>
                </li>
                
                <!-- REMEDIES DEPARTMENT -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="remediesDropdown" data-toggle="dropdown">
                        <i class="fas fa-heartbeat text-danger"></i> Remedies
                    </a>
                    <div class="dropdown-menu">
                        <h6 class="dropdown-header text-primary">
                            <i class="fas fa-clinic-medical"></i> Natural Health Center
                        </h6>
                        <a class="dropdown-item" href="/philadelphia-ministry/remedies/">
                            <i class="fas fa-home"></i> Overview
                        </a>
                        <a class="dropdown-item" href="/philadelphia-ministry/remedies/treatments/">
                            <i class="fas fa-spa"></i> Treatments
                        </a>
                        <a class="dropdown-item" href="/philadelphia-ministry/remedies/consultations/">
                            <i class="fas fa-user-md"></i> Consultations
                        </a>
                        <a class="dropdown-item" href="/philadelphia-ministry/remedies/store/">
                            <i class="fas fa-shopping-basket"></i> Remedies Store
                        </a>
                        <a class="dropdown-item" href="/philadelphia-ministry/remedies/education/">
                            <i class="fas fa-graduation-cap"></i> Health Education
                        </a>
                        <a class="dropdown-item" href="/philadelphia-ministry/remedies/medical-missionary/">
                            <i class="fas fa-hands-helping"></i> Medical Missionary
                        </a>
                        
                        <?php if($hasRemediesAccess): ?>
                        <div class="dropdown-divider"></div>
                        <h6 class="dropdown-header text-success">
                            <i class="fas fa-user-circle"></i> My Account
                        </h6>
                        <a class="dropdown-item" href="/philadelphia-ministry/remedies/patient-portal/">
                            <i class="fas fa-tachometer-alt"></i> Patient Portal
                        </a>
                        <a class="dropdown-item" href="/philadelphia-ministry/remedies/patient-portal/my-appointments.php">
                            <i class="fas fa-calendar-check"></i> My Appointments
                        </a>
                        <a class="dropdown-item" href="/philadelphia-ministry/remedies/patient-portal/medical-records.php">
                            <i class="fas fa-file-medical"></i> Medical Records
                        </a>
                        <?php endif; ?>
                        
                        <?php if($isRemediesAdminUser): ?>
                        <div class="dropdown-divider"></div>
                        <h6 class="dropdown-header text-warning">
                            <i class="fas fa-cogs"></i> Administration
                        </h6>
                        <a class="dropdown-item" href="/philadelphia-ministry/remedies/admin/">
                            <i class="fas fa-tachometer-alt"></i> Admin Dashboard
                        </a>
                        <a class="dropdown-item" href="/philadelphia-ministry/remedies/admin/manage-bookings.php">
                            <i class="fas fa-calendar-alt"></i> Manage Bookings
                        </a>
                        <a class="dropdown-item" href="/philadelphia-ministry/remedies/admin/manage-products.php">
                            <i class="fas fa-boxes"></i> Manage Products
                        </a>
                        <?php endif; ?>
                    </div>
                </li>
                
                <!-- Events -->
                <li class="nav-item">
                    <a class="nav-link" href="/philadelphia-ministry/events/">Events</a>
                </li>
                
                <!-- Resources -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="resourcesDropdown" data-toggle="dropdown">
                        Resources
                    </a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="/philadelphia-ministry/pages/songs.php">Songs</a>
                        <a class="dropdown-item" href="/philadelphia-ministry/pages/publications.php">Publications</a>
                        <a class="dropdown-item" href="/philadelphia-ministry/pages/gallery.php">Gallery</a>
                        <a class="dropdown-item" href="/philadelphia-ministry/pages/updates.php">Updates</a>
                    </div>
                </li>
                
                <!-- Contact -->
                <li class="nav-item">
                    <a class="nav-link" href="/philadelphia-ministry/pages/contact.php">Contact</a>
                </li>
                
                <!-- User Menu -->
                <?php if($isLoggedIn): ?>
                <li class="nav-item dropdown ml-3">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" data-toggle="dropdown">
                        <i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($userName); ?>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item" href="/philadelphia-ministry/members/dashboard.php">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                        <a class="dropdown-item" href="/philadelphia-ministry/members/profile.php">
                            <i class="fas fa-user"></i> Profile
                        </a>
                        
                        <?php if($hasRemediesAccess): ?>
                        <a class="dropdown-item" href="/philadelphia-ministry/remedies/patient-portal/">
                            <i class="fas fa-heartbeat"></i> Health Portal
                        </a>
                        <?php endif; ?>
                        
                        <div class="dropdown-divider"></div>
                        
                        <?php if($_SESSION['user_role'] == 'admin' || $_SESSION['user_role'] == 'super_admin'): ?>
                        <a class="dropdown-item" href="/philadelphia-ministry/admin/">
                            <i class="fas fa-cog"></i> Admin Panel
                        </a>
                        <div class="dropdown-divider"></div>
                        <?php endif; ?>
                        
                        <a class="dropdown-item" href="/philadelphia-ministry/members/logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </li>
                <?php else: ?>
                <li class="nav-item ml-3">
                    <a class="btn btn-primary" href="/philadelphia-ministry/members/login.php">
                        <i class="fas fa-sign-in-alt"></i> Login
                    </a>
                </li>
                <li class="nav-item ml-2">
                    <a class="btn btn-outline-primary" href="/philadelphia-ministry/pages/join.php">
                        <i class="fas fa-user-plus"></i> Join
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<!-- Emergency Alert Banner -->
<?php if($hasRemediesAccess): ?>
<div class="emergency-banner bg-danger text-white text-center py-2">
    <div class="container">
        <i class="fas fa-phone-alt"></i> 
        Remedies Emergency: <strong><?php echo REMEDIES_PHONE; ?></strong> | 
        <a href="/philadelphia-ministry/remedies/treatments/book-treatment.php" class="text-white ml-3">
            <i class="fas fa-calendar-plus"></i> Book Urgent Appointment
        </a>
    </div>
</div>
<?php endif; ?>

<style>
/* Navigation Styles */
.navbar {
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    padding: 10px 0;
}

.navbar-brand img {
    height: 50px;
    transition: transform 0.3s ease;
}

.navbar-brand img:hover {
    transform: scale(1.05);
}

.nav-link {
    font-weight: 500;
    padding: 10px 15px !important;
    transition: all 0.3s ease;
}

.nav-link:hover {
    color: #3498db !important;
}

.nav-link.active {
    color: #3498db !important;
    font-weight: 600;
}

.dropdown-menu {
    border: none;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    border-radius: 8px;
    padding: 10px 0;
    min-width: 220px;
}

.dropdown-item {
    padding: 10px 20px;
    color: #5d6d7e;
    transition: all 0.3s ease;
}

.dropdown-item:hover {
    background: #f8f9fa;
    color: #3498db;
    padding-left: 25px;
}

.dropdown-header {
    font-size: 0.8rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    padding: 10px 20px;
}

.dropdown-divider {
    margin: 10px 0;
}

.emergency-banner {
    position: sticky;
    top: 0;
    z-index: 1000;
    animation: pulse 2s infinite;
}

.emergency-banner a {
    text-decoration: underline;
}

.emergency-banner a:hover {
    text-decoration: none;
    opacity: 0.9;
}

@keyframes pulse {
    0% { opacity: 1; }
    50% { opacity: 0.8; }
    100% { opacity: 1; }
}

/* Mobile Responsiveness */
@media (max-width: 991px) {
    .navbar-nav {
        padding: 20px 0;
    }
    
    .nav-item {
        margin-bottom: 5px;
    }
    
    .dropdown-menu {
        box-shadow: none;
        border: 1px solid #eee;
        margin-left: 15px;
    }
    
    .btn {
        width: 100%;
        margin: 5px 0;
    }
}
</style>

<script>
$(document).ready(function() {
    // Add active class to current page
    var currentPage = window.location.pathname;
    $('.nav-link').each(function() {
        var linkPage = $(this).attr('href');
        if (currentPage === linkPage || 
            (linkPage !== '/' && currentPage.includes(linkPage.replace('/philadelphia-ministry/', '')))) {
            $(this).addClass('active');
            $(this).parents('.dropdown').find('.dropdown-toggle').addClass('active');
        }
    });
    
    // Smooth dropdown animation
    $('.dropdown').on('show.bs.dropdown', function() {
        $(this).find('.dropdown-menu').first().stop(true, true).slideDown(200);
    });
    
    $('.dropdown').on('hide.bs.dropdown', function() {
        $(this).find('.dropdown-menu').first().stop(true, true).slideUp(200);
    });
    
    // Mobile menu close on click
    $('.navbar-nav a').on('click', function() {
        $('.navbar-collapse').collapse('hide');
    });
});
</script>