<?php
// config.php
define('APP_ROOT', dirname(__DIR__));
define('APP_ENV', 'development'); // Change to 'production' when live

// Only allow direct access to config.php itself
if (basename($_SERVER['PHP_SELF']) === 'config.php') {
    die('Direct access not permitted');
}

// Now this file can be safely included anywhere
?>