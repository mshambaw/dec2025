<?php
// includes/db_connect.php - Universal database connection file

function getDBConnection() {
    static $conn = null;
    
    if ($conn === null) {
        $host = "localhost";
        $db_name = "philadelphia_ministry";
        $username = "root";
        $password = "";
        
        try {
            $conn = new PDO(
                "mysql:host=" . $host . ";dbname=" . $db_name,
                $username,
                $password
            );
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $conn->exec("set names utf8");
        } catch(PDOException $exception) {
            die("Database connection error: " . $exception->getMessage());
        }
    }
    
    return $conn;
}

// Alternative: Direct connection for quick use
function db() {
    return getDBConnection();
}
?>