<?php
// events/register.php
session_start();
$pageTitle = "Event Registration";
require_once '../includes/header.php';
require_once '../config/database.php';

$db = new Database();
$conn = $db->getConnection();

// Get event details if event_id is provided
$event = null;
$registration_closed = false;
$max_reached = false;

if (isset($_GET['event_id'])) {
    $event_id = intval($_GET['event_id']);
    $stmt = $conn->prepare("SELECT * FROM ministry_events WHERE id = ?");
    $stmt->execute([$event_id]);
    $event = $stmt->fetch();
    
    if ($event) {
        // Check if registration is closed (event passed)
        if (strtotime($event['end_date']) < time()) {
            $registration_closed = true;
        }
        
        // Check if max participants reached
        $stmt = $conn->prepare("SELECT COUNT(*) as registered FROM event_registrations WHERE event_id = ?");
        $stmt->execute([$event_id]);
        $registered_count = $stmt->fetch()['registered'];
        
        if ($event['max_participants'] > 0 && $registered_count >= $event['max_participants']) {
            $max_reached = true;
        }
    }
}

// Get all upcoming events for dropdown
$stmt = $conn->prepare("SELECT id, title, start_date, end_date, location FROM ministry_events 
                       WHERE status = 'upcoming' AND end_date >= CURDATE() 
                       ORDER BY start_date");
$stmt->execute();
$upcoming_events = $stmt->fetchAll();

// Registration success/error messages
$success_msg = '';
$error_msg = '';
$form_data = [];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form_data = [
        'event_id' => $_POST['event_id'] ?? '',
        'full_name' => trim($_POST['full_name'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'phone' => trim($_POST['phone'] ?? ''),
        'gender' => $_POST['gender'] ?? '',
        'age_group' => $_POST['age_group'] ?? '',
        'year_group' => $_POST['year_group'] ?? '',
        'emergency_contact' => trim($_POST['emergency_contact'] ?? ''),
        'dietary_requirements' => trim($_POST['dietary_requirements'] ?? ''),
        'special_needs' => trim($_POST['special_needs'] ?? ''),
        'church_member' => $_POST['church_member'] ?? 'no',
        'previous_mission' => $_POST['previous_mission'] ?? 'no',
        'expectations' => trim($_POST['expectations'] ?? '')
    ];
    
    // Validate form data
    $errors = [];
    
    if (empty($form_data['event_id'])) {
        $errors[] = "Please select an event";
    }
    
    if (empty($form_data['full_name'])) {
        $errors[] = "Full name is required";
    }
    
    if (empty($form_data['email'])) {
        $errors[] = "Email address is required";
    } elseif (!filter_var($form_data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address";
    }
    
    if (empty($form_data['phone'])) {
        $errors[] = "Phone number is required";
    }
    
    if (empty($form_data['emergency_contact'])) {
        $errors[] = "Emergency contact is required";
    }
    
    // If no validation errors, save to database
    if (empty($errors)) {
        try {
            $conn->beginTransaction();
            
            // Generate unique registration code
            $registration_code = 'PM' . date('Ymd') . strtoupper(substr(uniqid(), -6));
            
            // Save registration
            $stmt = $conn->prepare("INSERT INTO event_registrations (
                event_id, full_name, email, phone, gender, age_group, year_group,
                emergency_contact, dietary_requirements, special_needs, 
                church_member, previous_mission, expectations, registration_code,
                registration_date, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), 'pending')");
            
            $stmt->execute([
                $form_data['event_id'],
                $form_data['full_name'],
                $form_data['email'],
                $form_data['phone'],
                $form_data['gender'],
                $form_data['age_group'],
                $form_data['year_group'],
                $form_data['emergency_contact'],
                $form_data['dietary_requirements'],
                $form_data['special_needs'],
                $form_data['church_member'],
                $form_data['previous_mission'],
                $form_data['expectations'],
                $registration_code
            ]);
            
            $registration_id = $conn->lastInsertId();
            
            // Update event registration count
            $stmt = $conn->prepare("UPDATE ministry_events SET registered_count = registered_count + 1 WHERE id = ?");
            $stmt->execute([$form_data['event_id']]);
            
            $conn->commit();
            
            // Send confirmation email (commented for now)
            // send_confirmation_email($form_data['email'], $registration_code, $event);
            
            // Show success message with registration code
            $success_msg = "Registration successful! Your registration code is: <strong>{$registration_code}</strong>";
            
            // Clear form data
            $form_data = [];
            
        } catch (Exception $e) {
            $conn->rollBack();
            $error_msg = "Registration failed. Please try again or contact support.";
            error_log("Registration error: " . $e->getMessage());
        }
    } else {
        $error_msg = implode("<br>", $errors);
    }
}
?>

<div class="main-banner" style="background: linear-gradient(135deg, #1a5276 0%, #2c3e50 100%); padding: 100px 0 50px;">
    <div class="container">
        <h1 class="text-center text-white mb-3">Event Registration</h1>
        <p class="text-center text-white mb-0">Register for upcoming ministry events and missions</p>
    </div>
</div>

<section class="py-5">
    <div class="container">
        <!-- Registration Closed Warning -->
        <?php if ($registration_closed): ?>
            <div class="alert alert-warning">
                <h4><i class="fas fa-exclamation-triangle"></i> Registration Closed</h4>
                <p>Registration for this event has ended as the event date has passed.</p>
                <a href="index.php" class="btn btn-primary">View Other Events</a>
            </div>
        <?php elseif ($max_reached): ?>
            <div class="alert alert-danger">
                <h4><i class="fas fa-times-circle"></i> Event Full</h4>
                <p>This event has reached maximum capacity. Please check other upcoming events.</p>
                <a href="index.php" class="btn btn-primary">View Other Events</a>
            </div>
        <?php else: ?>
        
        <!-- Success/Error Messages -->
        <?php if ($success_msg): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <h4><i class="fas fa-check-circle"></i> Success!</h4>
                <?php echo $success_msg; ?>
                <p class="mt-3">Please save your registration code. You'll receive a confirmation email shortly.</p>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                <div class="mt-3">
                    <a href="index.php" class="btn btn-outline-primary">View More Events</a>
                    <a href="#" class="btn btn-primary" onclick="window.print()">
                        <i class="fas fa-print"></i> Print Confirmation
                    </a>
                </div>
            </div>
        <?php endif; ?>
        
        <?php if ($error_msg): ?>
            <div class="alert alert-danger">
                <h4><i class="fas fa-exclamation-circle"></i> Please correct the following:</h4>
                <?php echo $error_msg; ?>
            </div>
        <?php endif; ?>
        
        <div class="row">
            <!-- Registration Form -->
            <div class="col-lg-8 mb-4">
                <div class="card shadow-lg border-0">
                    <div class="card-header bg-primary text-white py-3">
                        <h3 class="mb-0"><i class="fas fa-user-plus me-2"></i>Registration Form</h3>
                        <p class="mb-0 opacity-75">All fields marked with * are required</p>
                    </div>
                    <div class="card-body p-4">
                        <form id="registrationForm" method="POST" action="" novalidate>
                            <!-- Event Selection -->
                            <div class="mb-4">
                                <h5 class="border-bottom pb-2 mb-3">1. Event Details</h5>
                                <div class="form-group">
                                    <label for="event_id" class="form-label fw-bold">Select Event *</label>
                                    <select name="event_id" id="event_id" class="form-select form-select-lg" required 
                                            <?php echo $event ? 'readonly' : ''; ?>>
                                        <?php if ($event): ?>
                                            <option value="<?php echo $event['id']; ?>" selected>
                                                <?php echo htmlspecialchars($event['title']); ?> 
                                                (<?php echo date('M d, Y', strtotime($event['start_date'])); ?> - 
                                                <?php echo date('M d, Y', strtotime($event['end_date'])); ?>)
                                            </option>
                                        <?php else: ?>
                                            <option value="">-- Select an Event --</option>
                                            <?php foreach ($upcoming_events as $upcoming): ?>
                                                <option value="<?php echo $upcoming['id']; ?>" 
                                                    <?php echo ($form_data['event_id'] ?? '') == $upcoming['id'] ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($upcoming['title']); ?> 
                                                    (<?php echo date('M d, Y', strtotime($upcoming['start_date'])); ?> 
                                                    <?php if ($upcoming['end_date']): ?>
                                                        - <?php echo date('M d, Y', strtotime($upcoming['end_date'])); ?>
                                                    <?php endif; ?>)
                                                    - <?php echo htmlspecialchars($upcoming['location']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                    <div class="form-text">Select the event you wish to register for</div>
                                </div>
                            </div>
                            
                            <!-- Personal Information -->
                            <div class="mb-4">
                                <h5 class="border-bottom pb-2 mb-3">2. Personal Information</h5>
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label for="full_name" class="form-label fw-bold">Full Name *</label>
                                        <input type="text" class="form-control form-control-lg" 
                                               id="full_name" name="full_name" 
                                               value="<?php echo htmlspecialchars($form_data['full_name'] ?? ''); ?>"
                                               placeholder="Enter your full name" required>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="email" class="form-label fw-bold">Email Address *</label>
                                        <input type="email" class="form-control form-control-lg" 
                                               id="email" name="email" 
                                               value="<?php echo htmlspecialchars($form_data['email'] ?? ''); ?>"
                                               placeholder="you@example.com" required>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="phone" class="form-label fw-bold">Phone Number *</label>
                                        <input type="tel" class="form-control form-control-lg" 
                                               id="phone" name="phone" 
                                               value="<?php echo htmlspecialchars($form_data['phone'] ?? ''); ?>"
                                               placeholder="+254 7XX XXX XXX" required>
                                    </div>
                                    
                                    <div class="col-md-4 mb-3">
                                        <label for="gender" class="form-label fw-bold">Gender</label>
                                        <select name="gender" id="gender" class="form-select">
                                            <option value="">-- Select --</option>
                                            <option value="Male" <?php echo ($form_data['gender'] ?? '') == 'Male' ? 'selected' : ''; ?>>Male</option>
                                            <option value="Female" <?php echo ($form_data['gender'] ?? '') == 'Female' ? 'selected' : ''; ?>>Female</option>
                                            <option value="Other" <?php echo ($form_data['gender'] ?? '') == 'Other' ? 'selected' : ''; ?>>Other</option>
                                        </select>
                                    </div>
                                    
                                    <div class="col-md-4 mb-3">
                                        <label for="age_group" class="form-label fw-bold">Age Group</label>
                                        <select name="age_group" id="age_group" class="form-select">
                                            <option value="">-- Select --</option>
                                            <option value="Under 18" <?php echo ($form_data['age_group'] ?? '') == 'Under 18' ? 'selected' : ''; ?>>Under 18</option>
                                            <option value="18-25" <?php echo ($form_data['age_group'] ?? '') == '18-25' ? 'selected' : ''; ?>>18-25</option>
                                            <option value="26-35" <?php echo ($form_data['age_group'] ?? '') == '26-35' ? 'selected' : ''; ?>>26-35</option>
                                            <option value="36-45" <?php echo ($form_data['age_group'] ?? '') == '36-45' ? 'selected' : ''; ?>>36-45</option>
                                            <option value="46-55" <?php echo ($form_data['age_group'] ?? '') == '46-55' ? 'selected' : ''; ?>>46-55</option>
                                            <option value="56+" <?php echo ($form_data['age_group'] ?? '') == '56+' ? 'selected' : ''; ?>>56+</option>
                                        </select>
                                    </div>
                                    
                                    <div class="col-md-4 mb-3">
                                        <label for="year_group" class="form-label fw-bold">Year Group</label>
                                        <input type="text" class="form-control" 
                                               id="year_group" name="year_group" 
                                               value="<?php echo htmlspecialchars($form_data['year_group'] ?? ''); ?>"
                                               placeholder="e.g., 2024">
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Emergency & Health Information -->
                            <div class="mb-4">
                                <h5 class="border-bottom pb-2 mb-3">3. Emergency & Health Information</h5>
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label for="emergency_contact" class="form-label fw-bold">Emergency Contact *</label>
                                        <input type="text" class="form-control form-control-lg" 
                                               id="emergency_contact" name="emergency_contact" 
                                               value="<?php echo htmlspecialchars($form_data['emergency_contact'] ?? ''); ?>"
                                               placeholder="Name and phone number of emergency contact" required>
                                        <div class="form-text">Name and phone number of person to contact in case of emergency</div>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="dietary_requirements" class="form-label">Dietary Requirements</label>
                                        <textarea class="form-control" id="dietary_requirements" 
                                                  name="dietary_requirements" rows="2"
                                                  placeholder="e.g., Vegetarian, Allergies, etc."><?php echo htmlspecialchars($form_data['dietary_requirements'] ?? ''); ?></textarea>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="special_needs" class="form-label">Special Needs / Medical Conditions</label>
                                        <textarea class="form-control" id="special_needs" 
                                                  name="special_needs" rows="2"
                                                  placeholder="Any medical conditions or special accommodations needed"><?php echo htmlspecialchars($form_data['special_needs'] ?? ''); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Ministry Information -->
                            <div class="mb-4">
                                <h5 class="border-bottom pb-2 mb-3">4. Ministry Information</h5>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label fw-bold">Are you a member of Philadelphia Ministry?</label>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="church_member" 
                                                   id="member_yes" value="yes"
                                                   <?php echo ($form_data['church_member'] ?? '') == 'yes' ? 'checked' : ''; ?>>
                                            <label class="form-check-label" for="member_yes">
                                                Yes
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="church_member" 
                                                   id="member_no" value="no"
                                                   <?php echo ($form_data['church_member'] ?? '') == 'no' ? 'checked' : ''; ?>>
                                            <label class="form-check-label" for="member_no">
                                                No
                                            </label>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label fw-bold">Have you attended a mission trip before?</label>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="previous_mission" 
                                                   id="mission_yes" value="yes"
                                                   <?php echo ($form_data['previous_mission'] ?? '') == 'yes' ? 'checked' : ''; ?>>
                                            <label class="form-check-label" for="mission_yes">
                                                Yes
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="previous_mission" 
                                                   id="mission_no" value="no"
                                                   <?php echo ($form_data['previous_mission'] ?? '') == 'no' ? 'checked' : ''; ?>>
                                            <label class="form-check-label" for="mission_no">
                                                No
                                            </label>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12 mb-3">
                                        <label for="expectations" class="form-label">What are your expectations from this event?</label>
                                        <textarea class="form-control" id="expectations" 
                                                  name="expectations" rows="3"
                                                  placeholder="Share what you hope to gain or contribute"><?php echo htmlspecialchars($form_data['expectations'] ?? ''); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Terms and Conditions -->
                            <div class="mb-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="terms" required>
                                    <label class="form-check-label" for="terms">
                                        I agree to the <a href="#" data-bs-toggle="modal" data-bs-target="#termsModal">Terms and Conditions</a> 
                                        and understand that my information will be used for event organization purposes. *
                                    </label>
                                </div>
                                <div class="form-check mt-2">
                                    <input class="form-check-input" type="checkbox" id="privacy" required>
                                    <label class="form-check-label" for="privacy">
                                        I agree to the <a href="#" data-bs-toggle="modal" data-bs-target="#privacyModal">Privacy Policy</a> 
                                        and consent to receive event-related communications. *
                                    </label>
                                </div>
                            </div>
                            
                            <!-- Submit Button -->
                            <div class="text-center mt-4">
                                <button type="submit" class="btn btn-primary btn-lg px-5 py-3">
                                    <i class="fas fa-paper-plane me-2"></i>Submit Registration
                                </button>
                                <button type="reset" class="btn btn-outline-secondary btn-lg ms-2 px-5 py-3">
                                    <i class="fas fa-redo me-2"></i>Reset Form
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Sidebar Information -->
            <div class="col-lg-4">
                <!-- Event Details Card -->
                <?php if ($event): ?>
                    <div class="card shadow-sm mb-4">
                        <div class="card-header bg-success text-white">
                            <h5 class="mb-0"><i class="fas fa-calendar-check me-2"></i>Selected Event</h5>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($event['title']); ?></h5>
                            <div class="event-details">
                                <p><i class="fas fa-calendar-alt text-primary"></i> 
                                   <strong>Dates:</strong> <?php echo date('F d, Y', strtotime($event['start_date'])); ?> 
                                   <?php if($event['end_date']): ?>
                                       - <?php echo date('F d, Y', strtotime($event['end_date'])); ?>
                                   <?php endif; ?>
                                </p>
                                <p><i class="fas fa-clock text-primary"></i> 
                                   <strong>Time:</strong> <?php echo date('g:i A', strtotime($event['time'])); ?>
                                </p>
                                <p><i class="fas fa-map-marker-alt text-primary"></i> 
                                   <strong>Location:</strong> <?php echo htmlspecialchars($event['location']); ?>
                                </p>
                                <?php if($event['max_participants'] > 0): ?>
                                    <p><i class="fas fa-users text-primary"></i> 
                                       <strong>Capacity:</strong> <?php echo $registered_count ?? 0; ?>/<?php echo $event['max_participants']; ?> registered
                                    </p>
                                    <div class="progress mb-2">
                                        <div class="progress-bar bg-success" 
                                             role="progressbar" 
                                             style="width: <?php echo min(100, (($registered_count ?? 0) / $event['max_participants']) * 100); ?>%">
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                
                <!-- Registration Instructions -->
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>Registration Instructions</h5>
                    </div>
                    <div class="card-body">
                        <ol class="list-group list-group-numbered">
                            <li class="list-group-item border-0 ps-0">Fill all required fields</li>
                            <li class="list-group-item border-0 ps-0">Review your information</li>
                            <li class="list-group-item border-0 ps-0">Agree to terms & conditions</li>
                            <li class="list-group-item border-0 ps-0">Submit registration</li>
                            <li class="list-group-item border-0 ps-0">Save your registration code</li>
                        </ol>
                        <hr>
                        <div class="alert alert-light">
                            <h6><i class="fas fa-exclamation-circle text-warning"></i> Important Notes:</h6>
                            <ul class="mb-0">
                                <li>Registration fees may apply for some events</li>
                                <li>You'll receive confirmation within 24 hours</li>
                                <li>Bring your registration code to the event</li>
                                <li>Contact admin for registration changes</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <!-- Need Help? -->
                <div class="card shadow-sm">
                    <div class="card-header bg-warning">
                        <h5 class="mb-0"><i class="fas fa-question-circle me-2"></i>Need Help?</h5>
                    </div>
                    <div class="card-body">
                        <p>Contact our registration team:</p>
                        <p><i class="fas fa-phone text-primary"></i> +254 769 228 426</p>
                        <p><i class="fas fa-envelope text-primary"></i> events@philadelphiaministry.org</p>
                        <p><i class="fas fa-clock text-primary"></i> Mon-Fri, 9AM-5PM</p>
                        <a href="../pages/contact.php" class="btn btn-outline-primary btn-sm w-100">
                            <i class="fas fa-headset me-1"></i> Contact Support
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <?php endif; // End of registration closed check ?>
    </div>
</section>

<!-- Terms & Conditions Modal -->
<div class="modal fade" id="termsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Terms and Conditions</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <h6>Event Participation Agreement</h6>
                <p>By registering for this event, you agree to:</p>
                <ul>
                    <li>Abide by Philadelphia Ministry's code of conduct</li>
                    <li>Follow event schedules and instructions</li>
                    <li>Respect other participants and organizers</li>
                    <li>Take responsibility for personal belongings</li>
                    <li>Participate in event activities responsibly</li>
                </ul>
                
                <h6 class="mt-4">Payment and Cancellation</h6>
                <ul>
                    <li>Registration fees are non-refundable</li>
                    <li>Cancellations must be made 48 hours before event</li>
                    <li>No-shows may affect future registration eligibility</li>
                </ul>
                
                <h6 class="mt-4">Health and Safety</h6>
                <ul>
                    <li>You must disclose any health conditions</li>
                    <li>Follow all safety guidelines provided</li>
                    <li>Ministry is not liable for personal injury</li>
                </ul>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal">I Understand</button>
            </div>
        </div>
    </div>
</div>

<!-- Privacy Policy Modal -->
<div class="modal fade" id="privacyModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title">Privacy Policy</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <h6>Data Collection and Use</h6>
                <p>Philadelphia Ministry collects your personal information for:</p>
                <ul>
                    <li>Event registration and management</li>
                    <li>Communication about event details</li>
                    <li>Emergency contact purposes</li>
                    <li>Ministry analytics and reporting</li>
                </ul>
                
                <h6 class="mt-4">Data Protection</h6>
                <ul>
                    <li>Your information is stored securely</li>
                    <li>Only authorized personnel have access</li>
                    <li>Data is not shared with third parties without consent</li>
                </ul>
                
                <h6 class="mt-4">Your Rights</h6>
                <ul>
                    <li>Request access to your data</li>
                    <li>Request corrections to your information</li>
                    <li>Opt-out of communications</li>
                    <li>Request data deletion (subject to limitations)</li>
                </ul>
                
                <p class="mt-4"><small>For more information, contact our data protection officer at privacy@philadelphiaministry.org</small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" data-bs-dismiss="modal">I Agree</button>
            </div>
        </div>
    </div>
</div>

<style>
    /* Custom styles for registration page */
    .form-label.required::after {
        content: " *";
        color: #dc3545;
    }
    
    .event-details p {
        margin-bottom: 0.8rem;
        padding-bottom: 0.8rem;
        border-bottom: 1px solid #f0f0f0;
    }
    
    .event-details p:last-child {
        border-bottom: none;
        margin-bottom: 0;
        padding-bottom: 0;
    }
    
    .form-control-lg {
        border-radius: 8px;
        padding: 12px 15px;
        font-size: 16px;
    }
    
    .form-select-lg {
        border-radius: 8px;
        padding: 12px 15px;
        font-size: 16px;
    }
    
    .progress {
        height: 8px;
        border-radius: 4px;
    }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
        .main-banner h1 {
            font-size: 2rem;
        }
        
        .card-body {
            padding: 20px;
        }
    }
    
    /* Validation styles */
    input:valid, select:valid {
        border-color: #198754;
    }
    
    input:invalid, select:invalid {
        border-color: #dc3545;
    }
    
    /* Print styles */
    @media print {
        .main-header, .main-banner, .card-header, .modal, 
        .alert, .sidebar-card, button, footer {
            display: none !important;
        }
        
        .card {
            border: none !important;
            box-shadow: none !important;
        }
    }
</style>

<script>
// Form validation and enhancement
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('registrationForm');
    const phoneInput = document.getElementById('phone');
    
    // Phone number formatting
    phoneInput.addEventListener('input', function(e) {
        let value = e.target.value.replace(/\D/g, '');
        if (value.length > 0) {
            if (value.startsWith('0')) {
                value = '+254' + value.substring(1);
            } else if (value.startsWith('254')) {
                value = '+' + value;
            } else if (value.startsWith('7') && value.length === 9) {
                value = '+254' + value;
            }
            e.target.value = formatPhoneNumber(value);
        }
    });
    
    // Form submission validation
    form.addEventListener('submit', function(e) {
        let valid = true;
        const requiredFields = form.querySelectorAll('[required]');
        
        requiredFields.forEach(function(field) {
            if (!field.value.trim()) {
                valid = false;
                field.classList.add('is-invalid');
            } else {
                field.classList.remove('is-invalid');
            }
        });
        
        // Email validation
        const emailField = document.getElementById('email');
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (emailField.value && !emailRegex.test(emailField.value)) {
            valid = false;
            emailField.classList.add('is-invalid');
        }
        
        if (!valid) {
            e.preventDefault();
            alert('Please fill in all required fields correctly.');
        }
    });
    
    // Real-time validation
    const inputs = form.querySelectorAll('input, select, textarea');
    inputs.forEach(function(input) {
        input.addEventListener('blur', function() {
            if (this.hasAttribute('required') && !this.value.trim()) {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
        
        input.addEventListener('input', function() {
            if (this.value.trim()) {
                this.classList.remove('is-invalid');
                this.classList.add('is-valid');
            }
        });
    });
    
    // Event selection change
    const eventSelect = document.getElementById('event_id');
    if (eventSelect && !eventSelect.hasAttribute('readonly')) {
        eventSelect.addEventListener('change', function() {
            if (this.value) {
                window.location.href = `register.php?event_id=${this.value}`;
            }
        });
    }
});

function formatPhoneNumber(phoneNumber) {
    // Remove all non-digits
    const cleaned = phoneNumber.replace(/\D/g, '');
    
    // Format: +XXX XX XXX XXXX
    const match = cleaned.match(/^(\d{3})(\d{2})(\d{3})(\d{4})$/);
    if (match) {
        return `+${match[1]} ${match[2]} ${match[3]} ${match[4]}`;
    }
    
    return phoneNumber;
}

// Show loading state on submit
document.getElementById('registrationForm')?.addEventListener('submit', function() {
    const submitBtn = this.querySelector('button[type="submit"]');
    if (submitBtn) {
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Processing...';
        submitBtn.disabled = true;
    }
});
</script>

<?php require_once '../includes/footer.php'; ?>