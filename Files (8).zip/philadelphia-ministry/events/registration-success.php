<?php
// events/registration-success.php
session_start();
$pageTitle = "Registration Confirmation";
require_once '../includes/header.php';
require_once '../config/database.php';

$db = new Database();
$conn = $db->getConnection();

// Get registration details
$registration_code = $_GET['code'] ?? '';
$registration = null;
$event = null;

if ($registration_code) {
    $stmt = $conn->prepare("SELECT r.*, e.title, e.start_date, e.end_date, e.location 
                           FROM event_registrations r
                           JOIN ministry_events e ON r.event_id = e.id
                           WHERE r.registration_code = ?");
    $stmt->execute([$registration_code]);
    $registration = $stmt->fetch();
}

if (!$registration) {
    header('Location: register.php');
    exit;
}

// Get event details
$stmt = $conn->prepare("SELECT * FROM ministry_events WHERE id = ?");
$stmt->execute([$registration['event_id']]);
$event = $stmt->fetch();
?>

<div class="main-banner" style="background: linear-gradient(135deg, #27ae60 0%, #2ecc71 100%); padding: 100px 0 50px;">
    <div class="container">
        <h1 class="text-center text-white mb-3">
            <i class="fas fa-check-circle me-2"></i>Registration Confirmed!
        </h1>
        <p class="text-center text-white">Thank you for registering with Philadelphia Ministry</p>
    </div>
</div>

<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <!-- Confirmation Card -->
                <div class="card shadow-lg border-0 mb-4">
                    <div class="card-header bg-success text-white py-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h3 class="mb-1"><i class="fas fa-ticket-alt me-2"></i>Registration Confirmation</h3>
                                <p class="mb-0">Your registration has been successfully processed</p>
                            </div>
                            <div class="text-end">
                                <span class="badge bg-light text-success fs-6">CONFIRMED</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card-body p-4">
                        <!-- Registration Details -->
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <h5 class="border-bottom pb-2 mb-3">Registration Details</h5>
                                <table class="table table-sm">
                                    <tr>
                                        <th>Registration Code:</th>
                                        <td>
                                            <span class="badge bg-primary fs-6">
                                                <?php echo $registration['registration_code']; ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Full Name:</th>
                                        <td><?php echo htmlspecialchars($registration['full_name']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Email:</th>
                                        <td><?php echo htmlspecialchars($registration['email']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Phone:</th>
                                        <td><?php echo htmlspecialchars($registration['phone']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Status:</th>
                                        <td>
                                            <span class="badge bg-success">Confirmed</span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Registration Date:</th>
                                        <td><?php echo date('F d, Y', strtotime($registration['registration_date'])); ?></td>
                                    </tr>
                                </table>
                            </div>
                            
                            <div class="col-md-6">
                                <h5 class="border-bottom pb-2 mb-3">Event Details</h5>
                                <table class="table table-sm">
                                    <tr>
                                        <th>Event:</th>
                                        <td><?php echo htmlspecialchars($event['title']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Dates:</th>
                                        <td>
                                            <?php echo date('F d, Y', strtotime($event['start_date'])); ?>
                                            <?php if($event['end_date']): ?>
                                                - <?php echo date('F d, Y', strtotime($event['end_date'])); ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Time:</th>
                                        <td><?php echo date('g:i A', strtotime($event['time'])); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Location:</th>
                                        <td><?php echo htmlspecialchars($event['location']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Event Type:</th>
                                        <td><?php echo ucfirst($event['event_type']); ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        
                        <!-- Payment Information -->
                        <div class="alert alert-info mb-4">
                            <h5><i class="fas fa-money-bill-wave me-2"></i>Payment Information</h5>
                            <p class="mb-2">Your registration is confirmed. Payment details will be sent to your email.</p>
                            <p class="mb-0"><strong>Payment Status:</strong> 
                                <span class="badge bg-warning">Pending</span>
                            </p>
                        </div>
                        
                        <!-- Important Instructions -->
                        <div class="alert alert-warning">
                            <h5><i class="fas fa-exclamation-triangle me-2"></i>Important Instructions</h5>
                            <ol class="mb-0">
                                <li>Save this registration code for check-in</li>
                                <li>Check your email for confirmation details</li>
                                <li>Bring valid ID to the event</li>
                                <li>Arrive 30 minutes before event start</li>
                                <li>Contact us if you need to make changes</li>
                            </ol>
                        </div>
                        
                        <!-- Action Buttons -->
                        <div class="text-center mt-4">
                            <button onclick="window.print()" class="btn btn-primary btn-lg me-3">
                                <i class="fas fa-print me-2"></i>Print Confirmation
                            </button>
                            <button onclick="downloadConfirmation()" class="btn btn-success btn-lg me-3">
                                <i class="fas fa-download me-2"></i>Download PDF
                            </button>
                            <a href="index.php" class="btn btn-outline-secondary btn-lg">
                                <i class="fas fa-calendar me-2"></i>View More Events
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- What's Next? -->
                <div class="card shadow-sm">
                    <div class="card-header bg-light">
                        <h5 class="mb-0"><i class="fas fa-forward me-2"></i>What's Next?</h5>
                    </div>
                    <div class="card-body">
                        <div class="row text-center">
                            <div class="col-md-3 mb-3">
                                <div class="p-3 border rounded">
                                    <i class="fas fa-envelope fa-2x text-primary mb-2"></i>
                                    <h6>Confirmation Email</h6>
                                    <small>Check your inbox</small>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="p-3 border rounded">
                                    <i class="fas fa-comments fa-2x text-success mb-2"></i>
                                    <h6>WhatsApp Group</h6>
                                    <small>Join event updates</small>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="p-3 border rounded">
                                    <i class="fas fa-file-pdf fa-2x text-danger mb-2"></i>
                                    <h6>Event Pack</h6>
                                    <small>Download materials</small>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="p-3 border rounded">
                                    <i class="fas fa-question-circle fa-2x text-warning mb-2"></i>
                                    <h6>Need Help?</h6>
                                    <small>Contact support</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
    .confirmation-card {
        background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
        border-left: 5px solid #28a745;
    }
    
    @media print {
        .main-header, .main-banner, .alert, button, footer {
            display: none !important;
        }
        
        .card {
            border: 1px solid #ddd !important;
            box-shadow: none !important;
        }
        
        .card-header {
            background: #fff !important;
            color: #000 !important;
            border-bottom: 2px solid #28a745;
        }
    }
</style>

<script>
function downloadConfirmation() {
    // In a real application, this would generate a PDF
    alert('PDF download would be generated here. Currently showing print preview.');
    window.print();
}

// Auto-scroll to confirmation
document.addEventListener('DOMContentLoaded', function() {
    window.scrollTo(0, 0);
    
    // Add to calendar functionality
    document.getElementById('addToCalendar')?.addEventListener('click', function() {
        const event = {
            title: '<?php echo addslashes($event['title']); ?>',
            start: '<?php echo $event['start_date'] . 'T' . $event['time']; ?>',
            end: '<?php echo $event['end_date'] ? $event['end_date'] . 'T' . $event['time'] : ''; ?>',
            location: '<?php echo addslashes($event['location']); ?>',
            description: 'Philadelphia Ministry Event'
        };
        
        // Create .ics file for calendar
        const icsContent = [
            'BEGIN:VCALENDAR',
            'VERSION:2.0',
            'BEGIN:VEVENT',
            'SUMMARY:' + event.title,
            'DTSTART:' + event.start.replace(/[-:]/g, ''),
            'DTEND:' + event.end.replace(/[-:]/g, ''),
            'LOCATION:' + event.location,
            'DESCRIPTION:' + event.description,
            'END:VEVENT',
            'END:VCALENDAR'
        ].join('\n');
        
        const blob = new Blob([icsContent], { type: 'text/calendar' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'event-calendar.ics';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>