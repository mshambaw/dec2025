<?php
// events/index.php
$pageTitle = "Events";
require_once '../includes/header.php';
require_once '../config/database.php';

$db = new Database();
$conn = $db->getConnection();

// Get events
$stmt = $conn->prepare("SELECT * FROM ministry_events WHERE end_date >= CURDATE() ORDER BY start_date");
$stmt->execute();
$upcomingEvents = $stmt->fetchAll();

// Get past events
$stmt = $conn->prepare("SELECT * FROM ministry_events WHERE end_date < CURDATE() ORDER BY start_date DESC LIMIT 6");
$stmt->execute();
$pastEvents = $stmt->fetchAll();
?>

<div class="main-banner" style="background: linear-gradient(135deg, #1a5276 0%, #2c3e50 100%); padding: 100px 0 50px;">
    <div class="container">
        <h1 class="text-center text-white">Ministry Events</h1>
        <p class="text-center text-white">Join us for transformative fellowship and service opportunities</p>
    </div>
</div>

<section class="py-5">
    <div class="container">
        <!-- Upcoming Events -->
        <div class="row mb-5">
            <div class="col-md-12">
                <h2 class="mb-4">Upcoming Events</h2>
                <?php if(count($upcomingEvents) > 0): ?>
                    <div class="row">
                        <?php foreach($upcomingEvents as $event): ?>
                        <div class="col-md-4 mb-4">
                            <div class="card h-100 shadow event-card">
                                <div class="card-header bg-primary text-white">
                                    <h5 class="mb-0"><?php echo htmlspecialchars($event['title']); ?></h5>
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <span class="badge bg-success">
                                            <i class="fas fa-calendar"></i> 
                                            <?php echo date('M d, Y', strtotime($event['start_date'])); ?>
                                            <?php if($event['end_date'] && $event['end_date'] != $event['start_date']): ?>
                                                - <?php echo date('M d, Y', strtotime($event['end_date'])); ?>
                                            <?php endif; ?>
                                        </span>
                                        <span class="badge bg-info ms-2">
                                            <i class="fas fa-clock"></i> <?php echo $event['time']; ?>
                                        </span>
                                    </div>
                                    <p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($event['location']); ?></p>
                                    <p><?php echo substr(htmlspecialchars($event['description']), 0, 150); ?>...</p>
                                </div>
                                <div class="card-footer">
                                    <a href="register.php?event=<?php echo $event['id']; ?>" class="btn btn-primary">
                                        <i class="fas fa-user-plus"></i> Register Now
                                    </a>
                                    <a href="mission-2025.php" class="btn btn-outline-secondary">
                                        <i class="fas fa-info-circle"></i> Details
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">
                        <h4>No upcoming events scheduled</h4>
                        <p>Check back soon for upcoming programs and missions!</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Mission Countdown -->
        <div class="row mb-5">
            <div class="col-md-12">
                <div class="card bg-success text-white">
                    <div class="card-body text-center">
                        <h3><i class="fas fa-hourglass-half"></i> Countdown to End-Year Mission</h3>
                        <p>Mahanga, Vihiga County - Dec 21, 2025 to Jan 4, 2026</p>
                        <div class="countdown-timer" id="mission-countdown">
                            <div class="d-inline-block mx-2">
                                <div class="countdown-box">
                                    <span class="countdown-value" id="days">00</span>
                                    <div class="countdown-label">Days</div>
                                </div>
                            </div>
                            <div class="d-inline-block mx-2">
                                <div class="countdown-box">
                                    <span class="countdown-value" id="hours">00</span>
                                    <div class="countdown-label">Hours</div>
                                </div>
                            </div>
                            <div class="d-inline-block mx-2">
                                <div class="countdown-box">
                                    <span class="countdown-value" id="minutes">00</span>
                                    <div class="countdown-label">Minutes</div>
                                </div>
                            </div>
                            <div class="d-inline-block mx-2">
                                <div class="countdown-box">
                                    <span class="countdown-value" id="seconds">00</span>
                                    <div class="countdown-label">Seconds</div>
                                </div>
                            </div>
                        </div>
                        <a href="register.php?event=mission" class="btn btn-light btn-lg mt-3">
                            <i class="fas fa-user-plus"></i> Register for Mission
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Past Events -->
        <?php if(count($pastEvents) > 0): ?>
        <div class="row">
            <div class="col-md-12">
                <h2 class="mb-4">Past Events</h2>
                <div class="row">
                    <?php foreach($pastEvents as $event): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100">
                            <div class="card-header bg-secondary text-white">
                                <h5 class="mb-0"><?php echo htmlspecialchars($event['title']); ?></h5>
                            </div>
                            <div class="card-body">
                                <p><i class="fas fa-calendar"></i> <?php echo date('M d, Y', strtotime($event['start_date'])); ?></p>
                                <p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($event['location']); ?></p>
                                <p class="text-muted"><?php echo substr(htmlspecialchars($event['description']), 0, 100); ?>...</p>
                            </div>
                            <div class="card-footer">
                                <a href="#" class="btn btn-outline-secondary">View Photos</a>
                                <a href="#" class="btn btn-outline-secondary">Download Resources</a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</section>

<style>
    .event-card {
        transition: transform 0.3s;
    }
    .event-card:hover {
        transform: translateY(-5px);
    }
    .countdown-box {
        background: rgba(255,255,255,0.2);
        padding: 15px 20px;
        border-radius: 10px;
        min-width: 100px;
    }
    .countdown-value {
        font-size: 2.5rem;
        font-weight: bold;
        display: block;
    }
    .countdown-label {
        font-size: 0.9rem;
        opacity: 0.9;
    }
</style>

<script>
    // Mission Countdown Timer
    function updateCountdown() {
        const missionDate = new Date('December 21, 2025 08:00:00').getTime();
        const now = new Date().getTime();
        const distance = missionDate - now;
        
        if (distance < 0) {
            document.getElementById("days").innerHTML = "00";
            document.getElementById("hours").innerHTML = "00";
            document.getElementById("minutes").innerHTML = "00";
            document.getElementById("seconds").innerHTML = "00";
            return;
        }
        
        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        document.getElementById("days").innerHTML = days.toString().padStart(2, '0');
        document.getElementById("hours").innerHTML = hours.toString().padStart(2, '0');
        document.getElementById("minutes").innerHTML = minutes.toString().padStart(2, '0');
        document.getElementById("seconds").innerHTML = seconds.toString().padStart(2, '0');
    }
    
    setInterval(updateCountdown, 1000);
    updateCountdown();
</script>

<?php require_once '../includes/footer.php'; ?>