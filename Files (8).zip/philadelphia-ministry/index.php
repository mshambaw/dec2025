<?php
// index.php - Philadelphia Ministry Homepage with Database Integration
session_start();
require_once 'config/database.php';

$db = new Database();
$conn = $db->getConnection();

// Get upcoming events for homepage
$stmt = $conn->prepare("SELECT * FROM ministry_events WHERE status = 'upcoming' ORDER BY start_date LIMIT 4");
$stmt->execute();
$upcomingEvents = $stmt->fetchAll();

// Get total members count
$stmt = $conn->query("SELECT COUNT(*) as total FROM members WHERE is_active = 1");
$totalMembers = $stmt->fetch()['total'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Philadelphia Ministry - A community of believers dedicated to serving God and transforming lives through the power of the Gospel">
    <meta name="author" content="Philadelphia Ministry">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">

    <title>Philadelphia Ministry</title>

    <!-- Bootstrap core CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/templatemo-grad-school.css">
    <link rel="stylesheet" href="css/owl.css">
    <link rel="stylesheet" href="css/lightbox.css">

    <style>
        /* Additional Custom Styles */
        .ministry-stats {
            background: linear-gradient(135deg, #1a5276 0%, #2c3e50 100%);
            color: white;
            padding: 40px 0;
            margin: 40px 0;
        }
        
        .stat-item {
            text-align: center;
            padding: 20px;
        }
        
        .stat-number {
            font-size: 2.5rem;
            font-weight: bold;
            display: block;
        }
        
        .stat-label {
            font-size: 1rem;
            opacity: 0.9;
        }
        
        .event-date-badge {
            background: #e67e22;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
            display: inline-block;
            margin-bottom: 10px;
        }
        
        .event-location {
            color: #666;
            font-size: 0.9rem;
        }
        
        .mission-countdown {
            background: linear-gradient(135deg, #27ae60 0%, #2ecc71 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            text-align: center;
            margin: 30px 0;
        }
        
        .countdown-timer {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 20px;
        }
        
        .countdown-unit {
            background: rgba(255,255,255,0.2);
            padding: 15px;
            border-radius: 10px;
            min-width: 80px;
        }
        
        .countdown-value {
            font-size: 2rem;
            font-weight: bold;
            display: block;
        }
        
        .countdown-label {
            font-size: 0.9rem;
            opacity: 0.9;
        }
        
        .upcoming-event-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s;
            height: 100%;
        }
        
        .upcoming-event-card:hover {
            transform: translateY(-10px);
        }
        
        .event-image {
            height: 200px;
            background-size: cover;
            background-position: center;
        }
        
        .event-mission {
            background-image: url('https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80');
        }
        
        .event-briefing {
            background-image: url('https://images.unsplash.com/photo-1519452639340-94fcedd3e85f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80');
        }
        
        .event-mentorship {
            background-image: url('https://images.unsplash.com/photo-1542744173-8e7e53415bb0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80');
        }
        
        .event-workshop {
            background-image: url('https://images.unsplash.com/photo-1542744173-8e7e53415bb0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80');
        }
        
        .quick-links {
            background: #f8f9fa;
            padding: 30px;
            border-radius: 15px;
            margin: 30px 0;
        }
        
        .quick-link-item {
            display: block;
            background: white;
            padding: 15px;
            margin: 10px 0;
            border-radius: 8px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s;
            border-left: 4px solid #1a5276;
        }
        
        .quick-link-item:hover {
            transform: translateX(10px);
            background: #1a5276;
            color: white;
        }
    </style>
</head>

<body>
    <!--header-->
    <header class="main-header clearfix" role="header">
        <div class="logo">
            <a href="#"><em>Philadelphia</em></a>
        </div>
        <a href="#menu" class="menu-link"><i class="fa fa-bars"></i></a>
        <nav id="menu" class="main-nav" role="navigation">
            <ul class="main-menu">
                <li><a href="#section1">Home</a></li>
                <li class="has-submenu"><a href="#">About Us</a>
                    <ul class="sub-menu">
                        <li><a href="about.php?page=history">History</a></li>
                        <li><a href="leadership.php">Leadership</a></li>
                        <li><a href="members.php">Membership</a></li>
                        <li><a href="events.php">Events</a></li>
                        <li><a href="gallery.php">Gallery</a></li>
                        <li><a href="vision.php">Vision & Future</a></li>
                    </ul>
                </li>
                <li><a href="songs.php">Songs</a></li>
                <li><a href="contributions.php">Contributions</a></li>
                <li><a href="bible-studies.php">Bible Studies</a></li>
                <li><a href="#section6">Contact</a></li>
                <li class="has-submenu"><a href="#">Quick Links</a>
                    <ul class="sub-menu">
                        <li><a href="join.php">Join Us</a></li>
                        <li><a href="updates.php">Updates</a></li>
                        <li><a href="publications.php">Publications</a></li>
                        <li><a href="admin/index.php">Admin Login</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
    </header>

    <!-- ***** Main Banner Area Start ***** -->
    <section class="section main-banner" id="top" data-section="section1">
        <video autoplay muted loop id="bg-video">
            <source src="assets/videos/worship-bg.mp4" type="video/mp4" />
        </video>

        <div class="video-overlay header-text">
            <div class="caption">
                <h6>Bound by the cords of love... </h6>
                <h2><em>Philadelphia</em> Ministry</h2>
                <p>Transforming lives through Christ's love since 2021</p>
                <div class="main-button">
                    <div class="scroll-to-section"><a href="#section2">Discover Our Ministry</a></div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** Main Banner Area End ***** -->

    <!-- Ministry Statistics -->
    <section class="ministry-stats">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-6">
                    <div class="stat-item">
                        <span class="stat-number"><?php echo $totalMembers; ?>+</span>
                        <span class="stat-label">Active Members</span>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-item">
                        <span class="stat-number">4+</span>
                        <span class="stat-label">Year Groups</span>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-item">
                        <span class="stat-number">10+</span>
                        <span class="stat-label">Events Yearly</span>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-item">
                        <span class="stat-number">24/7</span>
                        <span class="stat-label">Prayer Support</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="features">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-12">
                    <div class="features-post">
                        <div class="features-content">
                            <div class="content-show">
                                <h4><i class="fa fa-cross"></i> Our Mission</h4>
                            </div>
                            <div class="content-hide">
                                <p>To spread the Gospel of Jesus Christ, disciple believers, and serve our community with love and compassion. We believe in transforming lives through biblical teaching and practical ministry.</p>
                                <p><strong>Core Values:</strong> Love, Faith, Service, Integrity, Unity</p>
                                <div class="scroll-to-section"><a href="about.php">Learn More</a></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-12">
                    <div class="features-post second-features">
                        <div class="features-content">
                            <div class="content-show">
                                <h4><i class="fa fa-users"></i> Join Our Family</h4>
                            </div>
                            <div class="content-hide">
                                <p>Become part of our growing spiritual family. We welcome everyone seeking spiritual growth, fellowship, and service opportunities.</p>
                                <p><strong>Membership Benefits:</strong> Spiritual guidance, fellowship, leadership training, mission opportunities, prayer support.</p>
                                <div class="scroll-to-section"><a href="join.php">Join Today</a></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-12">
                    <div class="features-post third-features">
                        <div class="features-content">
                            <div class="content-show">
                                <h4><i class="fa fa-calendar-alt"></i> Upcoming Events</h4>
                            </div>
                            <div class="content-hide">
                                <p>Stay connected with our ministry activities, missions, and fellowship events throughout the year.</p>
                                <p><strong>Featured Events:</strong> End-Year Mission (Dec 21-Jan 4), Pastor Boaz Mentorship (Feb 2026), Weekly Bible Studies.</p>
                                <div class="scroll-to-section"><a href="events.php">View Calendar</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Add this to your homepage -->
<section class="music-highlight py-5 bg-light">
    <div class="container">
        <h2 class="text-center mb-4">Music Ministry</h2>
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Worship Through Music</h5>
                        <p class="card-text">Join our choir and worship teams as we lift our voices in praise to God.</p>
                        <a href="pages/music.php" class="btn btn-primary">Learn More</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Song Library</h5>
                        <p class="card-text">Access our collection of worship songs, hymns, and contemporary music.</p>
                        <a href="music/songs.php" class="btn btn-outline-primary">Browse Songs</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
    <!-- Mission Countdown -->
    <section class="mission-countdown">
        <div class="container">
            <h3><i class="fas fa-hourglass-half"></i> Countdown to End-Year Mission</h3>
            <p>Mahanga, Vihiga County - Dec 21, 2025 to Jan 4, 2026</p>
            <div class="countdown-timer" id="mission-countdown">
                <div class="countdown-unit">
                    <span class="countdown-value" id="days">00</span>
                    <span class="countdown-label">Days</span>
                </div>
                <div class="countdown-unit">
                    <span class="countdown-value" id="hours">00</span>
                    <span class="countdown-label">Hours</span>
                </div>
                <div class="countdown-unit">
                    <span class="countdown-value" id="minutes">00</span>
                    <span class="countdown-label">Minutes</span>
                </div>
                <div class="countdown-unit">
                    <span class="countdown-value" id="seconds">00</span>
                    <span class="countdown-label">Seconds</span>
                </div>
            </div>
            <a href="events.php?event=mission" class="btn btn-light mt-3">Register for Mission</a>
        </div>
    </section>

    <section class="section why-us" data-section="section2">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading">
                        <h2>Our Ministry Programs</h2>
                        <p>Transforming lives through comprehensive spiritual programs</p>
                    </div>
                </div>
                <div class="col-md-12">
                    <div id='tabs'>
                        <ul>
                            <li><a href='#tabs-1'>Weekly Fellowship</a></li>
                            <li><a href='#tabs-2'>Discipleship Training</a></li>
                            <li><a href='#tabs-3'>Bible Studies</a></li>
                            <li><a href='#tabs-4'>Community Outreach</a></li>
                        </ul>
                        <section class='tabs-content'>
                            <article id='tabs-1'>
                                <div class="row">
                                    <div class="col-md-6">
                                        <img src="assets/images/fellowship.jpg" alt="Weekly Fellowship" style="width:100%; border-radius:10px;">
                                    </div>
                                    <div class="col-md-6">
                                        <h4>Weekly Fellowship Meetings</h4>
                                        <p>Join us every week for uplifting worship, powerful sermons, and meaningful fellowship. Our gatherings are designed to strengthen your faith and build Christian community.</p>
                                        <p><strong>Schedule:</strong><br>
                                            • Sundays: Main Service (10:00 AM)<br>
                                            • Wednesdays: Prayer Meeting (6:00 PM)<br>
                                            • Fridays: Youth Fellowship (7:00 PM)</p>
                                        <a href="events.php" class="btn btn-primary">Join This Week</a>
                                    </div>
                                </div>
                            </article>
                            <article id='tabs-2'>
                                <div class="row">
                                    <div class="col-md-6">
                                        <img src="assets/images/discipleship.jpg" alt="Discipleship Training" style="width:100%; border-radius:10px;">
                                    </div>
                                    <div class="col-md-6">
                                        <h4>Discipleship & Leadership Training</h4>
                                        <p>We equip believers for effective ministry through comprehensive training programs. Our mentorship system ensures personal spiritual growth and leadership development.</p>
                                        <p><strong>Upcoming Training:</strong><br>
                                            • Pastor Boaz Ouma Mentorship (Feb 2026)<br>
                                            • Evangelism Training Workshop<br>
                                            • Worship Team Development</p>
                                        <a href="mentorship.php" class="btn btn-primary">Apply for Training</a>
                                    </div>
                                </div>
                            </article>
                            <article id='tabs-3'>
                                <div class="row">
                                    <div class="col-md-6">
                                        <img src="assets/images/bible-study.jpg" alt="Bible Studies" style="width:100%; border-radius:10px;">
                                    </div>
                                    <div class="col-md-6">
                                        <h4>In-Depth Bible Studies</h4>
                                        <p>Explore God's Word through systematic Bible studies led by experienced teachers. We cover various books of the Bible and topical studies relevant to Christian living.</p>
                                        <p><strong>Current Studies:</strong><br>
                                            • Book of Romans (Tuesday 7PM)<br>
                                            • Spiritual Warfare (Thursday 6PM)<br>
                                            • Youth Bible Study (Saturday 4PM)</p>
                                        <a href="bible-studies.php" class="btn btn-primary">Join Bible Study</a>
                                    </div>
                                </div>
                            </article>
                            <article id='tabs-4'>
                                <div class="row">
                                    <div class="col-md-6">
                                        <img src="assets/images/outreach.jpg" alt="Community Outreach" style="width:100%; border-radius:10px;">
                                    </div>
                                    <div class="col-md-6">
                                        <h4>Community Outreach & Missions</h4>
                                        <p>We actively serve our community through various outreach programs and mission trips. Our goal is to demonstrate Christ's love through practical service.</p>
                                        <p><strong>Upcoming Outreach:</strong><br>
                                            • End-Year Mission (Dec 21-Jan 4)<br>
                                            • Medical Camp - Mahanga<br>
                                            • School Supply Drive</p>
                                        <a href="events.php?type=mission" class="btn btn-primary">Volunteer Now</a>
                                    </div>
                                </div>
                            </article>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Upcoming Events Section -->
    <section class="section courses" data-section="section4">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading">
                        <h2>Upcoming Events</h2>
                        <p>Join us for these transformative ministry events</p>
                    </div>
                </div>
                
                <?php if(count($upcomingEvents) > 0): ?>
                    <div class="owl-carousel owl-theme">
                        <?php foreach($upcomingEvents as $event): ?>
                        <div class="item">
                            <div class="upcoming-event-card">
                                <div class="event-image <?php echo strtolower($event['event_type']); ?>"></div>
                                <div class="down-content p-4">
                                    <span class="event-date-badge">
                                        <?php echo date('M d, Y', strtotime($event['start_date'])); ?>
                                        <?php if($event['end_date']): ?> - <?php echo date('M d, Y', strtotime($event['end_date'])); ?><?php endif; ?>
                                    </span>
                                    <h4><?php echo htmlspecialchars($event['title']); ?></h4>
                                    <p class="event-location"><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($event['location']); ?></p>
                                    <p><?php echo substr(htmlspecialchars($event['description']), 0, 100); ?>...</p>
                                    <div class="author-image">
                                        <img src="assets/images/logo-icon.png" alt="Philadelphia Ministry" style="width:40px; height:40px; border-radius:50%;">
                                    </div>
                                    <div class="text-button-pay">
                                        <a href="events.php?event=<?php echo $event['id']; ?>">View Details <i class="fa fa-angle-double-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="col-md-12 text-center py-5">
                        <h4>No upcoming events scheduled</h4>
                        <p>Check back soon for our upcoming programs!</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Quick Links Section -->
    <section class="quick-links">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h3 class="text-center mb-4">Quick Access</h3>
                </div>
                <div class="col-md-3 col-6">
                    <a href="events.php" class="quick-link-item">
                        <i class="fas fa-calendar-alt fa-2x mb-2"></i>
                        <h5>Events Calendar</h5>
                        <p>View all upcoming events</p>
                    </a>
                </div>
                <div class="col-md-3 col-6">
                    <a href="members.php" class="quick-link-item">
                        <i class="fas fa-users fa-2x mb-2"></i>
                        <h5>Member Directory</h5>
                        <p>Connect with members</p>
                    </a>
                </div>
                <div class="col-md-3 col-6">
                    <a href="contributions.php" class="quick-link-item">
                        <i class="fas fa-donate fa-2x mb-2"></i>
                        <h5>Online Giving</h5>
                        <p>Support the ministry</p>
                    </a>
                </div>
                <div class="col-md-3 col-6">
                    <a href="admin/index.php" class="quick-link-item">
                        <i class="fas fa-cog fa-2x mb-2"></i>
                        <h5>Admin Portal</h5>
                        <p>Ministry management</p>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="section contact" data-section="section6">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading">
                        <h2>Contact Us</h2>
                        <p>Get in touch with Philadelphia Ministry</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <form id="contact" action="submit_contact.php" method="post">
                        <div class="row">
                            <div class="col-md-6">
                                <fieldset>
                                    <input name="name" type="text" class="form-control" id="name" placeholder="Your Name" required="">
                                </fieldset>
                            </div>
                            <div class="col-md-6">
                                <fieldset>
                                    <input name="phone" type="tel" class="form-control" id="phone" placeholder="Your Phone" required="">
                                </fieldset>
                            </div>
                            <div class="col-md-12">
                                <fieldset>
                                    <input name="email" type="email" class="form-control" id="email" placeholder="Your Email" required="">
                                </fieldset>
                            </div>
                            <div class="col-md-12">
                                <fieldset>
                                    <select name="subject" class="form-control" required>
                                        <option value="">Select Subject</option>
                                        <option value="membership">Membership Inquiry</option>
                                        <option value="event">Event Registration</option>
                                        <option value="prayer">Prayer Request</option>
                                        <option value="donation">Donation Inquiry</option>
                                        <option value="other">Other</option>
                                    </select>
                                </fieldset>
                            </div>
                            <div class="col-md-12">
                                <fieldset>
                                    <textarea name="message" rows="6" class="form-control" id="message" placeholder="Your message..." required=""></textarea>
                                </fieldset>
                            </div>
                            <div class="col-md-12">
                                <fieldset>
                                    <button type="submit" id="form-submit" class="button">Send Message</button>
                                </fieldset>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-6">
                    <div class="contact-info">
                        <h4>Contact Information</h4>
                        <p><i class="fas fa-map-marker-alt"></i> <strong>Location:</strong> Philadelphia Ministry Headquarters, Kenya</p>
                        <p><i class="fas fa-phone"></i> <strong>Phone:</strong> +254 769 228 426 (Elder Amos Koroso)</p>
                        <p><i class="fas fa-envelope"></i> <strong>Email:</strong> info@philadelphiaministry.org</p>
                        <p><i class="fas fa-clock"></i> <strong>Office Hours:</strong> Monday - Friday, 9:00 AM - 5:00 PM</p>
                        
                        <h5 class="mt-4">Leadership Contacts</h5>
                        <p>• Elder Amos Koroso: 0769 228 426</p>
                        <p>• Commander Caleb: 0798 914 401</p>
                        <p>• Esther Kamau: 0796 096 450</p>
                        
                        <div class="social-links mt-4">
                            <a href="#" class="btn btn-outline-primary"><i class="fab fa-facebook"></i> Facebook</a>
                            <a href="#" class="btn btn-outline-info"><i class="fab fa-twitter"></i> Twitter</a>
                            <a href="#" class="btn btn-outline-success"><i class="fab fa-whatsapp"></i> WhatsApp</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>Philadelphia Ministry</h5>
                    <p>Transforming lives through Christ's love since 2021. A community dedicated to discipleship, fellowship, and service.</p>
                </div>
                <div class="col-md-4">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="events.php">Events</a></li>
                        <li><a href="members.php">Members</a></li>
                        <li><a href="contributions.php">Give</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Connect With Us</h5>
                    <p><i class="fas fa-envelope"></i> info@philadelphiaministry.org</p>
                    <p><i class="fas fa-phone"></i> +254 769 228 426</p>
                    <p><i class="fas fa-map-marker-alt"></i> Ministry Headquarters</p>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-12 text-center">
                    <p><i class="fa fa-copyright"></i> <?php echo date('Y'); ?> Philadelphia Ministry | 
                    Design: <a href="https://templatemo.com" rel="sponsored" target="_parent">TemplateMo</a></p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl-carousel.js"></script>
    <script src="js/lightbox.js"></script>
    <script src="js/tabs.js"></script>
    <script src="js/video.js"></script>
    <script src="js/slick-slider.js"></script>
    <script src="js/custom.js"></script>
    
    <script>
        // Mission Countdown Timer
        function updateCountdown() {
            const missionDate = new Date('December 21, 2025 08:00:00').getTime();
            const now = new Date().getTime();
            const distance = missionDate - now;
            
            if (distance < 0) {
                document.getElementById("days").innerHTML = "00";
                document.getElementById("hours").innerHTML = "00";
                document.getElementById("minutes").innerHTML = "00";
                document.getElementById("seconds").innerHTML = "00";
                return;
            }
            
            const days = Math.floor(distance / (1000 * 60 * 60 * 24));
            const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);
            
            document.getElementById("days").innerHTML = days.toString().padStart(2, '0');
            document.getElementById("hours").innerHTML = hours.toString().padStart(2, '0');
            document.getElementById("minutes").innerHTML = minutes.toString().padStart(2, '0');
            document.getElementById("seconds").innerHTML = seconds.toString().padStart(2, '0');
        }
        
        // Update countdown every second
        setInterval(updateCountdown, 1000);
        updateCountdown(); // Initial call
        
        // Navigation and tab functionality
        $(document).ready(function() {
            $('.nav li:first').addClass('active');
            
            var showSection = function(section, isAnimate) {
                var direction = section.replace(/#/, ''),
                    reqSection = $('.section').filter('[data-section="' + direction + '"]'),
                    reqSectionPos = reqSection.offset().top - 0;
                
                if (isAnimate) {
                    $('body, html').animate({
                        scrollTop: reqSectionPos
                    }, 800);
                } else {
                    $('body, html').scrollTop(reqSectionPos);
                }
            };
            
            var checkSection = function() {
                $('.section').each(function() {
                    var $this = $(this),
                        topEdge = $this.offset().top - 80,
                        bottomEdge = topEdge + $this.height(),
                        wScroll = $(window).scrollTop();
                    
                    if (topEdge < wScroll && bottomEdge > wScroll) {
                        var currentId = $this.data('section'),
                            reqLink = $('a').filter('[href*=\\#' + currentId + ']');
                        reqLink.closest('li').addClass('active').siblings().removeClass('active');
                    }
                });
            };
            
            $('.main-menu, .scroll-to-section').on('click', 'a', function(e) {
                if ($(e.target).hasClass('external')) {
                    return;
                }
                e.preventDefault();
                $('#menu').removeClass('active');
                showSection($(this).attr('href'), true);
            });
            
            $(window).scroll(function() {
                checkSection();
            });
            
            // Initialize Owl Carousel for events
            $('.owl-carousel').owlCarousel({
                loop: true,
                margin: 20,
                nav: true,
                responsive: {
                    0: { items: 1 },
                    600: { items: 2 },
                    1000: { items: 3 }
                }
            });
        });
        
        // Simple contact form validation
        $('#contact').submit(function(e) {
            e.preventDefault();
            var form = $(this);
            var formData = form.serialize();
            
            $.ajax({
                type: 'POST',
                url: form.attr('action'),
                data: formData,
                success: function(response) {
                    alert('Thank you for your message! We will contact you soon.');
                    form[0].reset();
                },
                error: function() {
                    alert('There was an error sending your message. Please try again.');
                }
            });
        });
    </script>
</body>
</html>