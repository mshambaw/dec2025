const express = require('express');
const axios = require('axios');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

// M-Pesa Configuration
const MPESA_CONFIG = {
    BUSINESS_SHORT_CODE: process.env.BUSINESS_SHORT_CODE || '174379',
    PASSKEY: process.env.PASSKEY,
    CONSUMER_KEY: process.env.CONSUMER_KEY,
    CONSUMER_SECRET: process.env.CONSUMER_SECRET,
    CALLBACK_URL: process.env.CALLBACK_URL || 'https://your-domain.com/callback',
    ENVIRONMENT: process.env.ENVIRONMENT || 'sandbox' // sandbox or production
};

// Generate M-Pesa password
function generatePassword() {
    const timestamp = new Date().toISOString().replace(/[^0-9]/g, '').slice(0, -3);
    const password = Buffer.from(
        `${MPESA_CONFIG.BUSINESS_SHORT_CODE}${MPESA_CONFIG.PASSKEY}${timestamp}`
    ).toString('base64');
    return { password, timestamp };
}

// Get access token
async function getAccessToken() {
    try {
        const auth = Buffer.from(`${MPESA_CONFIG.CONSUMER_KEY}:${MPESA_CONFIG.CONSUMER_SECRET}`).toString('base64');
        const url = MPESA_CONFIG.ENVIRONMENT === 'sandbox' 
            ? 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials'
            : 'https://api.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';
        
        const response = await axios.get(url, {
            headers: { Authorization: `Basic ${auth}` }
        });
        
        return response.data.access_token;
    } catch (error) {
        console.error('Error getting access token:', error.response?.data || error.message);
        throw error;
    }
}

// STK Push endpoint
app.post('/api/mpesa/stkpush', async (req, res) => {
    try {
        const { phoneNumber, amount, accountReference, transactionDesc } = req.body;
        
        // Validate inputs
        if (!phoneNumber || !amount || amount < 10) {
            return res.status(400).json({ error: 'Invalid phone number or amount' });
        }
        
        // Get access token
        const accessToken = await getAccessToken();
        
        // Generate password
        const { password, timestamp } = generatePassword();
        
        // Prepare request body
        const requestBody = {
            BusinessShortCode: MPESA_CONFIG.BUSINESS_SHORT_CODE,
            Password: password,
            Timestamp: timestamp,
            TransactionType: 'CustomerPayBillOnline',
            Amount: amount,
            PartyA: phoneNumber,
            PartyB: MPESA_CONFIG.BUSINESS_SHORT_CODE,
            PhoneNumber: phoneNumber,
            CallBackURL: MPESA_CONFIG.CALLBACK_URL,
            AccountReference: accountReference,
            TransactionDesc: transactionDesc || 'Donation'
        };
        
        // Make STK Push request
        const url = MPESA_CONFIG.ENVIRONMENT === 'sandbox'
            ? 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest'
            : 'https://api.safaricom.co.ke/mpesa/stkpush/v1/processrequest';
        
        const response = await axios.post(url, requestBody, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            }
        });
        
        console.log('STK Push response:', response.data);
        
        if (response.data.ResponseCode === '0') {
            // Save transaction to database (you should implement this)
            saveTransaction({
                checkoutRequestID: response.data.CheckoutRequestID,
                merchantRequestID: response.data.MerchantRequestID,
                phoneNumber,
                amount,
                accountReference,
                status: 'pending'
            });
            
            res.json({
                success: true,
                checkoutRequestID: response.data.CheckoutRequestID,
                responseDescription: response.data.ResponseDescription
            });
        } else {
            res.status(400).json({
                success: false,
                error: response.data.ResponseDescription
            });
        }
        
    } catch (error) {
        console.error('STK Push error:', error.response?.data || error.message);
        res.status(500).json({
            success: false,
            error: error.response?.data?.errorMessage || 'Payment processing failed'
        });
    }
});

// Callback endpoint for M-Pesa
app.post('/api/mpesa/callback', (req, res) => {
    try {
        const callbackData = req.body;
        console.log('M-Pesa Callback:', JSON.stringify(callbackData, null, 2));
        
        // Extract the actual result from the nested structure
        const stkCallback = callbackData.Body?.stkCallback;
        
        if (stkCallback) {
            const resultCode = stkCallback.ResultCode;
            const resultDesc = stkCallback.ResultDesc;
            const checkoutID = stkCallback.CheckoutRequestID;
            const callbackMetadata = stkCallback.CallbackMetadata;
            
            if (resultCode === '0') {
                // Payment successful
                const items = callbackMetadata?.Item || [];
                const amount = items.find(i => i.Name === 'Amount')?.Value;
                const mpesaReceipt = items.find(i => i.Name === 'MpesaReceiptNumber')?.Value;
                const phone = items.find(i => i.Name === 'PhoneNumber')?.Value;
                
                // Update transaction in database
                updateTransaction(checkoutID, {
                    status: 'completed',
                    resultCode,
                    resultDesc,
                    amount,
                    mpesaReceipt,
                    phoneNumber: phone,
                    completedAt: new Date()
                });
                
                console.log(`Payment successful: ${mpesaReceipt}, Amount: ${amount}`);
            } else {
                // Payment failed
                updateTransaction(checkoutID, {
                    status: 'failed',
                    resultCode,
                    resultDesc,
                    failedAt: new Date()
                });
                
                console.log(`Payment failed: ${resultDesc}`);
            }
        }
        
        res.status(200).send('OK');
    } catch (error) {
        console.error('Callback error:', error);
        res.status(500).send('Error processing callback');
    }
});

// Check payment status
app.post('/api/mpesa/check-status', async (req, res) => {
    try {
        const { checkoutRequestID } = req.body;
        
        if (!checkoutRequestID) {
            return res.status(400).json({ error: 'CheckoutRequestID is required' });
        }
        
        const accessToken = await getAccessToken();
        
        const url = MPESA_CONFIG.ENVIRONMENT === 'sandbox'
            ? 'https://sandbox.safaricom.co.ke/mpesa/stkpushquery/v1/query'
            : 'https://api.safaricom.co.ke/mpesa/stkpushquery/v1/query';
        
        const { password, timestamp } = generatePassword();
        
        const requestBody = {
            BusinessShortCode: MPESA_CONFIG.BUSINESS_SHORT_CODE,
            Password: password,
            Timestamp: timestamp,
            CheckoutRequestID: checkoutRequestID
        };
        
        const response = await axios.post(url, requestBody, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            }
        });
        
        res.json(response.data);
        
    } catch (error) {
        console.error('Check status error:', error.response?.data || error.message);
        res.status(500).json({ error: 'Failed to check payment status' });
    }
});

// Save donation endpoint
app.post('/api/donations', (req, res) => {
    try {
        const donation = req.body;
        
        // Validate donation data
        if (!donation.amount || !donation.phone) {
            return res.status(400).json({ error: 'Missing required fields' });
        }
        
        // Here you would save to your database
        // Example with MongoDB:
        // await Donation.create(donation);
        
        console.log('Donation received:', donation);
        
        // Send confirmation email (optional)
        if (donation.email) {
            sendConfirmationEmail(donation);
        }
        
        res.json({ success: true, message: 'Donation saved successfully' });
        
    } catch (error) {
        console.error('Save donation error:', error);
        res.status(500).json({ error: 'Failed to save donation' });
    }
});

// Database functions (implement based on your database)
function saveTransaction(transaction) {
    // Save to your database
    console.log('Saving transaction:', transaction);
}

function updateTransaction(checkoutID, updates) {
    // Update transaction in your database
    console.log('Updating transaction:', checkoutID, updates);
}

function sendConfirmationEmail(donation) {
    // Implement email sending logic
    console.log('Would send confirmation email for donation:', donation.id);
}

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`M-Pesa environment: ${MPESA_CONFIG.ENVIRONMENT}`);
});

// Export for testing
module.exports = app;