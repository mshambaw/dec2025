-- database/ministry.sql
CREATE DATABASE IF NOT EXISTS philadelphia_ministry;
USE philadelphia_ministry;

-- Members table
CREATE TABLE members (
    id INT PRIMARY KEY AUTO_INCREMENT,
    membership_number VARCHAR(20) UNIQUE,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE,
    phone VARCHAR(20),
    dob DATE,
    gender ENUM('Male', 'Female', 'Other'),
    year_group VARCHAR(50),
    registration_date DATE DEFAULT CURRENT_DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Ministry events table
CREATE TABLE ministry_events (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    event_type ENUM('mission', 'fellowship', 'training', 'workshop', 'prayer'),
    start_date DATE NOT NULL,
    end_date DATE,
    time TIME,
    location VARCHAR(255),
    status ENUM('upcoming', 'ongoing', 'completed', 'cancelled') DEFAULT 'upcoming',
    max_participants INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Event registrations
CREATE TABLE event_registrations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    event_id INT,
    member_id INT,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    attendance_status ENUM('registered', 'attended', 'absent') DEFAULT 'registered',
    FOREIGN KEY (event_id) REFERENCES ministry_events(id),
    FOREIGN KEY (member_id) REFERENCES members(id)
);

-- Contact messages
CREATE TABLE contact_messages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(20),
    subject VARCHAR(255),
    message TEXT NOT NULL,
    status ENUM('new', 'read', 'replied', 'archived') DEFAULT 'new',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Attendance tracking
CREATE TABLE attendance (
    id INT PRIMARY KEY AUTO_INCREMENT,
    event_id INT,
    member_id INT,
    check_in_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    check_out_time TIMESTAMP NULL,
    FOREIGN KEY (event_id) REFERENCES ministry_events(id),
    FOREIGN KEY (member_id) REFERENCES members(id)
);

-- Insert sample data
INSERT INTO members (membership_number, first_name, last_name, email, phone, year_group) VALUES
('PM2024001', 'John', 'Doe', 'john@example.com', '+254712345678', '2024'),
('PM2024002', 'Jane', 'Smith', 'jane@example.com', '+254723456789', '2024'),
('PM2023001', 'Michael', 'Johnson', 'michael@example.com', '+254734567890', '2023');

INSERT INTO ministry_events (title, description, event_type, start_date, end_date, time, location, status) VALUES
('End-Year Mission 2025', 'Annual mission to Mahanga, Vihiga County', 'mission', '2025-12-21', '2026-01-04', '08:00:00', 'Mahanga, Vihiga County', 'upcoming'),
('Pastor Boaz Mentorship Program', 'Leadership and spiritual mentorship', 'training', '2026-02-15', '2026-02-20', '09:00:00', 'Nairobi Headquarters', 'upcoming'),
('Weekly Fellowship', 'Sunday worship service', 'fellowship', '2025-12-01', '2025-12-01', '10:00:00', 'Main Sanctuary', 'upcoming'),
('Bible Study - Book of Romans', 'Weekly Bible study session', 'workshop', '2025-12-03', '2025-12-03', '19:00:00', 'Fellowship Hall', 'upcoming');
-- Add these to your existing database/ministry.sql

-- Event registrations table (enhanced version)
CREATE TABLE IF NOT EXISTS event_registrations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    event_id INT NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    gender ENUM('Male', 'Female', 'Other'),
    age_group VARCHAR(20),
    year_group VARCHAR(50),
    emergency_contact TEXT,
    dietary_requirements TEXT,
    special_needs TEXT,
    church_member ENUM('yes', 'no') DEFAULT 'no',
    previous_mission ENUM('yes', 'no') DEFAULT 'no',
    expectations TEXT,
    registration_code VARCHAR(20) UNIQUE,
    status ENUM('pending', 'confirmed', 'cancelled', 'attended') DEFAULT 'pending',
    payment_status ENUM('pending', 'paid', 'partial', 'waived') DEFAULT 'pending',
    amount_paid DECIMAL(10,2) DEFAULT 0,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    confirmation_sent BOOLEAN DEFAULT FALSE,
    notes TEXT,
    FOREIGN KEY (event_id) REFERENCES ministry_events(id) ON DELETE CASCADE
);

-- Add registered_count column to events table
ALTER TABLE ministry_events ADD COLUMN IF NOT EXISTS registered_count INT DEFAULT 0;

-- Create event registration fees table
CREATE TABLE IF NOT EXISTS event_fees (
    id INT PRIMARY KEY AUTO_INCREMENT,
    event_id INT NOT NULL,
    fee_type VARCHAR(50) NOT NULL, -- 'standard', 'member', 'student', 'early_bird'
    amount DECIMAL(10,2) NOT NULL,
    description TEXT,
    valid_until DATE,
    FOREIGN KEY (event_id) REFERENCES ministry_events(id) ON DELETE CASCADE
);

-- Create payment transactions table
CREATE TABLE IF NOT EXISTS payments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    registration_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method ENUM('mpesa', 'cash', 'bank_transfer', 'card') DEFAULT 'mpesa',
    transaction_id VARCHAR(100),
    status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    confirmed_by INT,
    notes TEXT,
    FOREIGN KEY (registration_id) REFERENCES event_registrations(id) ON DELETE CASCADE
);

-- Add sample fees for events
INSERT INTO event_fees (event_id, fee_type, amount, description, valid_until) VALUES
(1, 'standard', 5000.00, 'Standard mission fee', '2025-12-15'),
(1, 'early_bird', 4000.00, 'Early bird discount', '2025-11-30'),
(1, 'member', 3500.00, 'Member discount', '2025-12-15'),
(2, 'standard', 2000.00, 'Mentorship program fee', '2026-02-10');

-- Add index for better performance
CREATE INDEX idx_event_registrations_event_id ON event_registrations(event_id);
CREATE INDEX idx_event_registrations_email ON event_registrations(email);
CREATE INDEX idx_event_registrations_registration_code ON event_registrations(registration_code);