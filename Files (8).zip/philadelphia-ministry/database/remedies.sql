-- Cart table
CREATE TABLE IF NOT EXISTS remedies_cart (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES members(id),
    FOREIGN KEY (product_id) REFERENCES remedies_products(id),
    UNIQUE KEY unique_cart_item (user_id, product_id)
);

-- Prescriptions
CREATE TABLE IF NOT EXISTS remedies_prescriptions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    prescription_reference VARCHAR(50) UNIQUE,
    patient_id INT NOT NULL,
    practitioner_id INT,
    consultation_id INT,
    prescribed_date DATE NOT NULL,
    expiry_date DATE,
    instructions TEXT,
    status ENUM('active', 'completed', 'cancelled', 'expired') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES members(id),
    FOREIGN KEY (practitioner_id) REFERENCES remedies_practitioners(id),
    FOREIGN KEY (consultation_id) REFERENCES remedies_consultations(id)
);

-- Prescription Items
CREATE TABLE IF NOT EXISTS remedies_prescription_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    prescription_id INT NOT NULL,
    product_id INT NOT NULL,
    dosage VARCHAR(100),
    frequency VARCHAR(100),
    duration_days INT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (prescription_id) REFERENCES remedies_prescriptions(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES remedies_products(id)
);

-- Messages
CREATE TABLE IF NOT EXISTS remedies_messages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    sender_id INT,
    sender_type ENUM('patient', 'practitioner', 'admin', 'system'),
    subject VARCHAR(255),
    message TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES members(id)
);

-- Health Metrics
CREATE TABLE IF NOT EXISTS remedies_health_metrics (
    id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    metric_type ENUM('weight', 'blood_pressure', 'blood_sugar', 'temperature', 'heart_rate') NOT NULL,
    metric_value VARCHAR(50),
    unit VARCHAR(20),
    recorded_date DATE NOT NULL,
    recorded_time TIME,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES members(id)
);

-- User Preferences
CREATE TABLE IF NOT EXISTS remedies_user_preferences (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL UNIQUE,
    notification_appointments BOOLEAN DEFAULT TRUE,
    notification_reminders BOOLEAN DEFAULT TRUE,
    notification_promotions BOOLEAN DEFAULT TRUE,
    email_notifications BOOLEAN DEFAULT TRUE,
    sms_notifications BOOLEAN DEFAULT TRUE,
    language VARCHAR(10) DEFAULT 'en',
    theme VARCHAR(20) DEFAULT 'light',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES members(id)
);

-- Create indexes for better performance
CREATE INDEX idx_bookings_date ON remedies_bookings(booking_date);
CREATE INDEX idx_bookings_status ON remedies_bookings(status);
CREATE INDEX idx_products_category ON remedies_products(category);
CREATE INDEX idx_products_stock ON remedies_products(quantity_in_stock);
CREATE INDEX idx_sales_date ON remedies_sales(created_at);
CREATE INDEX idx_patient_records ON remedies_patient_records(patient_id, record_date);
CREATE INDEX idx_education_dates ON remedies_education(start_date, end_date);
CREATE INDEX idx_mission_dates ON remedies_missions(start_date, end_date);