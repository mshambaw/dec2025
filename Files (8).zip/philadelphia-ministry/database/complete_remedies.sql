-- ============================================
-- COMPLETE REMEDIES DEPARTMENT DATABASE SETUP
-- ============================================

-- Drop existing tables if needed (use with caution in production)
-- DROP TABLE IF EXISTS remedies_cart, remedies_prescription_items, remedies_prescriptions;
-- DROP TABLE IF EXISTS remedies_messages, remedies_health_metrics, remedies_user_preferences;
-- DROP TABLE IF EXISTS remedies_mission_beneficiaries, remedies_mission_participants, remedies_missions;
-- DROP TABLE IF EXISTS remedies_education_registrations, remedies_education;
-- DROP TABLE IF EXISTS remedies_sale_items, remedies_sales;
-- DROP TABLE IF EXISTS remedies_patient_records, remedies_consultations;
-- DROP TABLE IF EXISTS remedies_bookings, remedies_treatments;
-- DROP TABLE IF EXISTS remedies_practitioners, remedies_products;
-- DROP TABLE IF EXISTS remedies_inventory_log;

-- ============================================
-- MAIN TABLES
-- ============================================

-- Treatments/Procedures
CREATE TABLE IF NOT EXISTS remedies_treatments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    duration_minutes INT DEFAULT 60,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    category VARCHAR(100) DEFAULT 'general',
    image_url VARCHAR(500),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Practitioners/Therapists
CREATE TABLE IF NOT EXISTS remedies_practitioners (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    full_name VARCHAR(255) NOT NULL,
    specialization VARCHAR(255),
    qualifications TEXT,
    bio TEXT,
    contact_phone VARCHAR(20),
    contact_email VARCHAR(255),
    profile_image VARCHAR(500),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES members(id) ON DELETE SET NULL
);

-- Treatment Bookings
CREATE TABLE IF NOT EXISTS remedies_bookings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    booking_reference VARCHAR(50) UNIQUE NOT NULL,
    patient_id INT NOT NULL,
    treatment_id INT NOT NULL,
    practitioner_id INT,
    booking_date DATE NOT NULL,
    booking_time TIME NOT NULL,
    status ENUM('pending', 'confirmed', 'completed', 'cancelled', 'no-show') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES members(id) ON DELETE CASCADE,
    FOREIGN KEY (treatment_id) REFERENCES remedies_treatments(id) ON DELETE CASCADE,
    FOREIGN KEY (practitioner_id) REFERENCES remedies_practitioners(id) ON DELETE SET NULL
);

-- Consultations
CREATE TABLE IF NOT EXISTS remedies_consultations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    consultation_reference VARCHAR(50) UNIQUE NOT NULL,
    patient_id INT NOT NULL,
    practitioner_id INT,
    consultation_date DATE NOT NULL,
    consultation_time TIME NOT NULL,
    type ENUM('initial', 'followup', 'emergency', 'routine', 'online') DEFAULT 'initial',
    chief_complaint TEXT,
    medical_history TEXT,
    assessment TEXT,
    recommendations TEXT,
    followup_date DATE,
    status ENUM('scheduled', 'in-progress', 'completed', 'cancelled') DEFAULT 'scheduled',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES members(id) ON DELETE CASCADE,
    FOREIGN KEY (practitioner_id) REFERENCES remedies_practitioners(id) ON DELETE SET NULL
);

-- Remedies Products
CREATE TABLE IF NOT EXISTS remedies_products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    sku VARCHAR(100) UNIQUE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    subcategory VARCHAR(100),
    unit_price DECIMAL(10,2) NOT NULL,
    cost_price DECIMAL(10,2),
    quantity_in_stock INT DEFAULT 0,
    reorder_level INT DEFAULT 10,
    unit_of_measure VARCHAR(50),
    supplier VARCHAR(255),
    benefits TEXT,
    usage_instructions TEXT,
    precautions TEXT,
    image_url VARCHAR(500),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Sales Transactions
CREATE TABLE IF NOT EXISTS remedies_sales (
    id INT PRIMARY KEY AUTO_INCREMENT,
    sale_reference VARCHAR(50) UNIQUE NOT NULL,
    customer_id INT,
    customer_name VARCHAR(255),
    customer_phone VARCHAR(20),
    customer_email VARCHAR(255),
    total_amount DECIMAL(10,2) NOT NULL,
    discount_amount DECIMAL(10,2) DEFAULT 0,
    tax_amount DECIMAL(10,2) DEFAULT 0,
    net_amount DECIMAL(10,2) NOT NULL,
    payment_method ENUM('cash', 'card', 'mobile_money', 'insurance', 'credit') DEFAULT 'cash',
    payment_status ENUM('pending', 'paid', 'partial', 'refunded') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES members(id) ON DELETE SET NULL
);

-- Sale Items
CREATE TABLE IF NOT EXISTS remedies_sale_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    sale_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    discount_percentage DECIMAL(5,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sale_id) REFERENCES remedies_sales(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES remedies_products(id) ON DELETE RESTRICT
);

-- Health Education
CREATE TABLE IF NOT EXISTS remedies_education (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    content LONGTEXT,
    type ENUM('workshop', 'course', 'seminar', 'webinar', 'article', 'video') NOT NULL,
    instructor_id INT,
    start_date DATE,
    end_date DATE,
    schedule_time TIME,
    duration_hours INT,
    location VARCHAR(500),
    max_participants INT,
    registration_fee DECIMAL(10,2) DEFAULT 0,
    is_certified BOOLEAN DEFAULT FALSE,
    status ENUM('upcoming', 'ongoing', 'completed', 'cancelled') DEFAULT 'upcoming',
    image_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (instructor_id) REFERENCES remedies_practitioners(id) ON DELETE SET NULL
);

-- Education Registrations
CREATE TABLE IF NOT EXISTS remedies_education_registrations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    education_id INT NOT NULL,
    participant_id INT NOT NULL,
    registration_date DATE NOT NULL,
    payment_status ENUM('pending', 'paid', 'free') DEFAULT 'pending',
    certificate_issued BOOLEAN DEFAULT FALSE,
    certificate_number VARCHAR(100),
    attendance_marked BOOLEAN DEFAULT FALSE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (education_id) REFERENCES remedies_education(id) ON DELETE CASCADE,
    FOREIGN KEY (participant_id) REFERENCES members(id) ON DELETE CASCADE,
    UNIQUE KEY unique_registration (education_id, participant_id)
);

-- Medical Missionary Activities
CREATE TABLE IF NOT EXISTS remedies_missions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    mission_name VARCHAR(255) NOT NULL,
    description TEXT,
    location VARCHAR(500) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    mission_type ENUM('health_screening', 'treatment_camp', 'education', 'vaccination', 'surgery') NOT NULL,
    target_beneficiaries INT,
    budget DECIMAL(10,2),
    coordinator_id INT,
    status ENUM('planning', 'active', 'completed', 'cancelled') DEFAULT 'planning',
    image_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (coordinator_id) REFERENCES remedies_practitioners(id) ON DELETE SET NULL
);

-- Mission Participants
CREATE TABLE IF NOT EXISTS remedies_mission_participants (
    id INT PRIMARY KEY AUTO_INCREMENT,
    mission_id INT NOT NULL,
    participant_id INT NOT NULL,
    role VARCHAR(100),
    assigned_tasks TEXT,
    commitment_level ENUM('full_time', 'part_time', 'volunteer') DEFAULT 'volunteer',
    start_date DATE,
    end_date DATE,
    status ENUM('registered', 'confirmed', 'active', 'completed', 'withdrawn') DEFAULT 'registered',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (mission_id) REFERENCES remedies_missions(id) ON DELETE CASCADE,
    FOREIGN KEY (participant_id) REFERENCES members(id) ON DELETE CASCADE,
    UNIQUE KEY unique_participation (mission_id, participant_id)
);

-- Mission Beneficiaries
CREATE TABLE IF NOT EXISTS remedies_mission_beneficiaries (
    id INT PRIMARY KEY AUTO_INCREMENT,
    mission_id INT NOT NULL,
    beneficiary_name VARCHAR(255) NOT NULL,
    age INT,
    gender ENUM('male', 'female', 'other'),
    contact_phone VARCHAR(20),
    village_location VARCHAR(255),
    services_received TEXT,
    medical_notes TEXT,
    followup_required BOOLEAN DEFAULT FALSE,
    followup_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (mission_id) REFERENCES remedies_missions(id) ON DELETE CASCADE
);

-- Patient Medical Records
CREATE TABLE IF NOT EXISTS remedies_patient_records (
    id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    record_type ENUM('vitals', 'allergy', 'medication', 'condition', 'test_result', 'progress_note', 'prescription') NOT NULL,
    record_date DATE NOT NULL,
    recorded_by INT,
    details TEXT,
    attachments JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES members(id) ON DELETE CASCADE,
    FOREIGN KEY (recorded_by) REFERENCES remedies_practitioners(id) ON DELETE SET NULL
);

-- Inventory Log
CREATE TABLE IF NOT EXISTS remedies_inventory_log (
    id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT NOT NULL,
    transaction_type ENUM('purchase', 'sale', 'adjustment', 'damage', 'return') NOT NULL,
    quantity INT NOT NULL,
    previous_quantity INT,
    new_quantity INT,
    reference_id INT,
    notes TEXT,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES remedies_products(id) ON DELETE CASCADE
);

-- ============================================
-- SUPPORTING TABLES
-- ============================================

-- Cart table
CREATE TABLE IF NOT EXISTS remedies_cart (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES members(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES remedies_products(id) ON DELETE CASCADE,
    UNIQUE KEY unique_cart_item (user_id, product_id)
);

-- Prescriptions
CREATE TABLE IF NOT EXISTS remedies_prescriptions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    prescription_reference VARCHAR(50) UNIQUE NOT NULL,
    patient_id INT NOT NULL,
    practitioner_id INT,
    consultation_id INT,
    prescribed_date DATE NOT NULL,
    expiry_date DATE,
    instructions TEXT,
    status ENUM('active', 'completed', 'cancelled', 'expired') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES members(id) ON DELETE CASCADE,
    FOREIGN KEY (practitioner_id) REFERENCES remedies_practitioners(id) ON DELETE SET NULL,
    FOREIGN KEY (consultation_id) REFERENCES remedies_consultations(id) ON DELETE SET NULL
);

-- Prescription Items
CREATE TABLE IF NOT EXISTS remedies_prescription_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    prescription_id INT NOT NULL,
    product_id INT NOT NULL,
    dosage VARCHAR(100),
    frequency VARCHAR(100),
    duration_days INT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (prescription_id) REFERENCES remedies_prescriptions(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES remedies_products(id) ON DELETE RESTRICT
);

-- Messages
CREATE TABLE IF NOT EXISTS remedies_messages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    sender_id INT,
    sender_type ENUM('patient', 'practitioner', 'admin', 'system'),
    subject VARCHAR(255),
    message TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES members(id) ON DELETE CASCADE,
    INDEX idx_patient_unread (patient_id, is_read)
);

-- Health Metrics
CREATE TABLE IF NOT EXISTS remedies_health_metrics (
    id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    metric_type ENUM('weight', 'blood_pressure', 'blood_sugar', 'temperature', 'heart_rate', 'bmi') NOT NULL,
    metric_value VARCHAR(50),
    unit VARCHAR(20),
    recorded_date DATE NOT NULL,
    recorded_time TIME,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES members(id) ON DELETE CASCADE,
    INDEX idx_patient_metrics (patient_id, metric_type, recorded_date)
);

-- User Preferences
CREATE TABLE IF NOT EXISTS remedies_user_preferences (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL UNIQUE,
    notification_appointments BOOLEAN DEFAULT TRUE,
    notification_reminders BOOLEAN DEFAULT TRUE,
    notification_promotions BOOLEAN DEFAULT TRUE,
    email_notifications BOOLEAN DEFAULT TRUE,
    sms_notifications BOOLEAN DEFAULT TRUE,
    language VARCHAR(10) DEFAULT 'en',
    theme VARCHAR(20) DEFAULT 'light',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES members(id) ON DELETE CASCADE
);

-- Payment Transactions
CREATE TABLE IF NOT EXISTS remedies_payments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    payment_reference VARCHAR(50) UNIQUE NOT NULL,
    sale_id INT,
    booking_id INT,
    consultation_id INT,
    education_registration_id INT,
    amount DECIMAL(10,2) NOT NULL,
    payment_method ENUM('cash', 'card', 'mobile_money', 'bank_transfer') NOT NULL,
    transaction_id VARCHAR(100),
    status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (sale_id) REFERENCES remedies_sales(id) ON DELETE SET NULL,
    FOREIGN KEY (booking_id) REFERENCES remedies_bookings(id) ON DELETE SET NULL,
    FOREIGN KEY (consultation_id) REFERENCES remedies_consultations(id) ON DELETE SET NULL,
    FOREIGN KEY (education_registration_id) REFERENCES remedies_education_registrations(id) ON DELETE SET NULL
);

-- ============================================
-- INDEXES FOR PERFORMANCE
-- ============================================

CREATE INDEX idx_bookings_date ON remedies_bookings(booking_date);
CREATE INDEX idx_bookings_status ON remedies_bookings(status);
CREATE INDEX idx_bookings_patient ON remedies_bookings(patient_id, booking_date);
CREATE INDEX idx_consultations_patient ON remedies_consultations(patient_id, consultation_date);
CREATE INDEX idx_products_category ON remedies_products(category);
CREATE INDEX idx_products_stock ON remedies_products(quantity_in_stock, is_active);
CREATE INDEX idx_sales_date ON remedies_sales(created_at);
CREATE INDEX idx_sales_customer ON remedies_sales(customer_id, created_at);
CREATE INDEX idx_patient_records ON remedies_patient_records(patient_id, record_date DESC);
CREATE INDEX idx_education_dates ON remedies_education(start_date, end_date, status);
CREATE INDEX idx_education_type ON remedies_education(type, status);
CREATE INDEX idx_mission_dates ON remedies_missions(start_date, end_date, status);
CREATE INDEX idx_messages_patient ON remedies_messages(patient_id, created_at DESC);
CREATE INDEX idx_prescriptions_patient ON remedies_prescriptions(patient_id, prescribed_date DESC);

-- ============================================
-- SAMPLE DATA FOR TESTING
-- ============================================

-- Insert sample treatments
INSERT INTO remedies_treatments (name, description, duration_minutes, price, category) VALUES
('Herbal Massage', 'Therapeutic massage using herbal oils for relaxation and pain relief', 60, 2500.00, 'massage'),
('Hydrotherapy Session', 'Water-based treatment for circulation and detoxification', 45, 1800.00, 'hydrotherapy'),
('Acupuncture Therapy', 'Traditional Chinese medicine for pain management', 60, 3000.00, 'therapy'),
('Cupping Therapy', 'Suction therapy for muscle tension and blood flow', 30, 1500.00, 'therapy'),
('Reflexology', 'Foot massage targeting reflex points for whole body wellness', 45, 2000.00, 'massage'),
('Aromatherapy', 'Essential oil treatment for stress relief and mood enhancement', 60, 2200.00, 'relaxation'),
('Detox Foot Bath', 'Ionic foot bath for detoxification and energy boost', 30, 1200.00, 'detox');

-- Insert sample practitioners
INSERT INTO remedies_practitioners (full_name, specialization, qualifications, bio, contact_phone, contact_email) VALUES
('Dr. Jane Wambui', 'Herbal Medicine & Nutrition', 'PhD in Natural Medicine, Certified Herbalist', '15+ years experience in natural healing and herbal remedies', '0712345678', 'jane@philadelphia-ministry.org'),
('John Mwangi', 'Massage & Physical Therapy', 'Certified Massage Therapist, Physical Therapy Diploma', 'Specialized in therapeutic massage and pain management', '0723456789', 'john@philadelphia-ministry.org'),
('Mary Atieno', 'Hydrotherapy & Detox', 'Hydrotherapy Certification, Detox Specialist', 'Expert in water-based treatments and detox programs', '0734567890', 'mary@philadelphia-ministry.org'),
('Dr. Robert Ochieng', 'Traditional Medicine', 'MD, Traditional Medicine Specialist', 'Combining modern and traditional healing methods', '0745678901', 'robert@philadelphia-ministry.org');

-- Insert sample products
INSERT INTO remedies_products (sku, name, description, category, unit_price, quantity_in_stock, unit_of_measure) VALUES
('HERB-001', 'Moringa Powder', 'Organic moringa leaf powder, rich in nutrients and antioxidants', 'Herbs', 800.00, 50, '100g pack'),
('HERB-002', 'Neem Leaves', 'Dried neem leaves for skin care and detoxification', 'Herbs', 500.00, 30, '200g pack'),
('SUPP-001', 'Vitamin C 1000mg', 'Natural vitamin C supplement for immune support', 'Supplements', 1200.00, 100, '60 tablets'),
('SUPP-002', 'Zinc 50mg', 'Zinc supplement for immune function and healing', 'Supplements', 900.00, 75, '90 capsules'),
('OIL-001', 'Lavender Essential Oil', 'Pure lavender oil for relaxation and sleep', 'Oils', 1500.00, 40, '15ml'),
('OIL-002', 'Tea Tree Oil', 'Antibacterial and antifungal essential oil', 'Oils', 1200.00, 35, '15ml'),
('TEA-001', 'Detox Herbal Tea', 'Herbal blend for detoxification and digestion', 'Teas', 600.00, 60, '20 tea bags'),
('EQP-001', 'Acupressure Mat', 'Acupressure mat for pain relief and relaxation', 'Equipment', 2500.00, 20, 'piece');

-- Insert sample education programs
INSERT INTO remedies_education (title, description, type, start_date, end_date, schedule_time, duration_hours, location, max_participants, registration_fee, is_certified) VALUES
('Herbal Medicine Basics', 'Learn fundamental principles of herbal medicine and basic remedy preparation', 'course', DATE_ADD(CURDATE(), INTERVAL 7 DAY), DATE_ADD(CURDATE(), INTERVAL 14 DAY), '10:00:00', 12, 'Training Room', 20, 5000.00, TRUE),
('Healthy Cooking Workshop', 'Hands-on workshop on preparing healthy, nutritious meals', 'workshop', DATE_ADD(CURDATE(), INTERVAL 3 DAY), NULL, '14:00:00', 4, 'Kitchen Lab', 15, 2000.00, FALSE),
('Stress Management Seminar', 'Learn natural techniques for managing stress and anxiety', 'seminar', DATE_ADD(CURDATE(), INTERVAL 5 DAY), NULL, '18:00:00', 3, 'Conference Hall', 50, 0.00, FALSE),
('First Aid with Herbs', 'Emergency first aid using natural herbs and remedies', 'course', DATE_ADD(CURDATE(), INTERVAL 10 DAY), DATE_ADD(CURDATE(), INTERVAL 17 DAY), '09:00:00', 8, 'Training Room', 25, 4000.00, TRUE);

-- Insert sample missions
INSERT INTO remedies_missions (mission_name, description, location, start_date, end_date, mission_type, target_beneficiaries, budget, status) VALUES
('Rural Health Screening', 'Free health screening and basic treatment for rural community', 'Kajiado County', DATE_ADD(CURDATE(), INTERVAL 14 DAY), DATE_ADD(CURDATE(), INTERVAL 16 DAY), 'health_screening', 500, 150000.00, 'planning'),
('Urban Slum Health Camp', 'Medical camp providing free consultations and medicines', 'Kibera, Nairobi', DATE_ADD(CURDATE(), INTERVAL 21 DAY), DATE_ADD(CURDATE(), INTERVAL 22 DAY), 'treatment_camp', 300, 100000.00, 'planning'),
('School Health Education', 'Health education program for primary school children', 'Machakos County', DATE_ADD(CURDATE(), INTERVAL 28 DAY), NULL, 'education', 200, 50000.00, 'planning');

-- Create admin user for remedies (if not exists in members table)
-- Note: You need to have a members table first. This assumes you have admin users.
-- INSERT INTO members (full_name, email, phone, role) VALUES 
-- ('Remedies Admin', 'remedies.admin@philadelphia-ministry.org', '0711111111', 'remedies_admin');

-- ============================================
-- STORED PROCEDURES FOR COMMON OPERATIONS
-- ============================================

DELIMITER $$

-- Procedure to create booking
CREATE PROCEDURE CreateBooking(
    IN p_patient_id INT,
    IN p_treatment_id INT,
    IN p_practitioner_id INT,
    IN p_booking_date DATE,
    IN p_booking_time TIME,
    IN p_notes TEXT
)
BEGIN
    DECLARE v_reference VARCHAR(50);
    DECLARE v_treatment_price DECIMAL(10,2);
    
    -- Generate unique reference
    SET v_reference = CONCAT('BOOK-', DATE_FORMAT(NOW(), '%Y%m%d'), '-', LPAD(FLOOR(RAND() * 10000), 4, '0'));
    
    -- Get treatment price
    SELECT price INTO v_treatment_price FROM remedies_treatments WHERE id = p_treatment_id;
    
    -- Insert booking
    INSERT INTO remedies_bookings (booking_reference, patient_id, treatment_id, practitioner_id, 
                                   booking_date, booking_time, notes)
    VALUES (v_reference, p_patient_id, p_treatment_id, p_practitioner_id,
            p_booking_date, p_booking_time, p_notes);
    
    SELECT v_reference as booking_reference, LAST_INSERT_ID() as booking_id;
END$$

-- Procedure to process sale
CREATE PROCEDURE ProcessSale(
    IN p_customer_id INT,
    IN p_customer_name VARCHAR(255),
    IN p_customer_phone VARCHAR(20),
    IN p_customer_email VARCHAR(255),
    IN p_payment_method ENUM('cash', 'card', 'mobile_money', 'insurance', 'credit'),
    IN p_notes TEXT
)
BEGIN
    DECLARE v_reference VARCHAR(50);
    DECLARE v_total DECIMAL(10,2) DEFAULT 0;
    DECLARE v_cart_count INT;
    DECLARE v_sale_id INT;
    
    -- Generate unique reference
    SET v_reference = CONCAT('SALE-', DATE_FORMAT(NOW(), '%Y%m%d'), '-', LPAD(FLOOR(RAND() * 10000), 4, '0'));
    
    -- Calculate total from cart
    SELECT SUM(p.unit_price * c.quantity) INTO v_total
    FROM remedies_cart c
    JOIN remedies_products p ON c.product_id = p.id
    WHERE c.user_id = p_customer_id;
    
    -- Count cart items
    SELECT COUNT(*) INTO v_cart_count FROM remedies_cart WHERE user_id = p_customer_id;
    
    IF v_cart_count > 0 AND v_total > 0 THEN
        -- Create sale record
        INSERT INTO remedies_sales (sale_reference, customer_id, customer_name, customer_phone, 
                                    customer_email, total_amount, net_amount, payment_method, notes)
        VALUES (v_reference, p_customer_id, p_customer_name, p_customer_phone, p_customer_email,
                v_total, v_total, p_payment_method, p_notes);
        
        SET v_sale_id = LAST_INSERT_ID();
        
        -- Insert sale items and update inventory
        INSERT INTO remedies_sale_items (sale_id, product_id, quantity, unit_price, total_price)
        SELECT v_sale_id, c.product_id, c.quantity, p.unit_price, (p.unit_price * c.quantity)
        FROM remedies_cart c
        JOIN remedies_products p ON c.product_id = p.id
        WHERE c.user_id = p_customer_id;
        
        -- Update product quantities
        UPDATE remedies_products p
        JOIN remedies_cart c ON p.id = c.product_id
        SET p.quantity_in_stock = p.quantity_in_stock - c.quantity
        WHERE c.user_id = p_customer_id;
        
        -- Clear cart
        DELETE FROM remedies_cart WHERE user_id = p_customer_id;
        
        -- Log inventory changes
        INSERT INTO remedies_inventory_log (product_id, transaction_type, quantity, previous_quantity, new_quantity, reference_id, notes)
        SELECT c.product_id, 'sale', c.quantity, p.quantity_in_stock + c.quantity, p.quantity_in_stock, v_sale_id, 'Sale processed'
        FROM remedies_cart c
        JOIN remedies_products p ON c.product_id = p.id
        WHERE c.user_id = p_customer_id;
        
        SELECT v_reference as sale_reference, v_sale_id as sale_id, v_total as total_amount;
    ELSE
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cart is empty or total is zero';
    END IF;
END$$

-- Procedure to check and send low stock alerts
CREATE PROCEDURE CheckLowStock()
BEGIN
    SELECT p.id, p.sku, p.name, p.quantity_in_stock, p.reorder_level, 
           p.supplier, p.category
    FROM remedies_products p
    WHERE p.is_active = 1 
      AND p.quantity_in_stock <= p.reorder_level
    ORDER BY p.quantity_in_stock ASC;
END$$

-- Procedure to get daily appointments
CREATE PROCEDURE GetDailyAppointments(IN p_date DATE)
BEGIN
    SELECT b.booking_reference, b.booking_time, t.name as treatment, 
           m.full_name as patient, p.full_name as practitioner, b.status
    FROM remedies_bookings b
    JOIN remedies_treatments t ON b.treatment_id = t.id
    JOIN members m ON b.patient_id = m.id
    LEFT JOIN remedies_practitioners p ON b.practitioner_id = p.id
    WHERE b.booking_date = p_date
      AND b.status IN ('confirmed', 'pending')
    ORDER BY b.booking_time ASC;
END$$

DELIMITER ;

-- ============================================
-- TRIGGERS FOR AUTOMATED ACTIONS
-- ============================================

DELIMITER $$

-- Trigger to generate prescription reference
CREATE TRIGGER before_prescription_insert
BEFORE INSERT ON remedies_prescriptions
FOR EACH ROW
BEGIN
    IF NEW.prescription_reference IS NULL THEN
        SET NEW.prescription_reference = CONCAT('RX-', DATE_FORMAT(NOW(), '%Y%m%d'), '-', LPAD(FLOOR(RAND() * 10000), 4, '0'));
    END IF;
END$$

-- Trigger to update booking status when past date
CREATE TRIGGER update_booking_status_daily
AFTER UPDATE ON remedies_bookings
FOR EACH ROW
BEGIN
    -- Auto-complete past appointments
    IF OLD.booking_date < CURDATE() AND OLD.status = 'confirmed' THEN
        UPDATE remedies_bookings 
        SET status = 'completed' 
        WHERE id = OLD.id AND status = 'confirmed';
    END IF;
END$$

-- Trigger to auto-create user preferences
CREATE TRIGGER after_member_insert
AFTER INSERT ON members
FOR EACH ROW
BEGIN
    INSERT INTO remedies_user_preferences (user_id) VALUES (NEW.id);
END$$

DELIMITER ;

-- ============================================
-- VIEWS FOR REPORTING
-- ============================================

-- Daily sales summary view
CREATE OR REPLACE VIEW v_daily_sales AS
SELECT 
    DATE(created_at) as sale_date,
    COUNT(*) as total_sales,
    SUM(net_amount) as total_revenue,
    AVG(net_amount) as average_sale,
    COUNT(DISTINCT customer_id) as unique_customers
FROM remedies_sales
WHERE payment_status = 'paid'
GROUP BY DATE(created_at);

-- Monthly revenue by category view
CREATE OR REPLACE VIEW v_monthly_category_revenue AS
SELECT 
    YEAR(s.created_at) as year,
    MONTH(s.created_at) as month,
    p.category,
    COUNT(si.id) as items_sold,
    SUM(si.total_price) as revenue
FROM remedies_sales s
JOIN remedies_sale_items si ON s.id = si.sale_id
JOIN remedies_products p ON si.product_id = p.id
WHERE s.payment_status = 'paid'
GROUP BY YEAR(s.created_at), MONTH(s.created_at), p.category;

-- Patient appointment history view
CREATE OR REPLACE VIEW v_patient_appointments AS
SELECT 
    m.id as patient_id,
    m.full_name as patient_name,
    COUNT(b.id) as total_appointments,
    SUM(CASE WHEN b.status = 'completed' THEN 1 ELSE 0 END) as completed_appointments,
    SUM(CASE WHEN b.status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_appointments,
    MAX(b.booking_date) as last_appointment
FROM members m
LEFT JOIN remedies_bookings b ON m.id = b.patient_id
GROUP BY m.id, m.full_name;

-- Inventory status view
CREATE OR REPLACE VIEW v_inventory_status AS
SELECT 
    p.id,
    p.sku,
    p.name,
    p.category,
    p.quantity_in_stock,
    p.reorder_level,
    p.unit_price,
    CASE 
        WHEN p.quantity_in_stock = 0 THEN 'Out of Stock'
        WHEN p.quantity_in_stock <= p.reorder_level THEN 'Low Stock'
        ELSE 'In Stock'
    END as stock_status,
    (SELECT SUM(quantity) FROM remedies_sale_items si 
     WHERE si.product_id = p.id AND MONTH(si.created_at) = MONTH(CURDATE())) as monthly_sales
FROM remedies_products p
WHERE p.is_active = 1;

-- ============================================
-- USER PERMISSIONS (Example)
-- ============================================

-- Note: These are examples. Adjust based on your actual user management system
/*
-- Create remedies admin role
CREATE ROLE IF NOT EXISTS 'remedies_admin';

-- Grant permissions to remedies admin
GRANT SELECT, INSERT, UPDATE, DELETE ON remedies.* TO 'remedies_admin';

-- Create remedies user role
CREATE ROLE IF NOT EXISTS 'remedies_user';

-- Grant limited permissions to regular users
GRANT SELECT ON remedies.remedies_treatments TO 'remedies_user';
GRANT SELECT, INSERT, UPDATE ON remedies.remedies_bookings TO 'remedies_user';
GRANT SELECT, INSERT ON remedies.remedies_cart TO 'remedies_user';
*/

-- ============================================
-- DATABASE MAINTENANCE
-- ============================================

-- Create event for daily maintenance
DELIMITER $$

CREATE EVENT IF NOT EXISTS daily_remedies_maintenance
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP
DO
BEGIN
    -- Archive old records (older than 2 years)
    -- CREATE TABLE IF NOT EXISTS remedies_bookings_archive LIKE remedies_bookings;
    -- INSERT INTO remedies_bookings_archive 
    -- SELECT * FROM remedies_bookings WHERE booking_date < DATE_SUB(CURDATE(), INTERVAL 2 YEAR);
    -- DELETE FROM remedies_bookings WHERE booking_date < DATE_SUB(CURDATE(), INTERVAL 2 YEAR);
    
    -- Update expired prescriptions
    UPDATE remedies_prescriptions 
    SET status = 'expired' 
    WHERE expiry_date < CURDATE() AND status = 'active';
    
    -- Update completed missions
    UPDATE remedies_missions 
    SET status = 'completed' 
    WHERE end_date < CURDATE() AND status = 'active';
    
    -- Update completed education programs
    UPDATE remedies_education 
    SET status = 'completed' 
    WHERE end_date < CURDATE() AND status = 'ongoing';
END$$

DELIMITER ;

-- ============================================
-- FINAL SETUP NOTES
-- ============================================

/*
SETUP INSTRUCTIONS:
1. Run this SQL file in your MySQL database
2. Update config/database.php with your database credentials
3. Add remedies admin user to your members table
4. Run the sample data inserts to populate test data
5. Configure .htaccess for remedies directory
6. Set up cron jobs for automated tasks
*/

SELECT 'Remedies Department Database Setup Complete!' as status;