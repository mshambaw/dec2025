-- Music Department Database Schema

CREATE DATABASE IF NOT EXISTS philadelphia_music;
USE philadelphia_music;

-- Music Users Table
CREATE TABLE music_users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(20),
    role ENUM('admin', 'user', 'leader') DEFAULT 'user',
    voice_part ENUM('soprano', 'alto', 'tenor', 'bass', 'instrumental', 'none') DEFAULT 'none',
    status ENUM('active', 'inactive', 'pending') DEFAULT 'active',
    join_date DATE,
    last_login DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Songs Table
CREATE TABLE songs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    song_number VARCHAR(20),
    title VARCHAR(200) NOT NULL,
    alternate_title VARCHAR(200),
    language ENUM('english', 'swahili', 'kiswahili', 'other') DEFAULT 'english',
    category ENUM('hymn', 'chorus', 'worship', 'contemporary', 'traditional', 'special') DEFAULT 'hymn',
    composer VARCHAR(100),
    arranger VARCHAR(100),
    key_signature VARCHAR(10),
    time_signature VARCHAR(10),
    tempo VARCHAR(50),
    lyrics TEXT,
    file_audio VARCHAR(255),
    file_pdf VARCHAR(255),
    file_lyrics VARCHAR(255),
    file_chords VARCHAR(255),
    status ENUM('active', 'archived', 'draft') DEFAULT 'active',
    views INT DEFAULT 0,
    downloads INT DEFAULT 0,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES music_users(id)
);

-- Service Schedule Table
CREATE TABLE service_schedule (
    id INT PRIMARY KEY AUTO_INCREMENT,
    service_date DATE NOT NULL,
    service_time TIME NOT NULL,
    service_type VARCHAR(50) NOT NULL,
    theme VARCHAR(200),
    leader INT,
    accompanist INT,
    notes TEXT,
    status ENUM('scheduled', 'cancelled', 'completed') DEFAULT 'scheduled',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (leader) REFERENCES music_users(id),
    FOREIGN KEY (accompanist) REFERENCES music_users(id)
);

-- Song Assignments for Services
CREATE TABLE service_songs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    service_id INT NOT NULL,
    song_id INT NOT NULL,
    order_number INT,
    special_notes TEXT,
    FOREIGN KEY (service_id) REFERENCES service_schedule(id) ON DELETE CASCADE,
    FOREIGN KEY (song_id) REFERENCES songs(id)
);

-- Choir Assignments
CREATE TABLE choir_assignments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    service_id INT NOT NULL,
    role ENUM('singer', 'soloist', 'instrumental', 'backup', 'none') DEFAULT 'singer',
    confirmed BOOLEAN DEFAULT FALSE,
    notes TEXT,
    FOREIGN KEY (user_id) REFERENCES music_users(id),
    FOREIGN KEY (service_id) REFERENCES service_schedule(id) ON DELETE CASCADE
);

-- Resources Table
CREATE TABLE music_resources (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    file_name VARCHAR(255),
    file_type VARCHAR(50),
    file_size INT,
    category ENUM('sheet_music', 'audio', 'video', 'document', 'other') DEFAULT 'document',
    uploaded_by INT,
    downloads INT DEFAULT 0,
    status ENUM('active', 'archived') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (uploaded_by) REFERENCES music_users(id)
);

-- Activity Log
CREATE TABLE music_activity_log (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    activity_type VARCHAR(50) NOT NULL,
    description TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES music_users(id)
);

-- Insert default admin user (password: admin123)
INSERT INTO music_users (username, password, full_name, email, role, status) 
VALUES ('admin', '$2y$10$YourHashedPasswordHere', 'Music Administrator', 'music@philadelphiaministry.org', 'admin', 'active');

-- Insert sample songs from the PDF
INSERT INTO songs (song_number, title, language, category, lyrics) VALUES
('1', 'Tunakutukuza', 'swahili', 'worship', 'Tunakutukuza ewe Mungu mwenye enzi...'),
('SDAH 495', 'Near to the Heart of God', 'english', 'hymn', 'There is a place of quiet rest...'),
('3', 'Conquering Now And Still To Conquer', 'english', 'hymn', 'Conquering now and still to conquer...'),
('NZK 62', 'Napenda Kitabu Chake', 'swahili', 'worship', 'Napenda kitabu chake, kilichotoka mbinguni...'),
('5', 'Heri', 'swahili', 'worship', 'Heri hao wanaomwamini muumbaji...');