-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 18, 2025 at 03:04 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `philadelphia_ministry`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `status` enum('present','absent','late') DEFAULT 'present',
  `checked_in` timestamp NOT NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `broadcast_logs`
--

CREATE TABLE `broadcast_logs` (
  `id` int(11) NOT NULL,
  `broadcast_type` enum('sms','email') NOT NULL,
  `message` text NOT NULL,
  `recipient_type` enum('all','year_group','event') NOT NULL,
  `recipient_count` int(11) DEFAULT 0,
  `year_group` varchar(50) DEFAULT NULL,
  `event_id` int(11) DEFAULT NULL,
  `status` enum('pending','sent','failed') DEFAULT 'pending',
  `sent_by` varchar(100) DEFAULT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `broadcast_logs`
--

INSERT INTO `broadcast_logs` (`id`, `broadcast_type`, `message`, `recipient_type`, `recipient_count`, `year_group`, `event_id`, `status`, `sent_by`, `sent_at`, `created_at`) VALUES
(2, 'email', 'Important: End-Year Mission briefing this Friday at 6 PM. All participants must attend. Bring your registration documents.', 'all', 4, NULL, NULL, 'sent', 'Administrator', '2025-12-17 17:22:35', '2025-12-17 17:22:18'),
(3, 'sms', 'Important: End-Year Mission briefing this Friday at 6 PM. All participants must attend. Bring your registration documents.', 'all', 4, NULL, NULL, 'sent', 'Administrator', '2025-12-17 17:23:13', '2025-12-17 17:23:04');

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `status` enum('new','read','replied','archived') DEFAULT 'new',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `event_fees`
--

CREATE TABLE `event_fees` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `fee_type` varchar(50) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL,
  `valid_until` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event_fees`
--

INSERT INTO `event_fees` (`id`, `event_id`, `fee_type`, `amount`, `description`, `valid_until`) VALUES
(1, 1, 'standard', 5000.00, 'Standard mission fee', '2025-12-15'),
(2, 1, 'early_bird', 4000.00, 'Early bird discount', '2025-11-30'),
(3, 1, 'member', 3500.00, 'Member discount', '2025-12-15'),
(4, 2, 'standard', 2000.00, 'Mentorship program fee', '2026-02-10');

-- --------------------------------------------------------

--
-- Table structure for table `event_registrations`
--

CREATE TABLE `event_registrations` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `age_group` varchar(20) DEFAULT NULL,
  `year_group` varchar(50) DEFAULT NULL,
  `emergency_contact` text DEFAULT NULL,
  `dietary_requirements` text DEFAULT NULL,
  `special_needs` text DEFAULT NULL,
  `church_member` enum('yes','no') DEFAULT 'no',
  `previous_mission` enum('yes','no') DEFAULT 'no',
  `expectations` text DEFAULT NULL,
  `registration_code` varchar(20) DEFAULT NULL,
  `status` enum('pending','confirmed','cancelled','attended') DEFAULT 'pending',
  `payment_status` enum('pending','paid','partial','waived') DEFAULT 'pending',
  `amount_paid` decimal(10,2) DEFAULT 0.00,
  `registration_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `confirmation_sent` tinyint(1) DEFAULT 0,
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event_registrations`
--

INSERT INTO `event_registrations` (`id`, `event_id`, `full_name`, `email`, `phone`, `gender`, `age_group`, `year_group`, `emergency_contact`, `dietary_requirements`, `special_needs`, `church_member`, `previous_mission`, `expectations`, `registration_code`, `status`, `payment_status`, `amount_paid`, `registration_date`, `confirmation_sent`, `notes`) VALUES
(1, 2, 'john', 'johnarumansi@gmail.com', '+254 74 135 1755', 'Female', '18-25', 'amusda', '0741351755 john', 'vegetatrian', 'none', 'yes', 'yes', 'glorify God', 'PM202512170E676F', 'pending', 'pending', 0.00, '2025-12-17 13:30:56', 0, NULL),
(2, 1, 'john', 'johnarumansi8390@gmail.com', '+254 74 135 1755', 'Male', '18-25', 'amusda', '0741351755 john', 'exactly vegetarian', 'none', 'yes', 'yes', 'manyu', 'PM2025121772F013', 'pending', 'pending', 0.00, '2025-12-17 13:39:35', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `membership_number` varchar(20) DEFAULT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `year_group` varchar(50) DEFAULT NULL,
  `registration_date` date DEFAULT curdate(),
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `membership_number`, `first_name`, `last_name`, `email`, `phone`, `dob`, `gender`, `year_group`, `registration_date`, `is_active`, `created_at`) VALUES
(1, 'PM2024001', 'John', 'Doe', 'john@example.com', '+254712345678', NULL, NULL, '2024', '2025-12-17', 1, '2025-12-17 13:18:10'),
(2, 'PM2024002', 'Jane', 'Smith', 'jane@example.com', '+254723456789', NULL, NULL, '2024', '2025-12-17', 1, '2025-12-17 13:18:10'),
(3, 'PM2023001', 'Michael', 'Johnson', 'michael@example.com', '+254734567890', NULL, NULL, '2023', '2025-12-17', 1, '2025-12-17 13:18:10'),
(4, 'PM20258449', 'Henry', 'Ombati', NULL, '0741351755', NULL, 'Male', 'Continuing', '2025-12-17', 1, '2025-12-17 16:21:13');

-- --------------------------------------------------------

--
-- Table structure for table `ministry_events`
--

CREATE TABLE `ministry_events` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `event_type` enum('mission','fellowship','training','workshop','prayer') DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `status` enum('upcoming','ongoing','completed','cancelled') DEFAULT 'upcoming',
  `max_participants` int(11) DEFAULT NULL,
  `registered_count` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ministry_events`
--

INSERT INTO `ministry_events` (`id`, `title`, `description`, `event_type`, `start_date`, `end_date`, `time`, `location`, `status`, `max_participants`, `registered_count`, `created_at`) VALUES
(1, 'End-Year Mission 2025', 'Annual mission to Mahanga, Vihiga County', 'mission', '2025-12-21', '2026-01-04', '08:00:00', 'Mahanga, Vihiga County', 'upcoming', 100, 1, '2025-12-17 13:18:10'),
(2, 'Pastor Boaz Mentorship Program', 'Leadership and spiritual mentorship', 'training', '2026-02-15', '2026-02-20', '09:00:00', 'Nairobi Headquarters', 'upcoming', 50, 1, '2025-12-17 13:18:10'),
(3, 'Weekly Fellowship', 'Sunday worship service', 'fellowship', '2025-12-01', '2025-12-01', '10:00:00', 'Main Sanctuary', 'upcoming', 200, 0, '2025-12-17 13:18:10'),
(4, 'Bible Study - Book of Romans', 'Weekly Bible study session', 'workshop', '2025-12-03', '2025-12-03', '19:00:00', 'Fellowship Hall', 'upcoming', 30, 0, '2025-12-17 13:18:10');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `registration_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` enum('mpesa','cash','bank_transfer','card') DEFAULT 'mpesa',
  `transaction_id` varchar(100) DEFAULT NULL,
  `status` enum('pending','completed','failed','refunded') DEFAULT 'pending',
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `confirmed_by` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `remedies`
--

CREATE TABLE `remedies` (
  `id` int(11) NOT NULL,
  `remedy_code` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `category` enum('herbal','oil','ointment','tea','supplement','other') DEFAULT 'herbal',
  `unit_price` decimal(10,2) NOT NULL,
  `cost_price` decimal(10,2) NOT NULL,
  `unit_type` enum('bottle','packet','jar','sachet','piece') DEFAULT 'bottle',
  `quantity_in_stock` int(11) DEFAULT 0,
  `reorder_level` int(11) DEFAULT 10,
  `batch_number` varchar(50) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `remedies`
--

INSERT INTO `remedies` (`id`, `remedy_code`, `name`, `description`, `category`, `unit_price`, `cost_price`, `unit_type`, `quantity_in_stock`, `reorder_level`, `batch_number`, `expiry_date`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'REM-001', 'Divine Healing Oil', 'Anointed prayer oil for healing and deliverance', 'oil', 500.00, 200.00, 'bottle', 50, 10, NULL, NULL, 1, '2025-12-17 17:27:29', '2025-12-17 17:27:29'),
(2, 'REM-002', 'Moringa Power Capsules', 'Pure moringa leaf capsules for vitality', 'supplement', 1200.00, 400.00, 'packet', 30, 5, NULL, NULL, 1, '2025-12-17 17:27:29', '2025-12-17 17:27:29'),
(3, 'REM-003', 'Peaceful Sleep Tea', 'Herbal blend for restful sleep and relaxation', 'tea', 300.00, 100.00, 'sachet', 94, 20, NULL, NULL, 1, '2025-12-17 17:27:29', '2025-12-17 18:45:17'),
(4, 'REM-004', 'Joint Relief Ointment', 'Topical ointment for joint and muscle pain', 'ointment', 800.00, 250.00, 'jar', 0, 8, NULL, NULL, 1, '2025-12-17 17:27:29', '2025-12-18 13:05:30'),
(5, 'REM-005', 'Immune Boost Tonic', 'Herbal tonic for immune system support', 'herbal', 1500.00, 500.00, 'bottle', 25, 5, NULL, NULL, 1, '2025-12-17 17:27:29', '2025-12-17 17:27:29');

-- --------------------------------------------------------

--
-- Table structure for table `remedies_cart`
--

CREATE TABLE `remedies_cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `remedies_products`
--

CREATE TABLE `remedies_products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(100) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `cost_price` decimal(10,2) DEFAULT NULL,
  `quantity_in_stock` int(11) DEFAULT 0,
  `image_url` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `is_featured` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `remedies_products`
--

INSERT INTO `remedies_products` (`id`, `name`, `description`, `category`, `unit_price`, `cost_price`, `quantity_in_stock`, `image_url`, `is_active`, `is_featured`, `created_at`, `updated_at`) VALUES
(1, 'Echinacea Tincture', 'Boosts immune system and fights infections', 'Herbs', 1200.00, 800.00, 50, 'https://via.placeholder.com/400x300/27ae60/ffffff?text=Echinacea', 1, 1, '2025-12-18 12:55:11', '2025-12-18 12:55:11'),
(2, 'Turmeric Capsules', 'Anti-inflammatory and antioxidant supplement', 'Supplements', 1500.00, 1000.00, 100, 'https://via.placeholder.com/400x300/3498db/ffffff?text=Turmeric', 1, 1, '2025-12-18 12:55:11', '2025-12-18 12:55:11'),
(3, 'Lavender Essential Oil', 'Calming and relaxing essential oil', 'Oils', 800.00, 500.00, 30, 'https://via.placeholder.com/400x300/9b59b6/ffffff?text=Lavender', 1, 1, '2025-12-18 12:55:11', '2025-12-18 12:55:11');

-- --------------------------------------------------------

--
-- Table structure for table `remedy_categories`
--

CREATE TABLE `remedy_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `remedy_categories`
--

INSERT INTO `remedy_categories` (`id`, `name`, `description`, `is_active`) VALUES
(1, 'Herbal Remedies', 'Traditional herbal medicines and extracts', 1),
(2, 'Anointing Oils', 'Prayer oils and anointing oils', 1),
(3, 'Healing Ointments', 'Topical ointments for various ailments', 1),
(4, 'Herbal Teas', 'Medicinal tea blends', 1),
(5, 'Supplements', 'Nutritional and herbal supplements', 1),
(6, 'Prayer Items', 'Blessed items for spiritual use', 1);

-- --------------------------------------------------------

--
-- Table structure for table `remedy_restocks`
--

CREATE TABLE `remedy_restocks` (
  `id` int(11) NOT NULL,
  `restock_code` varchar(20) NOT NULL,
  `remedy_id` int(11) NOT NULL,
  `quantity_added` int(11) NOT NULL,
  `unit_cost` decimal(10,2) NOT NULL,
  `total_cost` decimal(10,2) NOT NULL,
  `supplier_name` varchar(100) DEFAULT NULL,
  `supplier_contact` varchar(100) DEFAULT NULL,
  `batch_number` varchar(50) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `received_by` varchar(100) DEFAULT NULL,
  `restock_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `remedy_sales`
--

CREATE TABLE `remedy_sales` (
  `id` int(11) NOT NULL,
  `sale_code` varchar(20) NOT NULL,
  `remedy_id` int(11) NOT NULL,
  `quantity_sold` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `payment_method` enum('cash','mpesa','card','bank_transfer') DEFAULT 'cash',
  `payment_status` enum('pending','completed','refunded') DEFAULT 'completed',
  `sold_by` varchar(100) DEFAULT NULL,
  `sale_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `remedy_sales`
--

INSERT INTO `remedy_sales` (`id`, `sale_code`, `remedy_id`, `quantity_sold`, `unit_price`, `total_amount`, `customer_name`, `customer_phone`, `payment_method`, `payment_status`, `sold_by`, `sale_date`, `notes`) VALUES
(1, 'SALE-20251217-F44C9B', 3, 1, 300.00, 300.00, 'jin', '0741351755', 'cash', 'completed', 'Administrator', '2025-12-17 18:40:15', NULL),
(2, 'SALE-20251217-BCA2CD', 3, 1, 300.00, 300.00, 'jin', '0741351755', 'cash', 'completed', 'Administrator', '2025-12-17 18:41:15', NULL),
(3, 'SALE-20251217-84F7E9', 3, 1, 300.00, 300.00, 'jin', '0741351755', 'cash', 'completed', 'Administrator', '2025-12-17 18:42:16', NULL),
(4, 'SALE-20251217-4AB0B3', 3, 1, 300.00, 300.00, 'jin', '0741351755', 'cash', 'completed', 'Administrator', '2025-12-17 18:43:16', NULL),
(5, 'SALE-20251217-12B7F2', 3, 1, 300.00, 300.00, 'jin', '0741351755', 'cash', 'completed', 'Administrator', '2025-12-17 18:44:17', NULL),
(6, 'SALE-20251217-D8A350', 3, 1, 300.00, 300.00, 'jin', '0741351755', 'cash', 'completed', 'Administrator', '2025-12-17 18:45:17', NULL),
(7, 'SALE-20251218-B70CFA', 4, 1, 800.00, 800.00, '', '', 'cash', 'completed', 'Administrator', '2025-12-18 13:04:43', NULL),
(8, 'SALE-20251218-A5B356', 4, 39, 800.00, 31200.00, '', '', 'cash', 'completed', 'Administrator', '2025-12-18 13:05:30', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_attendance` (`event_id`,`member_id`),
  ADD KEY `member_id` (`member_id`);

--
-- Indexes for table `broadcast_logs`
--
ALTER TABLE `broadcast_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `event_id` (`event_id`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event_fees`
--
ALTER TABLE `event_fees`
  ADD PRIMARY KEY (`id`),
  ADD KEY `event_id` (`event_id`);

--
-- Indexes for table `event_registrations`
--
ALTER TABLE `event_registrations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `registration_code` (`registration_code`),
  ADD KEY `idx_event_registrations_event_id` (`event_id`),
  ADD KEY `idx_event_registrations_email` (`email`),
  ADD KEY `idx_event_registrations_registration_code` (`registration_code`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `membership_number` (`membership_number`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `ministry_events`
--
ALTER TABLE `ministry_events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `registration_id` (`registration_id`);

--
-- Indexes for table `remedies`
--
ALTER TABLE `remedies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `remedy_code` (`remedy_code`);

--
-- Indexes for table `remedies_cart`
--
ALTER TABLE `remedies_cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `remedies_products`
--
ALTER TABLE `remedies_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `remedy_categories`
--
ALTER TABLE `remedy_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `remedy_restocks`
--
ALTER TABLE `remedy_restocks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `restock_code` (`restock_code`),
  ADD KEY `remedy_id` (`remedy_id`);

--
-- Indexes for table `remedy_sales`
--
ALTER TABLE `remedy_sales`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sale_code` (`sale_code`),
  ADD KEY `remedy_id` (`remedy_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `broadcast_logs`
--
ALTER TABLE `broadcast_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `event_fees`
--
ALTER TABLE `event_fees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `event_registrations`
--
ALTER TABLE `event_registrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ministry_events`
--
ALTER TABLE `ministry_events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `remedies`
--
ALTER TABLE `remedies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `remedies_cart`
--
ALTER TABLE `remedies_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `remedies_products`
--
ALTER TABLE `remedies_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `remedy_categories`
--
ALTER TABLE `remedy_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `remedy_restocks`
--
ALTER TABLE `remedy_restocks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `remedy_sales`
--
ALTER TABLE `remedy_sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `ministry_events` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attendance_ibfk_2` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `broadcast_logs`
--
ALTER TABLE `broadcast_logs`
  ADD CONSTRAINT `broadcast_logs_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `ministry_events` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `event_fees`
--
ALTER TABLE `event_fees`
  ADD CONSTRAINT `event_fees_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `ministry_events` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `event_registrations`
--
ALTER TABLE `event_registrations`
  ADD CONSTRAINT `event_registrations_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `ministry_events` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`registration_id`) REFERENCES `event_registrations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `remedies_cart`
--
ALTER TABLE `remedies_cart`
  ADD CONSTRAINT `remedies_cart_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `remedies_products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `remedy_restocks`
--
ALTER TABLE `remedy_restocks`
  ADD CONSTRAINT `remedy_restocks_ibfk_1` FOREIGN KEY (`remedy_id`) REFERENCES `remedies` (`id`);

--
-- Constraints for table `remedy_sales`
--
ALTER TABLE `remedy_sales`
  ADD CONSTRAINT `remedy_sales_ibfk_1` FOREIGN KEY (`remedy_id`) REFERENCES `remedies` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
