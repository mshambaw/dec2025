<?php
// api/members.php
header('Content-Type: application/json');
require_once '../config/database.php';

$db = new Database();
$conn = $db->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'GET':
        if(isset($_GET['id'])) {
            $stmt = $conn->prepare("SELECT * FROM members WHERE id = ? AND is_active = 1");
            $stmt->execute([$_GET['id']]);
            $member = $stmt->fetch();
            
            if($member) {
                echo json_encode($member);
            } else {
                http_response_code(404);
                echo json_encode(['error' => 'Member not found']);
            }
        } else {
            $stmt = $conn->query("SELECT * FROM members WHERE is_active = 1 ORDER BY year_group, full_name");
            $members = $stmt->fetchAll();
            echo json_encode($members);
        }
        break;
        
    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        
        $stmt = $conn->prepare("
            INSERT INTO members (member_id, full_name, phone, gender, year_group, residence, date_joined) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        
        $member_id = 'PM' . date('Y') . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
        
        $stmt->execute([
            $member_id,
            $data['full_name'],
            $data['phone'],
            $data['gender'],
            $data['year_group'],
            $data['residence'],
            date('Y-m-d')
        ]);
        
        echo json_encode([
            'success' => true,
            'member_id' => $member_id,
            'id' => $conn->lastInsertId()
        ]);
        break;
        
    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);
        
        $stmt = $conn->prepare("
            UPDATE members SET 
            full_name = ?, phone = ?, gender = ?, year_group = ?, residence = ?,
            emergency_contact_name = ?, emergency_contact_phone = ?
            WHERE id = ?
        ");
        
        $stmt->execute([
            $data['full_name'],
            $data['phone'],
            $data['gender'],
            $data['year_group'],
            $data['residence'],
            $data['emergency_contact_name'],
            $data['emergency_contact_phone'],
            $data['id']
        ]);
        
        echo json_encode(['success' => true]);
        break;
        
    case 'DELETE':
        $id = $_GET['id'];
        $stmt = $conn->prepare("UPDATE members SET is_active = 0 WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(['success' => true]);
        break;
}