<?php
// Turn on all error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h2>Testing Errors</h2>";

// Try to include the remedies index
include 'remedies/index.php';
?>