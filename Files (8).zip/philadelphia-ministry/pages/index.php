<?php
// index.php - Main homepage
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Philadelphia Ministry</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <main>
        <section class="hero">
            <h1>Welcome to Philadelphia Ministry</h1>
            <p>Building disciples, transforming lives</p>
            <a href="events.php" class="btn">View Upcoming Events</a>
        </section>
        
        <section class="upcoming-events">
            <h2>Upcoming Events</h2>
            <div id="events-preview">
                <!-- Load events via AJAX -->
            </div>
        </section>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    
    <script src="assets/js/main.js"></script>
</body>
</html>