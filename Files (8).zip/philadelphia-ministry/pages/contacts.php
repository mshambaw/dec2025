<?php
// pages/contact.php
$pageTitle = "Contact Us";
require_once '../includes/header.php';
require_once '../config/database.php';

$db = new Database();
$conn = $db->getConnection();

// Handle form submission
$successMessage = $errorMessage = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $subject = $_POST['subject'] ?? '';
    $message = $_POST['message'] ?? '';
    
    try {
        $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, phone, subject, message, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$name, $email, $phone, $subject, $message]);
        $successMessage = "Thank you for your message! We'll contact you soon.";
        
        // Send email notification (you can implement this)
        // mail('admin@philadelphiaministry.org', "New Contact: $subject", "From: $name\nEmail: $email\nPhone: $phone\n\nMessage:\n$message");
        
    } catch(Exception $e) {
        $errorMessage = "Sorry, there was an error sending your message. Please try again.";
    }
}
?>

<div class="main-banner" style="background: linear-gradient(135deg, #1a5276 0%, #2c3e50 100%); padding: 100px 0 50px;">
    <div class="container">
        <h1 class="text-center text-white">Contact Us</h1>
        <p class="text-center text-white">Get in touch with Philadelphia Ministry leadership</p>
    </div>
</div>

<section class="py-5">
    <div class="container">
        <?php if($successMessage): ?>
            <div class="alert alert-success"><?php echo $successMessage; ?></div>
        <?php endif; ?>
        
        <?php if($errorMessage): ?>
            <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
        <?php endif; ?>
        
        <div class="row">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Send Us a Message</h4>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="name" class="form-label">Full Name *</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="phone" class="form-label">Phone Number *</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" required>
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label for="email" class="form-label">Email Address *</label>
                                    <input type="email" class="form-control" id="email" name="email" required>
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label for="subject" class="form-label">Subject *</label>
                                    <select class="form-control" id="subject" name="subject" required>
                                        <option value="">Select a subject</option>
                                        <option value="membership">Membership Inquiry</option>
                                        <option value="prayer">Prayer Request</option>
                                        <option value="event">Event Information</option>
                                        <option value="donation">Donation Inquiry</option>
                                        <option value="other">Other</option>
                                    </select>
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label for="message" class="form-label">Message *</label>
                                    <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                                </div>
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-primary btn-lg w-100">
                                        <i class="fas fa-paper-plane"></i> Send Message
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header bg-success text-white">
                        <h4 class="mb-0">Contact Information</h4>
                    </div>
                    <div class="card-body">
                        <div class="contact-info">
                            <div class="d-flex mb-4">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-map-marker-alt fa-2x text-primary"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h5>Location</h5>
                                    <p>Philadelphia Ministry Headquarters<br>Kenya</p>
                                </div>
                            </div>
                            
                            <div class="d-flex mb-4">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-phone fa-2x text-primary"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h5>Phone Numbers</h5>
                                    <p><strong>Elder Amos Koroso:</strong> +254 769 228 426</p>
                                    <p><strong>Commander Caleb:</strong> +254 798 914 401</p>
                                    <p><strong>Esther Kamau:</strong> +254 796 096 450</p>
                                </div>
                            </div>
                            
                            <div class="d-flex mb-4">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-envelope fa-2x text-primary"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h5>Email</h5>
                                    <p>info@philadelphiaministry.org</p>
                                </div>
                            </div>
                            
                            <div class="d-flex mb-4">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-clock fa-2x text-primary"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h5>Office Hours</h5>
                                    <p>Monday - Friday: 9:00 AM - 5:00 PM<br>
                                    Saturday: 9:00 AM - 1:00 PM</p>
                                </div>
                            </div>
                        </div>
                        
                        <hr>
                        
                        <h5 class="mt-4">Emergency Contacts</h5>
                        <p>For urgent pastoral care or emergencies outside office hours:</p>
                        <ul>
                            <li><strong>Pastoral Care:</strong> +254 712 345 678</li>
                            <li><strong>Prayer Chain:</strong> +254 723 456 789</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once '../includes/footer.php'; ?>