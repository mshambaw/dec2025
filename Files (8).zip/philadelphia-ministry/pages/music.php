<?php
require_once '../includes/header.php';
require_once '../includes/navigation.php';
?>

<div class="container">
    <div class="page-header">
        <h1>Music Ministry</h1>
        <p class="lead">Leading worship through music at Philadelphia Ministry</p>
    </div>
    
    <div class="row">
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="../assets/images/music/choir-photo.jpg" class="img-fluid rounded-start" alt="Choir">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Our Worship Team</h5>
                            <p class="card-text">The Philadelphia Ministry Worship Team is composed of dedicated volunteers who lead our congregation in worship through music. We have multiple teams serving different services.</p>
                            <a href="../music/choir.php" class="btn btn-primary">Meet the Choir</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <h3>Song Collections</h3>
            <div class="row">
                <div class="col-md-4 mb-3">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">Hymns</h5>
                            <p class="card-text">Traditional hymns from the Seventh-day Adventist Hymnal and other collections.</p>
                            <a href="../music/songs.php?category=hymns" class="btn btn-sm btn-outline-primary">Browse Hymns</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">Swahili Worship</h5>
                            <p class="card-text">Worship songs in Swahili for our Swahili-speaking congregation.</p>
                            <a href="../music/songs.php?category=swahili" class="btn btn-sm btn-outline-primary">Browse Songs</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">Contemporary</h5>
                            <p class="card-text">Modern worship songs and choruses.</p>
                            <a href="../music/songs.php?category=contemporary" class="btn btn-sm btn-outline-primary">Browse Contemporary</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Music Portal Access</h5>
                </div>
                <div class="card-body">
                    <p>Choir members and music ministry volunteers can access the music portal for resources, schedules, and song materials.</p>
                    <a href="../music/login.php" class="btn btn-primary w-100 mb-2">
                        <i class="fas fa-sign-in-alt"></i> Login to Music Portal
                    </a>
                    <a href="../music/index.php" class="btn btn-outline-primary w-100">
                        <i class="fas fa-info-circle"></i> Learn About Music Ministry
                    </a>
                </div>
            </div>
            
            <div class="card mt-4">
                <div class="card-body">
                    <h5>Join the Choir</h5>
                    <p>Interested in joining our music ministry? We're always looking for new voices and instrumentalists.</p>
                    <ul>
                        <li>Vocalists (all parts)</li>
                        <li>Pianists/Keyboardists</li>
                        <li>Guitarists</li>
                        <li>Drummers</li>
                        <li>Other instrumentalists</li>
                    </ul>
                    <a href="../contact.php" class="btn btn-success">Contact Music Director</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>