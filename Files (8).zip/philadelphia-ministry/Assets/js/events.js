   // Initialize Map
        function initMap() {
            // Coordinates for Mahanga, Vihiga County
            const mahanga = [-0.0847, 34.7290];
            
            const map = L.map('map').setView(mahanga, 13);
            
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors'
            }).addTo(map);
            
            // Add mission marker
            L.marker(mahanga)
                .addTo(map)
                .bindPopup('<b>Ministry Mission Location</b><br>Mahanga, Vihiga County<br>Dec 21, 2025 - Jan 4, 2026')
                .openPopup();
            
            // Add circle for mission area
            L.circle(mahanga, {
                color: '#27ae60',
                fillColor: '#27ae60',
                fillOpacity: 0.1,
                radius: 1000
            }).addTo(map);
        }
        
        // Countdown Timer Functions
        function updateCountdown() {
            const now = new Date();
            
            // Mission countdown (Dec 21, 2025)
            const missionDate = new Date('December 21, 2025 08:00:00');
            updateTimer('mission', missionDate, now);
            
            // Briefing countdown (Dec 20, 2025)
            const briefingDate = new Date('December 20, 2025 14:00:00');
            updateTimer('briefing', briefingDate, now);
            
            // Mentorship countdown (Feb 1, 2026)
            const mentorshipDate = new Date('February 1, 2026 09:00:00');
            updateTimer('mentorship', mentorshipDate, now);
        }
        
        function updateTimer(type, eventDate, currentDate) {
            const diff = eventDate - currentDate;
            
            if (diff <= 0) {
                document.getElementById(`${type}-days`).textContent = '00';
                document.getElementById(`${type}-hours`).textContent = '00';
                document.getElementById(`${type}-minutes`).textContent = '00';
                return;
            }
            
            const days = Math.floor(diff / (1000 * 60 * 60 * 24));
            const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
            
            document.getElementById(`${type}-days`).textContent = days.toString().padStart(2, '0');
            document.getElementById(`${type}-hours`).textContent = hours.toString().padStart(2, '0');
            document.getElementById(`${type}-minutes`).textContent = minutes.toString().padStart(2, '0');
        }
        
        // Modal Functions
        function openModal(modalId) {
            document.getElementById(modalId).style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
            document.body.style.overflow = 'auto';
        }
        
        // RSVP Functions
        function openRSVP(eventType) {
            const modal = document.getElementById('rsvp-modal');
            const header = document.getElementById('rsvp-header');
            const title = document.getElementById('rsvp-title');
            const eventSelect = document.getElementById('event-type');
            const roleGroup = document.getElementById('role-group');
            
            // Set modal based on event type
            switch(eventType) {
                case 'mission':
                    header.style.background = 'linear-gradient(135deg, var(--mission), #2ecc71)';
                    title.textContent = 'Register for Ministry Mission';
                    eventSelect.value = 'mission';
                    break;
                case 'briefing':
                    header.style.background = 'linear-gradient(135deg, var(--briefing), #c0392b)';
                    title.textContent = 'Confirm Briefing Attendance';
                    eventSelect.value = 'briefing';
                    roleGroup.style.display = 'none';
                    break;
                case 'mentorship':
                    header.style.background = 'linear-gradient(135deg, var(--mentorship), #8e44ad)';
                    title.textContent = 'Apply for Mentorship Program';
                    eventSelect.value = 'mentorship';
                    break;
            }
            
            openModal('rsvp-modal');
        }
        
        function submitRSVP(event) {
            event.preventDefault();
            
            // Get form data
            const formData = {
                name: document.getElementById('full-name').value,
                phone: document.getElementById('phone').value,
                email: document.getElementById('email').value,
                eventType: document.getElementById('event-type').value,
                role: document.getElementById('role').value,
                notes: document.getElementById('notes').value,
                timestamp: new Date().toISOString()
            };
            
            // Save to localStorage (in real app, send to server)
            const registrations = JSON.parse(localStorage.getItem('missionRegistrations') || '[]');
            registrations.push(formData);
            localStorage.setItem('missionRegistrations', JSON.stringify(registrations));
            
            // Update UI
            updateRegistrationsList();
            
            // Show success message
            alert('Registration submitted successfully! We will contact you with further details.');
            
            // Close modal and reset form
            closeModal('rsvp-modal');
            document.getElementById('rsvp-form').reset();
        }
        
        function updateRegistrationsList() {
            const registrations = JSON.parse(localStorage.getItem('missionRegistrations') || '[]');
            const container = document.getElementById('registrations-list');
            
            if (registrations.length === 0) {
                container.innerHTML = '<p style="text-align: center; color: #666; padding: 20px;">No registrations yet. Be the first to register!</p>';
                return;
            }
            
            container.innerHTML = '';
            registrations.forEach((reg, index) => {
                const div = document.createElement('div');
                div.className = 'registration-item';
                div.innerHTML = `
                    <div>
                        <strong>${reg.name}</strong>
                        <div style="font-size: 0.9rem; color: #666;">
                            ${reg.phone} • ${reg.eventType}
                        </div>
                    </div>
                    <div>
                        <span style="font-size: 0.8rem; color: #999;">
                            ${new Date(reg.timestamp).toLocaleDateString()}
                        </span>
                    </div>
                `;
                container.appendChild(div);
            });
        }
        
        // Download Functions
        function downloadResource(type) {
            const resources = {
                'mission-brochure': { name: 'mission-brochure.pdf', size: '2.4MB' },
                'briefing-pack': { name: 'briefing-package.docx', size: '3.1MB' },
                'mentorship-application': { name: 'mentorship-application.pdf', size: '1.8MB' },
                'medical-form': { name: 'medical-consent-form.pdf', size: '1.2MB' }
            };
            
            const resource = resources[type];
            if (resource) {
                alert(`Downloading ${resource.name} (${resource.size})...\n\nIn a real application, this would start the download.`);
                // In real app: window.location.href = `/downloads/${resource.name}`;
            }
        }
        
        // Calendar Functions
        function showEventDetails(eventType) {
            const messages = {
                'briefing': 'Mission Briefing - December 20, 2025\nTime: 2:00 PM - 5:00 PM\nLocation: Ministry Headquarters',
                'mission-start': 'Ministry Mission Begins - December 21, 2025\nDeparture: 8:00 AM from HQ',
                'mission': 'Mission Ongoing - Daily activities in Mahanga',
                'mission-end': 'Mission Concludes - January 4, 2026\nReturn: 4:00 PM to HQ'
            };
            
            if (messages[eventType]) {
                alert(messages[eventType]);
            }
        }
        
        // Initialize everything when page loads
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize map
            initMap();
            
            // Start countdown timers
            updateCountdown();
            setInterval(updateCountdown, 60000); // Update every minute
            
            // Load existing registrations
            updateRegistrationsList();
            
            // Close modal when clicking outside
            document.querySelectorAll('.modal').forEach(modal => {
                modal.addEventListener('click', function(e) {
                    if (e.target === this) {
                        closeModal(this.id);
                    }
                });
            });
            
            // Show role field only for mission registration
            document.getElementById('event-type').addEventListener('change', function() {
                const roleGroup = document.getElementById('role-group');
                roleGroup.style.display = this.value === 'mission' ? 'block' : 'none';
            });
        });
        
        // Keyboard navigation
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                document.querySelectorAll('.modal').forEach(modal => {
                    if (modal.style.display === 'flex') {
                        closeModal(modal.id);
                    }
                });
            }
        });