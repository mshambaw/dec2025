<?php
echo "<h2>Checking Folder Structure</h2>";
echo "<pre>";

// Check current directory
echo "Current directory: " . __DIR__ . "\n\n";

// Check if Remedies folder exists
$remediesPath = __DIR__ . '/Remedies';
echo "Remedies folder: " . $remediesPath . "\n";
echo "Exists: " . (is_dir($remediesPath) ? 'YES' : 'NO') . "\n\n";

// Check if includes folder exists
$includesPath = __DIR__ . '/includes';
echo "Includes folder: " . $includesPath . "\n";
echo "Exists: " . (is_dir($includesPath) ? 'YES' : 'NO') . "\n\n";

// Check if header.php exists
$headerPath = __DIR__ . '/includes/header.php';
echo "Header file: " . $headerPath . "\n";
echo "Exists: " . (file_exists($headerPath) ? 'YES' : 'NO') . "\n\n";

// List all files and folders
echo "Listing all items in current directory:\n";
$items = scandir(__DIR__);
foreach ($items as $item) {
    if ($item != '.' && $item != '..') {
        $type = is_dir(__DIR__ . '/' . $item) ? '[DIR] ' : '[FILE]';
        echo "$type $item\n";
    }
}
?>