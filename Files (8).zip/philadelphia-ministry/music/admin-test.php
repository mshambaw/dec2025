<?php
// Simple test admin page - no database required
session_start();
$_SESSION['music_user_id'] = 1;
$_SESSION['music_username'] = 'admin';
$_SESSION['music_role'] = 'admin';
$_SESSION['music_fullname'] = 'Administrator';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Test</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Music Admin - Working Test</h1>
        <div class="alert alert-success">
            ✓ Admin session is active
        </div>
        
        <div class="row mt-4">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5>Quick Admin Links</h5>
                        <ul class="list-unstyled">
                            <li><a href="manage-users.php">Manage Users</a></li>
                            <li><a href="manage-songs.php">Manage Songs</a></li>
                            <li><a href="reports.php">Reports</a></li>
                            <li><a href="../upload.php">Upload Files</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>