<?php
require_once 'includes/auth-check.php';
require_once 'includes/music-header.php';
require_once 'includes/music-nav.php';

$month = $_GET['month'] ?? date('n');
$year = $_GET['year'] ?? date('Y');
?>

<div class="container-fluid">
    <div class="row">
        <?php include 'includes/music-sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Service Schedule</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <?php if ($_SESSION['music_role'] === 'admin'): ?>
                        <a href="schedule.php?action=add" class="btn btn-sm btn-success">
                            <i class="fas fa-plus-circle"></i> Add Service
                        </a>
                        <?php endif; ?>
                        <button class="btn btn-sm btn-outline-secondary" onclick="printSchedule()">
                            <i class="fas fa-print"></i> Print
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Month Navigation -->
            <div class="card mb-4">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <h4 class="mb-0">
                                <?php
                                $dateObj = DateTime::createFromFormat('!m', $month);
                                echo $dateObj->format('F') . ' ' . $year;
                                ?>
                            </h4>
                        </div>
                        <div class="col-md-6 text-end">
                            <a href="?month=<?php echo ($month == 1 ? 12 : $month - 1); ?>&year=<?php echo ($month == 1 ? $year - 1 : $year); ?>" 
                               class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-chevron-left"></i> Previous
                            </a>
                            <a href="?month=<?php echo date('n'); ?>&year=<?php echo date('Y'); ?>" 
                               class="btn btn-sm btn-outline-secondary mx-2">
                                Current Month
                            </a>
                            <a href="?month=<?php echo ($month == 12 ? 1 : $month + 1); ?>&year=<?php echo ($month == 12 ? $year + 1 : $year); ?>" 
                               class="btn btn-sm btn-outline-primary">
                                Next <i class="fas fa-chevron-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Service Calendar -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="table-dark">
                                <tr>
                                    <th>Date</th>
                                    <th>Service Type</th>
                                    <th>Time</th>
                                    <th>Leader</th>
                                    <th>Theme/Songs</th>
                                    <th>Your Role</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Sample service data
                                $services = [
                                    [
                                        'date' => $year . '-' . str_pad($month, 2, '0', STR_PAD_LEFT) . '-15',
                                        'type' => 'Sunday Morning Worship',
                                        'time' => '10:00 AM',
                                        'leader' => 'John Doe',
                                        'theme' => 'God\'s Faithfulness',
                                        'songs' => ['Tunakutukuza', 'Near to the Heart of God', 'He\'s Worthy'],
                                        'role' => 'Singer',
                                        'confirmed' => true
                                    ],
                                    [
                                        'date' => $year . '-' . str_pad($month, 2, '0', STR_PAD_LEFT) . '-17',
                                        'type' => 'Midweek Service',
                                        'time' => '7:00 PM',
                                        'leader' => 'Jane Smith',
                                        'theme' => 'Prayer and Praise',
                                        'songs' => ['Rock of Ages', 'I Love To Tell The Story'],
                                        'role' => 'Backup Singer',
                                        'confirmed' => true
                                    ],
                                    [
                                        'date' => $year . '-' . str_pad($month, 2, '0', STR_PAD_LEFT) . '-22',
                                        'type' => 'Sunday Morning Worship',
                                        'time' => '10:00 AM',
                                        'leader' => 'Peter Johnson',
                                        'theme' => 'God\'s Grace',
                                        'songs' => ['Come To Jesus', 'Beulah Land'],
                                        'role' => 'Instrumentalist',
                                        'confirmed' => false
                                    ],
                                    [
                                        'date' => $year . '-' . str_pad($month, 2, '0', STR_PAD_LEFT) . '-29',
                                        'type' => 'Sunday Evening Service',
                                        'time' => '5:00 PM',
                                        'leader' => 'Mary Wilson',
                                        'theme' => 'Worship Night',
                                        'songs' => ['When He Comes in Glory', 'Kando Ya Mto Babeli'],
                                        'role' => 'Soloist',
                                        'confirmed' => true
                                    ],
                                ];
                                
                                foreach ($services as $service):
                                    $serviceDate = new DateTime($service['date']);
                                    $today = new DateTime();
                                    $isPast = $serviceDate < $today;
                                ?>
                                <tr class="<?php echo $isPast ? 'table-secondary' : ''; ?>">
                                    <td>
                                        <?php echo $serviceDate->format('D, M j, Y'); ?>
                                        <?php if ($serviceDate->format('Y-m-d') == $today->format('Y-m-d')): ?>
                                            <span class="badge bg-danger">Today</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo $service['type']; ?></td>
                                    <td><?php echo $service['time']; ?></td>
                                    <td><?php echo $service['leader']; ?></td>
                                    <td>
                                        <strong><?php echo $service['theme']; ?></strong>
                                        <div class="mt-1">
                                            <?php foreach ($service['songs'] as $song): ?>
                                                <span class="badge bg-info me-1"><?php echo $song; ?></span>
                                            <?php endforeach; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $service['confirmed'] ? 'bg-success' : 'bg-warning'; ?>">
                                            <?php echo $service['role']; ?>
                                            <?php if (!$service['confirmed']): ?>
                                                <i class="fas fa-question-circle"></i>
                                            <?php endif; ?>
                                        </span>
                                        <?php if (!$service['confirmed'] && !$isPast): ?>
                                            <button class="btn btn-sm btn-outline-primary btn-sm mt-1" 
                                                    onclick="confirmAttendance(<?php echo $serviceDate->format('Ymd'); ?>)">
                                                Confirm
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <button class="btn btn-outline-info" 
                                                    onclick="viewServiceDetails('<?php echo $serviceDate->format('Y-m-d'); ?>')">
                                                <i class="fas fa-info-circle"></i>
                                            </button>
                                            <button class="btn btn-outline-primary" 
                                                    onclick="downloadServicePlan('<?php echo $serviceDate->format('Y-m-d'); ?>')">
                                                <i class="fas fa-download"></i>
                                            </button>
                                            <?php if ($_SESSION['music_role'] === 'admin'): ?>
                                            <button class="btn btn-outline-warning" 
                                                    onclick="editService('<?php echo $serviceDate->format('Y-m-d'); ?>')">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Upcoming Practice Sessions -->
                    <div class="mt-5">
                        <h5>Upcoming Practice Sessions</h5>
                        <div class="list-group">
                            <div class="list-group-item">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1">Choir Practice</h6>
                                    <small>Friday, October 20, 2023</small>
                                </div>
                                <p class="mb-1">6:00 PM - 8:00 PM | Sanctuary</p>
                                <small>Focus: Sunday worship songs</small>
                            </div>
                            <div class="list-group-item">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1">Worship Team Rehearsal</h6>
                                    <small>Saturday, October 21, 2023</small>
                                </div>
                                <p class="mb-1">4:00 PM - 5:30 PM | Sanctuary</p>
                                <small>Sound check and run-through</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
function confirmAttendance(serviceId) {
    if (confirm('Confirm your attendance for this service?')) {
        // AJAX call to confirm attendance
        fetch('api/confirm-attendance.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                service_id: serviceId,
                user_id: <?php echo $_SESSION['music_user_id']; ?>
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Attendance confirmed!');
                location.reload();
            } else {
                alert('Error: ' + data.message);
            }
        });
    }
}

function viewServiceDetails(date) {
    window.open('service-details.php?date=' + date, '_blank');
}

function downloadServicePlan(date) {
    window.location.href = 'download-service-plan.php?date=' + date;
}

function editService(date) {
    window.location.href = 'admin/manage-schedule.php?date=' + date;
}

function printSchedule() {
    window.print();
}
</script>

<?php require_once 'includes/music-footer.php'; ?>