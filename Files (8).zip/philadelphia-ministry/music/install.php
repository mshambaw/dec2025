<?php
// Music Department Installation Script
// Run this once to set up the database and default data

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'includes/db-music.php';

echo "<h2>Philadelphia Ministry Music Department Installation</h2>";
echo "<div style='font-family: monospace; white-space: pre;'>";

try {
    // Create tables
    echo "Creating database tables...\n";
    createMusicTables($pdo);
    echo "✓ Tables created successfully\n\n";
    
    // Insert sample songs from PDF
    echo "Inserting sample songs...\n";
    
    $songs = [
        [
            'song_number' => '1',
            'title' => 'Tunakutukuza',
            'language' => 'swahili',
            'category' => 'worship',
            'lyrics' => "Tunakutukuza ewe Mungu mwenye enzi muumba mbingu na wa dunia uliumba ndege wanyama binadamu bahari na vyote vilivyomo.\n\nRefrain:\nHijeshima na utukufu sifa zote ni kwake muumba mbingu na nchi na vyote vilivyomo..."
        ],
        [
            'song_number' => 'SDAH 495',
            'title' => 'Near to the Heart of God',
            'language' => 'english',
            'category' => 'hymn',
            'lyrics' => "There is a place of quiet rest,\nNear to the heart of God;\nA place where sin cannot molest,\nNear to the heart of God.\n\nCHORUS:\nO Jesus, blest Redeemer,\nSent from the heart of God..."
        ],
        // Add more songs from the PDF
    ];
    
    foreach ($songs as $song) {
        $stmt = $pdo->prepare("INSERT INTO songs (song_number, title, language, category, lyrics, created_by) 
                              VALUES (?, ?, ?, ?, ?, 1)");
        $stmt->execute([
            $song['song_number'],
            $song['title'],
            $song['language'],
            $song['category'],
            $song['lyrics']
        ]);
        echo "✓ Added: " . $song['title'] . "\n";
    }
    
    echo "\n✓ Sample songs inserted\n\n";
    
    // Create default admin user if not exists
    echo "Checking admin user...\n";
    $check = $pdo->query("SELECT id FROM music_users WHERE username = 'admin'");
    if (!$check->fetch()) {
        $hashedPassword = password_hash('admin123', PASSWORD_DEFAULT);
        $pdo->prepare("INSERT INTO music_users (username, password, full_name, email, role, status) 
                      VALUES ('admin', ?, 'Music Administrator', 'music@philadelphiaministry.org', 'admin', 'active')")
            ->execute([$hashedPassword]);
        echo "✓ Admin user created (username: admin, password: admin123)\n";
    } else {
        echo "✓ Admin user already exists\n";
    }
    
    echo "\n========================================\n";
    echo "INSTALLATION COMPLETE!\n";
    echo "========================================\n\n";
    echo "Next steps:\n";
    echo "1. Change the default admin password\n";
    echo "2. Update config/music.php with your settings\n";
    echo "3. Remove or secure this installation script\n";
    echo "4. Access the music portal at: /philadelphia-ministry/music/login.php\n";
    
} catch (Exception $e) {
    echo "\n✗ ERROR: " . $e->getMessage() . "\n";
    echo "Installation failed.\n";
}

echo "</div>";
?>