<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Music Portal - Philadelphia Ministry</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom Music CSS -->
    <link rel="stylesheet" href="assets/css/music.css">
    
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    
    <style>
        .music-sidebar {
            background-color: #1a4a8f;
            color: white;
            min-height: calc(100vh - 56px);
            padding-top: 20px;
        }
        
        .music-sidebar .nav-link {
            color: rgba(255,255,255,.8);
            padding: 10px 15px;
            margin-bottom: 5px;
        }
        
        .music-sidebar .nav-link:hover,
        .music-sidebar .nav-link.active {
            color: white;
            background-color: rgba(255,255,255,.1);
        }
        
        .music-sidebar .nav-link i {
            width: 20px;
            text-align: center;
            margin-right: 10px;
        }
        
        .music-header {
            background: linear-gradient(to right, #1a4a8f, #2a6fdb);
            color: white;
            padding: 15px 0;
            margin-bottom: 20px;
        }
        
        .avatar-placeholder {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: bold;
        }
        
        .song-player {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            border-top: 2px solid #1a4a8f;
            padding: 10px;
            z-index: 1000;
        }
    </style>
</head>
<body>
    <!-- Fixed Music Player (optional) -->
    <div class="song-player d-none">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-3">
                    <strong id="nowPlaying">Not Playing</strong>
                </div>
                <div class="col-md-6">
                    <audio id="globalPlayer" controls style="width: 100%;"></audio>
                </div>
                <div class="col-md-3 text-end">
                    <button class="btn btn-sm btn-outline-secondary" onclick="hidePlayer()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    function showPlayer(songTitle, audioUrl) {
        document.getElementById('nowPlaying').textContent = 'Now Playing: ' + songTitle;
        document.getElementById('globalPlayer').src = audioUrl;
        document.querySelector('.song-player').classList.remove('d-none');
    }
    
    function hidePlayer() {
        document.querySelector('.song-player').classList.add('d-none');
        document.getElementById('globalPlayer').pause();
    }
    </script>