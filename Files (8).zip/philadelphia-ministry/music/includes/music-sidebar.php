<div class="col-md-3 col-lg-2 d-md-block music-sidebar">
    <div class="position-sticky pt-3">
        <div class="text-center mb-4">
            <div class="avatar-placeholder bg-light text-dark rounded-circle mx-auto d-flex align-items-center justify-content-center" 
                 style="width: 80px; height: 80px; font-size: 32px;">
                <?php echo strtoupper(substr($_SESSION['music_fullname'], 0, 1)); ?>
            </div>
            <h6 class="mt-3 mb-1"><?php echo $_SESSION['music_fullname']; ?></h6>
            <small class="text-light">
                <?php echo ucfirst($_SESSION['music_role']); ?>
                <?php if ($_SESSION['music_role'] === 'user'): ?>
                    <span class="badge bg-info">Choir Member</span>
                <?php endif; ?>
            </small>
        </div>
        
        <hr class="bg-light">
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'portal.php' ? 'active' : ''; ?>" href="portal.php">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'songs.php' ? 'active' : ''; ?>" href="songs.php">
                    <i class="fas fa-music"></i> Song Library
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'schedule.php' ? 'active' : ''; ?>" href="schedule.php">
                    <i class="fas fa-calendar-alt"></i> Service Schedule
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'choir.php' ? 'active' : ''; ?>" href="choir.php">
                    <i class="fas fa-users"></i> Choir Directory
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'resources.php' ? 'active' : ''; ?>" href="resources.php">
                    <i class="fas fa-file-audio"></i> Resources
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : ''; ?>" href="profile.php">
                    <i class="fas fa-user"></i> My Profile
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>" href="settings.php">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </li>
        </ul>
        
        <hr class="bg-light mt-4">
        
        <div class="px-3">
            <small class="text-light">Quick Actions</small>
            <div class="mt-2">
                <button class="btn btn-sm btn-outline-light w-100 mb-2" onclick="window.open('practice.php', '_blank')">
                    <i class="fas fa-headphones"></i> Practice Mode
                </button>
                <button class="btn btn-sm btn-outline-light w-100" onclick="printCurrentPage()">
                    <i class="fas fa-print"></i> Print This Page
                </button>
            </div>
        </div>
    </div>
</div>

<script>
function printCurrentPage() {
    window.print();
}
</script>