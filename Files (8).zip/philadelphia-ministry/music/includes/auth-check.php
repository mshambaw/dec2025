<?php
session_start();

// Check if user is logged into music portal
if (!isset($_SESSION['music_user_id'])) {
    // Redirect to music login
    header('Location: ../login.php');
    exit();
}

// Check user status (optional - if you have an active/inactive system)
// if ($_SESSION['music_status'] !== 'active') {
//     session_destroy();
//     header('Location: ../login.php?error=inactive');
//     exit();
// }
?>