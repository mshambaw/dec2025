<div class="col-md-3 col-lg-2 d-md-block admin-sidebar" style="background-color: #343a40; color: white; min-height: calc(100vh - 56px); padding-top: 20px;">
    <div class="position-sticky pt-3">
        <div class="text-center mb-4">
            <div class="avatar-placeholder bg-warning text-dark rounded-circle mx-auto d-flex align-items-center justify-content-center" 
                 style="width: 80px; height: 80px; font-size: 32px;">
                <i class="fas fa-user-shield"></i>
            </div>
            <h6 class="mt-3 mb-1 text-white"><?php echo $_SESSION['music_fullname']; ?></h6>
            <small class="text-warning">
                <i class="fas fa-star"></i> Administrator
            </small>
        </div>
        
        <hr class="bg-light">
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'bg-secondary rounded' : ''; ?>" 
                   href="index.php">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'manage-songs.php' ? 'bg-secondary rounded' : ''; ?>" 
                   href="manage-songs.php">
                    <i class="fas fa-music"></i> Manage Songs
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'manage-users.php' ? 'bg-secondary rounded' : ''; ?>" 
                   href="manage-users.php">
                    <i class="fas fa-users-cog"></i> Manage Users
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="../upload.php">
                    <i class="fas fa-upload"></i> Upload Resources
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'bg-secondary rounded' : ''; ?>" 
                   href="reports.php">
                    <i class="fas fa-chart-bar"></i> Reports
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'uploads.php' ? 'bg-secondary rounded' : ''; ?>" 
                   href="uploads.php">
                    <i class="fas fa-folder"></i> File Management
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="../portal.php">
                    <i class="fas fa-exchange-alt"></i> Switch to User View
                </a>
            </li>
        </ul>
        
        <hr class="bg-light mt-4">
        
        <div class="px-3">
            <small class="text-light">Quick Actions</small>
            <div class="mt-2">
                <a href="manage-songs.php?action=add" class="btn btn-sm btn-success w-100 mb-2">
                    <i class="fas fa-plus-circle"></i> Add Song
                </a>
                <a href="manage-users.php?action=add" class="btn btn-sm btn-primary w-100 mb-2">
                    <i class="fas fa-user-plus"></i> Add User
                </a>
                <a href="../schedule.php?edit=1" class="btn btn-sm btn-info w-100">
                    <i class="fas fa-calendar-plus"></i> Add Service
                </a>
            </div>
        </div>
    </div>
</div>