<nav class="navbar navbar-expand-lg navbar-dark music-navbar">
    <div class="container-fluid">
        <a class="navbar-brand" href="../index.php">
            <i class="fas fa-home"></i> Philadelphia Ministry
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#musicNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="musicNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="portal.php">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        <i class="fas fa-music"></i> Music
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="songs.php"><i class="fas fa-list"></i> Song Library</a></li>
                        <li><a class="dropdown-item" href="schedule.php"><i class="fas fa-calendar-alt"></i> Service Schedule</a></li>
                        <li><a class="dropdown-item" href="choir.php"><i class="fas fa-users"></i> Choir Directory</a></li>
                        <li><a class="dropdown-item" href="resources.php"><i class="fas fa-file-audio"></i> Resources</a></li>
                    </ul>
                </li>
                <?php if ($_SESSION['music_role'] === 'admin'): ?>
                <li class="nav-item">
                    <a class="nav-link text-warning" href="admin/index.php">
                        <i class="fas fa-user-cog"></i> Admin Panel
                    </a>
                </li>
                <?php endif; ?>
            </ul>
            
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle"></i> <?php echo $_SESSION['music_fullname']; ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user"></i> My Profile</a></li>
                        <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>