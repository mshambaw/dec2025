<?php
require_once '../includes/auth-check.php';

// Only allow admins
if ($_SESSION['music_role'] !== 'admin') {
    header('Location: ../portal.php');
    exit();
}

require_once '../includes/music-header.php';
require_once '../includes/music-nav.php';
?>

<div class="container-fluid">
    <div class="row">
        <!-- Admin Sidebar -->
        <div class="col-md-3 col-lg-2 d-md-block bg-dark sidebar">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active text-white" href="index.php">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="manage-songs.php">
                            <i class="fas fa-music"></i> Manage Songs
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="manage-users.php">
                            <i class="fas fa-users-cog"></i> Manage Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="../upload.php">
                            <i class="fas fa-upload"></i> Upload Resources
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="reports.php">
                            <i class="fas fa-chart-bar"></i> Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="uploads.php">
                            <i class="fas fa-folder"></i> File Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="../portal.php">
                            <i class="fas fa-exchange-alt"></i> Switch to User View
                        </a>
                    </li>
                </ul>
                
                <hr class="bg-light">
                
                <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-white">
                    <span>Quick Actions</span>
                </h6>
                <ul class="nav flex-column mb-2">
                    <li class="nav-item">
                        <a class="nav-link text-white" href="manage-songs.php?action=add">
                            <i class="fas fa-plus-circle"></i> Add New Song
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="manage-users.php?action=add">
                            <i class="fas fa-user-plus"></i> Add New User
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="../schedule.php?edit=1">
                            <i class="fas fa-calendar-plus"></i> Add Service
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- Main Admin Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Music Admin Dashboard</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <span class="badge bg-danger">Admin Mode</span>
                </div>
            </div>
            
            <!-- Admin Stats -->
            <div class="row">
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                        Total Songs</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">120</div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-music fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-success shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                        Active Users</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">24</div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-users fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-info shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                        Audio Files</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">156</div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-file-audio fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-warning shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                        This Week Services</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">4</div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-calendar-alt fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Recent Activities Table -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Recent Activities</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Date/Time</th>
                                    <th>User</th>
                                    <th>Activity</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>2023-10-15 14:30</td>
                                    <td>John Doe</td>
                                    <td>Song Downloaded</td>
                                    <td>"Tunakutukuza" audio file</td>
                                </tr>
                                <tr>
                                    <td>2023-10-15 11:15</td>
                                    <td>Admin User</td>
                                    <td>Song Added</td>
                                    <td>Added "He's Worthy" to library</td>
                                </tr>
                                <tr>
                                    <td>2023-10-14 09:45</td>
                                    <td>Jane Smith</td>
                                    <td>Practice Track Accessed</td>
                                    <td>SDAH 495 practice track</td>
                                </tr>
                                <tr>
                                    <td>2023-10-14 16:20</td>
                                    <td>Admin User</td>
                                    <td>User Added</td>
                                    <td>Added new choir member</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php require_once '../includes/music-footer.php'; ?>