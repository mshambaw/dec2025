<?php
require_once '../includes/auth-check.php';

if ($_SESSION['music_role'] !== 'admin') {
    header('Location: ../portal.php');
    exit();
}

require_once '../includes/music-header.php';
require_once '../includes/music-nav.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include '../includes/admin-sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Reports & Analytics</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <button class="btn btn-sm btn-outline-secondary" onclick="exportReport('pdf')">
                            <i class="fas fa-file-pdf"></i> PDF
                        </button>
                        <button class="btn btn-sm btn-outline-secondary" onclick="exportReport('excel')">
                            <i class="fas fa-file-excel"></i> Excel
                        </button>
                        <button class="btn btn-sm btn-outline-secondary" onclick="printReport()">
                            <i class="fas fa-print"></i> Print
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Report Filters -->
            <div class="card mb-4">
                <div class="card-body">
                    <form id="reportFilters">
                        <div class="row g-3">
                            <div class="col-md-3">
                                <label for="reportType" class="form-label">Report Type</label>
                                <select class="form-control" id="reportType" onchange="loadReport()">
                                    <option value="usage">Usage Statistics</option>
                                    <option value="songs">Song Popularity</option>
                                    <option value="users">User Activity</option>
                                    <option value="downloads">Download Reports</option>
                                    <option value="attendance">Service Attendance</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label for="dateFrom" class="form-label">Date From</label>
                                <input type="date" class="form-control" id="dateFrom" value="<?php echo date('Y-m-d', strtotime('-30 days')); ?>">
                            </div>
                            <div class="col-md-3">
                                <label for="dateTo" class="form-label">Date To</label>
                                <input type="date" class="form-control" id="dateTo" value="<?php echo date('Y-m-d'); ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">&nbsp;</label>
                                <button type="button" class="btn btn-primary w-100" onclick="loadReport()">
                                    <i class="fas fa-chart-line"></i> Generate Report
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Report Content -->
            <div id="reportContent">
                <!-- Usage Statistics -->
                <div class="card" id="usageReport">
                    <div class="card-header">
                        <h5 class="mb-0">Usage Statistics (Last 30 Days)</h5>
                    </div>
                    <div class="card-body">
                        <div class="row mb-4">
                            <div class="col-md-3">
                                <div class="card border-left-primary shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                    Total Logins</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">1,245</div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-sign-in-alt fa-2x text-gray-300"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="card border-left-success shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                    Songs Played</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">3,567</div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-play fa-2x text-gray-300"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="card border-left-info shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                                    Downloads</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">892</div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-download fa-2x text-gray-300"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="card border-left-warning shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                    Active Users</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">24</div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-users fa-2x text-gray-300"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <h6>Daily Activity</h6>
                        <div class="chart-container">
                            <canvas id="usageChart"></canvas>
                        </div>
                    </div>
                </div>
                
                <!-- Song Popularity -->
                <div class="card d-none" id="songsReport">
                    <div class="card-header">
                        <h5 class="mb-0">Most Popular Songs</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Rank</th>
                                        <th>Song Title</th>
                                        <th>Plays</th>
                                        <th>Downloads</th>
                                        <th>Views</th>
                                        <th>Popularity</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $popularSongs = [
                                        ['title' => 'Tunakutukuza', 'plays' => 245, 'downloads' => 89, 'views' => 567],
                                        ['title' => 'Near to the Heart of God', 'plays' => 198, 'downloads' => 76, 'views' => 432],
                                        ['title' => 'He\'s Worthy', 'plays' => 176, 'downloads' => 65, 'views' => 389],
                                        ['title' => 'Rock of Ages', 'plays' => 154, 'downloads' => 54, 'views' => 321],
                                        ['title' => 'I Love To Tell The Story', 'plays' => 143, 'downloads' => 48, 'views' => 298],
                                    ];
                                    
                                    foreach ($popularSongs as $index => $song):
                                        $popularity = $song['plays'] + $song['downloads'] + ($song['views'] * 0.1);
                                    ?>
                                    <tr>
                                        <td>
                                            <span class="badge bg-<?php echo $index < 3 ? 'warning' : 'secondary'; ?>">
                                                #<?php echo $index + 1; ?>
                                            </span>
                                        </td>
                                        <td><?php echo $song['title']; ?></td>
                                        <td><?php echo $song['plays']; ?></td>
                                        <td><?php echo $song['downloads']; ?></td>
                                        <td><?php echo $song['views']; ?></td>
                                        <td>
                                            <div class="progress" style="height: 20px;">
                                                <div class="progress-bar bg-success" 
                                                     style="width: <?php echo min(100, ($popularity / 300) * 100); ?>%">
                                                    <?php echo round($popularity); ?> pts
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
function loadReport() {
    const reportType = document.getElementById('reportType').value;
    
    // Hide all reports
    document.querySelectorAll('#reportContent > .card').forEach(card => {
        card.classList.add('d-none');
    });
    
    // Show selected report
    document.getElementById(reportType + 'Report').classList.remove('d-none');
    
    // Load chart for usage report
    if (reportType === 'usage') {
        loadUsageChart();
    }
}

function loadUsageChart() {
    const ctx = document.getElementById('usageChart').getContext('2d');
    
    // Destroy existing chart if it exists
    if (window.usageChart) {
        window.usageChart.destroy();
    }
    
    window.usageChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Oct 1', 'Oct 5', 'Oct 10', 'Oct 15', 'Oct 20', 'Oct 25', 'Oct 30'],
            datasets: [{
                label: 'Logins',
                data: [45, 52, 48, 67, 58, 49, 62],
                borderColor: '#1a4a8f',
                backgroundColor: 'rgba(26, 74, 143, 0.1)',
                fill: true
            }, {
                label: 'Song Plays',
                data: [120, 145, 132, 167, 158, 142, 175],
                borderColor: '#28a745',
                backgroundColor: 'rgba(40, 167, 69, 0.1)',
                fill: true
            }, {
                label: 'Downloads',
                data: [35, 42, 38, 45, 41, 39, 48],
                borderColor: '#17a2b8',
                backgroundColor: 'rgba(23, 162, 184, 0.1)',
                fill: true
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

function exportReport(format) {
    const reportType = document.getElementById('reportType').value;
    const dateFrom = document.getElementById('dateFrom').value;
    const dateTo = document.getElementById('dateTo').value;
    
    window.location.href = `api/export-report.php?type=${reportType}&format=${format}&from=${dateFrom}&to=${dateTo}`;
}

function printReport() {
    window.print();
}

// Load initial report
document.addEventListener('DOMContentLoaded', function() {
    loadUsageChart();
});
</script>

<?php require_once '../includes/music-footer.php'; ?>