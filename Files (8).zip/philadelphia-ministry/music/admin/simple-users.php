<?php
require_once '../includes/auth-check.php';

if ($_SESSION['music_role'] !== 'admin') {
    header('Location: ../portal.php');
    exit();
}

require_once '../includes/music-header.php';
require_once '../includes/music-nav.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include '../includes/admin-sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Manage Users (Simple Version)</h1>
            </div>
            
            <!-- Manual User Management -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">User List</h5>
                </div>
                <div class="card-body">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Full Name</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td><strong>admin</strong> <span class="badge bg-danger">Admin</span></td>
                                <td>Music Administrator</td>
                                <td><span class="badge bg-danger">Admin</span></td>
                                <td><span class="badge bg-success">Active</span></td>
                                <td>
                                    <button class="btn btn-sm btn-warning" onclick="editUser(1)">Edit</button>
                                    <button class="btn btn-sm btn-info" onclick="resetPassword(1)">Reset PW</button>
                                </td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>user123</td>
                                <td>Test User</td>
                                <td><span class="badge bg-primary">User</span></td>
                                <td><span class="badge bg-success">Active</span></td>
                                <td>
                                    <button class="btn btn-sm btn-warning" onclick="editUser(2)">Edit</button>
                                    <button class="btn btn-sm btn-danger" onclick="deleteUser(2)">Delete</button>
                                </td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>john_doe</td>
                                <td>John Doe</td>
                                <td><span class="badge bg-primary">User</span></td>
                                <td><span class="badge bg-success">Active</span></td>
                                <td>
                                    <button class="btn btn-sm btn-warning" onclick="editUser(3)">Edit</button>
                                    <button class="btn btn-sm btn-info" onclick="resetPassword(3)">Reset PW</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    
                    <!-- Add User Form -->
                    <div class="mt-5">
                        <h5>Add New User</h5>
                        <form id="addUserForm" class="row g-3">
                            <div class="col-md-4">
                                <input type="text" class="form-control" placeholder="Username" required>
                            </div>
                            <div class="col-md-4">
                                <input type="text" class="form-control" placeholder="Full Name" required>
                            </div>
                            <div class="col-md-2">
                                <select class="form-control">
                                    <option value="user">User</option>
                                    <option value="admin">Admin</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-success w-100">Add User</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
function editUser(id) {
    alert('Edit user ID: ' + id);
}

function resetPassword(id) {
    if (confirm('Reset password for user ID ' + id + '?')) {
        alert('Password reset email sent!');
    }
}

function deleteUser(id) {
    if (confirm('Delete user ID ' + id + '?')) {
        alert('User deleted! (This is a demo)');
    }
}
</script>

<?php require_once '../includes/music-footer.php'; ?>