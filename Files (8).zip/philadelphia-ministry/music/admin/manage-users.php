<?php
require_once '../includes/auth-check.php';

if ($_SESSION['music_role'] !== 'admin') {
    header('Location: ../portal.php');
    exit();
}

// Fix for older PHP versions - use ternary instead of ??
$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

require_once '../includes/music-header.php';
require_once '../includes/music-nav.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include '../includes/admin-sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">
                    <?php 
                    if ($action === 'add') {
                        echo 'Add New User';
                    } elseif ($action === 'edit') {
                        echo 'Edit User';
                    } else {
                        echo 'Manage Users';
                    }
                    ?>
                </h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="?action=list" class="btn btn-sm btn-outline-secondary">
                        <i class="fas fa-list"></i> View All Users
                    </a>
                </div>
            </div>
            
            <?php if ($action === 'list'): ?>
            <!-- User List -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="usersTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Username</th>
                                    <th>Full Name</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Voice Part</th>
                                    <th>Status</th>
                                    <th>Last Login</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Direct database connection (bypass API)
                                try {
                                    require_once '../includes/db-music.php';
                                    
                                    $stmt = $pdo->query("SELECT id, username, full_name, email, role, voice_part, 
                                                        status, last_login FROM music_users ORDER BY full_name");
                                    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                    
                                    if ($users) {
                                        foreach ($users as $user):
                                ?>
                                <tr>
                                    <td><?php echo $user['id']; ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($user['username']); ?></strong>
                                        <?php if ($user['role'] === 'admin'): ?>
                                            <span class="badge bg-danger">Admin</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td>
                                        <?php
                                        $role_color = 'primary';
                                        if ($user['role'] === 'admin') {
                                            $role_color = 'danger';
                                        } elseif ($user['role'] === 'leader') {
                                            $role_color = 'warning';
                                        }
                                        ?>
                                        <span class="badge bg-<?php echo $role_color; ?>">
                                            <?php echo ucfirst($user['role']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($user['voice_part'] !== 'none'): ?>
                                        <span class="badge bg-info"><?php echo $user['voice_part']; ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                        $status_color = 'secondary';
                                        if ($user['status'] === 'active') {
                                            $status_color = 'success';
                                        }
                                        ?>
                                        <span class="badge bg-<?php echo $status_color; ?>">
                                            <?php echo ucfirst($user['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo $user['last_login'] ? date('Y-m-d H:i', strtotime($user['last_login'])) : 'Never'; ?></td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="?action=edit&id=<?php echo $user['id']; ?>" class="btn btn-outline-warning">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <button class="btn btn-outline-danger" onclick="deleteUser(<?php echo $user['id']; ?>)">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                            <button class="btn btn-outline-info" onclick="resetPassword(<?php echo $user['id']; ?>)">
                                                <i class="fas fa-key"></i>
                                            </button>
                                            <?php if ($user['status'] === 'active'): ?>
                                            <button class="btn btn-outline-secondary" onclick="deactivateUser(<?php echo $user['id']; ?>)">
                                                <i class="fas fa-user-slash"></i>
                                            </button>
                                            <?php else: ?>
                                            <button class="btn btn-outline-success" onclick="activateUser(<?php echo $user['id']; ?>)">
                                                <i class="fas fa-user-check"></i>
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php 
                                        endforeach;
                                    } else {
                                        echo '<tr><td colspan="9" class="text-center">No users found. <a href="?action=add">Add your first user</a></td></tr>';
                                    }
                                    
                                } catch (PDOException $e) {
                                    echo '<tr><td colspan="9" class="text-center text-danger">Database Error: ' . $e->getMessage() . '</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <?php elseif ($action === 'add' || $action === 'edit'): ?>
            <!-- Add/Edit User Form -->
            <div class="card">
                <div class="card-body">
                    <form id="userForm" method="POST" action="save-user.php">
                        <input type="hidden" name="action" value="<?php echo $action; ?>">
                        <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="username" class="form-label">Username *</label>
                                    <input type="text" class="form-control" id="username" name="username" required>
                                </div>
                                
                                <?php if ($action === 'add'): ?>
                                <div class="mb-3">
                                    <label for="password" class="form-label">Password *</label>
                                    <input type="password" class="form-control" id="password" name="password" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="confirm_password" class="form-label">Confirm Password *</label>
                                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                </div>
                                <?php endif; ?>
                                
                                <div class="mb-3">
                                    <label for="full_name" class="form-label">Full Name *</label>
                                    <input type="text" class="form-control" id="full_name" name="full_name" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email Address</label>
                                    <input type="email" class="form-control" id="email" name="email">
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="phone" class="form-label">Phone Number</label>
                                    <input type="tel" class="form-control" id="phone" name="phone">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="role" class="form-label">Role *</label>
                                    <select class="form-control" id="role" name="role" required>
                                        <option value="">Select Role</option>
                                        <option value="admin">Admin</option>
                                        <option value="leader">Leader</option>
                                        <option value="user">User</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="voice_part" class="form-label">Voice Part</label>
                                    <select class="form-control" id="voice_part" name="voice_part">
                                        <option value="none">None/Instrumental</option>
                                        <option value="soprano">Soprano</option>
                                        <option value="alto">Alto</option>
                                        <option value="tenor">Tenor</option>
                                        <option value="bass">Bass</option>
                                        <option value="instrumental">Instrumental</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="status" class="form-label">Status *</label>
                                    <select class="form-control" id="status" name="status" required>
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                        <option value="pending">Pending</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="join_date" class="form-label">Join Date</label>
                                    <input type="date" class="form-control" id="join_date" name="join_date" value="<?php echo date('Y-m-d'); ?>">
                                </div>
                            </div>
                        </div>
                        
                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> 
                                <?php 
                                if ($action === 'add') {
                                    echo 'Add User';
                                } else {
                                    echo 'Update User';
                                }
                                ?>
                            </button>
                            <a href="?action=list" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
            <?php endif; ?>
        </main>
    </div>
</div>

<script>
    function deleteUser(id) {
    // Prevent deleting user ID 1 (admin)
    if (id === 1) {
        alert('Cannot delete the main administrator account!');
        return;
    }
    
    if (confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
        fetch('save-user.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=delete&user_id=' + id
        })
        .then(response => response.text())
        .then(data => {
            alert(data);
            location.reload();
        })
        .catch(error => {
            alert('Error: ' + error);
        });
    }
}
function deleteUser(id) {
    if (confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
        fetch('save-user.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=delete&user_id=' + id
        })
        .then(response => response.text())
        .then(data => {
            alert(data);
            location.reload();
        })
        .catch(error => {
            alert('Error: ' + error);
        });
    }
}

function resetPassword(id) {
    if (confirm('Reset password for this user? A temporary password will be emailed.')) {
        fetch('save-user.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=reset_password&user_id=' + id
        })
        .then(response => response.text())
        .then(data => {
            alert(data);
        })
        .catch(error => {
            alert('Error: ' + error);
        });
    }
}

function deactivateUser(id) {
    if (confirm('Deactivate this user? They will no longer be able to access the music portal.')) {
        fetch('save-user.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=deactivate&user_id=' + id
        })
        .then(response => response.text())
        .then(data => {
            alert(data);
            location.reload();
        })
        .catch(error => {
            alert('Error: ' + error);
        });
    }
}

function activateUser(id) {
    if (confirm('Activate this user?')) {
        fetch('save-user.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=activate&user_id=' + id
        })
        .then(response => response.text())
        .then(data => {
            alert(data);
            location.reload();
        })
        .catch(error => {
            alert('Error: ' + error);
        });
    }
}

// Form validation
document.addEventListener('DOMContentLoaded', function() {
    var form = document.getElementById('userForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            var action = document.querySelector('input[name="action"]').value;
            
            if (action === 'add') {
                var password = document.getElementById('password').value;
                var confirmPassword = document.getElementById('confirm_password').value;
                
                if (password !== confirmPassword) {
                    e.preventDefault();
                    alert('Passwords do not match!');
                    return false;
                }
                
                if (password.length < 6) {
                    e.preventDefault();
                    alert('Password must be at least 6 characters long!');
                    return false;
                }
            }
            return true;
        });
    }
});
</script>

<?php require_once '../includes/music-footer.php'; ?>