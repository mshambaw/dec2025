<?php
require_once '../includes/auth-check.php';

if ($_SESSION['music_role'] !== 'admin') {
    header('Location: ../portal.php');
    exit();
}

$action = $_GET['action'] ?? 'list';
$song_id = $_GET['id'] ?? 0;

require_once '../includes/music-header.php';
require_once '../includes/music-nav.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include '../includes/admin-sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">
                    <?php 
                    echo $action === 'add' ? 'Add New Song' : 
                         ($action === 'edit' ? 'Edit Song' : 'Manage Songs');
                    ?>
                </h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="?action=list" class="btn btn-sm btn-outline-secondary">
                        <i class="fas fa-list"></i> View All Songs
                    </a>
                </div>
            </div>
            
            <?php if ($action === 'list'): ?>
            <!-- Song List for Admin -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="adminSongsTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Song #</th>
                                    <th>Title</th>
                                    <th>Language</th>
                                    <th>Category</th>
                                    <th>Status</th>
                                    <th>Views</th>
                                    <th>Downloads</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php for ($i = 1; $i <= 20; $i++): ?>
                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><?php echo $i; ?></td>
                                    <td>
                                        <strong>Song <?php echo $i; ?> Title</strong>
                                        <div class="small text-muted">Composer Name</div>
                                    </td>
                                    <td><?php echo $i % 3 == 0 ? 'Swahili' : 'English'; ?></td>
                                    <td>
                                        <span class="badge bg-secondary">
                                            <?php echo ['Hymn', 'Worship', 'Contemporary'][$i % 3]; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-success">Active</span>
                                    </td>
                                    <td><?php echo rand(50, 500); ?></td>
                                    <td><?php echo rand(10, 100); ?></td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <button class="btn btn-outline-primary" onclick="viewSong(<?php echo $i; ?>)">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <a href="?action=edit&id=<?php echo $i; ?>" class="btn btn-outline-warning">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <button class="btn btn-outline-danger" onclick="deleteSong(<?php echo $i; ?>)">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endfor; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <?php elseif (in_array($action, ['add', 'edit'])): ?>
            <!-- Add/Edit Song Form -->
            <div class="card">
                <div class="card-body">
                    <form id="songForm" method="POST" action="api/save-song.php" enctype="multipart/form-data">
                        <input type="hidden" name="action" value="<?php echo $action; ?>">
                        <input type="hidden" name="song_id" value="<?php echo $song_id; ?>">
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="song_number" class="form-label">Song Number</label>
                                    <input type="text" class="form-control" id="song_number" name="song_number" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="title" class="form-label">Song Title *</label>
                                    <input type="text" class="form-control" id="title" name="title" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="alternate_title" class="form-label">Alternate Title</label>
                                    <input type="text" class="form-control" id="alternate_title" name="alternate_title">
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="language" class="form-label">Language *</label>
                                            <select class="form-control" id="language" name="language" required>
                                                <option value="">Select Language</option>
                                                <option value="english">English</option>
                                                <option value="swahili">Swahili</option>
                                                <option value="kiswahili">Kiswahili</option>
                                                <option value="other">Other</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="category" class="form-label">Category *</label>
                                            <select class="form-control" id="category" name="category" required>
                                                <option value="">Select Category</option>
                                                <option value="hymn">Hymn</option>
                                                <option value="chorus">Chorus</option>
                                                <option value="worship">Worship</option>
                                                <option value="contemporary">Contemporary</option>
                                                <option value="traditional">Traditional</option>
                                                <option value="special">Special</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="composer" class="form-label">Composer</label>
                                            <input type="text" class="form-control" id="composer" name="composer">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="arranger" class="form-label">Arranger</label>
                                            <input type="text" class="form-control" id="arranger" name="arranger">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="key_signature" class="form-label">Key Signature</label>
                                            <select class="form-control" id="key_signature" name="key_signature">
                                                <option value="">Select Key</option>
                                                <option value="C">C Major</option>
                                                <option value="G">G Major</option>
                                                <option value="D">D Major</option>
                                                <option value="A">A Major</option>
                                                <option value="E">E Major</option>
                                                <option value="B">B Major</option>
                                                <option value="F">F Major</option>
                                                <option value="Bb">Bb Major</option>
                                                <option value="Eb">Eb Major</option>
                                                <option value="Ab">Ab Major</option>
                                                <option value="Db">Db Major</option>
                                                <option value="Gb">Gb Major</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="time_signature" class="form-label">Time Signature</label>
                                            <select class="form-control" id="time_signature" name="time_signature">
                                                <option value="">Select Time</option>
                                                <option value="4/4">4/4</option>
                                                <option value="3/4">3/4</option>
                                                <option value="6/8">6/8</option>
                                                <option value="2/4">2/4</option>
                                                <option value="12/8">12/8</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="tempo" class="form-label">Tempo</label>
                                    <input type="text" class="form-control" id="tempo" name="tempo" placeholder="e.g., Moderate, Fast, Slow">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="lyrics" class="form-label">Lyrics *</label>
                                    <textarea class="form-control" id="lyrics" name="lyrics" rows="6" required></textarea>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mt-3">
                            <div class="col-md-12">
                                <h5>File Uploads</h5>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label for="audio_file" class="form-label">Audio File (MP3)</label>
                                            <input type="file" class="form-control" id="audio_file" name="audio_file" accept="audio/*">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label for="pdf_file" class="form-label">Sheet Music (PDF)</label>
                                            <input type="file" class="form-control" id="pdf_file" name="pdf_file" accept=".pdf">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label for="chords_file" class="form-label">Chords (PDF/Image)</label>
                                            <input type="file" class="form-control" id="chords_file" name="chords_file" accept=".pdf,.jpg,.png">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> <?php echo $action === 'add' ? 'Add Song' : 'Update Song'; ?>
                            </button>
                            <a href="?action=list" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
            <?php endif; ?>
        </main>
    </div>
</div>

<script>
function deleteSong(id) {
    if (confirm('Are you sure you want to delete this song? This action cannot be undone.')) {
        fetch('api/delete-song.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                song_id: id
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Song deleted successfully!');
                location.reload();
            } else {
                alert('Error deleting song: ' + data.message);
            }
        });
    }
}

function viewSong(id) {
    window.open('../song-details.php?id=' + id, '_blank');
}

// Form submission
document.getElementById('songForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    fetch('api/save-song.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(data.message);
            window.location.href = '?action=list';
        } else {
            alert('Error: ' + data.message);
        }
    })
    .catch(error => {
        alert('Error: ' + error.message);
    });
});
</script>

<?php require_once '../includes/music-footer.php'; ?>