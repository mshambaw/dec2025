<?php
require_once '../includes/auth-check.php';
require_once '../includes/db-music.php';

if ($_SESSION['music_role'] !== 'admin') {
    die('Unauthorized access');
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$user_id = $_POST['user_id'] ?? $_GET['id'] ?? 0;

header('Content-Type: text/plain');

try {
    switch ($action) {
        case 'add':
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';
            $full_name = $_POST['full_name'] ?? '';
            $email = $_POST['email'] ?? '';
            $phone = $_POST['phone'] ?? '';
            $role = $_POST['role'] ?? 'user';
            $voice_part = $_POST['voice_part'] ?? 'none';
            $status = $_POST['status'] ?? 'active';
            $join_date = $_POST['join_date'] ?? date('Y-m-d');
            
            // Check if username exists
            $stmt = $pdo->prepare("SELECT id FROM music_users WHERE username = ?");
            $stmt->execute([$username]);
            if ($stmt->fetch()) {
                die('Username already exists');
            }
            
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            $stmt = $pdo->prepare("INSERT INTO music_users (username, password, full_name, email, phone, 
                                  role, voice_part, status, join_date) 
                                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$username, $hashed_password, $full_name, $email, $phone, 
                           $role, $voice_part, $status, $join_date]);
            
            echo 'User added successfully!';
            break;
            
        case 'edit':
            $username = $_POST['username'] ?? '';
            $full_name = $_POST['full_name'] ?? '';
            $email = $_POST['email'] ?? '';
            $phone = $_POST['phone'] ?? '';
            $role = $_POST['role'] ?? 'user';
            $voice_part = $_POST['voice_part'] ?? 'none';
            $status = $_POST['status'] ?? 'active';
            
            $stmt = $pdo->prepare("UPDATE music_users SET username = ?, full_name = ?, email = ?, 
                                  phone = ?, role = ?, voice_part = ?, status = ? WHERE id = ?");
            $stmt->execute([$username, $full_name, $email, $phone, $role, $voice_part, $status, $user_id]);
            
            echo 'User updated successfully!';
            break;
            
        case 'delete':
            $stmt = $pdo->prepare("DELETE FROM music_users WHERE id = ?");
            $stmt->execute([$user_id]);
            echo 'User deleted successfully!';
            break;
            
        case 'deactivate':
            $stmt = $pdo->prepare("UPDATE music_users SET status = 'inactive' WHERE id = ?");
            $stmt->execute([$user_id]);
            echo 'User deactivated!';
            break;
            
        case 'activate':
            $stmt = $pdo->prepare("UPDATE music_users SET status = 'active' WHERE id = ?");
            $stmt->execute([$user_id]);
            echo 'User activated!';
            break;
            
        case 'reset_password':
            $temp_password = 'Temp123';
            $hashed_password = password_hash($temp_password, PASSWORD_DEFAULT);
            
            $stmt = $pdo->prepare("UPDATE music_users SET password = ? WHERE id = ?");
            $stmt->execute([$hashed_password, $user_id]);
            
            echo "Password reset! Temporary password: $temp_password";
            break;
            
        default:
            echo 'Invalid action';
    }
    
} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
}
?>
<?php
require_once '../includes/auth-check.php';
require_once '../includes/db-music.php';

if ($_SESSION['music_role'] !== 'admin') {
    die('Unauthorized access');
}

$action = isset($_POST['action']) ? $_POST['action'] : (isset($_GET['action']) ? $_GET['action'] : '');
$user_id = isset($_POST['user_id']) ? (int)$_POST['user_id'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);

header('Content-Type: text/plain');

try {
    switch ($action) {
        case 'add':
            $username = isset($_POST['username']) ? $_POST['username'] : '';
            $password = isset($_POST['password']) ? $_POST['password'] : '';
            $full_name = isset($_POST['full_name']) ? $_POST['full_name'] : '';
            $email = isset($_POST['email']) ? $_POST['email'] : '';
            $phone = isset($_POST['phone']) ? $_POST['phone'] : '';
            $role = isset($_POST['role']) ? $_POST['role'] : 'user';
            $voice_part = isset($_POST['voice_part']) ? $_POST['voice_part'] : 'none';
            $status = isset($_POST['status']) ? $_POST['status'] : 'active';
            $join_date = isset($_POST['join_date']) ? $_POST['join_date'] : date('Y-m-d');
            
            // Check if username exists
            $stmt = $pdo->prepare("SELECT id FROM music_users WHERE username = ?");
            $stmt->execute([$username]);
            if ($stmt->fetch()) {
                die('Username already exists');
            }
            
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            $stmt = $pdo->prepare("INSERT INTO music_users (username, password, full_name, email, phone, 
                                  role, voice_part, status, join_date) 
                                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$username, $hashed_password, $full_name, $email, $phone, 
                           $role, $voice_part, $status, $join_date]);
            
            echo 'User added successfully!';
            break;
            
        case 'edit':
            $username = isset($_POST['username']) ? $_POST['username'] : '';
            $full_name = isset($_POST['full_name']) ? $_POST['full_name'] : '';
            $email = isset($_POST['email']) ? $_POST['email'] : '';
            $phone = isset($_POST['phone']) ? $_POST['phone'] : '';
            $role = isset($_POST['role']) ? $_POST['role'] : 'user';
            $voice_part = isset($_POST['voice_part']) ? $_POST['voice_part'] : 'none';
            $status = isset($_POST['status']) ? $_POST['status'] : 'active';
            
            $stmt = $pdo->prepare("UPDATE music_users SET username = ?, full_name = ?, email = ?, 
                                  phone = ?, role = ?, voice_part = ?, status = ? WHERE id = ?");
            $stmt->execute([$username, $full_name, $email, $phone, $role, $voice_part, $status, $user_id]);
            
            echo 'User updated successfully!';
            break;
            
        case 'delete':
            // First, update all references to set NULL
            $pdo->exec("UPDATE songs SET created_by = NULL WHERE created_by = $user_id");
            $pdo->exec("UPDATE service_schedule SET leader = NULL WHERE leader = $user_id");
            $pdo->exec("UPDATE service_schedule SET accompanist = NULL WHERE accompanist = $user_id");
            $pdo->exec("UPDATE music_resources SET uploaded_by = NULL WHERE uploaded_by = $user_id");
            $pdo->exec("UPDATE music_activity_log SET user_id = NULL WHERE user_id = $user_id");
            $pdo->exec("DELETE FROM choir_assignments WHERE user_id = $user_id");
            
            // Now delete the user
            $stmt = $pdo->prepare("DELETE FROM music_users WHERE id = ?");
            $stmt->execute([$user_id]);
            
            if ($stmt->rowCount() > 0) {
                echo 'User deleted successfully!';
            } else {
                echo 'User not found or could not be deleted.';
            }
            break;
            
        case 'deactivate':
            $stmt = $pdo->prepare("UPDATE music_users SET status = 'inactive' WHERE id = ?");
            $stmt->execute([$user_id]);
            echo 'User deactivated!';
            break;
            
        case 'activate':
            $stmt = $pdo->prepare("UPDATE music_users SET status = 'active' WHERE id = ?");
            $stmt->execute([$user_id]);
            echo 'User activated!';
            break;
            
        case 'reset_password':
            $temp_password = 'Temp123';
            $hashed_password = password_hash($temp_password, PASSWORD_DEFAULT);
            
            $stmt = $pdo->prepare("UPDATE music_users SET password = ? WHERE id = ?");
            $stmt->execute([$hashed_password, $user_id]);
            
            echo "Password reset! Temporary password: $temp_password";
            break;
            
        default:
            echo 'Invalid action';
    }
    
} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
}
?>