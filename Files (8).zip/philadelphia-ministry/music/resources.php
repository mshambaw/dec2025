<?php
require_once 'includes/auth-check.php';
require_once 'includes/music-header.php';
require_once 'includes/music-nav.php';

$category = $_GET['category'] ?? 'all';
$type = $_GET['type'] ?? 'all';
?>

<div class="container-fluid">
    <div class="row">
        <?php include 'includes/music-sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Music Resources</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <?php if ($_SESSION['music_role'] === 'admin'): ?>
                        <a href="upload.php" class="btn btn-sm btn-success">
                            <i class="fas fa-upload"></i> Upload Resource
                        </a>
                        <?php endif; ?>
                        <button class="btn btn-sm btn-outline-secondary" onclick="refreshResources()">
                            <i class="fas fa-sync-alt"></i> Refresh
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Resource Categories -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-file-pdf fa-3x text-danger mb-3"></i>
                            <h5>Sheet Music</h5>
                            <p class="text-muted">45 files</p>
                            <a href="?type=sheet_music" class="btn btn-sm btn-outline-danger">Browse</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-file-audio fa-3x text-primary mb-3"></i>
                            <h5>Audio Files</h5>
                            <p class="text-muted">120 files</p>
                            <a href="?type=audio" class="btn btn-sm btn-outline-primary">Browse</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-video fa-3x text-success mb-3"></i>
                            <h5>Video Tutorials</h5>
                            <p class="text-muted">23 files</p>
                            <a href="?type=video" class="btn btn-sm btn-outline-success">Browse</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-folder fa-3x text-warning mb-3"></i>
                            <h5>Documents</h5>
                            <p class="text-muted">18 files</p>
                            <a href="?type=document" class="btn btn-sm btn-outline-warning">Browse</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Resource List -->
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-8">
                            <h5 class="mb-0">All Resources</h5>
                        </div>
                        <div class="col-md-4">
                            <select class="form-control form-control-sm" onchange="filterByCategory(this.value)">
                                <option value="all">All Categories</option>
                                <option value="practice_tracks" <?php echo $category === 'practice_tracks' ? 'selected' : ''; ?>>Practice Tracks</option>
                                <option value="sheet_music" <?php echo $category === 'sheet_music' ? 'selected' : ''; ?>>Sheet Music</option>
                                <option value="tutorials" <?php echo $category === 'tutorials' ? 'selected' : ''; ?>>Tutorials</option>
                                <option value="recordings" <?php echo $category === 'recordings' ? 'selected' : ''; ?>>Service Recordings</option>
                                <option value="documents" <?php echo $category === 'documents' ? 'selected' : ''; ?>>Documents</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Resource Name</th>
                                    <th>Type</th>
                                    <th>Category</th>
                                    <th>Size</th>
                                    <th>Downloads</th>
                                    <th>Uploaded</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $resources = [
                                    [
                                        'name' => 'Tunakutukuza - Sheet Music',
                                        'type' => 'PDF',
                                        'category' => 'Sheet Music',
                                        'size' => '2.4 MB',
                                        'downloads' => 45,
                                        'uploaded' => '2023-10-10',
                                        'url' => '#'
                                    ],
                                    [
                                        'name' => 'Near to the Heart of God - Practice Track',
                                        'type' => 'MP3',
                                        'category' => 'Practice Tracks',
                                        'size' => '5.6 MB',
                                        'downloads' => 32,
                                        'uploaded' => '2023-10-12',
                                        'url' => '#'
                                    ],
                                    [
                                        'name' => 'Worship Team Guidelines',
                                        'type' => 'DOCX',
                                        'category' => 'Documents',
                                        'size' => '1.2 MB',
                                        'downloads' => 28,
                                        'uploaded' => '2023-10-05',
                                        'url' => '#'
                                    ],
                                    [
                                        'name' => 'He\'s Worthy - Vocal Harmony Tutorial',
                                        'type' => 'MP4',
                                        'category' => 'Tutorials',
                                        'size' => '45.2 MB',
                                        'downloads' => 18,
                                        'uploaded' => '2023-10-08',
                                        'url' => '#'
                                    ],
                                    [
                                        'name' => 'Sunday Service Recording - Oct 15',
                                        'type' => 'MP3',
                                        'category' => 'Recordings',
                                        'size' => '120.5 MB',
                                        'downloads' => 22,
                                        'uploaded' => '2023-10-16',
                                        'url' => '#'
                                    ],
                                    [
                                        'name' => 'Choir Roster 2023',
                                        'type' => 'XLSX',
                                        'category' => 'Documents',
                                        'size' => '0.8 MB',
                                        'downloads' => 15,
                                        'uploaded' => '2023-10-01',
                                        'url' => '#'
                                    ],
                                ];
                                
                                foreach ($resources as $resource):
                                    if ($category !== 'all' && strtolower(str_replace(' ', '_', $resource['category'])) !== $category) continue;
                                    if ($type !== 'all' && strtolower($resource['type']) !== $type) continue;
                                    
                                    $type_icons = [
                                        'PDF' => 'fa-file-pdf text-danger',
                                        'MP3' => 'fa-file-audio text-primary',
                                        'MP4' => 'fa-file-video text-success',
                                        'DOCX' => 'fa-file-word text-info',
                                        'XLSX' => 'fa-file-excel text-success'
                                    ];
                                ?>
                                <tr>
                                    <td>
                                        <i class="fas <?php echo $type_icons[$resource['type']]; ?> me-2"></i>
                                        <strong><?php echo $resource['name']; ?></strong>
                                    </td>
                                    <td>
                                        <span class="badge bg-secondary"><?php echo $resource['type']; ?></span>
                                    </td>
                                    <td>
                                        <span class="badge bg-info"><?php echo $resource['category']; ?></span>
                                    </td>
                                    <td><?php echo $resource['size']; ?></td>
                                    <td>
                                        <span class="badge bg-success"><?php echo $resource['downloads']; ?></span>
                                    </td>
                                    <td><?php echo $resource['uploaded']; ?></td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <button class="btn btn-outline-primary" onclick="previewResource('<?php echo $resource['name']; ?>')">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="btn btn-outline-success" onclick="downloadResource('<?php echo $resource['name']; ?>')">
                                                <i class="fas fa-download"></i>
                                            </button>
                                            <button class="btn btn-outline-info" onclick="shareResource('<?php echo $resource['name']; ?>')">
                                                <i class="fas fa-share"></i>
                                            </button>
                                            <?php if ($_SESSION['music_role'] === 'admin'): ?>
                                            <button class="btn btn-outline-danger" onclick="deleteResource('<?php echo $resource['name']; ?>')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Storage Statistics -->
                    <div class="mt-5">
                        <h5>Storage Usage</h5>
                        <div class="progress mb-3" style="height: 25px;">
                            <div class="progress-bar bg-success" role="progressbar" style="width: 45%;" 
                                 aria-valuenow="45" aria-valuemin="0" aria-valuemax="100">
                                45% Used (2.3 GB of 5 GB)
                            </div>
                        </div>
                        <div class="row text-center">
                            <div class="col-md-3">
                                <div class="border rounded p-2">
                                    <small class="text-muted">Audio Files</small>
                                    <div class="h6 mb-0">1.2 GB</div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="border rounded p-2">
                                    <small class="text-muted">Documents</small>
                                    <div class="h6 mb-0">350 MB</div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="border rounded p-2">
                                    <small class="text-muted">Videos</small>
                                    <div class="h6 mb-0">650 MB</div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="border rounded p-2">
                                    <small class="text-muted">Other</small>
                                    <div class="h6 mb-0">100 MB</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
function filterByCategory(category) {
    window.location.href = '?category=' + category;
}

function previewResource(name) {
    alert('Previewing: ' + name);
    // In real app, open preview modal or new tab
}

function downloadResource(name) {
    if (confirm('Download ' + name + '?')) {
        // Simulate download
        window.location.href = 'download.php?resource=' + encodeURIComponent(name);
    }
}

function shareResource(name) {
    const email = prompt('Enter email address to share with:');
    if (email) {
        // AJAX call to share resource
        fetch('api/share-resource.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                resource: name,
                email: email,
                shared_by: <?php echo $_SESSION['music_user_id']; ?>
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Resource shared successfully!');
            } else {
                alert('Error sharing resource: ' + data.message);
            }
        });
    }
}

function deleteResource(name) {
    if (confirm('Are you sure you want to delete ' + name + '?')) {
        // AJAX call to delete resource
        fetch('api/delete-resource.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                resource: name
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Resource deleted successfully!');
                location.reload();
            } else {
                alert('Error deleting resource: ' + data.message);
            }
        });
    }
}

function refreshResources() {
    location.reload();
}
</script>

<?php require_once 'includes/music-footer.php'; ?>