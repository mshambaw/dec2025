<?php
session_start();
require_once '../includes/db_connect.php';
require_once 'includes/auth-check.php';

// Redirect if already logged in
if (isset($_SESSION['music_user_id'])) {
    header('Location: portal.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    // Query music department users
    $stmt = $pdo->prepare("SELECT * FROM music_users WHERE username = ? AND status = 'active'");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['music_user_id'] = $user['id'];
        $_SESSION['music_username'] = $user['username'];
        $_SESSION['music_role'] = $user['role'];
        $_SESSION['music_fullname'] = $user['full_name'];
        
        // Redirect based on role
        if ($user['role'] === 'admin') {
            header('Location: admin/index.php');
        } else {
            header('Location: portal.php');
        }
        exit();
    } else {
        $error = "Invalid username or password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Music Portal Login - Philadelphia Ministry</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="assets/css/music.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="music-login-page">
    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-center bg-primary text-white">
                        <h3><i class="fas fa-music"></i> Music Portal Login</h3>
                        <p class="mb-0">Philadelphia Ministry Music Department</p>
                    </div>
                    <div class="card-body">
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <form method="POST" action="">
                            <div class="form-group">
                                <label for="username">Username</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                                    </div>
                                    <input type="text" class="form-control" id="username" name="username" required>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="password">Password</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                    </div>
                                    <input type="password" class="form-control" id="password" name="password" required>
                                </div>
                            </div>
                            
                            <div class="form-group form-check">
                                <input type="checkbox" class="form-check-input" id="remember" name="remember">
                                <label class="form-check-label" for="remember">Remember me</label>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-sign-in-alt"></i> Login to Music Portal
                            </button>
                        </form>
                        
                        <hr>
                        
                        <div class="text-center">
                            <p>Need access? Contact the music department coordinator.</p>
                            <a href="../index.php" class="btn btn-outline-secondary btn-sm">
                                <i class="fas fa-home"></i> Back to Main Site
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="text-center mt-3">
                    <small class="text-muted">
                        "Let the word of Christ dwell in you richly... singing with grace in your hearts to the Lord." - Colossians 3:16
                    </small>
                </div>
            </div>
        </div>
    </div>
</body>
</html>