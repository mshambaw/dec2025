<?php
require_once '../includes/header.php';
require_once '../includes/navigation.php';
?>

<div class="container">
    <div class="music-department-header">
        <h1><i class="fas fa-music"></i> Music Department</h1>
        <p class="lead">"Singing and making melody in your heart to the Lord" - Ephesians 5:19</p>
    </div>
    
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <h3>Welcome to Music Ministry</h3>
                    <p>The Philadelphia Ministry Music Department is dedicated to leading worship 
                    and glorifying God through music. Our choir and worship teams serve during 
                    regular services and special events.</p>
                    
                    <h4>Our Mission</h4>
                    <ul>
                        <li>Lead the congregation in worship through music</li>
                        <li>Train and develop musical talents for God's service</li>
                        <li>Maintain a collection of worship songs and hymns</li>
                        <li>Prepare special music for services and events</li>
                    </ul>
                    
                    <a href="login.php" class="btn btn-primary">Access Music Portal</a>
                    <a href="songs.php" class="btn btn-outline-primary">Browse Songs</a>
                </div>
            </div>
            
            <div class="row mt-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5><i class="fas fa-users"></i> Choir Information</h5>
                            <p>Join our choir! Practice every Friday at 6 PM.</p>
                            <a href="choir.php" class="btn btn-sm btn-outline-primary">View Choir</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5><i class="fas fa-calendar-alt"></i> Service Schedule</h5>
                            <p>View upcoming worship service schedules.</p>
                            <a href="schedule.php" class="btn btn-sm btn-outline-primary">View Schedule</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5>Quick Links</h5>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <a href="songs.php"><i class="fas fa-music"></i> Song Library</a>
                        </li>
                        <li class="list-group-item">
                            <a href="resources.php"><i class="fas fa-file-audio"></i> Music Resources</a>
                        </li>
                        <li class="list-group-item">
                            <a href="choir.php"><i class="fas fa-user-friends"></i> Choir Directory</a>
                        </li>
                        <li class="list-group-item">
                            <a href="../pages/ministry.php"><i class="fas fa-church"></i> Other Ministries</a>
                        </li>
                        <li class="list-group-item">
                            <a href="../events/"><i class="fas fa-calendar-check"></i> Upcoming Events</a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="card mt-4">
                <div class="card-body">
                    <h5>Featured Song</h5>
                    <h6>Tunakutukuza</h6>
                    <p class="text-muted">Swahili worship song praising God as Creator</p>
                    <audio controls style="width: 100%;">
                        <source src="assets/audio/songs/tunakutukuza.mp3" type="audio/mpeg">
                        Your browser does not support the audio element.
                    </audio>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>