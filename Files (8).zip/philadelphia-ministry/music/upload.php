<?php
require_once 'includes/auth-check.php';

if ($_SESSION['music_role'] !== 'admin') {
    header('Location: portal.php');
    exit();
}

require_once 'includes/music-header.php';
require_once 'includes/music-nav.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include 'includes/music-sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Upload Resources</h1>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Upload New File</h5>
                        </div>
                        <div class="card-body">
                            <form id="uploadForm" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label for="fileType" class="form-label">File Type</label>
                                    <select class="form-control" id="fileType" required>
                                        <option value="">Select Type</option>
                                        <option value="audio">Audio File (MP3, WAV)</option>
                                        <option value="sheet_music">Sheet Music (PDF)</option>
                                        <option value="video">Video Tutorial (MP4)</option>
                                        <option value="document">Document (DOC, PDF)</option>
                                        <option value="other">Other</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="category" class="form-label">Category</label>
                                    <select class="form-control" id="category" required>
                                        <option value="">Select Category</option>
                                        <option value="practice_tracks">Practice Tracks</option>
                                        <option value="service_recordings">Service Recordings</option>
                                        <option value="tutorials">Tutorials</option>
                                        <option value="documents">Documents</option>
                                        <option value="other">Other</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="title" class="form-label">Title *</label>
                                    <input type="text" class="form-control" id="title" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="description" class="form-label">Description</label>
                                    <textarea class="form-control" id="description" rows="3"></textarea>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="fileUpload" class="form-label">Select File *</label>
                                    <input type="file" class="form-control" id="fileUpload" required>
                                    <small class="text-muted">Maximum file size: 50MB</small>
                                </div>
                                
                                <div class="progress mb-3 d-none" id="uploadProgress">
                                    <div class="progress-bar" role="progressbar" style="width: 0%"></div>
                                </div>
                                
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-upload"></i> Upload File
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Upload Guidelines</h5>
                        </div>
                        <div class="card-body">
                            <h6>Accepted File Types:</h6>
                            <ul>
                                <li><strong>Audio:</strong> MP3, WAV, M4A (max 20MB)</li>
                                <li><strong>Documents:</strong> PDF, DOC, DOCX (max 10MB)</li>
                                <li><strong>Images:</strong> JPG, PNG, GIF (max 5MB)</li>
                                <li><strong>Video:</strong> MP4, MOV (max 50MB)</li>
                            </ul>
                            
                            <h6 class="mt-4">Naming Convention:</h6>
                            <p>Please name files descriptively:</p>
                            <code>SongName_Type_Date.ext</code>
                            <p>Example: <code>Tunakutukuza_PracticeTrack_20231015.mp3</code></p>
                            
                            <h6 class="mt-4">Storage Limits:</h6>
                            <div class="progress mb-2">
                                <div class="progress-bar bg-success" style="width: 45%">2.3 GB / 5 GB</div>
                            </div>
                            <small>45% of storage used</small>
                        </div>
                    </div>
                    
                    <div class="card mt-4">
                        <div class="card-body">
                            <h6>Quick Uploads</h6>
                            <div class="btn-group-vertical w-100">
                                <button class="btn btn-outline-primary text-start" onclick="quickUpload('practice_track')">
                                    <i class="fas fa-headphones"></i> Practice Track
                                </button>
                                <button class="btn btn-outline-success text-start mt-2" onclick="quickUpload('sheet_music')">
                                    <i class="fas fa-file-pdf"></i> Sheet Music
                                </button>
                                <button class="btn btn-outline-info text-start mt-2" onclick="quickUpload('service_recording')">
                                    <i class="fas fa-record-vinyl"></i> Service Recording
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
document.getElementById('uploadForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const fileInput = document.getElementById('fileUpload');
    const file = fileInput.files[0];
    
    if (!file) {
        alert('Please select a file to upload');
        return;
    }
    
    if (file.size > 50 * 1024 * 1024) { // 50MB limit
        alert('File size exceeds 50MB limit');
        return;
    }
    
    const formData = new FormData();
    formData.append('file', file);
    formData.append('title', document.getElementById('title').value);
    formData.append('description', document.getElementById('description').value);
    formData.append('type', document.getElementById('fileType').value);
    formData.append('category', document.getElementById('category').value);
    formData.append('user_id', <?php echo $_SESSION['music_user_id']; ?>);
    
    const progressBar = document.getElementById('uploadProgress');
    progressBar.classList.remove('d-none');
    
    const xhr = new XMLHttpRequest();
    
    xhr.upload.addEventListener('progress', function(e) {
        if (e.lengthComputable) {
            const percent = (e.loaded / e.total) * 100;
            progressBar.querySelector('.progress-bar').style.width = percent + '%';
        }
    });
    
    xhr.addEventListener('load', function() {
        const response = JSON.parse(xhr.responseText);
        
        if (response.success) {
            alert('File uploaded successfully!');
            progressBar.classList.add('d-none');
            document.getElementById('uploadForm').reset();
        } else {
            alert('Error: ' + response.message);
        }
    });
    
    xhr.open('POST', 'api/upload.php');
    xhr.send(formData);
});

function quickUpload(type) {
    const typeMap = {
        'practice_track': { fileType: 'audio', category: 'practice_tracks' },
        'sheet_music': { fileType: 'sheet_music', category: 'sheet_music' },
        'service_recording': { fileType: 'audio', category: 'service_recordings' }
    };
    
    const mapping = typeMap[type];
    if (mapping) {
        document.getElementById('fileType').value = mapping.fileType;
        document.getElementById('category').value = mapping.category;
        document.getElementById('title').focus();
    }
}
</script>

<?php require_once 'includes/music-footer.php'; ?>