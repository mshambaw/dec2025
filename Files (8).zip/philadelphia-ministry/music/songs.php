<?php
require_once 'includes/auth-check.php';
require_once 'includes/music-header.php';
require_once 'includes/music-nav.php';

$category = $_GET['category'] ?? 'all';
$search = $_GET['search'] ?? '';
$language = $_GET['language'] ?? '';
?>

<div class="container-fluid">
    <div class="row">
        <?php include 'includes/music-sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Song Library</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <?php if ($_SESSION['music_role'] === 'admin'): ?>
                        <a href="admin/manage-songs.php?action=add" class="btn btn-sm btn-success">
                            <i class="fas fa-plus-circle"></i> Add New Song
                        </a>
                        <?php endif; ?>
                        <button class="btn btn-sm btn-outline-secondary" onclick="printSongList()">
                            <i class="fas fa-print"></i> Print
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Search and Filter -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" action="" class="row g-3">
                        <div class="col-md-4">
                            <input type="text" class="form-control" name="search" placeholder="Search songs..." value="<?php echo htmlspecialchars($search); ?>">
                        </div>
                        <div class="col-md-3">
                            <select class="form-control" name="category">
                                <option value="all">All Categories</option>
                                <option value="hymn" <?php echo $category === 'hymn' ? 'selected' : ''; ?>>Hymns</option>
                                <option value="worship" <?php echo $category === 'worship' ? 'selected' : ''; ?>>Worship</option>
                                <option value="contemporary" <?php echo $category === 'contemporary' ? 'selected' : ''; ?>>Contemporary</option>
                                <option value="swahili" <?php echo $category === 'swahili' ? 'selected' : ''; ?>>Swahili</option>
                                <option value="chorus" <?php echo $category === 'chorus' ? 'selected' : ''; ?>>Choruses</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select class="form-control" name="language">
                                <option value="">All Languages</option>
                                <option value="english" <?php echo $language === 'english' ? 'selected' : ''; ?>>English</option>
                                <option value="swahili" <?php echo $language === 'swahili' ? 'selected' : ''; ?>>Swahili</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-search"></i> Filter
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Songs Table -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="songsTable">
                            <thead>
                                <tr>
                                    <th>Song #</th>
                                    <th>Title</th>
                                    <th>Language</th>
                                    <th>Category</th>
                                    <th>Key</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Sample data - in real app, fetch from database
                                $songs = [
                                    ['number' => '1', 'title' => 'Tunakutukuza', 'language' => 'Swahili', 'category' => 'Worship', 'key' => 'G Major', 'id' => 1],
                                    ['number' => 'SDAH 495', 'title' => 'Near to the Heart of God', 'language' => 'English', 'category' => 'Hymn', 'key' => 'Db Major', 'id' => 2],
                                    ['number' => '3', 'title' => 'Conquering Now And Still To Conquer', 'language' => 'English', 'category' => 'Hymn', 'key' => 'C Major', 'id' => 3],
                                    ['number' => 'NZK 62', 'title' => 'Napenda Kitabu Chake', 'language' => 'Swahili', 'category' => 'Worship', 'key' => 'F Major', 'id' => 4],
                                    ['number' => '5', 'title' => 'Heri', 'language' => 'Swahili', 'category' => 'Worship', 'key' => 'G Major', 'id' => 5],
                                    ['number' => 'NZK 32', 'title' => 'Tangu Kuamini', 'language' => 'Swahili', 'category' => 'Worship', 'key' => 'A Major', 'id' => 6],
                                    ['number' => 'SDAH 300', 'title' => 'Rock Of Ages Cleft For Me', 'language' => 'English', 'category' => 'Hymn', 'key' => 'C Major', 'id' => 7],
                                    ['number' => 'SDAH 77', 'title' => 'I Love To Tell The Story', 'language' => 'English', 'category' => 'Hymn', 'key' => 'G Major', 'id' => 8],
                                    ['number' => 'NZK 22', 'title' => 'Usinipite', 'language' => 'Swahili', 'category' => 'Worship', 'key' => 'D Major', 'id' => 9],
                                    ['number' => '136', 'title' => 'I Remember Calvary', 'language' => 'English', 'category' => 'Hymn', 'key' => 'F Major', 'id' => 10],
                                    ['number' => '241', 'title' => 'Beulah Land', 'language' => 'English', 'category' => 'Hymn', 'key' => 'G Major', 'id' => 11],
                                    ['number' => '14', 'title' => "He's Worthy", 'language' => 'English', 'category' => 'Contemporary', 'key' => 'A Major', 'id' => 12],
                                    ['number' => 'SDAH 244', 'title' => 'Come To Jesus', 'language' => 'English', 'category' => 'Invitation', 'key' => 'C Major', 'id' => 13],
                                    ['number' => '16', 'title' => 'Kwaheri', 'language' => 'Swahili', 'category' => 'Farewell', 'key' => 'G Major', 'id' => 14],
                                    ['number' => '17', 'title' => 'Coming King', 'language' => 'English', 'category' => 'Anticipatory', 'key' => 'D Major', 'id' => 15],
                                    ['number' => '18', 'title' => 'Kando Ya Mto Babeli', 'language' => 'Swahili', 'category' => 'Worship', 'key' => 'E Major', 'id' => 16],
                                    ['number' => '19', 'title' => 'Wakati Ukung\'u Umekwisha Juu Millmani', 'language' => 'Swahili', 'category' => 'Worship', 'key' => 'F Major', 'id' => 17],
                                    ['number' => '20', 'title' => 'When He Comes in Glory By and By', 'language' => 'English', 'category' => 'Anticipatory', 'key' => 'G Major', 'id' => 18],
                                ];
                                
                                foreach ($songs as $song):
                                    // Apply filters
                                    if ($category !== 'all' && strtolower($song['category']) !== $category) continue;
                                    if ($search && stripos($song['title'], $search) === false && stripos($song['number'], $search) === false) continue;
                                    if ($language && strtolower($song['language']) !== $language) continue;
                                ?>
                                <tr>
                                    <td><?php echo $song['number']; ?></td>
                                    <td>
                                        <strong><?php echo $song['title']; ?></strong>
                                        <?php if ($song['language'] === 'Swahili'): ?>
                                            <span class="badge bg-info">SW</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo $song['language']; ?></td>
                                    <td><span class="badge bg-secondary"><?php echo $song['category']; ?></span></td>
                                    <td><code><?php echo $song['key']; ?></code></td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <button class="btn btn-outline-primary" onclick="viewSong(<?php echo $song['id']; ?>)">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="btn btn-outline-success" onclick="playSong('<?php echo $song['title']; ?>')">
                                                <i class="fas fa-play"></i>
                                            </button>
                                            <button class="btn btn-outline-info" onclick="downloadSong(<?php echo $song['id']; ?>, 'pdf')">
                                                <i class="fas fa-file-pdf"></i>
                                            </button>
                                            <?php if ($_SESSION['music_role'] === 'admin'): ?>
                                            <button class="btn btn-outline-warning" onclick="editSong(<?php echo $song['id']; ?>)">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Song Player Modal -->
                    <div class="modal fade" id="songPlayerModal" tabindex="-1">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="songTitle"></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="card">
                                                <div class="card-body">
                                                    <h6>Audio Player</h6>
                                                    <audio id="audioPlayer" controls style="width: 100%;">
                                                        <source src="" type="audio/mpeg">
                                                        Your browser does not support the audio element.
                                                    </audio>
                                                    <div class="mt-3">
                                                        <button class="btn btn-sm btn-outline-primary" onclick="playPracticeTrack()">
                                                            <i class="fas fa-headphones"></i> Practice Track
                                                        </button>
                                                        <button class="btn btn-sm btn-outline-secondary" onclick="downloadAudio()">
                                                            <i class="fas fa-download"></i> Download
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="card">
                                                <div class="card-body">
                                                    <h6>Song Details</h6>
                                                    <p><strong>Key:</strong> <span id="songKey"></span></p>
                                                    <p><strong>Tempo:</strong> <span id="songTempo"></span></p>
                                                    <p><strong>Time Signature:</strong> <span id="songTime"></span></p>
                                                    <p><strong>Category:</strong> <span id="songCategory"></span></p>
                                                    <div class="mt-3">
                                                        <button class="btn btn-sm btn-info" onclick="viewLyrics()">
                                                            <i class="fas fa-file-alt"></i> View Lyrics
                                                        </button>
                                                        <button class="btn btn-sm btn-warning" onclick="viewChords()">
                                                            <i class="fas fa-guitar"></i> View Chords
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
function viewSong(id) {
    // In real app, fetch song details via AJAX
    alert('Viewing song details for ID: ' + id);
    // You would implement AJAX call here
}

function playSong(title) {
    document.getElementById('songTitle').textContent = title;
    document.getElementById('songKey').textContent = 'G Major';
    document.getElementById('songTempo').textContent = 'Moderate';
    document.getElementById('songTime').textContent = '4/4';
    document.getElementById('songCategory').textContent = 'Worship';
    
    var modal = new bootstrap.Modal(document.getElementById('songPlayerModal'));
    modal.show();
}

function downloadSong(id, type) {
    if (type === 'pdf') {
        window.location.href = 'download.php?type=pdf&id=' + id;
    } else {
        window.location.href = 'download.php?type=audio&id=' + id;
    }
}

function editSong(id) {
    window.location.href = 'admin/manage-songs.php?action=edit&id=' + id;
}

function printSongList() {
    window.print();
}

// Additional JavaScript functions
function playPracticeTrack() {
    alert('Playing practice track...');
}

function downloadAudio() {
    alert('Downloading audio file...');
}

function viewLyrics() {
    window.open('song-lyrics.php', '_blank');
}

function viewChords() {
    window.open('song-chords.php', '_blank');
}
</script>

<?php require_once 'includes/music-footer.php'; ?>