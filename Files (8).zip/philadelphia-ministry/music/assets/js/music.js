// Music Portal JavaScript

// Initialize tooltips
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Set current date in date fields
    const today = new Date().toISOString().split('T')[0];
    document.querySelectorAll('input[type="date"]:not([value])').forEach(input => {
        input.value = today;
    });
});

// Global audio player
let currentAudio = null;

function playAudio(url, title) {
    if (currentAudio) {
        currentAudio.pause();
    }
    
    currentAudio = new Audio(url);
    currentAudio.play();
    
    // Update global player
    showGlobalPlayer(title, url);
    
    // Track play event
    trackActivity('audio_play', title);
}

function showGlobalPlayer(title, url) {
    const player = document.getElementById('globalPlayer');
    const titleSpan = document.getElementById('nowPlaying');
    
    if (player && titleSpan) {
        titleSpan.textContent = 'Now Playing: ' + title;
        player.src = url;
        document.querySelector('.song-player').classList.remove('d-none');
    }
}

function hideGlobalPlayer() {
    if (currentAudio) {
        currentAudio.pause();
    }
    document.querySelector('.song-player').classList.add('d-none');
}

// Download tracking
function trackDownload(resourceId, resourceType) {
    fetch('api/track-download.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            resource_id: resourceId,
            resource_type: resourceType,
            user_id: window.currentUserId || 0
        })
    });
}

// Activity tracking
function trackActivity(activityType, description) {
    fetch('api/track-activity.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            activity_type: activityType,
            description: description,
            user_id: window.currentUserId || 0
        })
    });
}

// Search functionality
function searchSongs(query) {
    if (query.length < 2) return;
    
    fetch(`api/search.php?q=${encodeURIComponent(query)}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                displaySearchResults(data.results);
            }
        });
}

// File upload handling
function uploadFile(file, type) {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('type', type);
    formData.append('user_id', window.currentUserId);
    
    return fetch('api/upload.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json());
}

// Print functionality
function printSong(songId) {
    window.open(`print-song.php?id=${songId}`, '_blank');
}

// Export functionality
function exportToCSV(data, filename) {
    const csvContent = "data:text/csv;charset=utf-8," 
        + data.map(row => Object.values(row).join(",")).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Theme switching (light/dark mode)
function toggleTheme() {
    const body = document.body;
    const currentTheme = body.getAttribute('data-theme') || 'light';
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    
    body.setAttribute('data-theme', newTheme);
    localStorage.setItem('music-theme', newTheme);
    
    // Update theme icon
    const themeIcon = document.getElementById('themeIcon');
    if (themeIcon) {
        themeIcon.className = newTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }
}

// Load saved theme
function loadTheme() {
    const savedTheme = localStorage.getItem('music-theme') || 'light';
    document.body.setAttribute('data-theme', savedTheme);
    
    const themeIcon = document.getElementById('themeIcon');
    if (themeIcon) {
        themeIcon.className = savedTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }
}

// Initialize when page loads
window.addEventListener('load', function() {
    loadTheme();
    
    // Set current user ID from session
    window.currentUserId = document.body.getAttribute('data-user-id') || 0;
    
    // Auto-logout after 60 minutes of inactivity
    let inactivityTimer;
    function resetInactivityTimer() {
        clearTimeout(inactivityTimer);
        inactivityTimer = setTimeout(() => {
            if (confirm('Your session will expire due to inactivity. Click OK to stay logged in.')) {
                resetInactivityTimer();
            } else {
                window.location.href = 'logout.php';
            }
        }, 60 * 60 * 1000); // 60 minutes
    }
    
    // Reset timer on user activity
    ['mousemove', 'keypress', 'click', 'scroll'].forEach(event => {
        document.addEventListener(event, resetInactivityTimer);
    });
    
    resetInactivityTimer();
});

// Error handling
window.addEventListener('error', function(event) {
    console.error('Error:', event.error);
    // You could send this to your error tracking service
});

// Offline detection
window.addEventListener('online', function() {
    document.getElementById('connectionStatus')?.classList.remove('bg-danger');
    document.getElementById('connectionStatus')?.classList.add('bg-success');
    document.getElementById('connectionStatus')?.textContent = 'Online';
});

window.addEventListener('offline', function() {
    document.getElementById('connectionStatus')?.classList.remove('bg-success');
    document.getElementById('connectionStatus')?.classList.add('bg-danger');
    document.getElementById('connectionStatus')?.textContent = 'Offline';
});