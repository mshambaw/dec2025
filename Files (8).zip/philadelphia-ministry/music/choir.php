<?php
require_once 'includes/auth-check.php';
require_once 'includes/music-header.php';
require_once 'includes/music-nav.php';

$voice_part = $_GET['voice'] ?? 'all';
$search = $_GET['search'] ?? '';
?>

<div class="container-fluid">
    <div class="row">
        <?php include 'includes/music-sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Choir Directory</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <?php if ($_SESSION['music_role'] === 'admin'): ?>
                        <a href="admin/manage-users.php?action=add" class="btn btn-sm btn-success">
                            <i class="fas fa-user-plus"></i> Add Member
                        </a>
                        <?php endif; ?>
                        <button class="btn btn-sm btn-outline-secondary" onclick="exportDirectory()">
                            <i class="fas fa-file-export"></i> Export
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Filter and Search -->
            <div class="card mb-4">
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <input type="text" class="form-control" id="searchInput" placeholder="Search by name..." 
                                   value="<?php echo htmlspecialchars($search); ?>">
                        </div>
                        <div class="col-md-3">
                            <select class="form-control" id="voiceFilter">
                                <option value="all">All Voice Parts</option>
                                <option value="soprano" <?php echo $voice_part === 'soprano' ? 'selected' : ''; ?>>Soprano</option>
                                <option value="alto" <?php echo $voice_part === 'alto' ? 'selected' : ''; ?>>Alto</option>
                                <option value="tenor" <?php echo $voice_part === 'tenor' ? 'selected' : ''; ?>>Tenor</option>
                                <option value="bass" <?php echo $voice_part === 'bass' ? 'selected' : ''; ?>>Bass</option>
                                <option value="instrumental" <?php echo $voice_part === 'instrumental' ? 'selected' : ''; ?>>Instrumental</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <button class="btn btn-primary w-100" onclick="filterMembers()">
                                <i class="fas fa-filter"></i> Apply Filters
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Choir Members Grid -->
            <div class="row" id="membersGrid">
                <?php
                // Sample choir members data
                $members = [
                    ['id' => 1, 'name' => 'John Doe', 'voice' => 'Tenor', 'email' => 'john@example.com', 'phone' => '555-0101', 'role' => 'Choir Member', 'joined' => '2022-01-15', 'photo' => ''],
                    ['id' => 2, 'name' => 'Jane Smith', 'voice' => 'Soprano', 'email' => 'jane@example.com', 'phone' => '555-0102', 'role' => 'Choir Leader', 'joined' => '2021-03-20', 'photo' => ''],
                    ['id' => 3, 'name' => 'Peter Johnson', 'voice' => 'Bass', 'email' => 'peter@example.com', 'phone' => '555-0103', 'role' => 'Section Leader', 'joined' => '2020-08-10', 'photo' => ''],
                    ['id' => 4, 'name' => 'Mary Wilson', 'voice' => 'Alto', 'email' => 'mary@example.com', 'phone' => '555-0104', 'role' => 'Choir Member', 'joined' => '2023-02-28', 'photo' => ''],
                    ['id' => 5, 'name' => 'David Brown', 'voice' => 'Instrumental', 'email' => 'david@example.com', 'phone' => '555-0105', 'role' => 'Pianist', 'joined' => '2019-11-05', 'photo' => ''],
                    ['id' => 6, 'name' => 'Sarah Miller', 'voice' => 'Soprano', 'email' => 'sarah@example.com', 'phone' => '555-0106', 'role' => 'Soloist', 'joined' => '2022-09-15', 'photo' => ''],
                    ['id' => 7, 'name' => 'Michael Davis', 'voice' => 'Tenor', 'email' => 'michael@example.com', 'phone' => '555-0107', 'role' => 'Choir Member', 'joined' => '2023-05-20', 'photo' => ''],
                    ['id' => 8, 'name' => 'Lisa Anderson', 'voice' => 'Alto', 'email' => 'lisa@example.com', 'phone' => '555-0108', 'role' => 'Choir Member', 'joined' => '2021-12-01', 'photo' => ''],
                ];
                
                foreach ($members as $member):
                    if ($voice_part !== 'all' && $member['voice'] !== ucfirst($voice_part)) continue;
                    if ($search && stripos($member['name'], $search) === false) continue;
                    
                    $voice_colors = [
                        'Soprano' => 'danger',
                        'Alto' => 'warning',
                        'Tenor' => 'primary',
                        'Bass' => 'success',
                        'Instrumental' => 'info'
                    ];
                ?>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-3">
                                <div class="flex-shrink-0">
                                    <div class="avatar-placeholder bg-secondary text-white rounded-circle d-flex align-items-center justify-content-center" 
                                         style="width: 60px; height: 60px;">
                                        <?php echo substr($member['name'], 0, 1); ?>
                                    </div>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h5 class="mb-0"><?php echo $member['name']; ?></h5>
                                    <p class="text-muted mb-0"><?php echo $member['role']; ?></p>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <span class="badge bg-<?php echo $voice_colors[$member['voice']]; ?>">
                                    <?php echo $member['voice']; ?>
                                </span>
                                <?php if ($member['role'] !== 'Choir Member'): ?>
                                <span class="badge bg-dark"><?php echo $member['role']; ?></span>
                                <?php endif; ?>
                            </div>
                            
                            <ul class="list-unstyled mb-0">
                                <li class="mb-2">
                                    <i class="fas fa-envelope me-2 text-primary"></i>
                                    <a href="mailto:<?php echo $member['email']; ?>"><?php echo $member['email']; ?></a>
                                </li>
                                <li class="mb-2">
                                    <i class="fas fa-phone me-2 text-success"></i>
                                    <?php echo $member['phone']; ?>
                                </li>
                                <li>
                                    <i class="fas fa-calendar-alt me-2 text-info"></i>
                                    Joined: <?php echo date('M Y', strtotime($member['joined'])); ?>
                                </li>
                            </ul>
                        </div>
                        <div class="card-footer bg-transparent">
                            <div class="btn-group w-100">
                                <button class="btn btn-sm btn-outline-primary" onclick="viewMember(<?php echo $member['id']; ?>)">
                                    <i class="fas fa-eye"></i> View
                                </button>
                                <button class="btn btn-sm btn-outline-success" onclick="sendMessage(<?php echo $member['id']; ?>)">
                                    <i class="fas fa-comment"></i> Message
                                </button>
                                <?php if ($_SESSION['music_role'] === 'admin'): ?>
                                <button class="btn btn-sm btn-outline-warning" onclick="editMember(<?php echo $member['id']; ?>)">
                                    <i class="fas fa-edit"></i> Edit
                                </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Voice Part Statistics -->
            <div class="card mt-4">
                <div class="card-header">
                    <h5 class="mb-0">Voice Part Distribution</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php
                        $voice_stats = [
                            'Soprano' => 8,
                            'Alto' => 6,
                            'Tenor' => 5,
                            'Bass' => 4,
                            'Instrumental' => 3
                        ];
                        
                        foreach ($voice_stats as $voice => $count):
                        ?>
                        <div class="col-md-2 col-4 text-center mb-3">
                            <div class="p-3 border rounded">
                                <div class="h3 mb-0"><?php echo $count; ?></div>
                                <div class="small text-muted"><?php echo $voice; ?></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
function filterMembers() {
    const search = document.getElementById('searchInput').value;
    const voice = document.getElementById('voiceFilter').value;
    window.location.href = `?search=${encodeURIComponent(search)}&voice=${voice}`;
}

function viewMember(id) {
    window.open('member-profile.php?id=' + id, '_blank');
}

function sendMessage(id) {
    const message = prompt('Enter your message:');
    if (message) {
        // AJAX call to send message
        fetch('api/send-message.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                to_member: id,
                message: message,
                from_member: <?php echo $_SESSION['music_user_id']; ?>
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Message sent successfully!');
            } else {
                alert('Error sending message: ' + data.message);
            }
        });
    }
}

function editMember(id) {
    window.location.href = 'admin/manage-users.php?action=edit&id=' + id;
}

function exportDirectory() {
    if (confirm('Export choir directory to CSV?')) {
        window.location.href = 'export-directory.php';
    }
}

// Live search
document.getElementById('searchInput').addEventListener('keyup', function(e) {
    if (e.key === 'Enter') {
        filterMembers();
    }
});
</script>

<?php require_once 'includes/music-footer.php'; ?>