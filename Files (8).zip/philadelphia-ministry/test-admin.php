<?php
session_start();
// Force admin login for testing
$_SESSION['music_user_id'] = 1;
$_SESSION['music_username'] = 'admin';
$_SESSION['music_role'] = 'admin';
$_SESSION['music_fullname'] = 'Music Admin';

echo "Admin session set. <a href='admin/'>Go to Admin Panel</a>";
?>