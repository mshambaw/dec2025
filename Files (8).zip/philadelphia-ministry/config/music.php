<?php
// Music Department Configuration

// Database Configuration
define('MUSIC_DB_HOST', 'localhost');
define('MUSIC_DB_NAME', 'philadelphia_music');
define('MUSIC_DB_USER', 'root');
define('MUSIC_DB_PASS', '');

// File Upload Configuration
define('MAX_UPLOAD_SIZE', 50 * 1024 * 1024); // 50MB
define('ALLOWED_AUDIO_TYPES', ['audio/mpeg', 'audio/wav', 'audio/x-wav', 'audio/mp4']);
define('ALLOWED_DOC_TYPES', ['application/pdf', 'application/msword', 
                           'application/vnd.openxmlformats-officedocument.wordprocessingml.document']);
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif']);
define('ALLOWED_VIDEO_TYPES', ['video/mp4', 'video/quicktime']);

// Path Configuration
define('MUSIC_UPLOAD_PATH', $_SERVER['DOCUMENT_ROOT'] . '/philadelphia-ministry/music/assets/audio/');
define('MUSIC_UPLOAD_URL', '/philadelphia-ministry/music/assets/audio/');

// Session Configuration
define('SESSION_TIMEOUT', 60 * 60); // 1 hour in seconds

// Email Configuration
define('MUSIC_ADMIN_EMAIL', 'music@philadelphiaministry.org');
define('MUSIC_SENDER_EMAIL', 'noreply@philadelphiaministry.org');
define('MUSIC_SENDER_NAME', 'Philadelphia Ministry Music Department');

// Security Configuration
define('PASSWORD_MIN_LENGTH', 8);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_TIME', 15 * 60); // 15 minutes

// Feature Flags
define('ENABLE_SONG_UPLOADS', true);
define('ENABLE_USER_REGISTRATION', false); // Only admins can add users
define('ENABLE_AUDIO_STREAMING', true);
define('ENABLE_PRINTING', true);

// API Configuration
define('API_RATE_LIMIT', 100); // Requests per hour
define('API_KEY', 'music_' . md5('philadelphia_ministry_2023'));

// Display Configuration
define('ITEMS_PER_PAGE', 20);
define('DEFAULT_THEME', 'light'); // light or dark

// Notification Settings
define('SEND_WELCOME_EMAIL', true);
define('SEND_PASSWORD_RESET_EMAIL', true);
define('NOTIFY_NEW_UPLOADS', true);

// Backup Configuration
define('BACKUP_ENABLED', true);
define('BACKUP_PATH', $_SERVER['DOCUMENT_ROOT'] . '/philadelphia-ministry/backup/music/');
define('BACKUP_RETENTION_DAYS', 30);

// Logging Configuration
define('ENABLE_LOGGING', true);
define('LOG_PATH', $_SERVER['DOCUMENT_ROOT'] . '/philadelphia-ministry/logs/music.log');

// Audio Player Configuration
define('DEFAULT_VOLUME', 80);
define('AUTO_PLAY_NEXT', false);
define('SHOW_LYRICS', true);

// Choir Settings
define('CHOIR_PRACTICE_DAY', 'Friday');
define('CHOIR_PRACTICE_TIME', '18:00');
define('CHOIR_PRACTICE_DURATION', '2 hours');

// Service Settings
define('DEFAULT_SERVICE_TIME', '10:00');
define('SERVICE_DURATION', '90 minutes');
define('SONGS_PER_SERVICE', 4);
?>