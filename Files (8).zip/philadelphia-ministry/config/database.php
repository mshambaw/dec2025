<?php
// config/database.php - FIXED VERSION

class Database {
    private $host = "localhost";
    private $db_name = "philadelphia_ministry";
    private $username = "root";
    private $password = "";
    private $conn;
    
    // PUBLIC constructor - this fixes the error
    public function __construct() {
        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name,
                $this->username,
                $this->password
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->exec("set names utf8");
        } catch(PDOException $exception) {
            die("Connection error: " . $exception->getMessage());
        }
    }
    
    public function getConnection() {
        return $this->conn;
    }
}

// Alternative simple connection function
function getDB() {
    static $db = null;
    if ($db === null) {
        $db = new Database();
    }
    return $db->getConnection();
}
?>